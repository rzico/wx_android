// { "framework": "Vue"} 

// { "framework": "Vue"} 

/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 897);
/******/ })
/************************************************************************/
/******/ ({

/***/ 897:
/***/ (function(module, exports, __webpack_require__) {

var __vue_exports__, __vue_options__
var __vue_styles__ = []

/* styles */
__vue_styles__.push(__webpack_require__(898)
)

/* script */
__vue_exports__ = __webpack_require__(899)

/* template */
var __vue_template__ = __webpack_require__(900)
__vue_options__ = __vue_exports__ = __vue_exports__ || {}
if (
  typeof __vue_exports__.default === "object" ||
  typeof __vue_exports__.default === "function"
) {
if (Object.keys(__vue_exports__).some(function (key) { return key !== "default" && key !== "__esModule" })) {console.error("named exports are not supported in *.vue files.")}
__vue_options__ = __vue_exports__ = __vue_exports__.default
}
if (typeof __vue_options__ === "function") {
  __vue_options__ = __vue_options__.options
}
__vue_options__.__file = "D:\\farmer\\src\\widget\\TabCard\\T3.vue"
__vue_options__.render = __vue_template__.render
__vue_options__.staticRenderFns = __vue_template__.staticRenderFns
__vue_options__._scopeId = "data-v-8e2be310"
__vue_options__.style = __vue_options__.style || {}
__vue_styles__.forEach(function (module) {
  for (var name in module) {
    __vue_options__.style[name] = module[name]
  }
})
if (typeof __register_static_styles__ === "function") {
  __register_static_styles__(__vue_options__._scopeId, __vue_styles__)
}

module.exports = __vue_exports__
module.exports.el = 'true'
new Vue(module.exports)


/***/ }),

/***/ 898:
/***/ (function(module, exports) {

module.exports = {
  "scroller-tab-card": {
    "width": "750",
    "height": "140",
    "flexDirection": "row",
    "alignItems": "stretch",
    "backgroundColor": "#cc0000"
  },
  "tab-card-box": {
    "marginTop": "40",
    "paddingLeft": "10",
    "paddingRight": "10",
    "justifyContent": "center",
    "alignItems": "center",
    "borderBottomWidth": "3",
    "borderBottomStyle": "solid"
  },
  "tab-card-text": {
    "fontSize": "28",
    "color": "#ffffff",
    "lines": 1,
    "textOverflow": "ellipsis"
  }
}

/***/ }),

/***/ 899:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
var wxDom = weex.requireModule('dom');
var modal = weex.requireModule('modal');
exports.default = {
  data: function data() {
    var self = this;
    return {
      activeTabIndex: self.activeTabIndexP,
      tabList: self.tabListP,
      wrapBackgroundColor: self.wrapBackgroundColorP,
      activeColor: self.activeColorP,
      textDefaultColor: self.textDefaultColorP,
      spacing: self.spacingP,
      wrapHeight: self.wrapHeightP,
      isTextBold: self.isTextBoldP
    };
  },

  props: {
    wrapHeightP: { // wrap高度
      default: 88
    },
    tabListP: { // tab(card)项列表
      default: [{
        id: null,
        name: '默认页签'
      }]
    },
    activeTabIndexP: { // tab激活项索引
      default: 0
    },
    wrapBackgroundColorP: { // wrap背景色
      default: '#fff'
    },
    activeColorP: { // 激活色
      default: '#fff'
    },
    textDefaultColorP: { // 文本默认颜色
      default: '#fff'
    },
    spacingP: { // margin左右边距
      type: Number,
      default: 10
    },
    isTextBoldP: { // 文字是否加粗
      type: Boolean,
      default: true
    }
  },
  watch: {
    /**
     * 监听tabListP的变化
     * @param  {[type]} newValue [description]
     * @param  {[type]} oldValue [description]
     * @return {[type]}          [description]
     */
    tabListP: function tabListP(newValue, oldValue) {
      var self = this;
      self.tabList = newValue;
    },

    /**
     * 监听activeTabIndexP的变化
     * @param  {[type]} newValue [description]
     * @param  {[type]} oldValue [description]
     * @return {[type]}          [description]
     */
    activeTabIndexP: function activeTabIndexP(newValue, oldValue) {
      var self = this;
      // 监听到prop:activeTabIndexP主动改变
      var tabIndexValid = newValue;
      self.activeTabIndex = tabIndexValid;
      // modal.toast({
      //   message: `TabCard listen prop change and force set current active index: ${tabIndexValid}`,
      //   duration: 3
      // })
      var targetTabIndexToScroll = tabIndexValid > 2 ? tabIndexValid - 2 : 0; // 目标滚动项索引
      wxDom.scrollToElement(self.$refs.refTabCardBox[targetTabIndexToScroll]);
    }
  },
  methods: {
    /**
     * tab项点击句柄
     * @param  {[type]} e     [description]
     * @param  {[type]} tabId    [description]
     * @param  {[type]} curTabIndex [description]
     * @return {[type]}       [description]
     */
    hdlTabCardClick: function hdlTabCardClick(e, tabId, curTabIndex) {
      var self = this;
      self.activeTabIndex = curTabIndex;
      var targetTabIndexToScroll = curTabIndex > 2 ? curTabIndex - 2 : 0; // 目标滚动项索引
      wxDom.scrollToElement(self.$refs.refTabCardBox[targetTabIndexToScroll]);
      self.$emit('tab:index:change:com:tab:card', curTabIndex); // 发射事件
    },

    /**
     * tab card box style helper
     * @param  {[type]} tabItemIndex [description]
     * @return {[type]}              [description]
     */
    hlpTabCardBoxStyle: function hlpTabCardBoxStyle(tabItemIndex) {
      var self = this;
      var styleObj = {
        'margin-left': self.spacing + 'px',
        'margin-right': self.spacing + 'px'
      };
      if (tabItemIndex === self.activeTabIndex) {
        styleObj['border-bottom-color'] = self.activeColor; // tab box 底边框色
      } else {
        styleObj['border-bottom-color'] = 'transparent'; // tab box 底边框色
      }
      if (tabItemIndex === 0) {
        styleObj['margin-left'] = self.spacing + 10 + 'px';
      }
      if (tabItemIndex === self.tabList.length - 1) {
        styleObj['margin-right'] = self.spacing + 10 + 'px';
      }
      return styleObj;
    },

    /**
     * tab card text style helper
     * @param  {[type]} tabItemIndex [description]
     * @return {[type]}              [description]
     */
    hlpTabCardTextStyle: function hlpTabCardTextStyle(tabItemIndex) {
      var self = this;
      var styleObj = {};
      if (tabItemIndex === self.activeTabIndex) {
        styleObj.color = self.activeColor; // tab box text文字颜色
      } else {
        styleObj.color = self.textDefaultColor; // tab box text文字颜色
      }
      if (self.isTextBold) {
        styleObj['font-weight'] = 'bold';
      } else {
        styleObj['font-weight'] = 'normal';
      }
      return styleObj;
    }
  }
};

/***/ }),

/***/ 900:
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('scroller', {
    staticClass: ["scroller-tab-card"],
    attrs: {
      "scrollDirection": "horizontal",
      "showScrollbar": "false"
    }
  }, [(_vm.tabList && _vm.tabList.length) ? [_vm._l((_vm.tabList), function(tabItem, tabItemIndex) {
    return [_c('div', {
      key: tabItem.id,
      ref: "refTabCardBox",
      refInFor: true,
      staticClass: ["tab-card-box"],
      style: _vm.hlpTabCardBoxStyle(tabItemIndex),
      on: {
        "click": function($event) {
          _vm.hdlTabCardClick($event, tabItem.id, tabItemIndex)
        }
      }
    }, [_c('text', {
      staticClass: ["tab-card-text"],
      style: _vm.hlpTabCardTextStyle(tabItemIndex)
    }, [_vm._v(_vm._s(tabItem.name))])])]
  })] : _vm._e()], 2)
},staticRenderFns: []}
module.exports.render._withStripped = true

/***/ })

/******/ });