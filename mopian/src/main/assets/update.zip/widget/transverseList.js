// { "framework": "Vue"} 

// { "framework": "Vue"} 

/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 901);
/******/ })
/************************************************************************/
/******/ ({

/***/ 901:
/***/ (function(module, exports, __webpack_require__) {

var __vue_exports__, __vue_options__
var __vue_styles__ = []

/* styles */
__vue_styles__.push(__webpack_require__(902)
)
__vue_styles__.push(__webpack_require__(903)
)

/* script */
__vue_exports__ = __webpack_require__(904)

/* template */
var __vue_template__ = __webpack_require__(905)
__vue_options__ = __vue_exports__ = __vue_exports__ || {}
if (
  typeof __vue_exports__.default === "object" ||
  typeof __vue_exports__.default === "function"
) {
if (Object.keys(__vue_exports__).some(function (key) { return key !== "default" && key !== "__esModule" })) {console.error("named exports are not supported in *.vue files.")}
__vue_options__ = __vue_exports__ = __vue_exports__.default
}
if (typeof __vue_options__ === "function") {
  __vue_options__ = __vue_options__.options
}
__vue_options__.__file = "D:\\farmer\\src\\widget\\transverseList.vue"
__vue_options__.render = __vue_template__.render
__vue_options__.staticRenderFns = __vue_template__.staticRenderFns
__vue_options__._scopeId = "data-v-d1e54966"
__vue_options__.style = __vue_options__.style || {}
__vue_styles__.forEach(function (module) {
  for (var name in module) {
    __vue_options__.style[name] = module[name]
  }
})
if (typeof __register_static_styles__ === "function") {
  __register_static_styles__(__vue_options__._scopeId, __vue_styles__)
}

module.exports = __vue_exports__
module.exports.el = 'true'
new Vue(module.exports)


/***/ }),

/***/ 902:
/***/ (function(module, exports) {

module.exports = {
  "ft6": {
    "fontSize": "6"
  },
  "ft7": {
    "fontSize": "7"
  },
  "ft8": {
    "fontSize": "8"
  },
  "ft9": {
    "fontSize": "9"
  },
  "ft10": {
    "fontSize": "10"
  },
  "ft11": {
    "fontSize": "11"
  },
  "ft12": {
    "fontSize": "12"
  },
  "ft13": {
    "fontSize": "13"
  },
  "ft14": {
    "fontSize": "14"
  },
  "ft15": {
    "fontSize": "15"
  },
  "ft16": {
    "fontSize": "16"
  },
  "ft17": {
    "fontSize": "17"
  },
  "ft18": {
    "fontSize": "18"
  },
  "ft19": {
    "fontSize": "19"
  },
  "ft20": {
    "fontSize": "20"
  },
  "ft21": {
    "fontSize": "21"
  },
  "ft22": {
    "fontSize": "22"
  },
  "ft23": {
    "fontSize": "23"
  },
  "ft24": {
    "fontSize": "24"
  },
  "ft25": {
    "fontSize": "25"
  },
  "ft26": {
    "fontSize": "26"
  },
  "ft27": {
    "fontSize": "27"
  },
  "ft28": {
    "fontSize": "28"
  },
  "ft29": {
    "fontSize": "29"
  },
  "ft30": {
    "fontSize": "30"
  },
  "ft31": {
    "fontSize": "31"
  },
  "ft32": {
    "fontSize": "32"
  },
  "ft33": {
    "fontSize": "33"
  },
  "ft34": {
    "fontSize": "34"
  },
  "ft35": {
    "fontSize": "35"
  },
  "ft36": {
    "fontSize": "36"
  },
  "ft37": {
    "fontSize": "37"
  },
  "ft38": {
    "fontSize": "38"
  },
  "ft39": {
    "fontSize": "39"
  },
  "ft40": {
    "fontSize": "40"
  },
  "ft41": {
    "fontSize": "41"
  },
  "ft42": {
    "fontSize": "42"
  },
  "ft43": {
    "fontSize": "43"
  },
  "ft44": {
    "fontSize": "44"
  },
  "ft45": {
    "fontSize": "45"
  },
  "ft46": {
    "fontSize": "46"
  },
  "ft47": {
    "fontSize": "47"
  },
  "ft48": {
    "fontSize": "48"
  },
  "ft49": {
    "fontSize": "49"
  },
  "ft50": {
    "fontSize": "50"
  },
  "ft51": {
    "fontSize": "51"
  },
  "ft52": {
    "fontSize": "52"
  },
  "ft53": {
    "fontSize": "53"
  },
  "ft54": {
    "fontSize": "54"
  },
  "ft55": {
    "fontSize": "55"
  },
  "ft56": {
    "fontSize": "56"
  },
  "ft57": {
    "fontSize": "57"
  },
  "ft58": {
    "fontSize": "58"
  },
  "ft59": {
    "fontSize": "59"
  },
  "ft60": {
    "fontSize": "60"
  },
  "ft61": {
    "fontSize": "61"
  },
  "ft62": {
    "fontSize": "62"
  },
  "ft63": {
    "fontSize": "63"
  },
  "ft64": {
    "fontSize": "64"
  },
  "ft65": {
    "fontSize": "65"
  },
  "ft66": {
    "fontSize": "66"
  },
  "ft67": {
    "fontSize": "67"
  },
  "ft68": {
    "fontSize": "68"
  },
  "ft69": {
    "fontSize": "69"
  },
  "ft70": {
    "fontSize": "70"
  },
  "ft71": {
    "fontSize": "71"
  },
  "ft72": {
    "fontSize": "72"
  },
  "ft73": {
    "fontSize": "73"
  },
  "ft74": {
    "fontSize": "74"
  },
  "ft75": {
    "fontSize": "75"
  },
  "ft76": {
    "fontSize": "76"
  },
  "ft77": {
    "fontSize": "77"
  },
  "ft78": {
    "fontSize": "78"
  },
  "ft79": {
    "fontSize": "79"
  },
  "ft80": {
    "fontSize": "80"
  },
  "ft81": {
    "fontSize": "81"
  },
  "ft82": {
    "fontSize": "82"
  },
  "ft83": {
    "fontSize": "83"
  },
  "ft84": {
    "fontSize": "84"
  },
  "ft85": {
    "fontSize": "85"
  },
  "ft86": {
    "fontSize": "86"
  },
  "ft87": {
    "fontSize": "87"
  },
  "ft88": {
    "fontSize": "88"
  },
  "ft89": {
    "fontSize": "89"
  },
  "ft90": {
    "fontSize": "90"
  },
  "ft91": {
    "fontSize": "91"
  },
  "ft92": {
    "fontSize": "92"
  },
  "ft93": {
    "fontSize": "93"
  },
  "ft94": {
    "fontSize": "94"
  },
  "ft95": {
    "fontSize": "95"
  },
  "ft96": {
    "fontSize": "96"
  },
  "ft97": {
    "fontSize": "97"
  },
  "ft98": {
    "fontSize": "98"
  },
  "ft99": {
    "fontSize": "99"
  },
  "ft100": {
    "fontSize": "100"
  },
  "mgt2": {
    "marginTop": "2"
  },
  "mgb2": {
    "marginBottom": "2"
  },
  "mgl2": {
    "marginLeft": "2"
  },
  "mgr2": {
    "marginRight": "2"
  },
  "pdt2": {
    "paddingTop": "2"
  },
  "pdb2": {
    "paddingBottom": "2"
  },
  "pdl2": {
    "paddingLeft": "2"
  },
  "pdr2": {
    "paddingRight": "2"
  },
  "mgt4": {
    "marginTop": "4"
  },
  "mgb4": {
    "marginBottom": "4"
  },
  "mgl4": {
    "marginLeft": "4"
  },
  "mgr4": {
    "marginRight": "4"
  },
  "pdt4": {
    "paddingTop": "4"
  },
  "pdb4": {
    "paddingBottom": "4"
  },
  "pdl4": {
    "paddingLeft": "4"
  },
  "pdr4": {
    "paddingRight": "4"
  },
  "mgt5": {
    "marginTop": "5"
  },
  "mgb5": {
    "marginBottom": "5"
  },
  "mgl5": {
    "marginLeft": "5"
  },
  "mgr5": {
    "marginRight": "5"
  },
  "pdt5": {
    "paddingTop": "5"
  },
  "pdb5": {
    "paddingBottom": "5"
  },
  "pdl5": {
    "paddingLeft": "5"
  },
  "pdr5": {
    "paddingRight": "5"
  },
  "mgt6": {
    "marginTop": "6"
  },
  "mgb6": {
    "marginBottom": "6"
  },
  "mgl6": {
    "marginLeft": "6"
  },
  "mgr6": {
    "marginRight": "6"
  },
  "pdt6": {
    "paddingTop": "6"
  },
  "pdb6": {
    "paddingBottom": "6"
  },
  "pdl6": {
    "paddingLeft": "6"
  },
  "pdr6": {
    "paddingRight": "6"
  },
  "mgt8": {
    "marginTop": "8"
  },
  "mgb8": {
    "marginBottom": "8"
  },
  "mgl8": {
    "marginLeft": "8"
  },
  "mgr8": {
    "marginRight": "8"
  },
  "pdt8": {
    "paddingTop": "8"
  },
  "pdb8": {
    "paddingBottom": "8"
  },
  "pdl8": {
    "paddingLeft": "8"
  },
  "pdr8": {
    "paddingRight": "8"
  },
  "mgt10": {
    "marginTop": "10"
  },
  "mgb10": {
    "marginBottom": "10"
  },
  "mgl10": {
    "marginLeft": "10"
  },
  "mgr10": {
    "marginRight": "10"
  },
  "pdt10": {
    "paddingTop": "10"
  },
  "pdb10": {
    "paddingBottom": "10"
  },
  "pdl10": {
    "paddingLeft": "10"
  },
  "pdr10": {
    "paddingRight": "10"
  },
  "mgt12": {
    "marginTop": "12"
  },
  "mgb12": {
    "marginBottom": "12"
  },
  "mgl12": {
    "marginLeft": "12"
  },
  "mgr12": {
    "marginRight": "12"
  },
  "pdt12": {
    "paddingTop": "12"
  },
  "pdb12": {
    "paddingBottom": "12"
  },
  "pdl12": {
    "paddingLeft": "12"
  },
  "pdr12": {
    "paddingRight": "12"
  },
  "mgt14": {
    "marginTop": "14"
  },
  "mgb14": {
    "marginBottom": "14"
  },
  "mgl14": {
    "marginLeft": "14"
  },
  "mgr14": {
    "marginRight": "14"
  },
  "pdt14": {
    "paddingTop": "14"
  },
  "pdb14": {
    "paddingBottom": "14"
  },
  "pdl14": {
    "paddingLeft": "14"
  },
  "pdr14": {
    "paddingRight": "14"
  },
  "mgt15": {
    "marginTop": "15"
  },
  "mgb15": {
    "marginBottom": "15"
  },
  "mgl15": {
    "marginLeft": "15"
  },
  "mgr15": {
    "marginRight": "15"
  },
  "pdt15": {
    "paddingTop": "15"
  },
  "pdb15": {
    "paddingBottom": "15"
  },
  "pdl15": {
    "paddingLeft": "15"
  },
  "pdr15": {
    "paddingRight": "15"
  },
  "mgt16": {
    "marginTop": "16"
  },
  "mgb16": {
    "marginBottom": "16"
  },
  "mgl16": {
    "marginLeft": "16"
  },
  "mgr16": {
    "marginRight": "16"
  },
  "pdt16": {
    "paddingTop": "16"
  },
  "pdb16": {
    "paddingBottom": "16"
  },
  "pdl16": {
    "paddingLeft": "16"
  },
  "pdr16": {
    "paddingRight": "16"
  },
  "mgt18": {
    "marginTop": "18"
  },
  "mgb18": {
    "marginBottom": "18"
  },
  "mgl18": {
    "marginLeft": "18"
  },
  "mgr18": {
    "marginRight": "18"
  },
  "pdt18": {
    "paddingTop": "18"
  },
  "pdb18": {
    "paddingBottom": "18"
  },
  "pdl18": {
    "paddingLeft": "18"
  },
  "pdr18": {
    "paddingRight": "18"
  },
  "mgt20": {
    "marginTop": "20"
  },
  "mgb20": {
    "marginBottom": "20"
  },
  "mgl20": {
    "marginLeft": "20"
  },
  "mgr20": {
    "marginRight": "20"
  },
  "pdt20": {
    "paddingTop": "20"
  },
  "pdb20": {
    "paddingBottom": "20"
  },
  "pdl20": {
    "paddingLeft": "20"
  },
  "pdr20": {
    "paddingRight": "20"
  },
  "mgt22": {
    "marginTop": "22"
  },
  "mgb22": {
    "marginBottom": "22"
  },
  "mgl22": {
    "marginLeft": "22"
  },
  "mgr22": {
    "marginRight": "22"
  },
  "pdt22": {
    "paddingTop": "22"
  },
  "pdb22": {
    "paddingBottom": "22"
  },
  "pdl22": {
    "paddingLeft": "22"
  },
  "pdr22": {
    "paddingRight": "22"
  },
  "mgt24": {
    "marginTop": "24"
  },
  "mgb24": {
    "marginBottom": "24"
  },
  "mgl24": {
    "marginLeft": "24"
  },
  "mgr24": {
    "marginRight": "24"
  },
  "pdt24": {
    "paddingTop": "24"
  },
  "pdb24": {
    "paddingBottom": "24"
  },
  "pdl24": {
    "paddingLeft": "24"
  },
  "pdr24": {
    "paddingRight": "24"
  },
  "mgt25": {
    "marginTop": "25"
  },
  "mgb25": {
    "marginBottom": "25"
  },
  "mgl25": {
    "marginLeft": "25"
  },
  "mgr25": {
    "marginRight": "25"
  },
  "pdt25": {
    "paddingTop": "25"
  },
  "pdb25": {
    "paddingBottom": "25"
  },
  "pdl25": {
    "paddingLeft": "25"
  },
  "pdr25": {
    "paddingRight": "25"
  },
  "mgt26": {
    "marginTop": "26"
  },
  "mgb26": {
    "marginBottom": "26"
  },
  "mgl26": {
    "marginLeft": "26"
  },
  "mgr26": {
    "marginRight": "26"
  },
  "pdt26": {
    "paddingTop": "26"
  },
  "pdb26": {
    "paddingBottom": "26"
  },
  "pdl26": {
    "paddingLeft": "26"
  },
  "pdr26": {
    "paddingRight": "26"
  },
  "mgt28": {
    "marginTop": "28"
  },
  "mgb28": {
    "marginBottom": "28"
  },
  "mgl28": {
    "marginLeft": "28"
  },
  "mgr28": {
    "marginRight": "28"
  },
  "pdt28": {
    "paddingTop": "28"
  },
  "pdb28": {
    "paddingBottom": "28"
  },
  "pdl28": {
    "paddingLeft": "28"
  },
  "pdr28": {
    "paddingRight": "28"
  },
  "mgt30": {
    "marginTop": "30"
  },
  "mgb30": {
    "marginBottom": "30"
  },
  "mgl30": {
    "marginLeft": "30"
  },
  "mgr30": {
    "marginRight": "30"
  },
  "pdt30": {
    "paddingTop": "30"
  },
  "pdb30": {
    "paddingBottom": "30"
  },
  "pdl30": {
    "paddingLeft": "30"
  },
  "pdr30": {
    "paddingRight": "30"
  },
  "mgt32": {
    "marginTop": "32"
  },
  "mgb32": {
    "marginBottom": "32"
  },
  "mgl32": {
    "marginLeft": "32"
  },
  "mgr32": {
    "marginRight": "32"
  },
  "pdt32": {
    "paddingTop": "32"
  },
  "pdb32": {
    "paddingBottom": "32"
  },
  "pdl32": {
    "paddingLeft": "32"
  },
  "pdr32": {
    "paddingRight": "32"
  },
  "mgt34": {
    "marginTop": "34"
  },
  "mgb34": {
    "marginBottom": "34"
  },
  "mgl34": {
    "marginLeft": "34"
  },
  "mgr34": {
    "marginRight": "34"
  },
  "pdt34": {
    "paddingTop": "34"
  },
  "pdb34": {
    "paddingBottom": "34"
  },
  "pdl34": {
    "paddingLeft": "34"
  },
  "pdr34": {
    "paddingRight": "34"
  },
  "mgt35": {
    "marginTop": "35"
  },
  "mgb35": {
    "marginBottom": "35"
  },
  "mgl35": {
    "marginLeft": "35"
  },
  "mgr35": {
    "marginRight": "35"
  },
  "pdt35": {
    "paddingTop": "35"
  },
  "pdb35": {
    "paddingBottom": "35"
  },
  "pdl35": {
    "paddingLeft": "35"
  },
  "pdr35": {
    "paddingRight": "35"
  },
  "mgt36": {
    "marginTop": "36"
  },
  "mgb36": {
    "marginBottom": "36"
  },
  "mgl36": {
    "marginLeft": "36"
  },
  "mgr36": {
    "marginRight": "36"
  },
  "pdt36": {
    "paddingTop": "36"
  },
  "pdb36": {
    "paddingBottom": "36"
  },
  "pdl36": {
    "paddingLeft": "36"
  },
  "pdr36": {
    "paddingRight": "36"
  },
  "mgt38": {
    "marginTop": "38"
  },
  "mgb38": {
    "marginBottom": "38"
  },
  "mgl38": {
    "marginLeft": "38"
  },
  "mgr38": {
    "marginRight": "38"
  },
  "pdt38": {
    "paddingTop": "38"
  },
  "pdb38": {
    "paddingBottom": "38"
  },
  "pdl38": {
    "paddingLeft": "38"
  },
  "pdr38": {
    "paddingRight": "38"
  },
  "mgt40": {
    "marginTop": "40"
  },
  "mgb40": {
    "marginBottom": "40"
  },
  "mgl40": {
    "marginLeft": "40"
  },
  "mgr40": {
    "marginRight": "40"
  },
  "pdt40": {
    "paddingTop": "40"
  },
  "pdb40": {
    "paddingBottom": "40"
  },
  "pdl40": {
    "paddingLeft": "40"
  },
  "pdr40": {
    "paddingRight": "40"
  },
  "mgt42": {
    "marginTop": "42"
  },
  "mgb42": {
    "marginBottom": "42"
  },
  "mgl42": {
    "marginLeft": "42"
  },
  "mgr42": {
    "marginRight": "42"
  },
  "pdt42": {
    "paddingTop": "42"
  },
  "pdb42": {
    "paddingBottom": "42"
  },
  "pdl42": {
    "paddingLeft": "42"
  },
  "pdr42": {
    "paddingRight": "42"
  },
  "mgt44": {
    "marginTop": "44"
  },
  "mgb44": {
    "marginBottom": "44"
  },
  "mgl44": {
    "marginLeft": "44"
  },
  "mgr44": {
    "marginRight": "44"
  },
  "pdt44": {
    "paddingTop": "44"
  },
  "pdb44": {
    "paddingBottom": "44"
  },
  "pdl44": {
    "paddingLeft": "44"
  },
  "pdr44": {
    "paddingRight": "44"
  },
  "mgt45": {
    "marginTop": "45"
  },
  "mgb45": {
    "marginBottom": "45"
  },
  "mgl45": {
    "marginLeft": "45"
  },
  "mgr45": {
    "marginRight": "45"
  },
  "pdt45": {
    "paddingTop": "45"
  },
  "pdb45": {
    "paddingBottom": "45"
  },
  "pdl45": {
    "paddingLeft": "45"
  },
  "pdr45": {
    "paddingRight": "45"
  },
  "mgt46": {
    "marginTop": "46"
  },
  "mgb46": {
    "marginBottom": "46"
  },
  "mgl46": {
    "marginLeft": "46"
  },
  "mgr46": {
    "marginRight": "46"
  },
  "pdt46": {
    "paddingTop": "46"
  },
  "pdb46": {
    "paddingBottom": "46"
  },
  "pdl46": {
    "paddingLeft": "46"
  },
  "pdr46": {
    "paddingRight": "46"
  },
  "mgt48": {
    "marginTop": "48"
  },
  "mgb48": {
    "marginBottom": "48"
  },
  "mgl48": {
    "marginLeft": "48"
  },
  "mgr48": {
    "marginRight": "48"
  },
  "pdt48": {
    "paddingTop": "48"
  },
  "pdb48": {
    "paddingBottom": "48"
  },
  "pdl48": {
    "paddingLeft": "48"
  },
  "pdr48": {
    "paddingRight": "48"
  },
  "mgt50": {
    "marginTop": "50"
  },
  "mgb50": {
    "marginBottom": "50"
  },
  "mgl50": {
    "marginLeft": "50"
  },
  "mgr50": {
    "marginRight": "50"
  },
  "pdt50": {
    "paddingTop": "50"
  },
  "pdb50": {
    "paddingBottom": "50"
  },
  "pdl50": {
    "paddingLeft": "50"
  },
  "pdr50": {
    "paddingRight": "50"
  },
  "mgt52": {
    "marginTop": "52"
  },
  "mgb52": {
    "marginBottom": "52"
  },
  "mgl52": {
    "marginLeft": "52"
  },
  "mgr52": {
    "marginRight": "52"
  },
  "pdt52": {
    "paddingTop": "52"
  },
  "pdb52": {
    "paddingBottom": "52"
  },
  "pdl52": {
    "paddingLeft": "52"
  },
  "pdr52": {
    "paddingRight": "52"
  },
  "mgt54": {
    "marginTop": "54"
  },
  "mgb54": {
    "marginBottom": "54"
  },
  "mgl54": {
    "marginLeft": "54"
  },
  "mgr54": {
    "marginRight": "54"
  },
  "pdt54": {
    "paddingTop": "54"
  },
  "pdb54": {
    "paddingBottom": "54"
  },
  "pdl54": {
    "paddingLeft": "54"
  },
  "pdr54": {
    "paddingRight": "54"
  },
  "mgt55": {
    "marginTop": "55"
  },
  "mgb55": {
    "marginBottom": "55"
  },
  "mgl55": {
    "marginLeft": "55"
  },
  "mgr55": {
    "marginRight": "55"
  },
  "pdt55": {
    "paddingTop": "55"
  },
  "pdb55": {
    "paddingBottom": "55"
  },
  "pdl55": {
    "paddingLeft": "55"
  },
  "pdr55": {
    "paddingRight": "55"
  },
  "mgt56": {
    "marginTop": "56"
  },
  "mgb56": {
    "marginBottom": "56"
  },
  "mgl56": {
    "marginLeft": "56"
  },
  "mgr56": {
    "marginRight": "56"
  },
  "pdt56": {
    "paddingTop": "56"
  },
  "pdb56": {
    "paddingBottom": "56"
  },
  "pdl56": {
    "paddingLeft": "56"
  },
  "pdr56": {
    "paddingRight": "56"
  },
  "mgt58": {
    "marginTop": "58"
  },
  "mgb58": {
    "marginBottom": "58"
  },
  "mgl58": {
    "marginLeft": "58"
  },
  "mgr58": {
    "marginRight": "58"
  },
  "pdt58": {
    "paddingTop": "58"
  },
  "pdb58": {
    "paddingBottom": "58"
  },
  "pdl58": {
    "paddingLeft": "58"
  },
  "pdr58": {
    "paddingRight": "58"
  },
  "mgt60": {
    "marginTop": "60"
  },
  "mgb60": {
    "marginBottom": "60"
  },
  "mgl60": {
    "marginLeft": "60"
  },
  "mgr60": {
    "marginRight": "60"
  },
  "pdt60": {
    "paddingTop": "60"
  },
  "pdb60": {
    "paddingBottom": "60"
  },
  "pdl60": {
    "paddingLeft": "60"
  },
  "pdr60": {
    "paddingRight": "60"
  },
  "mgt62": {
    "marginTop": "62"
  },
  "mgb62": {
    "marginBottom": "62"
  },
  "mgl62": {
    "marginLeft": "62"
  },
  "mgr62": {
    "marginRight": "62"
  },
  "pdt62": {
    "paddingTop": "62"
  },
  "pdb62": {
    "paddingBottom": "62"
  },
  "pdl62": {
    "paddingLeft": "62"
  },
  "pdr62": {
    "paddingRight": "62"
  },
  "mgt64": {
    "marginTop": "64"
  },
  "mgb64": {
    "marginBottom": "64"
  },
  "mgl64": {
    "marginLeft": "64"
  },
  "mgr64": {
    "marginRight": "64"
  },
  "pdt64": {
    "paddingTop": "64"
  },
  "pdb64": {
    "paddingBottom": "64"
  },
  "pdl64": {
    "paddingLeft": "64"
  },
  "pdr64": {
    "paddingRight": "64"
  },
  "mgt65": {
    "marginTop": "65"
  },
  "mgb65": {
    "marginBottom": "65"
  },
  "mgl65": {
    "marginLeft": "65"
  },
  "mgr65": {
    "marginRight": "65"
  },
  "pdt65": {
    "paddingTop": "65"
  },
  "pdb65": {
    "paddingBottom": "65"
  },
  "pdl65": {
    "paddingLeft": "65"
  },
  "pdr65": {
    "paddingRight": "65"
  },
  "mgt66": {
    "marginTop": "66"
  },
  "mgb66": {
    "marginBottom": "66"
  },
  "mgl66": {
    "marginLeft": "66"
  },
  "mgr66": {
    "marginRight": "66"
  },
  "pdt66": {
    "paddingTop": "66"
  },
  "pdb66": {
    "paddingBottom": "66"
  },
  "pdl66": {
    "paddingLeft": "66"
  },
  "pdr66": {
    "paddingRight": "66"
  },
  "mgt68": {
    "marginTop": "68"
  },
  "mgb68": {
    "marginBottom": "68"
  },
  "mgl68": {
    "marginLeft": "68"
  },
  "mgr68": {
    "marginRight": "68"
  },
  "pdt68": {
    "paddingTop": "68"
  },
  "pdb68": {
    "paddingBottom": "68"
  },
  "pdl68": {
    "paddingLeft": "68"
  },
  "pdr68": {
    "paddingRight": "68"
  },
  "mgt70": {
    "marginTop": "70"
  },
  "mgb70": {
    "marginBottom": "70"
  },
  "mgl70": {
    "marginLeft": "70"
  },
  "mgr70": {
    "marginRight": "70"
  },
  "pdt70": {
    "paddingTop": "70"
  },
  "pdb70": {
    "paddingBottom": "70"
  },
  "pdl70": {
    "paddingLeft": "70"
  },
  "pdr70": {
    "paddingRight": "70"
  },
  "mgt72": {
    "marginTop": "72"
  },
  "mgb72": {
    "marginBottom": "72"
  },
  "mgl72": {
    "marginLeft": "72"
  },
  "mgr72": {
    "marginRight": "72"
  },
  "pdt72": {
    "paddingTop": "72"
  },
  "pdb72": {
    "paddingBottom": "72"
  },
  "pdl72": {
    "paddingLeft": "72"
  },
  "pdr72": {
    "paddingRight": "72"
  },
  "mgt74": {
    "marginTop": "74"
  },
  "mgb74": {
    "marginBottom": "74"
  },
  "mgl74": {
    "marginLeft": "74"
  },
  "mgr74": {
    "marginRight": "74"
  },
  "pdt74": {
    "paddingTop": "74"
  },
  "pdb74": {
    "paddingBottom": "74"
  },
  "pdl74": {
    "paddingLeft": "74"
  },
  "pdr74": {
    "paddingRight": "74"
  },
  "mgt75": {
    "marginTop": "75"
  },
  "mgb75": {
    "marginBottom": "75"
  },
  "mgl75": {
    "marginLeft": "75"
  },
  "mgr75": {
    "marginRight": "75"
  },
  "pdt75": {
    "paddingTop": "75"
  },
  "pdb75": {
    "paddingBottom": "75"
  },
  "pdl75": {
    "paddingLeft": "75"
  },
  "pdr75": {
    "paddingRight": "75"
  },
  "mgt76": {
    "marginTop": "76"
  },
  "mgb76": {
    "marginBottom": "76"
  },
  "mgl76": {
    "marginLeft": "76"
  },
  "mgr76": {
    "marginRight": "76"
  },
  "pdt76": {
    "paddingTop": "76"
  },
  "pdb76": {
    "paddingBottom": "76"
  },
  "pdl76": {
    "paddingLeft": "76"
  },
  "pdr76": {
    "paddingRight": "76"
  },
  "mgt78": {
    "marginTop": "78"
  },
  "mgb78": {
    "marginBottom": "78"
  },
  "mgl78": {
    "marginLeft": "78"
  },
  "mgr78": {
    "marginRight": "78"
  },
  "pdt78": {
    "paddingTop": "78"
  },
  "pdb78": {
    "paddingBottom": "78"
  },
  "pdl78": {
    "paddingLeft": "78"
  },
  "pdr78": {
    "paddingRight": "78"
  },
  "mgt80": {
    "marginTop": "80"
  },
  "mgb80": {
    "marginBottom": "80"
  },
  "mgl80": {
    "marginLeft": "80"
  },
  "mgr80": {
    "marginRight": "80"
  },
  "pdt80": {
    "paddingTop": "80"
  },
  "pdb80": {
    "paddingBottom": "80"
  },
  "pdl80": {
    "paddingLeft": "80"
  },
  "pdr80": {
    "paddingRight": "80"
  },
  "clr-red01": {
    "color": "#ff0000"
  },
  "clr-red02": {
    "color": "#ea3f29"
  },
  "clr-red03": {
    "color": "#cc0000"
  },
  "clr-red04": {
    "color": "#ff6666"
  },
  "clr-orange01": {
    "color": "#f58220"
  },
  "clr-orange02": {
    "color": "#ff9933"
  },
  "clr-orange03": {
    "color": "#ff6600"
  },
  "clr-orange04": {
    "color": "#ed4200"
  },
  "clr-yellow01": {
    "color": "#ffff00"
  },
  "clr-green01": {
    "color": "#008000"
  },
  "clr-cyan01": {
    "color": "#00ffff"
  },
  "clr-cyan02": {
    "color": "#00c1a0"
  },
  "clr-blue01": {
    "color": "#0000ff"
  },
  "clr-purple01": {
    "color": "#800080"
  },
  "clr-black": {
    "color": "#000000"
  },
  "clr-grey-0": {
    "color": "#000000"
  },
  "clr-grey-1": {
    "color": "#111111"
  },
  "clr-grey-2": {
    "color": "#222222"
  },
  "clr-grey-3": {
    "color": "#333333"
  },
  "clr-grey-4": {
    "color": "#444444"
  },
  "clr-grey-5": {
    "color": "#555555"
  },
  "clr-grey-6": {
    "color": "#666666"
  },
  "clr-grey-7": {
    "color": "#777777"
  },
  "clr-grey-8": {
    "color": "#888888"
  },
  "clr-grey-9": {
    "color": "#999999"
  },
  "clr-grey-a": {
    "color": "#aaaaaa"
  },
  "clr-grey-b": {
    "color": "#bbbbbb"
  },
  "clr-grey-c": {
    "color": "#cccccc"
  },
  "clr-grey-d": {
    "color": "#dddddd"
  },
  "clr-grey-e": {
    "color": "#eeeeee"
  },
  "clr-grey-f": {
    "color": "#ffffff"
  },
  "clr-white": {
    "color": "#ffffff"
  },
  "clr-grey01": {
    "color": "#e4e4e4"
  },
  "clr-grey02": {
    "color": "#7a7a7a"
  },
  "clr-grey03": {
    "color": "#757575"
  },
  "clr-grey04": {
    "color": "#7e7e7e"
  },
  "clr-grey05": {
    "color": "#e3e3e3"
  },
  "clr-grey06": {
    "color": "#fafafa"
  },
  "bg-clr-red01": {
    "backgroundColor": "#ff0000"
  },
  "bg-clr-red02": {
    "backgroundColor": "#cc0000"
  },
  "bg-clr-orange01": {
    "backgroundColor": "#f58220"
  },
  "bg-clr-orange02": {
    "backgroundColor": "#ff9900"
  },
  "bg-clr-orange03": {
    "backgroundColor": "#e6a067"
  },
  "bg-clr-yellow01": {
    "backgroundColor": "#ffff00"
  },
  "bg-clr-green01": {
    "backgroundColor": "#008000"
  },
  "bg-clr-cyan01": {
    "backgroundColor": "#00ffff"
  },
  "bg-clr-blue01": {
    "backgroundColor": "#0000ff"
  },
  "bg-clr-purple01": {
    "backgroundColor": "#800080"
  },
  "bg-clr-black": {
    "backgroundColor": "#000000"
  },
  "bg-clr-grey-0": {
    "backgroundColor": "#000000"
  },
  "bg-clr-grey-1": {
    "backgroundColor": "#111111"
  },
  "bg-clr-grey-2": {
    "backgroundColor": "#222222"
  },
  "bg-clr-grey-3": {
    "backgroundColor": "#333333"
  },
  "bg-clr-grey-4": {
    "backgroundColor": "#444444"
  },
  "bg-clr-grey-5": {
    "backgroundColor": "#555555"
  },
  "bg-clr-grey-6": {
    "backgroundColor": "#666666"
  },
  "bg-clr-grey-7": {
    "backgroundColor": "#777777"
  },
  "bg-clr-grey-8": {
    "backgroundColor": "#888888"
  },
  "bg-clr-grey-9": {
    "backgroundColor": "#999999"
  },
  "bg-clr-grey-a": {
    "backgroundColor": "#aaaaaa"
  },
  "bg-clr-grey-b": {
    "backgroundColor": "#bbbbbb"
  },
  "bg-clr-grey-c": {
    "backgroundColor": "#cccccc"
  },
  "bg-clr-grey-d": {
    "backgroundColor": "#dddddd"
  },
  "bg-clr-grey-e": {
    "backgroundColor": "#eeeeee"
  },
  "bg-clr-grey-f": {
    "backgroundColor": "#ffffff"
  },
  "bg-clr-white": {
    "backgroundColor": "#ffffff"
  },
  "wxcell-line": {
    "height": "90",
    "flexDirection": "row",
    "justifyContent": "space-between",
    "alignItems": "center",
    "paddingLeft": "20",
    "paddingRight": "20"
  },
  "wxcell-line-sm": {
    "height": "78"
  },
  "wxcell-line__bd": {
    "flex": 1
  },
  "wxcell-line__ft": {
    "textAlign": "right"
  },
  "ttbd": {
    "fontWeight": "bold"
  },
  "ttnm": {
    "fontWeight": "normal"
  },
  "ttct": {
    "textAlign": "center"
  },
  "ttl": {
    "textAlign": "left"
  },
  "ttr": {
    "textAlign": "right"
  },
  "dirrow": {
    "flexDirection": "row"
  },
  "dircol": {
    "flexDirection": "column"
  },
  "jcct": {
    "justifyContent": "center"
  },
  "aict": {
    "alignItems": "center"
  },
  "wrapper": {
    "position": "absolute",
    "top": 0,
    "left": 0,
    "right": 0,
    "bottom": 0,
    "width": "750",
    "backgroundColor": "#f5f5f5"
  },
  "line": {
    "width": "750",
    "height": "20",
    "backgroundColor": "#f2f2f2"
  },
  "nav_title": {
    "fontSize": "38",
    "color": "#ffffff",
    "lineHeight": "38"
  },
  "header-common-title": {
    "fontSize": "38",
    "color": "#ffffff",
    "lineHeight": "38"
  },
  "title": {
    "fontSize": "32",
    "color": "#000000"
  },
  "icon_title": {
    "fontSize": "30",
    "color": "#999999"
  },
  "sub_title": {
    "fontSize": "30",
    "color": "#999999"
  },
  "sub_date": {
    "fontSize": "26",
    "color": "#999999"
  },
  "fz26": {
    "fontSize": "26"
  },
  "fz28": {
    "fontSize": "28"
  },
  "fz30": {
    "fontSize": "30"
  },
  "fz32": {
    "fontSize": "32"
  },
  "fz35": {
    "fontSize": "35"
  },
  "fz40": {
    "fontSize": "40"
  },
  "boder-bottom": {
    "borderStyle": "solid",
    "borderBottomWidth": "1",
    "borderColor": "#e6e6e6"
  },
  "boder-top": {
    "borderStyle": "solid",
    "borderTopWidth": "1",
    "borderColor": "#e6e6e6"
  },
  "boder-right": {
    "borderStyle": "solid",
    "borderRightWidth": "1",
    "borderColor": "#e6e6e6"
  },
  "boder-left": {
    "borderStyle": "solid",
    "borderLeftWidth": "1",
    "borderColor": "#e6e6e6"
  },
  "pl10": {
    "paddingLeft": "10"
  },
  "pl5": {
    "paddingLeft": "5"
  },
  "pt0": {
    "paddingTop": "0"
  },
  "pt10": {
    "paddingTop": "10"
  },
  "pt15": {
    "paddingTop": "15"
  },
  "pb10": {
    "paddingBottom": "10"
  },
  "pl20": {
    "paddingLeft": "20"
  },
  "pt20": {
    "paddingTop": "20"
  },
  "pb15": {
    "paddingBottom": "15"
  },
  "pb20": {
    "paddingBottom": "20"
  },
  "pt25": {
    "paddingTop": "25"
  },
  "pt30": {
    "paddingTop": "30"
  },
  "pt40": {
    "paddingTop": "40"
  },
  "pb40": {
    "paddingBottom": "40"
  },
  "pb30": {
    "paddingBottom": "30"
  },
  "pb25": {
    "paddingBottom": "25"
  },
  "pl25": {
    "paddingLeft": "25"
  },
  "pl30": {
    "paddingLeft": "30"
  },
  "pr5": {
    "paddingRight": "5"
  },
  "pr10": {
    "paddingRight": "10"
  },
  "pr20": {
    "paddingRight": "20"
  },
  "pr25": {
    "paddingRight": "25"
  },
  "pr30": {
    "paddingRight": "30"
  },
  "pl35": {
    "paddingLeft": "35"
  },
  "pr35": {
    "paddingRight": "35"
  },
  "bgWhite": {
    "backgroundColor": "#ffffff"
  },
  "textActive": {
    "backgroundColor:active": "#cccccc"
  },
  "mt0": {
    "marginTop": "0"
  },
  "mt10": {
    "marginTop": "10"
  },
  "mt20": {
    "marginTop": "20"
  },
  "mt30": {
    "marginTop": "30"
  },
  "mt40": {
    "marginTop": "40"
  },
  "mt50": {
    "marginTop": "50"
  },
  "bt0": {
    "marginBottom": "0"
  },
  "bt5": {
    "marginBottom": "5"
  },
  "bt10": {
    "marginBottom": "10"
  },
  "bt15": {
    "marginBottom": "15"
  },
  "bt20": {
    "marginBottom": "20"
  },
  "bt30": {
    "marginBottom": "30"
  },
  "bt45": {
    "marginBottom": "45"
  },
  "bt50": {
    "marginBottom": "50"
  },
  "mr5": {
    "marginRight": "5"
  },
  "mr10": {
    "marginRight": "10"
  },
  "mr15": {
    "marginRight": "15"
  },
  "mr30": {
    "marginRight": "30"
  },
  "ml5": {
    "marginLeft": "5"
  },
  "ml10": {
    "marginLeft": "10"
  },
  "ml20": {
    "marginLeft": "20"
  },
  "ml30": {
    "marginLeft": "30"
  },
  "header": {
    "height": "136",
    "paddingTop": "44",
    "flexDirection": "row",
    "position": "sticky",
    "backgroundColor": "#00c1a0"
  },
  "topbar": {
    "height": "136",
    "paddingTop": "44",
    "flexDirection": "row",
    "position": "sticky",
    "backgroundColor": "#00c1a0"
  },
  "topbar-common-actual": {
    "flex": 1,
    "width": "750",
    "flexDirection": "row",
    "justifyContent": "space-between",
    "alignItems": "center"
  },
  "topbar-common-hd": {
    "width": "100",
    "flexDirection": "row",
    "justifyContent": "flex-start",
    "alignItems": "center"
  },
  "topbar-common-bd": {
    "flex": 1,
    "flexDirection": "row",
    "justifyContent": "center",
    "alignItems": "center"
  },
  "topbar-common-ft": {
    "width": "100",
    "flexDirection": "row",
    "justifyContent": "flex-end",
    "alignItems": "center"
  },
  "topbar-common-icon": {
    "fontSize": "38",
    "color": "#ffffff"
  },
  "baseNavBg": {
    "backgroundColor": "#00c1a0"
  },
  "baseNavColor": {
    "color": "#00c1a0"
  },
  "nav": {
    "width": "654",
    "justifyContent": "space-between",
    "flexDirection": "row",
    "height": "92",
    "alignItems": "center",
    "marginTop": "0"
  },
  "nav_back": {
    "marginTop": "0",
    "flexDirection": "row",
    "width": "92",
    "height": "92",
    "alignItems": "center",
    "justifyContent": "center"
  },
  "corpusActive": {
    "color": "#00c1a0",
    "borderColor": "#00c1a0",
    "borderStyle": "solid",
    "borderBottomWidth": "4"
  },
  "footer": {
    "position": "fixed",
    "bottom": "0",
    "left": "0",
    "right": "0",
    "height": "100"
  },
  "fill": {
    "height": "500",
    "width": "750",
    "backgroundColor": "#f5f5f5"
  },
  "iconImg": {
    "width": "60",
    "height": "60",
    "fontSize": "60"
  },
  "cell-header": {
    "height": "70",
    "flexDirection": "row",
    "backgroundColor": "#dddddd",
    "paddingLeft": "20"
  },
  "cell-row": {
    "minHeight": "100",
    "flexDirection": "column",
    "backgroundColor": "#ffffff",
    "paddingLeft": "20",
    "marginTop": "20"
  },
  "cell-row-1": {
    "flexDirection": "column",
    "backgroundColor": "#ffffff",
    "paddingLeft": "20",
    "marginTop": "20"
  },
  "cell-row-row": {
    "minHeight": "100",
    "flexDirection": "row",
    "justifyContent": "space-between",
    "backgroundColor": "#ffffff",
    "paddingLeft": "20",
    "paddingRight": "20",
    "alignItems": "center",
    "marginTop": "20"
  },
  "cell-line": {
    "borderTopWidth": "1",
    "borderTopColor": "#e6e6e6",
    "borderTopStyle": "solid",
    "borderBottomWidth": "1",
    "borderBottomColor": "#e6e6e6",
    "borderBottomStyle": "solid"
  },
  "borderTop": {
    "borderTopWidth": "1",
    "borderTopColor": "#e6e6e6",
    "borderTopStyle": "solid"
  },
  "border-top": {
    "borderTopWidth": "1",
    "borderTopStyle": "solid",
    "borderTopColor": "#e6e6e6"
  },
  "borderBottom": {
    "borderBottomWidth": "1",
    "borderBottomColor": "#e6e6e6",
    "borderBottomStyle": "solid"
  },
  "border-bottom": {
    "borderBottomWidth": "1",
    "borderBottomStyle": "solid",
    "borderBottomColor": "#e6e6e6"
  },
  "border-left": {
    "borderLeftWidth": "1",
    "borderLeftStyle": "solid",
    "borderLeftColor": "#e6e6e6"
  },
  "border-right": {
    "borderRightWidth": "1",
    "borderRightStyle": "solid",
    "borderRightColor": "#e6e6e6"
  },
  "cell-panel": {
    "height": "98",
    "minHeight": "98",
    "flexDirection": "row",
    "alignItems": "center",
    "borderBottomWidth": "1",
    "borderBottomColor": "#e6e6e6",
    "borderBottomStyle": "solid"
  },
  "cell-panel-column": {
    "height": "98",
    "minHeight": "98",
    "flexDirection": "column",
    "justifyContent": "space-around",
    "borderBottomWidth": "1",
    "borderBottomColor": "#e6e6e6",
    "borderBottomStyle": "solid",
    "paddingTop": "10",
    "paddingBottom": "10"
  },
  "cell-bottom-clear": {
    "borderBottomWidth": "0"
  },
  "cell-clear": {
    "marginTop": "0",
    "marginBottom": "0",
    "borderBottomWidth": "0",
    "borderTopWidth": "0"
  },
  "space-between": {
    "justifyContent": "space-between",
    "flexDirection": "row",
    "alignItems": "center"
  },
  "flex-start": {
    "justifyContent": "flex-start",
    "flexDirection": "row",
    "alignItems": "center"
  },
  "flex-end": {
    "justifyContent": "flex-end",
    "flexDirection": "row",
    "alignItems": "center"
  },
  "flex-center": {
    "justifyContent": "center",
    "flexDirection": "row",
    "alignItems": "center"
  },
  "space-around": {
    "justifyContent": "space-around",
    "flexDirection": "row",
    "alignItems": "center"
  },
  "flex-row": {
    "flexDirection": "row",
    "alignItems": "center"
  },
  "flex-column": {
    "flexDirection": "column",
    "alignItems": "center"
  },
  "flex1": {
    "flex": 1
  },
  "flex2": {
    "flex": 2
  },
  "flex3": {
    "flex": 3
  },
  "flex4": {
    "flex": 4
  },
  "flex5": {
    "flex": 6
  },
  "flex6": {
    "flex": 6
  },
  "bkg-white": {
    "backgroundColor": "#ffffff"
  },
  "bkg-primary": {
    "backgroundColor": "#00c1a0"
  },
  "bkg-gray": {
    "backgroundColor": "#f5f5f5"
  },
  "bd-primary": {
    "borderColor": "#00c1a0"
  },
  "bkg-delete": {
    "backgroundColor": "#ff0000"
  },
  "white": {
    "color": "#ffffff"
  },
  "primary": {
    "color": "#00c1a0"
  },
  "gray": {
    "color": "#999999"
  },
  "ico": {
    "fontSize": "48",
    "color": "#00c1a0",
    "marginTop": "2"
  },
  "ico_big": {
    "fontSize": "72",
    "color": "#00c1a0",
    "marginTop": "4"
  },
  "ico_small": {
    "fontSize": "32",
    "color": "#00c1a0",
    "marginTop": "1"
  },
  "arrow": {
    "fontSize": "40",
    "color": "#cccccc",
    "width": "40",
    "marginLeft": "20"
  },
  "check": {
    "fontSize": "32",
    "color": "#00c1a0",
    "width": "40"
  },
  "shopCheck": {
    "fontSize": "32",
    "color": "#00c1a0",
    "width": "40",
    "marginLeft": "150"
  },
  "button": {
    "fontSize": "32",
    "textAlign": "center",
    "color": "#ffffff",
    "paddingTop": "15",
    "paddingBottom": "15",
    "backgroundColor": "#00c1a0",
    "borderRadius": "15",
    "height": "80",
    "lineHeight": "50",
    "alignItems": "center",
    "justifyContent": "center",
    "backgroundColor:active": "#e6e6e6",
    "color:active": "#00c1a0",
    "backgroundColor:disabled": "#00c1a0",
    "color:disabled": "#999999"
  },
  "refresh": {
    "flexDirection": "column",
    "alignItems": "center",
    "paddingTop": "10"
  },
  "loading": {
    "flexDirection": "column",
    "alignItems": "center",
    "paddingTop": "10"
  },
  "noLoading": {
    "height": "999"
  },
  "gif": {
    "width": "50",
    "height": "50"
  },
  "indicator": {
    "fontSize": "36",
    "color": "#00c1a0",
    "width": "750",
    "textAlign": "center",
    "marginTop": "20",
    "marginBottom": "20"
  },
  "lines-ellipsis": {
    "lines": 1,
    "textOverflow": "ellipsis"
  },
  "V1": {
    "height": "146",
    "paddingTop": "54"
  },
  "IPhoneX": {
    "height": "156",
    "paddingTop": "64"
  },
  "addTopV1": {
    "top": "54"
  },
  "addTopIPhoneX": {
    "top": "64"
  },
  "addInfoV1": {
    "height": "430",
    "paddingTop": "50"
  },
  "addInfoIPhoneX": {
    "height": "440",
    "paddingTop": "60"
  },
  "addBgImgV1": {
    "height": "430"
  },
  "addBgImgIPhoneX": {
    "height": "440"
  },
  "hideCorpusV1": {
    "top": "146"
  },
  "hideCorpusIPhoneX": {
    "top": "156"
  },
  "pageTopV1": {
    "top": "226"
  },
  "pageTopIPhoneX": {
    "top": "236"
  },
  "maskLayer": {
    "position": "fixed",
    "top": "0",
    "left": "0",
    "right": "0",
    "bottom": "0",
    "backgroundColor": "#000000",
    "opacity": 0.4
  },
  "showBox": {
    "position": "fixed",
    "top": "150",
    "right": "15",
    "paddingTop": "20",
    "paddingBottom": "20"
  },
  "showBg": {
    "position": "absolute",
    "top": 0,
    "bottom": 0,
    "left": 0,
    "right": 0,
    "backgroundColor": "#ffffff",
    "borderRadius": "20"
  },
  "arrowUp": {
    "position": "fixed",
    "top": "148",
    "right": "30"
  },
  "refreshImg": {
    "width": "60",
    "height": "60",
    "borderRadius": "30"
  },
  "refreshBox": {
    "height": "120",
    "width": "750",
    "alignItems": "center",
    "justifyContent": "center"
  },
  "indexMtIPhoneX": {
    "marginTop": "124"
  },
  "indexSliderMtIPhone": {
    "marginTop": "44"
  },
  "indexSliderMtIPhoneX": {
    "marginTop": "124"
  },
  "artOutBoxTopIPhoneX": {
    "top": "156"
  },
  "processTotal": {
    "position": "absolute",
    "bottom": "40",
    "right": "50",
    "fontSize": "28",
    "color": "#888888"
  },
  "processBg": {
    "backgroundColor": "#cccccc",
    "width": "500"
  },
  "processStyle": {
    "height": "10",
    "position": "absolute",
    "left": "50",
    "bottom": "100"
  },
  "processText": {
    "position": "absolute",
    "top": "40",
    "left": "50",
    "fontSize": "32"
  },
  "processBox": {
    "height": "250",
    "borderRadius": "5",
    "width": "600",
    "backgroundColor": "#ffffff",
    "justifyContent": "space-between"
  },
  "sendMask": {
    "position": "absolute",
    "top": 0,
    "bottom": 0,
    "left": 0,
    "right": 0,
    "backgroundColor": "rgba(0,0,0,0.8)",
    "alignItems": "center",
    "justifyContent": "center"
  },
  "placeholder-blue-bg": {
    "position": "absolute",
    "top": 0,
    "backgroundColor": "rgba(136,136,136,0.1)"
  }
}

/***/ }),

/***/ 903:
/***/ (function(module, exports) {

module.exports = {
  "aboutUserBox": {
    "width": "730",
    "paddingTop": "30",
    "paddingBottom": "30",
    "backgroundColor": "#ffffff"
  },
  "aboutUserImg": {
    "width": "100",
    "height": "100",
    "borderRadius": "50",
    "marginTop": "30",
    "marginBottom": "20"
  },
  "aboutImgName": {
    "width": "130",
    "alignItems": "center",
    "marginLeft": "18",
    "marginRight": "18"
  },
  "userName": {
    "lines": 1,
    "width": "130",
    "textAlign": "center",
    "textOverflow": "ellipsis",
    "fontSize": "26",
    "lineHeight": "26"
  },
  "corpusScroll": {
    "flexDirection": "row",
    "marginLeft": "20",
    "backgroundColor": "#ffffff",
    "height": "180"
  }
}

/***/ }),

/***/ 904:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

exports.default = {
  data: function data() {
    return {
      arrayList: this.userList,
      showTitle: this.title
    };
  },
  props: {
    userList: { default: [] },
    title: { default: '' }
  },
  methods: {
    goAuthor: function goAuthor(id) {
      this.$emit('goAuthor', id);
    },

    //            封面加载出来
    onImageLoad: function onImageLoad(item) {
      item.loading = true;
    }
  }
};

/***/ }),

/***/ 905:
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: ["aboutUserBox", "bt10"]
  }, [_c('div', {
    staticClass: ["ml20"]
  }, [_c('text', {
    staticClass: ["title", "fz32"]
  }, [_vm._v(_vm._s(_vm.showTitle))])]), _c('scroller', {
    staticClass: ["corpusScroll"],
    attrs: {
      "scrollDirection": "horizontal",
      "showScrollbar": "false"
    }
  }, _vm._l((_vm.arrayList), function(user) {
    return _c('div', [_c('div', {
      staticClass: ["aboutImgName"],
      on: {
        "click": function($event) {
          _vm.goAuthor(user.id)
        }
      }
    }, [(!user.loading) ? _c('div', {
      staticClass: ["aboutUserImg", "placeholder-blue-bg"]
    }) : _vm._e(), _c('image', {
      staticClass: ["aboutUserImg"],
      attrs: {
        "src": user.logo
      },
      on: {
        "load": function($event) {
          _vm.onImageLoad(user)
        }
      }
    }), _c('text', {
      staticClass: ["userName"]
    }, [_vm._v(_vm._s(user.nickName))])])])
  }))])
},staticRenderFns: []}
module.exports.render._withStripped = true

/***/ })

/******/ });