// { "framework": "Vue"} 

/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// identity function for calling harmony imports with the correct context
/******/ 	__webpack_require__.i = function(value) { return value; };
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 283);
/******/ })
/************************************************************************/
/******/ ({

/***/ 0:
/***/ (function(module, exports) {

/*
	MIT License http://www.opensource.org/licenses/mit-license.php
	Author Tobias Koppers @sokra
*/
// css base code, injected by the css-loader
module.exports = function() {
	var list = [];

	// return the list of modules as css string
	list.toString = function toString() {
		var result = [];
		for(var i = 0; i < this.length; i++) {
			var item = this[i];
			if(item[2]) {
				result.push("@media " + item[2] + "{" + item[1] + "}");
			} else {
				result.push(item[1]);
			}
		}
		return result.join("");
	};

	// import a list of modules into the list
	list.i = function(modules, mediaQuery) {
		if(typeof modules === "string")
			modules = [[null, modules, ""]];
		var alreadyImportedModules = {};
		for(var i = 0; i < this.length; i++) {
			var id = this[i][0];
			if(typeof id === "number")
				alreadyImportedModules[id] = true;
		}
		for(i = 0; i < modules.length; i++) {
			var item = modules[i];
			// skip already imported module
			// this implementation is not 100% perfect for weird media query combinations
			//  when a module is imported multiple times with different media queries.
			//  I hope this will never occur (Hey this way we have smaller bundles)
			if(typeof item[0] !== "number" || !alreadyImportedModules[item[0]]) {
				if(mediaQuery && !item[2]) {
					item[2] = mediaQuery;
				} else if(mediaQuery) {
					item[2] = "(" + item[2] + ") and (" + mediaQuery + ")";
				}
				list.push(item);
			}
		}
	};
	return list;
};


/***/ }),

/***/ 1:
/***/ (function(module, exports, __webpack_require__) {

/*
  MIT License http://www.opensource.org/licenses/mit-license.php
  Author Tobias Koppers @sokra
  Modified by Evan You @yyx990803
*/

var hasDocument = typeof document !== 'undefined'

if (typeof DEBUG !== 'undefined' && DEBUG) {
  if (!hasDocument) {
    throw new Error(
    'vue-style-loader cannot be used in a non-browser environment. ' +
    "Use { target: 'node' } in your Webpack config to indicate a server-rendering environment."
  ) }
}

var listToStyles = __webpack_require__(4)

/*
type StyleObject = {
  id: number;
  parts: Array<StyleObjectPart>
}

type StyleObjectPart = {
  css: string;
  media: string;
  sourceMap: ?string
}
*/

var stylesInDom = {/*
  [id: number]: {
    id: number,
    refs: number,
    parts: Array<(obj?: StyleObjectPart) => void>
  }
*/}

var head = hasDocument && (document.head || document.getElementsByTagName('head')[0])
var singletonElement = null
var singletonCounter = 0
var isProduction = false
var noop = function () {}

// Force single-tag solution on IE6-9, which has a hard limit on the # of <style>
// tags it will allow on a page
var isOldIE = typeof navigator !== 'undefined' && /msie [6-9]\b/.test(navigator.userAgent.toLowerCase())

module.exports = function (parentId, list, _isProduction) {
  isProduction = _isProduction

  var styles = listToStyles(parentId, list)
  addStylesToDom(styles)

  return function update (newList) {
    var mayRemove = []
    for (var i = 0; i < styles.length; i++) {
      var item = styles[i]
      var domStyle = stylesInDom[item.id]
      domStyle.refs--
      mayRemove.push(domStyle)
    }
    if (newList) {
      styles = listToStyles(parentId, newList)
      addStylesToDom(styles)
    } else {
      styles = []
    }
    for (var i = 0; i < mayRemove.length; i++) {
      var domStyle = mayRemove[i]
      if (domStyle.refs === 0) {
        for (var j = 0; j < domStyle.parts.length; j++) {
          domStyle.parts[j]()
        }
        delete stylesInDom[domStyle.id]
      }
    }
  }
}

function addStylesToDom (styles /* Array<StyleObject> */) {
  for (var i = 0; i < styles.length; i++) {
    var item = styles[i]
    var domStyle = stylesInDom[item.id]
    if (domStyle) {
      domStyle.refs++
      for (var j = 0; j < domStyle.parts.length; j++) {
        domStyle.parts[j](item.parts[j])
      }
      for (; j < item.parts.length; j++) {
        domStyle.parts.push(addStyle(item.parts[j]))
      }
      if (domStyle.parts.length > item.parts.length) {
        domStyle.parts.length = item.parts.length
      }
    } else {
      var parts = []
      for (var j = 0; j < item.parts.length; j++) {
        parts.push(addStyle(item.parts[j]))
      }
      stylesInDom[item.id] = { id: item.id, refs: 1, parts: parts }
    }
  }
}

function createStyleElement () {
  var styleElement = document.createElement('style')
  styleElement.type = 'text/css'
  head.appendChild(styleElement)
  return styleElement
}

function addStyle (obj /* StyleObjectPart */) {
  var update, remove
  var styleElement = document.querySelector('style[data-vue-ssr-id~="' + obj.id + '"]')

  if (styleElement) {
    if (isProduction) {
      // has SSR styles and in production mode.
      // simply do nothing.
      return noop
    } else {
      // has SSR styles but in dev mode.
      // for some reason Chrome can't handle source map in server-rendered
      // style tags - source maps in <style> only works if the style tag is
      // created and inserted dynamically. So we remove the server rendered
      // styles and inject new ones.
      styleElement.parentNode.removeChild(styleElement)
    }
  }

  if (isOldIE) {
    // use singleton mode for IE9.
    var styleIndex = singletonCounter++
    styleElement = singletonElement || (singletonElement = createStyleElement())
    update = applyToSingletonTag.bind(null, styleElement, styleIndex, false)
    remove = applyToSingletonTag.bind(null, styleElement, styleIndex, true)
  } else {
    // use multi-style-tag mode in all other cases
    styleElement = createStyleElement()
    update = applyToTag.bind(null, styleElement)
    remove = function () {
      styleElement.parentNode.removeChild(styleElement)
    }
  }

  update(obj)

  return function updateStyle (newObj /* StyleObjectPart */) {
    if (newObj) {
      if (newObj.css === obj.css &&
          newObj.media === obj.media &&
          newObj.sourceMap === obj.sourceMap) {
        return
      }
      update(obj = newObj)
    } else {
      remove()
    }
  }
}

var replaceText = (function () {
  var textStore = []

  return function (index, replacement) {
    textStore[index] = replacement
    return textStore.filter(Boolean).join('\n')
  }
})()

function applyToSingletonTag (styleElement, index, remove, obj) {
  var css = remove ? '' : obj.css

  if (styleElement.styleSheet) {
    styleElement.styleSheet.cssText = replaceText(index, css)
  } else {
    var cssNode = document.createTextNode(css)
    var childNodes = styleElement.childNodes
    if (childNodes[index]) styleElement.removeChild(childNodes[index])
    if (childNodes.length) {
      styleElement.insertBefore(cssNode, childNodes[index])
    } else {
      styleElement.appendChild(cssNode)
    }
  }
}

function applyToTag (styleElement, obj) {
  var css = obj.css
  var media = obj.media
  var sourceMap = obj.sourceMap

  if (media) {
    styleElement.setAttribute('media', media)
  }

  if (sourceMap) {
    // https://developer.chrome.com/devtools/docs/javascript-debugging
    // this makes source maps inside style tags work properly in Chrome
    css += '\n/*# sourceURL=' + sourceMap.sources[0] + ' */'
    // http://stackoverflow.com/a/26603875
    css += '\n/*# sourceMappingURL=data:application/json;base64,' + btoa(unescape(encodeURIComponent(JSON.stringify(sourceMap)))) + ' */'
  }

  if (styleElement.styleSheet) {
    styleElement.styleSheet.cssText = css
  } else {
    while (styleElement.firstChild) {
      styleElement.removeChild(styleElement.firstChild)
    }
    styleElement.appendChild(document.createTextNode(css))
  }
}


/***/ }),

/***/ 192:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__assets_utils__ = __webpack_require__(2);
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//


const event = weex.requireModule('event');
/* harmony default export */ __webpack_exports__["default"] = ({
    data() {
        return {
            showLoading: 'hide',
            listCurrent: 0,
            listPageSize: 10,
            //                articleList:[]
            articleList: [{
                value: {
                    key: 1,
                    title: '你好22',
                    thumbnail: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg'
                } }, {
                value: {
                    key: 1,
                    title: '你好发',
                    thumbnail: 'https://gd2.alicdn.com/bao/uploaded/i2/T14H1LFwBcXXXXXXXX_!!0-item_pic.jpg'
                } }, {
                value: {
                    key: 1,
                    title: '你好额',
                    thumbnail: 'https://gd1.alicdn.com/bao/uploaded/i1/TB1PXJCJFXXXXciXFXXXXXXXXXX_!!0-item_pic.jpg'
                } }, {
                value: {
                    key: 1,
                    title: '你好的',
                    thumbnail: 'https://gd3.alicdn.com/bao/uploaded/i3/TB1x6hYLXXXXXazXVXXXXXXXXXX_!!0-item_pic.jpg'
                } }, {
                value: {
                    key: 1,
                    title: '你好啊',
                    thumbnail: 'https://gd2.alicdn.com/bao/uploaded/i2/T14H1LFwBcXXXXXXXX_!!0-item_pic.jpg'
                } }, {
                value: {
                    key: 1,
                    title: '你好a',
                    thumbnail: 'https://gd1.alicdn.com/bao/uploaded/i1/TB1PXJCJFXXXXciXFXXXXXXXXXX_!!0-item_pic.jpg'
                }
            }]
        };
    },
    props: {
        //            whichCorpus:{default:0}
    },
    created() {
        __WEBPACK_IMPORTED_MODULE_0__assets_utils__["a" /* default */].initIconFont();
        var _this = this;
        let options = {
            type: 'article',
            keyword: '',
            orderBy: 'desc',
            current: _this.listCurrent,
            pageSize: _this.listPageSize
        };
        event.findList(options, function (data) {
            if (data.type == "success" && data.data != '') {
                data.data.forEach(function (item) {
                    //                    将value json化
                    item.value = JSON.parse(item.value);
                    //                        把读取到的文章push进去文章列表
                    _this.articleList.push(item);
                });
            } else {
                return;
            }
        });
    },
    methods: {
        goArticle() {},
        onpanmove(e) {
            this.$emit('onpanmove', e.direction);
        },
        onloading(event) {
            this.showLoading = 'show';
            setTimeout(() => {
                this.articleList.push({
                    value: {
                        key: 1,
                        title: '我是新加入的3333',
                        thumbnail: 'https://gd1.alicdn.com/bao/uploaded/i1/TB1PXJCJFXXXXciXFXXXXXXXXXX_!!0-item_pic.jpg'
                    }
                });
                this.showLoading = 'hide';
            }, 1500);
        }
    }
});

/***/ }),

/***/ 2:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/**
 * Created by zwwill on 2017/8/27.
 */
const resLocateURL = 'file://';
const resRemoteURL = 'http://cdn.rzico.com/weex/';
const websiteURL = 'http://dev.rzico.com';
const event = weex.requireModule('event');
const debug = false; //删掉该属性时请查找该页所有debug变量并删除变量
let utilsFunc = {
    initIconFont() {
        let domModule = weex.requireModule('dom');
        domModule.addRule('fontFace', {
            'fontFamily': "iconfont",
            'src': "url('" + resLocateURL + "resources/fonts/iconfont.ttf')"
        });
    },
    //获取本地资源
    locate(url) {
        const newUrl = resLocateURL + url;
        return newUrl;
    },
    //获取远程资源
    remote(url) {
        const newUrl = resRemoteURL + url;
        return newUrl;
    },
    //获取网站资源
    website(url) {
        const newUrl = websiteURL + url;
        return newUrl;
    },
    //获取URL参数
    getUrlParameter(name, dataUrl) {
        let url;
        if (dataUrl == null || dataUrl == undefined || dataUrl == '') {
            url = weex.config.bundleUrl;
        } else {
            url = dataUrl;
        }
        let reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
        let r = url.slice(url.indexOf('?') + 1).match(reg);
        if (r != null) {
            try {
                return decodeURIComponent(r[2]);
            } catch (_e) {
                return null;
            }
        }
        return null;
    },
    message(_type, _content, _data) {
        return {
            type: _type,
            content: _content,
            data: _data
        };
    },
    //判空
    isNull(value) {
        if (value == null || value == undefined || value == '' || value == 'undefined') {
            return true;
        } else {
            return false;
        }
    },
    //获取缩略图
    thumbnail(url, w, h) {
        //获取屏幕宽度计算得出比例
        let proportion = weex.config.env.deviceWidth / 750;
        //                获取缩略图的宽高
        w = parseInt(w * proportion);
        h = parseInt(h * proportion);
        if (url.substring(0, 11) == "http://cdnx") {
            return url + "?x-oss-process=image/resize,w_" + w + ",h_" + h + "";
        } else if (url.substring(0, 10) == "http://cdn") {
            return url + "@" + w + "w_" + h + "h_1e_1c_100Q";
        } else {
            return url;
        }
    },
    //获取全屏的高度尺寸,可传入父组件的导航栏高度进行适配
    fullScreen(topHeight) {
        //减1是为了能触发loading，不能够高度刚刚好
        topHeight = topHeight == '' ? 0 : topHeight - 1;
        return 750 / weex.config.env.deviceWidth * weex.config.env.deviceHeight - topHeight;
    },
    //模糊图片，r , s  为 1-50，超大超模糊
    blur(url, r, s) {
        if (url.substring(0, 10) == "http://cdn") {
            return url + "@" + r + "-" + s + "bl";
        } else {
            return url;
        }
    },
    //获取文章URL地址
    articleUrl(template, id) {
        template = template == '' ? 't1001' : template;
        return websiteURL + "/" + template + "?id=" + id;
    },
    debug(msg) {
        if (debug) {
            event.toast(msg);
        }
    },
    isRoles(roles, all) {
        for (var i = 0; i < roles.length; i++) {
            let role = roles.substring(i, i + 1);
            if (all.indexOf(role) >= 0) {
                return true;
            }
        }
        return false;
    },
    //  获取字符串的字符总长度
    getLength(e) {
        var name = e;
        var len = 0;
        for (let i = 0; i < name.length; i++) {
            var a = name.charAt(i);
            if (a.match(/[^\x00-\xff]/ig) != null) {
                len += 2;
            } else {
                len += 1;
            }
        }
        return len;
    },
    //    将过长的字符串换成 XXX...XXX格式
    changeStr(e) {
        return e.substr(0, 4) + '...' + e.substr(-4);
    },
    //js中用正则表达式 过滤特殊字符, 校验所有输入域是否含有特殊符号 (无法过滤 \ )
    //  searchFilter(s) {
    //         event.toast(s);
    //         var pattern = new RegExp("[`~!@#$^&*()=|{}':;',\\[\\].<>/?~！@#￥……&*（）&mdash;—|{}【】‘；：”“'。，、？]");
    //         var rs = "";
    //         for (var i = 0; i < s.length; i++) {
    //             rs = rs + s.substr(i, 1).replace(pattern,'');
    //         }
    //         return rs;
    //     }

    //老的二维码转换成新格式
    qr2scan(e) {
        let type = this.getUrlParameter("type", e);
        let code = this.getUrlParameter("no", e);
        if (type == "paybill") {
            return websiteURL + "/q/818804" + code + ".jhtml";
        } else if (type == "card_active") {
            return websiteURL + "/q/818801" + code + ".jhtml";
        } else {
            return e;
        }
    },
    //    二维码读取内容
    readScan(e, callback) {
        e = this.qr2scan(e);
        let backData = {};
        //二维码字段截取. indexOf 没找到时返回-1， 此时如果2个indexof都没找到 那么 e.substring（-1 + 3 ，-1）,e的长度会变为2
        // let subData = e.substring(e.indexOf("/q/8") + 3,e.indexOf(".jhtml"));

        let start = e.indexOf("/q/8");
        let end = e.indexOf(".jhtml");
        var subData = null;
        if (start != -1 && end != -1) {
            subData = e.substring(start + 3, end);
        }
        //判断是不是web  code'000000'为无效二维码 '999999'为webView；
        if (subData == null) {
            //如果没有找到q/ 和 .jhtml中的字端，就执行该段代码
            if (e.substring(0, 4) == 'http' && debug) {
                let data = {
                    type: 'webView',
                    code: '999999'
                };
                backData = this.message('success', 'webView', data);
            } else {
                let data = {
                    type: 'error',
                    code: '000000'
                };
                backData = this.message('error', '无效二维码', data);
            }
            callback(backData);
        } else {
            //截取11位的判断码
            let type = subData.substring(0, 6);
            let code = subData.slice(6);
            let data = {
                type: type,
                code: code
            };
            if (code == '000000') {
                backData = this.message('error', '无效二维码', data);
            } else {
                backData = this.message('success', '扫描成功', data);
            }
            callback(backData);
        }
    },
    //判断用户是否只输入了空格
    isAllEmpty(str) {
        if (str.replace(/ /g, "").length == 0) {
            return true;
        } else {
            return false;
        }
    },
    //判断设备型号
    device: function () {
        let s = weex.config.env.deviceModel;
        if (this.isNull(s)) {
            return "";
        } else {
            if (s.indexOf("V1") > 0) {
                return "V1";
            } else if (s.indexOf("10,3") > 0 || s.indexOf("10,6") > 0) {
                return 'IPhoneX';
            } else {
                return s;
            }
        }
    },

    //    登录主页的轮播图控制
    indexMt() {
        let s = this.device();
        if (this.isNull(s)) {
            return "";
        } else {
            if (s == 'V1') {
                return 'indexMtV1';
            } else if (s == 'IPhoneX') {
                return 'indexMtIPhoneX';
            } else {
                return s;
            }
        }
    },

    //    判断设备型号为fix定位的元素添加高度 (会员首页 作者专栏 顶部设置跟返回按钮)
    addTop: function () {
        let s = this.device();
        if (this.isNull(s)) {
            return "";
        } else {
            if (s == 'V1') {
                return 'addTopV1';
            } else if (s == 'IPhoneX') {
                return 'addTopIPhoneX';
            } else {
                return s;
            }
        }
    },
    //   会员首页 作者专栏 顶部信息栏
    addInfo: function () {
        let s = this.device();
        if (this.isNull(s)) {
            return "";
        } else {
            if (s == 'V1') {
                return 'addInfoV1';
            } else if (s == 'IPhoneX') {
                return 'addInfoIPhoneX';
            } else {
                return s;
            }
        }
    },
    //    判断设备型号为fix定位的元素添加高度 (会员首页 作者专栏 顶部设置跟返回按钮)
    addBgImg: function () {
        let s = this.device();
        if (this.isNull(s)) {
            return "";
        } else {
            if (s == 'V1') {
                return 'addBgImgV1';
            } else if (s == 'IPhoneX') {
                return 'addBgImgIPhoneX';
            } else {
                return s;
            }
        }
    },
    //    控制滑动时文集box的显示
    hideCorpus: function () {
        let s = this.device();
        if (this.isNull(s)) {
            return "";
        } else {
            if (s == 'V1') {
                return 'hideCorpusV1';
            } else if (s == 'IPhoneX') {
                return 'hideCorpusIPhoneX';
            } else {
                return s;
            }
        }
    },
    //    控制滑动时文集box的显示
    pageTop: function () {
        let s = this.device();
        if (this.isNull(s)) {
            return "";
        } else {
            if (s == 'V1') {
                return 'pageTopV1';
            } else if (s == 'IPhoneX') {
                return 'pageTopIPhoneX';
            } else {
                return s;
            }
        }
    },

    //判断设备系统是不是ios
    isIosSystem: function () {
        let s = weex.config.env.osName;
        if (s == 'iOS') {
            return true;
        } else {
            return false;
        }
    },

    resolvetimefmt: function (value) {
        //value 传进来是个整数型，要判断是10位还是13位需要转成字符串。这边的方法是检测13位的时间戳 所以要*1000；并且转回整型。安卓下，时间早了8个小时
        if (value.toString().length == 10) {
            value = parseInt(value) * 1000;
        } else {
            value = parseInt(value);
        }
        // 返回处理后的值
        var date = new Date(value);

        var d2 = Date.UTC(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate(), date.getUTCHours(), date.getUTCMinutes(), date.getUTCSeconds());

        date = new Date(d2 + 28800000);

        var y = date.getUTCFullYear();
        var m = date.getUTCMonth() + 1;
        var d = date.getUTCDate();
        var h = date.getUTCHours();
        var i = date.getUTCMinutes();
        var s = date.getUTCSeconds();
        if (m < 10) {
            m = '0' + m;
        }
        if (d < 10) {
            d = '0' + d;
        }
        if (h < 10) {
            h = '0' + h;
        }
        if (i < 10) {
            i = '0' + i;
        }
        if (s < 10) {
            s = '0' + s;
        }
        let timeObj = {
            y: y,
            m: m,
            d: d,
            h: h,
            i: i,
            s: s
        };
        return timeObj;
    },
    //返回格式 2017-09-01
    ymdtimefmt: function (value) {
        if (value == '' || value == null || value == undefined) {
            return value;
        }
        let timeObj = this.resolvetimefmt(value);
        return timeObj.y + '-' + timeObj.m + '-' + timeObj.d;
    },
    //返回格式 2017-09-01 06:35:59
    ymdhistimefmt: function (value) {
        if (value == '' || value == null || value == undefined) {
            return value;
        }
        let timeObj = this.resolvetimefmt(value);

        return timeObj.y + '-' + timeObj.m + '-' + timeObj.d + ' ' + timeObj.h + ':' + timeObj.i + ':' + timeObj.s;
    },
    //返回格式 2017年09月01日 06:35:59
    ymdhisdayfmt: function (value) {
        if (value == '' || value == null || value == undefined) {
            return value;
        }
        let timeObj = this.resolvetimefmt(value);

        return timeObj.y + '年' + timeObj.m + '月' + timeObj.d + '日' + ' ' + timeObj.h + ':' + timeObj.i + ':' + timeObj.s;
    },
    //返回格式 06:35:59
    histimefmt: function (value) {
        if (value == '' || value == null || value == undefined) {
            return value;
        }
        let timeObj = this.resolvetimefmt(value);
        return timeObj.h + ':' + timeObj.i + ':' + timeObj.s;
    }
};

/* harmony default export */ __webpack_exports__["a"] = (utilsFunc);

/***/ }),

/***/ 283:
/***/ (function(module, exports, __webpack_require__) {

var App = __webpack_require__(99);
App.el = '#root';
new Vue(App);

/***/ }),

/***/ 3:
/***/ (function(module, exports) {

module.exports = function normalizeComponent (
  rawScriptExports,
  compiledTemplate,
  scopeId,
  cssModules
) {
  var esModule
  var scriptExports = rawScriptExports = rawScriptExports || {}

  // ES6 modules interop
  var type = typeof rawScriptExports.default
  if (type === 'object' || type === 'function') {
    esModule = rawScriptExports
    scriptExports = rawScriptExports.default
  }

  // Vue.extend constructor export interop
  var options = typeof scriptExports === 'function'
    ? scriptExports.options
    : scriptExports

  // render functions
  if (compiledTemplate) {
    options.render = compiledTemplate.render
    options.staticRenderFns = compiledTemplate.staticRenderFns
  }

  // scopedId
  if (scopeId) {
    options._scopeId = scopeId
  }

  // inject cssModules
  if (cssModules) {
    var computed = options.computed || (options.computed = {})
    Object.keys(cssModules).forEach(function (key) {
      var module = cssModules[key]
      computed[key] = function () { return module }
    })
  }

  return {
    esModule: esModule,
    exports: scriptExports,
    options: options
  }
}


/***/ }),

/***/ 387:
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(0)();
// imports


// module
exports.push([module.i, "\n.activeClass{\n    visibility: visible;\n}\n.noactive{\n    visibility: hidden;\n}\n/*.wrapper{*/\n/*background-color: #f4f4f4;*/\n/*flex:1;*/\n/*}*/\n.relevantImage {\n    flex-direction: row;\n    font-size: 32px;\n    color: #888;\n    margin-right: 5px;\n    margin-left: 5px;\n    align-items: center;\n}\n.relevantText {\n    color: #888;\n    font-size: 26px;\n}\n.relevantInfo {\n    flex-direction: row;\n    align-items: center;\n}\n.articleFoot {\n    flex-direction: row;\n    justify-content: space-between;\n    width: 690px;\n    align-items: center;\n}\n.articleDate {\n    font-size: 24px;\n    color: #888;\n}\n.articleCover {\n    height: 300px;\n    width:690px;\n    border-radius: 5px;\n    margin-top: 30px;\n    margin-bottom: 30px;\n}\n.articleBox {\n    background-color: #ffffff;\n    padding-left: 30px;\n    padding-top: 30px;\n    padding-right: 30px;\n    padding-bottom: 30px;\n    margin-bottom: 10px;\n}\n.atricleHead {\n    flex-direction: row;\n    align-items: center;\n}\n.articleTitle {\n    font-size: 32px;\n    margin-left: 10px;\n}\n.articleSign {\n    border-radius: 10px;\n    padding: 5px;\n    color: #888;\n    font-size: 26px;\n    border-width: 1px;\n    border-style: solid;\n    border-color: gainsboro;\n}\n", ""]);

// exports


/***/ }),

/***/ 4:
/***/ (function(module, exports) {

/**
 * Translates the list format produced by css-loader into something
 * easier to manipulate.
 */
module.exports = function listToStyles (parentId, list) {
  var styles = []
  var newStyles = {}
  for (var i = 0; i < list.length; i++) {
    var item = list[i]
    var id = item[0]
    var css = item[1]
    var media = item[2]
    var sourceMap = item[3]
    var part = {
      id: parentId + ':' + i,
      css: css,
      media: media,
      sourceMap: sourceMap
    }
    if (!newStyles[id]) {
      styles.push(newStyles[id] = { id: id, parts: [part] })
    } else {
      newStyles[id].parts.push(part)
    }
  }
  return styles
}


/***/ }),

/***/ 562:
/***/ (function(module, exports, __webpack_require__) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('scroller', [_vm._l((_vm.articleList), function(item, index) {
    return _c('div', {
      key: index,
      staticClass: "articleBox",
      on: {
        "click": function($event) {
          _vm.goArticle(item.key)
        },
        "swipe": function($event) {
          _vm.onpanmove($event)
        }
      }
    }, [_c('div', {
      staticClass: "atricleHead"
    }, [_c('text', {
      staticClass: "articleTitle"
    }, [_vm._v(_vm._s(item.value.title))])]), _vm._v(" "), _c('div', {
      staticStyle: {
        "position": "relative"
      }
    }, [_c('image', {
      staticClass: "articleCover",
      attrs: {
        "src": item.value.thumbnail,
        "resize": "cover"
      }
    })]), _vm._v(" "), _c('div', {
      staticClass: "articleFoot"
    }, [_c('div', [_c('text', {
      staticClass: "articleDate"
    }, [_vm._v("2017-09-01")])]), _vm._v(" "), (item.articleSign != '样例') ? _c('div', {
      staticClass: "relevantInfo"
    }, [_c('text', {
      staticClass: "relevantImage",
      style: ({
        fontFamily: 'iconfont'
      })
    }, [_vm._v("")]), _vm._v(" "), _c('text', {
      staticClass: "relevantText"
    }, [_vm._v(_vm._s(item.value.hits))]), _vm._v(" "), _c('text', {
      staticClass: "relevantImage ",
      staticStyle: {
        "padding-bottom": "2px"
      },
      style: ({
        fontFamily: 'iconfont'
      })
    }, [_vm._v("")]), _vm._v(" "), _c('text', {
      staticClass: "relevantText"
    }, [_vm._v(_vm._s(item.value.laud))]), _vm._v(" "), _c('text', {
      staticClass: "relevantImage",
      style: ({
        fontFamily: 'iconfont'
      })
    }, [_vm._v("")]), _vm._v(" "), _c('text', {
      staticClass: "relevantText"
    }, [_vm._v(_vm._s(item.value.review))])]) : _vm._e()])])
  }), _vm._v(" "), _c('loading', {
    staticClass: "loading",
    attrs: {
      "display": _vm.showLoading
    },
    on: {
      "loading": _vm.onloading
    }
  }, [_c('text', {
    staticClass: "indicator"
  }, [_vm._v("Loading ...")])])], 2)
},staticRenderFns: []}
module.exports.render._withStripped = true
if (false) {
  module.hot.accept()
  if (module.hot.data) {
     require("vue-loader/node_modules/vue-hot-reload-api").rerender("data-v-1222e767", module.exports)
  }
}

/***/ }),

/***/ 665:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(387);
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var update = __webpack_require__(1)("71c60ee8", content, false);
// Hot Module Replacement
if(false) {
 // When the styles change, update the <style> tags
 if(!content.locals) {
   module.hot.accept("!!../../../node_modules/_css-loader@0.26.4@css-loader/index.js!../../../node_modules/_vue-loader@10.3.0@vue-loader/lib/style-rewriter.js?id=data-v-1222e767!../../../node_modules/_vue-loader@10.3.0@vue-loader/lib/selector.js?type=styles&index=0!./focusCategory.vue", function() {
     var newContent = require("!!../../../node_modules/_css-loader@0.26.4@css-loader/index.js!../../../node_modules/_vue-loader@10.3.0@vue-loader/lib/style-rewriter.js?id=data-v-1222e767!../../../node_modules/_vue-loader@10.3.0@vue-loader/lib/selector.js?type=styles&index=0!./focusCategory.vue");
     if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
     update(newContent);
   });
 }
 // When the module is disposed, remove the <style> tags
 module.hot.dispose(function() { update(); });
}

/***/ }),

/***/ 99:
/***/ (function(module, exports, __webpack_require__) {


/* styles */
__webpack_require__(665)

var Component = __webpack_require__(3)(
  /* script */
  __webpack_require__(192),
  /* template */
  __webpack_require__(562),
  /* scopeId */
  null,
  /* cssModules */
  null
)
Component.options.__file = "/Users/leistercheung/Documents/mopian/mp/src/view/home/focusCategory.vue"
if (Component.esModule && Object.keys(Component.esModule).some(function (key) {return key !== "default" && key !== "__esModule"})) {console.error("named exports are not supported in *.vue files.")}
if (Component.options.functional) {console.error("[vue-loader] focusCategory.vue: functional components are not supported with templates, they should use render functions.")}

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-loader/node_modules/vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-1222e767", Component.options)
  } else {
    hotAPI.reload("data-v-1222e767", Component.options)
  }
})()}

module.exports = Component.exports


/***/ })

/******/ });