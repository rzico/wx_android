// { "framework": "Vue"} 

// { "framework": "Vue"} 

/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 678);
/******/ })
/************************************************************************/
/******/ ({

/***/ 0:
/***/ (function(module, exports) {

// https://github.com/zloirock/core-js/issues/86#issuecomment-115759028
var global = module.exports = typeof window != 'undefined' && window.Math == Math
  ? window : typeof self != 'undefined' && self.Math == Math ? self
  // eslint-disable-next-line no-new-func
  : Function('return this')();
if (typeof __g == 'number') __g = global; // eslint-disable-line no-undef


/***/ }),

/***/ 1:
/***/ (function(module, exports, __webpack_require__) {

var store = __webpack_require__(32)('wks');
var uid = __webpack_require__(28);
var Symbol = __webpack_require__(0).Symbol;
var USE_SYMBOL = typeof Symbol == 'function';

var $exports = module.exports = function (name) {
  return store[name] || (store[name] =
    USE_SYMBOL && Symbol[name] || (USE_SYMBOL ? Symbol : uid)('Symbol.' + name));
};

$exports.store = store;


/***/ }),

/***/ 10:
/***/ (function(module, exports, __webpack_require__) {

// optional / simple context binding
var aFunction = __webpack_require__(14);
module.exports = function (fn, that, length) {
  aFunction(fn);
  if (that === undefined) return fn;
  switch (length) {
    case 1: return function (a) {
      return fn.call(that, a);
    };
    case 2: return function (a, b) {
      return fn.call(that, a, b);
    };
    case 3: return function (a, b, c) {
      return fn.call(that, a, b, c);
    };
  }
  return function (/* ...args */) {
    return fn.apply(that, arguments);
  };
};


/***/ }),

/***/ 11:
/***/ (function(module, exports) {

module.exports = {};


/***/ }),

/***/ 12:
/***/ (function(module, exports) {

module.exports = function (exec) {
  try {
    return !!exec();
  } catch (e) {
    return true;
  }
};


/***/ }),

/***/ 13:
/***/ (function(module, exports) {

var toString = {}.toString;

module.exports = function (it) {
  return toString.call(it).slice(8, -1);
};


/***/ }),

/***/ 14:
/***/ (function(module, exports) {

module.exports = function (it) {
  if (typeof it != 'function') throw TypeError(it + ' is not a function!');
  return it;
};


/***/ }),

/***/ 142:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


/* eslint-disable no-undefined,no-param-reassign,no-shadow */

/**
 * Throttle execution of a function. Especially useful for rate limiting
 * execution of handlers on events like resize and scroll.
 *
 * @param  {Number}    delay          A zero-or-greater delay in milliseconds. For event callbacks, values around 100 or 250 (or even higher) are most useful.
 * @param  {Boolean}   noTrailing     Optional, defaults to false. If noTrailing is true, callback will only execute every `delay` milliseconds while the
 *                                    throttled-function is being called. If noTrailing is false or unspecified, callback will be executed one final time
 *                                    after the last throttled-function call. (After the throttled-function has not been called for `delay` milliseconds,
 *                                    the internal counter is reset)
 * @param  {Function}  callback       A function to be executed after delay milliseconds. The `this` context and all arguments are passed through, as-is,
 *                                    to `callback` when the throttled-function is executed.
 * @param  {Boolean}   debounceMode   If `debounceMode` is true (at begin), schedule `clear` to execute after `delay` ms. If `debounceMode` is false (at end),
 *                                    schedule `callback` to execute after `delay` ms.
 *
 * @return {Function}  A new, throttled, function.
 */
module.exports = function (delay, noTrailing, callback, debounceMode) {

	// After wrapper has stopped being called, this timeout ensures that
	// `callback` is executed at the proper times in `throttle` and `end`
	// debounce modes.
	var timeoutID;

	// Keep track of the last time `callback` was executed.
	var lastExec = 0;

	// `noTrailing` defaults to falsy.
	if (typeof noTrailing !== 'boolean') {
		debounceMode = callback;
		callback = noTrailing;
		noTrailing = undefined;
	}

	// The `wrapper` function encapsulates all of the throttling / debouncing
	// functionality and when executed will limit the rate at which `callback`
	// is executed.
	function wrapper() {

		var self = this;
		var elapsed = Number(new Date()) - lastExec;
		var args = arguments;

		// Execute `callback` and update the `lastExec` timestamp.
		function exec() {
			lastExec = Number(new Date());
			callback.apply(self, args);
		}

		// If `debounceMode` is true (at begin) this is used to clear the flag
		// to allow future `callback` executions.
		function clear() {
			timeoutID = undefined;
		}

		if (debounceMode && !timeoutID) {
			// Since `wrapper` is being called for the first time and
			// `debounceMode` is true (at begin), execute `callback`.
			exec();
		}

		// Clear any existing timeout.
		if (timeoutID) {
			clearTimeout(timeoutID);
		}

		if (debounceMode === undefined && elapsed > delay) {
			// In throttle mode, if `delay` time has been exceeded, execute
			// `callback`.
			exec();
		} else if (noTrailing !== true) {
			// In trailing throttle mode, since `delay` time has not been
			// exceeded, schedule `callback` to execute `delay` ms after most
			// recent execution.
			//
			// If `debounceMode` is true (at begin), schedule `clear` to execute
			// after `delay` ms.
			//
			// If `debounceMode` is false (at end), schedule `callback` to
			// execute after `delay` ms.
			timeoutID = setTimeout(debounceMode ? clear : exec, debounceMode === undefined ? delay - elapsed : delay);
		}
	}

	// Return the wrapper function.
	return wrapper;
};

/***/ }),

/***/ 15:
/***/ (function(module, exports, __webpack_require__) {

// to indexed object, toObject with fallback for non-array-like ES3 strings
var IObject = __webpack_require__(49);
var defined = __webpack_require__(23);
module.exports = function (it) {
  return IObject(defined(it));
};


/***/ }),

/***/ 16:
/***/ (function(module, exports) {

module.exports = true;


/***/ }),

/***/ 17:
/***/ (function(module, exports, __webpack_require__) {

var def = __webpack_require__(8).f;
var has = __webpack_require__(9);
var TAG = __webpack_require__(1)('toStringTag');

module.exports = function (it, tag, stat) {
  if (it && !has(it = stat ? it : it.prototype, TAG)) def(it, TAG, { configurable: true, value: tag });
};


/***/ }),

/***/ 18:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _promise = __webpack_require__(37);

var _promise2 = _interopRequireDefault(_promise);

exports.initIconFont = initIconFont;
exports.locate = locate;
exports.remote = remote;
exports.website = website;
exports.getUrlParameter = getUrlParameter;
exports.gerUrlQueryString = gerUrlQueryString;
exports.message = message;
exports.isNull = isNull;
exports.filterThumbnail = filterThumbnail;
exports.thumbnail = thumbnail;
exports.fullScreen = fullScreen;
exports.blur = blur;
exports.articleUrl = articleUrl;
exports.couponUrl = couponUrl;
exports.debug = debug;
exports.isRoles = isRoles;
exports.getLength = getLength;
exports.changeStrLast = changeStrLast;
exports.changeStrLastDote = changeStrLastDote;
exports.changeStr = changeStr;
exports.qr2scan = qr2scan;
exports.readScan = readScan;
exports.isAllEmpty = isAllEmpty;
exports.device = device;
exports.indexMt = indexMt;
exports.indexMtSlider = indexMtSlider;
exports.addTop = addTop;
exports.addInfo = addInfo;
exports.addBgImg = addBgImg;
exports.hideCorpus = hideCorpus;
exports.pageTop = pageTop;
exports.artOutTop = artOutTop;
exports.previewBottom = previewBottom;
exports.isIosSystem = isIosSystem;
exports.resolvetimefmt = resolvetimefmt;
exports.ymdtimefmt = ymdtimefmt;
exports.ymdhistimefmt = ymdhistimefmt;
exports.ymdhisdayfmt = ymdhisdayfmt;
exports.histimefmt = histimefmt;
exports.filteremoji = filteremoji;
exports.currencyfmt = currencyfmt;
exports.getCurLocation = getCurLocation;
exports.getAmapKeys = getAmapKeys;

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * Created by zwwill on 2017/8/27.
 */
var event = weex.requireModule('event');
var resLocateURL = 'file://';
var resRemoteURL = "http://cdnx.ahxinying.cn/farmer/";
var websiteURL = "https://www.ahxinying.cn";
var isDevelopment = "development" === 'development';
/**
 * 初始化iconfont
 * @return {[type]} [description]
 */
function initIconFont() {
  var domModule = weex.requireModule('dom');
  domModule.addRule('fontFace', {
    'fontFamily': 'iconfont',
    'src': "url('" + resLocateURL + "resource/fonts/iconfont.ttf')"
  });
}
// 获取本地资源
function locate(url) {
  var newUrl = resLocateURL + url;
  return newUrl;
}
// 获取远程资源
function remote(url) {
  var newUrl = resRemoteURL + url;
  return newUrl;
}
// 获取网站资源
function website(url) {
  var newUrl = websiteURL + url;
  return newUrl;
}
// 获取URL参数
function getUrlParameter(name, dataUrl) {
  var url = void 0;
  if (dataUrl === null || dataUrl === undefined || dataUrl === '') {
    url = weex.config.bundleUrl;
  } else {
    url = dataUrl;
  }
  var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
  var r = url.slice(url.indexOf('?') + 1).match(reg);
  if (r !== null) {
    try {
      return decodeURIComponent(r[2]);
    } catch (_e) {
      return null;
    }
  }
  return null;
}
// 返回给定或当前url中的尾串(whole query string)
function gerUrlQueryString(url) {
  url = url || weex.config.bundleUrl;
  var seIndex = url.indexOf('?');
  if (seIndex >= 0) {
    return url.slice(seIndex + 1);
  } else {
    return '';
  }
}
function message(_type, _content, _data) {
  return {
    type: _type,
    content: _content,
    data: _data
  };
}
// 判空
function isNull(value) {
  if (value === null || value === undefined || value === '' || value === 'undefined') {
    return true;
  } else {
    return false;
  }
}
// 把缩略图过滤为原图
function filterThumbnail(url) {
  if (this.isNull(url)) {
    return url;
  }
  if (url.indexOf('?x-oss-') !== -1) {
    url = url.substring(0, url.indexOf('?x-oss-'));
  } else if (url.indexOf('@') !== -1) {
    url = url.substring(0, url.indexOf('@'));
  }
  return url;
}
// 获取缩略图
function thumbnail(url, w, h) {
  if (this.isNull(url)) {
    return url;
  }
  // 获取屏幕宽度计算得出比例
  var proportion = weex.config.env.deviceWidth / 750;
  // 获取缩略图的宽高
  w = parseInt(w * proportion);
  h = parseInt(h * proportion);
  if (url.substring(0, 11) === "http://cdnx") {
    return url + "?x-oss-process=image/resize,m_fill,w_" + w + ",h_" + h + "";
  } else if (url.substring(0, 10) === "http://cdn") {
    return url + "@" + w + "w_" + h + "h_1e_1c_100Q";
  } else {
    return url;
  }
}
// 获取全屏的高度尺寸,可传入父组件的导航栏高度进行适配
function fullScreen(topHeight) {
  // 减1是为了能触发loading，不能够高度刚刚好
  topHeight = topHeight == '' ? 0 : topHeight - 1;
  return 750 / weex.config.env.deviceWidth * weex.config.env.deviceHeight - topHeight;
}
// 模糊图片，r, s  为 1-50，超大超模糊
function blur(url, r, s) {
  if (this.isNull(url)) {
    return url;
  }
  if (url.substring(0, 10) == "http://cdn") {
    return url + "@" + r + "-" + s + "bl";
  } else {
    return url;
  }
}
// 获取文章URL地址
function articleUrl(template, id) {
  template = template == '' ? 't1001' : template;
  return websiteURL + "/weexsite/#/" + template + "?id=" + id;
}
// 获取优惠券的地址
function couponUrl(id) {
  return websiteURL + "/weexsite/#/couponView?id=" + id;
}
function debug(msg) {
  if (isDevelopment) {
    event.toast(msg);
  }
}
function isRoles(roles, all) {
  for (var i = 0; i < roles.length; i++) {
    var role = roles.substring(i, i + 1);
    if (all.indexOf(role) >= 0) {
      return true;
    }
  }
  return false;
}
//  获取字符串的字符总长度
function getLength(e) {
  var name = e;
  var len = 0;
  for (var i = 0; i < name.length; i++) {
    var a = name.charAt(i);
    if (a.match(/[^\x00-\xff]/ig) != null) {
      len += 2;
    } else {
      len += 1;
    }
  }
  return len;
}
//    将过长的字符串换成 XXX...格式 默认取前7个字符
function changeStrLast(value, length, maxLength) {
  length = this.isNull(length) ? 7 : length;
  maxLength = this.isNull(maxLength) ? 16 : maxLength;
  //              如果用户名称过长，便截取拼成名字
  if (this.getLength(value) > maxLength) {
    value = value.substr(0, length) + '...';
  }
  return value;
}
//    将过长的字符串取前几位 默认取前7个字符
function changeStrLastDote(value, length, maxLength) {
  length = this.isNull(length) ? 7 : length;
  maxLength = this.isNull(maxLength) ? 16 : maxLength;
  //              如果用户名称过长，便截取拼成名字
  if (this.getLength(value) > maxLength) {
    value = value.substr(0, length);
  }
  return value;
}
//    将过长的字符串换成 XXX...XXX格式
function changeStr(e) {
  return e.substr(0, 4) + '...' + e.substr(-4);
}
// js中用正则表达式 过滤特殊字符, 校验所有输入域是否含有特殊符号 (无法过滤 \ )
//  searchFilter(s) {
//         event.toast(s)
//         var pattern = new RegExp("[`~!@#$^&*()=|{}':',\\[\\].<>/?~！@#￥……&*（）&mdash—|{}【】‘；：”“'。，、？]")
//         var rs = ""
//         for (var i = 0 i < s.length i++) {
//             rs = rs + s.substr(i, 1).replace(pattern,'')
//         }
//         return rs
//     }
// 老的二维码转换成新格式
function qr2scan(e) {
  var type = this.getUrlParameter("type", e);
  var code = this.getUrlParameter("no", e);
  if (type == "paybill") {
    return websiteURL + "/q/818804" + code + ".jhtml";
  } else if (type == "card_active") {
    return websiteURL + "/q/818803" + code + ".jhtml";
  } else {
    return e;
  }
}
//    二维码读取内容
function readScan(e, callback) {
  e = this.qr2scan(e);
  var backData = {};
  // 二维码字段截取. indexOf 没找到时返回-1， 此时如果2个indexof都没找到 那么 e.substring（-1 + 3 ，-1）,e的长度会变为2
  // let subData = e.substring(e.indexOf("/q/8") + 3,e.indexOf(".jhtml"))
  var start = e.indexOf("/q/8");
  var end = e.indexOf(".jhtml");
  var subData = null;
  if (start != -1 && end != -1) {
    subData = e.substring(start + 3, end);
  }
  // 判断是不是web  code'000000'为无效二维码 '999999'为webView；
  if (subData == null) {
    // 如果没有找到q/ 和 .jhtml中的字端，就执行该段代码
    if (e.substring(0, 4) == 'http' && isDevelopment) {
      var data = {
        type: 'webView',
        code: '999999'
      };
      backData = this.message('success', 'webView', data);
    } else {
      var _data2 = {
        type: 'error',
        code: '000000'
      };
      backData = this.message('error', '无效二维码', _data2);
    }
    callback(backData);
  } else {
    // 截取11位的判断码
    var type = subData.substring(0, 6);
    var code = subData.slice(6);
    var _data3 = {
      type: type,
      code: code
    };
    if (code == '000000') {
      backData = this.message('error', '无效二维码', _data3);
    } else {
      backData = this.message('success', '扫描成功', _data3);
    }
    callback(backData);
  }
}
// 判断用户是否只输入了空格
function isAllEmpty(str) {
  if (str.replace(/ /g, "").length == 0) {
    return true;
  } else {
    return false;
  }
}
// 判断设备型号
function device() {
  var s = weex.config.env.deviceModel;
  if (this.isNull(s)) {
    return "";
  } else {
    if (s.indexOf("V1") > 0) {
      return "V1";
    } else if (s.indexOf("10,3") > 0 || s.indexOf("10,6") > 0) {
      return 'IPhoneX';
    } else {
      return s;
    }
  }
}
//    登录主页的轮播图控制
function indexMt() {
  var s = this.device();
  if (this.isNull(s)) {
    return "";
  } else {
    if (s == 'V1') {
      return 'indexMtV1';
    } else if (s == 'IPhoneX') {
      return 'indexMtIPhoneX';
    } else {
      return s;
    }
  }
}
//    登录主页的轮播图slider控制
function indexMtSlider() {
  var s = this.device();
  if (this.isNull(s)) {
    return "";
  } else {
    if (s === 'IPhoneX') {
      return 'indexSliderMtIPhoneX';
    } else if (this.isIosSystem()) {
      return 'indexSliderMtIPhone';
    } else {
      return s;
    }
  }
}
//    判断设备型号为fix定位的元素添加高度 (会员首页 作者专栏 顶部设置跟返回按钮)
function addTop() {
  var s = this.device();
  if (this.isNull(s)) {
    return "";
  } else {
    if (s === 'V1') {
      return 'addTopV1';
    } else if (s === 'IPhoneX') {
      return 'addTopIPhoneX';
    } else {
      return s;
    }
  }
}
//   会员首页 作者专栏 顶部信息栏
function addInfo() {
  var s = this.device();
  if (this.isNull(s)) {
    return "";
  } else {
    if (s === 'V1') {
      return 'addInfoV1';
    } else if (s === 'IPhoneX') {
      return 'addInfoIPhoneX';
    } else {
      return s;
    }
  }
}
//    判断设备型号为fix定位的元素添加高度 (会员首页 作者专栏 顶部设置跟返回按钮)
function addBgImg() {
  var s = this.device();
  if (this.isNull(s)) {
    return "";
  } else {
    if (s == 'V1') {
      return 'addBgImgV1';
    } else if (s == 'IPhoneX') {
      return 'addBgImgIPhoneX';
    } else {
      return s;
    }
  }
}
//    控制滑动时文集box的显示
function hideCorpus() {
  var s = this.device();
  if (this.isNull(s)) {
    return "";
  } else {
    if (s == 'V1') {
      return 'hideCorpusV1';
    } else if (s == 'IPhoneX') {
      return 'hideCorpusIPhoneX';
    } else {
      return s;
    }
  }
}
//    控制滑动时文集box的显示
function pageTop() {
  var s = this.device();
  if (this.isNull(s)) {
    return "";
  } else {
    if (s == 'V1') {
      return 'pageTopV1';
    } else if (s == 'IPhoneX') {
      return 'pageTopIPhoneX';
    } else {
      return s;
    }
  }
}
//    控制preview文章box的top
function artOutTop() {
  var s = this.device();
  if (this.isNull(s)) {
    return "";
  } else {
    if (s == 'V1') {
      return 'artOutBoxTopV1';
    } else if (s == 'IPhoneX') {
      return 'artOutBoxTopIPhoneX';
    } else {
      return s;
    }
  }
}
//    控制预览文章页底部栏的bottom高度
function previewBottom() {
  var s = this.device();
  if (this.isNull(s)) {
    return '';
  } else {
    if (s == 'IPhoneX') {
      return s;
    } else {
      return '';
    }
  }
}
// 判断设备系统是不是ios
function isIosSystem() {
  var s = weex.config.env.osName;
  if (s == 'iOS') {
    return true;
  } else {
    return false;
  }
}
function resolvetimefmt(value) {
  if (this.isNull(value)) {
    return value;
  }
  // value 传进来是个整数型，要判断是10位还是13位需要转成字符串。这边的方法是检测13位的时间戳 所以要*1000；并且转回整型。安卓下，时间早了8个小时
  if (value.toString().length == 10) {
    value = parseInt(value) * 1000;
  } else {
    value = parseInt(value);
  }
  // 返回处理后的值
  var date = new Date(value);
  var d2 = Date.UTC(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate(), date.getUTCHours(), date.getUTCMinutes(), date.getUTCSeconds());
  date = new Date(d2 + 28800000);
  var y = date.getUTCFullYear();
  var m = date.getUTCMonth() + 1;
  var d = date.getUTCDate();
  var h = date.getUTCHours();
  var i = date.getUTCMinutes();
  var s = date.getUTCSeconds();
  if (m < 10) {
    m = '0' + m;
  }
  if (d < 10) {
    d = '0' + d;
  }
  if (h < 10) {
    h = '0' + h;
  }
  if (i < 10) {
    i = '0' + i;
  }
  if (s < 10) {
    s = '0' + s;
  }
  var timeObj = {
    y: y,
    m: m,
    d: d,
    h: h,
    i: i,
    s: s
  };
  return timeObj;
}
// 返回格式 2017-09-01
function ymdtimefmt(value) {
  if (value == '' || value == null || value == undefined) {
    return value;
  }
  var timeObj = this.resolvetimefmt(value);
  return timeObj.y + '-' + timeObj.m + '-' + timeObj.d;
}
// 返回格式 2017-09-01 06:35:59
function ymdhistimefmt(value) {
  if (value == '' || value == null || value == undefined) {
    return value;
  }
  var timeObj = this.resolvetimefmt(value);
  return timeObj.y + '-' + timeObj.m + '-' + timeObj.d + ' ' + timeObj.h + ':' + timeObj.i + ':' + timeObj.s;
}
// 返回格式 2017年09月01日 06:35:59
function ymdhisdayfmt(value) {
  if (value == '' || value == null || value == undefined) {
    return value;
  }
  var timeObj = this.resolvetimefmt(value);
  return timeObj.y + '年' + timeObj.m + '月' + timeObj.d + '日 ' + timeObj.h + ':' + timeObj.i + ':' + timeObj.s;
}
// 返回格式 06:35:59
function histimefmt(value) {
  if (value == '' || value == null || value == undefined) {
    return value;
  }
  var timeObj = this.resolvetimefmt(value);
  return timeObj.h + ':' + timeObj.i + ':' + timeObj.s;
}
// 过滤表情
function filteremoji(text, type) {
  var ranges = ['\uD83C[\uDF00-\uDFFF]', '\uD83D[\uDC00-\uDE4F]', '\uD83D[\uDE80-\uDEFF]'];
  text = text.replace(new RegExp(ranges.join('|'), 'g'), '');
  if (this.isNull(text) && type == 'article') {
    return '点击设置标题';
  }
  return text;
}
// 金额保留两位小数点
function currencyfmt(value) {
  if (value == '' || value == null || value == undefined) {
    return value;
  }
  // 返回处理后的值
  if (value != null) {
    if (value == 0) {
      return value;
    } else {
      var price = (Math.round(value * Math.pow(10, 2)) / Math.pow(10, 2)).toFixed(2);
      return price;
    }
  }
}
/**
 * 获取当前位置经纬度
 * @return {[type]} [description]
 */
function getCurLocation() {
  return new _promise2.default(function (resolve, reject) {
    event.getLocation(function (res) {
      if (res.type === 'success') {
        var resData = res.data;
        // resData.lat // 纬度
        // resData.lng // 经度
        if (resData.lat && resData.lng) {
          resolve({
            type: 'success',
            content: '地址获取成功',
            data: {
              lat: resData.lat,
              lng: resData.lng
            }
          });
        } else {
          reject({
            type: 'error',
            content: '经纬度获取失败'
          });
        }
      } else {
        reject({
          type: 'error',
          content: '经纬度获取失败'
        });
      }
    });
  });
}
/**
 * 获取高德地图sdk key
 * @return {[type]} [description]
 */
function getAmapKeys() {
  return {
    ios: "6d97eee2092d44233d8b326a33a08d61",
    android: "b6b33af45fdaf6b44f3155a197ab70d8"
  };
}

/***/ }),

/***/ 19:
/***/ (function(module, exports) {



/***/ }),

/***/ 2:
/***/ (function(module, exports) {

var core = module.exports = { version: '2.5.7' };
if (typeof __e == 'number') __e = core; // eslint-disable-line no-undef


/***/ }),

/***/ 20:
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(68);
var global = __webpack_require__(0);
var hide = __webpack_require__(6);
var Iterators = __webpack_require__(11);
var TO_STRING_TAG = __webpack_require__(1)('toStringTag');

var DOMIterables = ('CSSRuleList,CSSStyleDeclaration,CSSValueList,ClientRectList,DOMRectList,DOMStringList,' +
  'DOMTokenList,DataTransferItemList,FileList,HTMLAllCollection,HTMLCollection,HTMLFormElement,HTMLSelectElement,' +
  'MediaList,MimeTypeArray,NamedNodeMap,NodeList,PaintRequestList,Plugin,PluginArray,SVGLengthList,SVGNumberList,' +
  'SVGPathSegList,SVGPointList,SVGStringList,SVGTransformList,SourceBufferList,StyleSheetList,TextTrackCueList,' +
  'TextTrackList,TouchList').split(',');

for (var i = 0; i < DOMIterables.length; i++) {
  var NAME = DOMIterables[i];
  var Collection = global[NAME];
  var proto = Collection && Collection.prototype;
  if (proto && !proto[TO_STRING_TAG]) hide(proto, TO_STRING_TAG, NAME);
  Iterators[NAME] = Iterators.Array;
}


/***/ }),

/***/ 21:
/***/ (function(module, exports, __webpack_require__) {

var ctx = __webpack_require__(10);
var call = __webpack_require__(71);
var isArrayIter = __webpack_require__(72);
var anObject = __webpack_require__(3);
var toLength = __webpack_require__(35);
var getIterFn = __webpack_require__(55);
var BREAK = {};
var RETURN = {};
var exports = module.exports = function (iterable, entries, fn, that, ITERATOR) {
  var iterFn = ITERATOR ? function () { return iterable; } : getIterFn(iterable);
  var f = ctx(fn, that, entries ? 2 : 1);
  var index = 0;
  var length, step, iterator, result;
  if (typeof iterFn != 'function') throw TypeError(iterable + ' is not iterable!');
  // fast case for arrays with default iterator
  if (isArrayIter(iterFn)) for (length = toLength(iterable.length); length > index; index++) {
    result = entries ? f(anObject(step = iterable[index])[0], step[1]) : f(iterable[index]);
    if (result === BREAK || result === RETURN) return result;
  } else for (iterator = iterFn.call(iterable); !(step = iterator.next()).done;) {
    result = call(iterator, f, step.value, entries);
    if (result === BREAK || result === RETURN) return result;
  }
};
exports.BREAK = BREAK;
exports.RETURN = RETURN;


/***/ }),

/***/ 22:
/***/ (function(module, exports) {

// 7.1.4 ToInteger
var ceil = Math.ceil;
var floor = Math.floor;
module.exports = function (it) {
  return isNaN(it = +it) ? 0 : (it > 0 ? floor : ceil)(it);
};


/***/ }),

/***/ 23:
/***/ (function(module, exports) {

// 7.2.1 RequireObjectCoercible(argument)
module.exports = function (it) {
  if (it == undefined) throw TypeError("Can't call method on  " + it);
  return it;
};


/***/ }),

/***/ 24:
/***/ (function(module, exports, __webpack_require__) {

var isObject = __webpack_require__(4);
var document = __webpack_require__(0).document;
// typeof document.createElement is 'object' in old IE
var is = isObject(document) && isObject(document.createElement);
module.exports = function (it) {
  return is ? document.createElement(it) : {};
};


/***/ }),

/***/ 25:
/***/ (function(module, exports, __webpack_require__) {

var shared = __webpack_require__(32)('keys');
var uid = __webpack_require__(28);
module.exports = function (key) {
  return shared[key] || (shared[key] = uid(key));
};


/***/ }),

/***/ 26:
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// 25.4.1.5 NewPromiseCapability(C)
var aFunction = __webpack_require__(14);

function PromiseCapability(C) {
  var resolve, reject;
  this.promise = new C(function ($$resolve, $$reject) {
    if (resolve !== undefined || reject !== undefined) throw TypeError('Bad Promise constructor');
    resolve = $$resolve;
    reject = $$reject;
  });
  this.resolve = aFunction(resolve);
  this.reject = aFunction(reject);
}

module.exports.f = function (C) {
  return new PromiseCapability(C);
};


/***/ }),

/***/ 27:
/***/ (function(module, exports) {

module.exports = function (bitmap, value) {
  return {
    enumerable: !(bitmap & 1),
    configurable: !(bitmap & 2),
    writable: !(bitmap & 4),
    value: value
  };
};


/***/ }),

/***/ 28:
/***/ (function(module, exports) {

var id = 0;
var px = Math.random();
module.exports = function (key) {
  return 'Symbol('.concat(key === undefined ? '' : key, ')_', (++id + px).toString(36));
};


/***/ }),

/***/ 29:
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $at = __webpack_require__(63)(true);

// 21.1.3.27 String.prototype[@@iterator]()
__webpack_require__(34)(String, 'String', function (iterated) {
  this._t = String(iterated); // target
  this._i = 0;                // next index
// 21.1.5.2.1 %StringIteratorPrototype%.next()
}, function () {
  var O = this._t;
  var index = this._i;
  var point;
  if (index >= O.length) return { value: undefined, done: true };
  point = $at(O, index);
  this._i += point.length;
  return { value: point, done: false };
});


/***/ }),

/***/ 3:
/***/ (function(module, exports, __webpack_require__) {

var isObject = __webpack_require__(4);
module.exports = function (it) {
  if (!isObject(it)) throw TypeError(it + ' is not an object!');
  return it;
};


/***/ }),

/***/ 30:
/***/ (function(module, exports, __webpack_require__) {

// 19.1.2.14 / 15.2.3.14 Object.keys(O)
var $keys = __webpack_require__(52);
var enumBugKeys = __webpack_require__(33);

module.exports = Object.keys || function keys(O) {
  return $keys(O, enumBugKeys);
};


/***/ }),

/***/ 31:
/***/ (function(module, exports, __webpack_require__) {

// 7.1.13 ToObject(argument)
var defined = __webpack_require__(23);
module.exports = function (it) {
  return Object(defined(it));
};


/***/ }),

/***/ 32:
/***/ (function(module, exports, __webpack_require__) {

var core = __webpack_require__(2);
var global = __webpack_require__(0);
var SHARED = '__core-js_shared__';
var store = global[SHARED] || (global[SHARED] = {});

(module.exports = function (key, value) {
  return store[key] || (store[key] = value !== undefined ? value : {});
})('versions', []).push({
  version: core.version,
  mode: __webpack_require__(16) ? 'pure' : 'global',
  copyright: '© 2018 Denis Pushkarev (zloirock.ru)'
});


/***/ }),

/***/ 33:
/***/ (function(module, exports) {

// IE 8- don't enum bug keys
module.exports = (
  'constructor,hasOwnProperty,isPrototypeOf,propertyIsEnumerable,toLocaleString,toString,valueOf'
).split(',');


/***/ }),

/***/ 34:
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var LIBRARY = __webpack_require__(16);
var $export = __webpack_require__(5);
var redefine = __webpack_require__(47);
var hide = __webpack_require__(6);
var Iterators = __webpack_require__(11);
var $iterCreate = __webpack_require__(64);
var setToStringTag = __webpack_require__(17);
var getPrototypeOf = __webpack_require__(53);
var ITERATOR = __webpack_require__(1)('iterator');
var BUGGY = !([].keys && 'next' in [].keys()); // Safari has buggy iterators w/o `next`
var FF_ITERATOR = '@@iterator';
var KEYS = 'keys';
var VALUES = 'values';

var returnThis = function () { return this; };

module.exports = function (Base, NAME, Constructor, next, DEFAULT, IS_SET, FORCED) {
  $iterCreate(Constructor, NAME, next);
  var getMethod = function (kind) {
    if (!BUGGY && kind in proto) return proto[kind];
    switch (kind) {
      case KEYS: return function keys() { return new Constructor(this, kind); };
      case VALUES: return function values() { return new Constructor(this, kind); };
    } return function entries() { return new Constructor(this, kind); };
  };
  var TAG = NAME + ' Iterator';
  var DEF_VALUES = DEFAULT == VALUES;
  var VALUES_BUG = false;
  var proto = Base.prototype;
  var $native = proto[ITERATOR] || proto[FF_ITERATOR] || DEFAULT && proto[DEFAULT];
  var $default = $native || getMethod(DEFAULT);
  var $entries = DEFAULT ? !DEF_VALUES ? $default : getMethod('entries') : undefined;
  var $anyNative = NAME == 'Array' ? proto.entries || $native : $native;
  var methods, key, IteratorPrototype;
  // Fix native
  if ($anyNative) {
    IteratorPrototype = getPrototypeOf($anyNative.call(new Base()));
    if (IteratorPrototype !== Object.prototype && IteratorPrototype.next) {
      // Set @@toStringTag to native iterators
      setToStringTag(IteratorPrototype, TAG, true);
      // fix for some old engines
      if (!LIBRARY && typeof IteratorPrototype[ITERATOR] != 'function') hide(IteratorPrototype, ITERATOR, returnThis);
    }
  }
  // fix Array#{values, @@iterator}.name in V8 / FF
  if (DEF_VALUES && $native && $native.name !== VALUES) {
    VALUES_BUG = true;
    $default = function values() { return $native.call(this); };
  }
  // Define iterator
  if ((!LIBRARY || FORCED) && (BUGGY || VALUES_BUG || !proto[ITERATOR])) {
    hide(proto, ITERATOR, $default);
  }
  // Plug for library
  Iterators[NAME] = $default;
  Iterators[TAG] = returnThis;
  if (DEFAULT) {
    methods = {
      values: DEF_VALUES ? $default : getMethod(VALUES),
      keys: IS_SET ? $default : getMethod(KEYS),
      entries: $entries
    };
    if (FORCED) for (key in methods) {
      if (!(key in proto)) redefine(proto, key, methods[key]);
    } else $export($export.P + $export.F * (BUGGY || VALUES_BUG), NAME, methods);
  }
  return methods;
};


/***/ }),

/***/ 35:
/***/ (function(module, exports, __webpack_require__) {

// 7.1.15 ToLength
var toInteger = __webpack_require__(22);
var min = Math.min;
module.exports = function (it) {
  return it > 0 ? min(toInteger(it), 0x1fffffffffffff) : 0; // pow(2, 53) - 1 == 9007199254740991
};


/***/ }),

/***/ 36:
/***/ (function(module, exports, __webpack_require__) {

// getting tag from 19.1.3.6 Object.prototype.toString()
var cof = __webpack_require__(13);
var TAG = __webpack_require__(1)('toStringTag');
// ES3 wrong here
var ARG = cof(function () { return arguments; }()) == 'Arguments';

// fallback for IE11 Script Access Denied error
var tryGet = function (it, key) {
  try {
    return it[key];
  } catch (e) { /* empty */ }
};

module.exports = function (it) {
  var O, T, B;
  return it === undefined ? 'Undefined' : it === null ? 'Null'
    // @@toStringTag case
    : typeof (T = tryGet(O = Object(it), TAG)) == 'string' ? T
    // builtinTag case
    : ARG ? cof(O)
    // ES3 arguments fallback
    : (B = cof(O)) == 'Object' && typeof O.callee == 'function' ? 'Arguments' : B;
};


/***/ }),

/***/ 37:
/***/ (function(module, exports, __webpack_require__) {

module.exports = { "default": __webpack_require__(62), __esModule: true };

/***/ }),

/***/ 38:
/***/ (function(module, exports) {

module.exports = function (it, Constructor, name, forbiddenField) {
  if (!(it instanceof Constructor) || (forbiddenField !== undefined && forbiddenField in it)) {
    throw TypeError(name + ': incorrect invocation!');
  } return it;
};


/***/ }),

/***/ 39:
/***/ (function(module, exports, __webpack_require__) {

var hide = __webpack_require__(6);
module.exports = function (target, src, safe) {
  for (var key in src) {
    if (safe && target[key]) target[key] = src[key];
    else hide(target, key, src[key]);
  } return target;
};


/***/ }),

/***/ 4:
/***/ (function(module, exports) {

module.exports = function (it) {
  return typeof it === 'object' ? it !== null : typeof it === 'function';
};


/***/ }),

/***/ 40:
/***/ (function(module, exports, __webpack_require__) {

var document = __webpack_require__(0).document;
module.exports = document && document.documentElement;


/***/ }),

/***/ 41:
/***/ (function(module, exports, __webpack_require__) {

// 7.3.20 SpeciesConstructor(O, defaultConstructor)
var anObject = __webpack_require__(3);
var aFunction = __webpack_require__(14);
var SPECIES = __webpack_require__(1)('species');
module.exports = function (O, D) {
  var C = anObject(O).constructor;
  var S;
  return C === undefined || (S = anObject(C)[SPECIES]) == undefined ? D : aFunction(S);
};


/***/ }),

/***/ 42:
/***/ (function(module, exports, __webpack_require__) {

var ctx = __webpack_require__(10);
var invoke = __webpack_require__(73);
var html = __webpack_require__(40);
var cel = __webpack_require__(24);
var global = __webpack_require__(0);
var process = global.process;
var setTask = global.setImmediate;
var clearTask = global.clearImmediate;
var MessageChannel = global.MessageChannel;
var Dispatch = global.Dispatch;
var counter = 0;
var queue = {};
var ONREADYSTATECHANGE = 'onreadystatechange';
var defer, channel, port;
var run = function () {
  var id = +this;
  // eslint-disable-next-line no-prototype-builtins
  if (queue.hasOwnProperty(id)) {
    var fn = queue[id];
    delete queue[id];
    fn();
  }
};
var listener = function (event) {
  run.call(event.data);
};
// Node.js 0.9+ & IE10+ has setImmediate, otherwise:
if (!setTask || !clearTask) {
  setTask = function setImmediate(fn) {
    var args = [];
    var i = 1;
    while (arguments.length > i) args.push(arguments[i++]);
    queue[++counter] = function () {
      // eslint-disable-next-line no-new-func
      invoke(typeof fn == 'function' ? fn : Function(fn), args);
    };
    defer(counter);
    return counter;
  };
  clearTask = function clearImmediate(id) {
    delete queue[id];
  };
  // Node.js 0.8-
  if (__webpack_require__(13)(process) == 'process') {
    defer = function (id) {
      process.nextTick(ctx(run, id, 1));
    };
  // Sphere (JS game engine) Dispatch API
  } else if (Dispatch && Dispatch.now) {
    defer = function (id) {
      Dispatch.now(ctx(run, id, 1));
    };
  // Browsers with MessageChannel, includes WebWorkers
  } else if (MessageChannel) {
    channel = new MessageChannel();
    port = channel.port2;
    channel.port1.onmessage = listener;
    defer = ctx(port.postMessage, port, 1);
  // Browsers with postMessage, skip WebWorkers
  // IE8 has postMessage, but it's sync & typeof its postMessage is 'object'
  } else if (global.addEventListener && typeof postMessage == 'function' && !global.importScripts) {
    defer = function (id) {
      global.postMessage(id + '', '*');
    };
    global.addEventListener('message', listener, false);
  // IE8-
  } else if (ONREADYSTATECHANGE in cel('script')) {
    defer = function (id) {
      html.appendChild(cel('script'))[ONREADYSTATECHANGE] = function () {
        html.removeChild(this);
        run.call(id);
      };
    };
  // Rest old browsers
  } else {
    defer = function (id) {
      setTimeout(ctx(run, id, 1), 0);
    };
  }
}
module.exports = {
  set: setTask,
  clear: clearTask
};


/***/ }),

/***/ 43:
/***/ (function(module, exports) {

module.exports = function (exec) {
  try {
    return { e: false, v: exec() };
  } catch (e) {
    return { e: true, v: e };
  }
};


/***/ }),

/***/ 44:
/***/ (function(module, exports, __webpack_require__) {

var anObject = __webpack_require__(3);
var isObject = __webpack_require__(4);
var newPromiseCapability = __webpack_require__(26);

module.exports = function (C, x) {
  anObject(C);
  if (isObject(x) && x.constructor === C) return x;
  var promiseCapability = newPromiseCapability.f(C);
  var resolve = promiseCapability.resolve;
  resolve(x);
  return promiseCapability.promise;
};


/***/ }),

/***/ 46:
/***/ (function(module, exports, __webpack_require__) {

// 7.1.1 ToPrimitive(input [, PreferredType])
var isObject = __webpack_require__(4);
// instead of the ES6 spec version, we didn't implement @@toPrimitive case
// and the second argument - flag - preferred type is a string
module.exports = function (it, S) {
  if (!isObject(it)) return it;
  var fn, val;
  if (S && typeof (fn = it.toString) == 'function' && !isObject(val = fn.call(it))) return val;
  if (typeof (fn = it.valueOf) == 'function' && !isObject(val = fn.call(it))) return val;
  if (!S && typeof (fn = it.toString) == 'function' && !isObject(val = fn.call(it))) return val;
  throw TypeError("Can't convert object to primitive value");
};


/***/ }),

/***/ 47:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(6);


/***/ }),

/***/ 48:
/***/ (function(module, exports, __webpack_require__) {

// 19.1.2.2 / 15.2.3.5 Object.create(O [, Properties])
var anObject = __webpack_require__(3);
var dPs = __webpack_require__(65);
var enumBugKeys = __webpack_require__(33);
var IE_PROTO = __webpack_require__(25)('IE_PROTO');
var Empty = function () { /* empty */ };
var PROTOTYPE = 'prototype';

// Create object with fake `null` prototype: use iframe Object with cleared prototype
var createDict = function () {
  // Thrash, waste and sodomy: IE GC bug
  var iframe = __webpack_require__(24)('iframe');
  var i = enumBugKeys.length;
  var lt = '<';
  var gt = '>';
  var iframeDocument;
  iframe.style.display = 'none';
  __webpack_require__(40).appendChild(iframe);
  iframe.src = 'javascript:'; // eslint-disable-line no-script-url
  // createDict = iframe.contentWindow.Object;
  // html.removeChild(iframe);
  iframeDocument = iframe.contentWindow.document;
  iframeDocument.open();
  iframeDocument.write(lt + 'script' + gt + 'document.F=Object' + lt + '/script' + gt);
  iframeDocument.close();
  createDict = iframeDocument.F;
  while (i--) delete createDict[PROTOTYPE][enumBugKeys[i]];
  return createDict();
};

module.exports = Object.create || function create(O, Properties) {
  var result;
  if (O !== null) {
    Empty[PROTOTYPE] = anObject(O);
    result = new Empty();
    Empty[PROTOTYPE] = null;
    // add "__proto__" for Object.getPrototypeOf polyfill
    result[IE_PROTO] = O;
  } else result = createDict();
  return Properties === undefined ? result : dPs(result, Properties);
};


/***/ }),

/***/ 49:
/***/ (function(module, exports, __webpack_require__) {

// fallback for non-array-like ES3 and non-enumerable old V8 strings
var cof = __webpack_require__(13);
// eslint-disable-next-line no-prototype-builtins
module.exports = Object('z').propertyIsEnumerable(0) ? Object : function (it) {
  return cof(it) == 'String' ? it.split('') : Object(it);
};


/***/ }),

/***/ 5:
/***/ (function(module, exports, __webpack_require__) {

var global = __webpack_require__(0);
var core = __webpack_require__(2);
var ctx = __webpack_require__(10);
var hide = __webpack_require__(6);
var has = __webpack_require__(9);
var PROTOTYPE = 'prototype';

var $export = function (type, name, source) {
  var IS_FORCED = type & $export.F;
  var IS_GLOBAL = type & $export.G;
  var IS_STATIC = type & $export.S;
  var IS_PROTO = type & $export.P;
  var IS_BIND = type & $export.B;
  var IS_WRAP = type & $export.W;
  var exports = IS_GLOBAL ? core : core[name] || (core[name] = {});
  var expProto = exports[PROTOTYPE];
  var target = IS_GLOBAL ? global : IS_STATIC ? global[name] : (global[name] || {})[PROTOTYPE];
  var key, own, out;
  if (IS_GLOBAL) source = name;
  for (key in source) {
    // contains in native
    own = !IS_FORCED && target && target[key] !== undefined;
    if (own && has(exports, key)) continue;
    // export native or passed
    out = own ? target[key] : source[key];
    // prevent global pollution for namespaces
    exports[key] = IS_GLOBAL && typeof target[key] != 'function' ? source[key]
    // bind timers to global for call from export context
    : IS_BIND && own ? ctx(out, global)
    // wrap global constructors for prevent change them in library
    : IS_WRAP && target[key] == out ? (function (C) {
      var F = function (a, b, c) {
        if (this instanceof C) {
          switch (arguments.length) {
            case 0: return new C();
            case 1: return new C(a);
            case 2: return new C(a, b);
          } return new C(a, b, c);
        } return C.apply(this, arguments);
      };
      F[PROTOTYPE] = C[PROTOTYPE];
      return F;
    // make static versions for prototype methods
    })(out) : IS_PROTO && typeof out == 'function' ? ctx(Function.call, out) : out;
    // export proto methods to core.%CONSTRUCTOR%.methods.%NAME%
    if (IS_PROTO) {
      (exports.virtual || (exports.virtual = {}))[key] = out;
      // export proto methods to core.%CONSTRUCTOR%.prototype.%NAME%
      if (type & $export.R && expProto && !expProto[key]) hide(expProto, key, out);
    }
  }
};
// type bitmap
$export.F = 1;   // forced
$export.G = 2;   // global
$export.S = 4;   // static
$export.P = 8;   // proto
$export.B = 16;  // bind
$export.W = 32;  // wrap
$export.U = 64;  // safe
$export.R = 128; // real proto method for `library`
module.exports = $export;


/***/ }),

/***/ 51:
/***/ (function(module, exports, __webpack_require__) {

module.exports = !__webpack_require__(7) && !__webpack_require__(12)(function () {
  return Object.defineProperty(__webpack_require__(24)('div'), 'a', { get: function () { return 7; } }).a != 7;
});


/***/ }),

/***/ 52:
/***/ (function(module, exports, __webpack_require__) {

var has = __webpack_require__(9);
var toIObject = __webpack_require__(15);
var arrayIndexOf = __webpack_require__(66)(false);
var IE_PROTO = __webpack_require__(25)('IE_PROTO');

module.exports = function (object, names) {
  var O = toIObject(object);
  var i = 0;
  var result = [];
  var key;
  for (key in O) if (key != IE_PROTO) has(O, key) && result.push(key);
  // Don't enum bug & hidden keys
  while (names.length > i) if (has(O, key = names[i++])) {
    ~arrayIndexOf(result, key) || result.push(key);
  }
  return result;
};


/***/ }),

/***/ 53:
/***/ (function(module, exports, __webpack_require__) {

// 19.1.2.9 / 15.2.3.2 Object.getPrototypeOf(O)
var has = __webpack_require__(9);
var toObject = __webpack_require__(31);
var IE_PROTO = __webpack_require__(25)('IE_PROTO');
var ObjectProto = Object.prototype;

module.exports = Object.getPrototypeOf || function (O) {
  O = toObject(O);
  if (has(O, IE_PROTO)) return O[IE_PROTO];
  if (typeof O.constructor == 'function' && O instanceof O.constructor) {
    return O.constructor.prototype;
  } return O instanceof Object ? ObjectProto : null;
};


/***/ }),

/***/ 54:
/***/ (function(module, exports) {

module.exports = function (done, value) {
  return { value: value, done: !!done };
};


/***/ }),

/***/ 55:
/***/ (function(module, exports, __webpack_require__) {

var classof = __webpack_require__(36);
var ITERATOR = __webpack_require__(1)('iterator');
var Iterators = __webpack_require__(11);
module.exports = __webpack_require__(2).getIteratorMethod = function (it) {
  if (it != undefined) return it[ITERATOR]
    || it['@@iterator']
    || Iterators[classof(it)];
};


/***/ }),

/***/ 56:
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var global = __webpack_require__(0);
var core = __webpack_require__(2);
var dP = __webpack_require__(8);
var DESCRIPTORS = __webpack_require__(7);
var SPECIES = __webpack_require__(1)('species');

module.exports = function (KEY) {
  var C = typeof core[KEY] == 'function' ? core[KEY] : global[KEY];
  if (DESCRIPTORS && C && !C[SPECIES]) dP.f(C, SPECIES, {
    configurable: true,
    get: function () { return this; }
  });
};


/***/ }),

/***/ 6:
/***/ (function(module, exports, __webpack_require__) {

var dP = __webpack_require__(8);
var createDesc = __webpack_require__(27);
module.exports = __webpack_require__(7) ? function (object, key, value) {
  return dP.f(object, key, createDesc(1, value));
} : function (object, key, value) {
  object[key] = value;
  return object;
};


/***/ }),

/***/ 62:
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(19);
__webpack_require__(29);
__webpack_require__(20);
__webpack_require__(70);
__webpack_require__(77);
__webpack_require__(78);
module.exports = __webpack_require__(2).Promise;


/***/ }),

/***/ 63:
/***/ (function(module, exports, __webpack_require__) {

var toInteger = __webpack_require__(22);
var defined = __webpack_require__(23);
// true  -> String#at
// false -> String#codePointAt
module.exports = function (TO_STRING) {
  return function (that, pos) {
    var s = String(defined(that));
    var i = toInteger(pos);
    var l = s.length;
    var a, b;
    if (i < 0 || i >= l) return TO_STRING ? '' : undefined;
    a = s.charCodeAt(i);
    return a < 0xd800 || a > 0xdbff || i + 1 === l || (b = s.charCodeAt(i + 1)) < 0xdc00 || b > 0xdfff
      ? TO_STRING ? s.charAt(i) : a
      : TO_STRING ? s.slice(i, i + 2) : (a - 0xd800 << 10) + (b - 0xdc00) + 0x10000;
  };
};


/***/ }),

/***/ 64:
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var create = __webpack_require__(48);
var descriptor = __webpack_require__(27);
var setToStringTag = __webpack_require__(17);
var IteratorPrototype = {};

// 25.1.2.1.1 %IteratorPrototype%[@@iterator]()
__webpack_require__(6)(IteratorPrototype, __webpack_require__(1)('iterator'), function () { return this; });

module.exports = function (Constructor, NAME, next) {
  Constructor.prototype = create(IteratorPrototype, { next: descriptor(1, next) });
  setToStringTag(Constructor, NAME + ' Iterator');
};


/***/ }),

/***/ 65:
/***/ (function(module, exports, __webpack_require__) {

var dP = __webpack_require__(8);
var anObject = __webpack_require__(3);
var getKeys = __webpack_require__(30);

module.exports = __webpack_require__(7) ? Object.defineProperties : function defineProperties(O, Properties) {
  anObject(O);
  var keys = getKeys(Properties);
  var length = keys.length;
  var i = 0;
  var P;
  while (length > i) dP.f(O, P = keys[i++], Properties[P]);
  return O;
};


/***/ }),

/***/ 66:
/***/ (function(module, exports, __webpack_require__) {

// false -> Array#indexOf
// true  -> Array#includes
var toIObject = __webpack_require__(15);
var toLength = __webpack_require__(35);
var toAbsoluteIndex = __webpack_require__(67);
module.exports = function (IS_INCLUDES) {
  return function ($this, el, fromIndex) {
    var O = toIObject($this);
    var length = toLength(O.length);
    var index = toAbsoluteIndex(fromIndex, length);
    var value;
    // Array#includes uses SameValueZero equality algorithm
    // eslint-disable-next-line no-self-compare
    if (IS_INCLUDES && el != el) while (length > index) {
      value = O[index++];
      // eslint-disable-next-line no-self-compare
      if (value != value) return true;
    // Array#indexOf ignores holes, Array#includes - not
    } else for (;length > index; index++) if (IS_INCLUDES || index in O) {
      if (O[index] === el) return IS_INCLUDES || index || 0;
    } return !IS_INCLUDES && -1;
  };
};


/***/ }),

/***/ 67:
/***/ (function(module, exports, __webpack_require__) {

var toInteger = __webpack_require__(22);
var max = Math.max;
var min = Math.min;
module.exports = function (index, length) {
  index = toInteger(index);
  return index < 0 ? max(index + length, 0) : min(index, length);
};


/***/ }),

/***/ 678:
/***/ (function(module, exports, __webpack_require__) {

var __vue_exports__, __vue_options__
var __vue_styles__ = []

/* styles */
__vue_styles__.push(__webpack_require__(679)
)
__vue_styles__.push(__webpack_require__(680)
)

/* script */
__vue_exports__ = __webpack_require__(681)

/* template */
var __vue_template__ = __webpack_require__(682)
__vue_options__ = __vue_exports__ = __vue_exports__ || {}
if (
  typeof __vue_exports__.default === "object" ||
  typeof __vue_exports__.default === "function"
) {
if (Object.keys(__vue_exports__).some(function (key) { return key !== "default" && key !== "__esModule" })) {console.error("named exports are not supported in *.vue files.")}
__vue_options__ = __vue_exports__ = __vue_exports__.default
}
if (typeof __vue_options__ === "function") {
  __vue_options__ = __vue_options__.options
}
__vue_options__.__file = "D:\\farmer\\src\\view\\staffEditor\\staffEditor.vue"
__vue_options__.render = __vue_template__.render
__vue_options__.staticRenderFns = __vue_template__.staticRenderFns
__vue_options__._scopeId = "data-v-7275d64d"
__vue_options__.style = __vue_options__.style || {}
__vue_styles__.forEach(function (module) {
  for (var name in module) {
    __vue_options__.style[name] = module[name]
  }
})
if (typeof __register_static_styles__ === "function") {
  __register_static_styles__(__vue_options__._scopeId, __vue_styles__)
}

module.exports = __vue_exports__
module.exports.el = 'true'
new Vue(module.exports)


/***/ }),

/***/ 679:
/***/ (function(module, exports) {

module.exports = {
  "ft6": {
    "fontSize": "6"
  },
  "ft7": {
    "fontSize": "7"
  },
  "ft8": {
    "fontSize": "8"
  },
  "ft9": {
    "fontSize": "9"
  },
  "ft10": {
    "fontSize": "10"
  },
  "ft11": {
    "fontSize": "11"
  },
  "ft12": {
    "fontSize": "12"
  },
  "ft13": {
    "fontSize": "13"
  },
  "ft14": {
    "fontSize": "14"
  },
  "ft15": {
    "fontSize": "15"
  },
  "ft16": {
    "fontSize": "16"
  },
  "ft17": {
    "fontSize": "17"
  },
  "ft18": {
    "fontSize": "18"
  },
  "ft19": {
    "fontSize": "19"
  },
  "ft20": {
    "fontSize": "20"
  },
  "ft21": {
    "fontSize": "21"
  },
  "ft22": {
    "fontSize": "22"
  },
  "ft23": {
    "fontSize": "23"
  },
  "ft24": {
    "fontSize": "24"
  },
  "ft25": {
    "fontSize": "25"
  },
  "ft26": {
    "fontSize": "26"
  },
  "ft27": {
    "fontSize": "27"
  },
  "ft28": {
    "fontSize": "28"
  },
  "ft29": {
    "fontSize": "29"
  },
  "ft30": {
    "fontSize": "30"
  },
  "ft31": {
    "fontSize": "31"
  },
  "ft32": {
    "fontSize": "32"
  },
  "ft33": {
    "fontSize": "33"
  },
  "ft34": {
    "fontSize": "34"
  },
  "ft35": {
    "fontSize": "35"
  },
  "ft36": {
    "fontSize": "36"
  },
  "ft37": {
    "fontSize": "37"
  },
  "ft38": {
    "fontSize": "38"
  },
  "ft39": {
    "fontSize": "39"
  },
  "ft40": {
    "fontSize": "40"
  },
  "ft41": {
    "fontSize": "41"
  },
  "ft42": {
    "fontSize": "42"
  },
  "ft43": {
    "fontSize": "43"
  },
  "ft44": {
    "fontSize": "44"
  },
  "ft45": {
    "fontSize": "45"
  },
  "ft46": {
    "fontSize": "46"
  },
  "ft47": {
    "fontSize": "47"
  },
  "ft48": {
    "fontSize": "48"
  },
  "ft49": {
    "fontSize": "49"
  },
  "ft50": {
    "fontSize": "50"
  },
  "ft51": {
    "fontSize": "51"
  },
  "ft52": {
    "fontSize": "52"
  },
  "ft53": {
    "fontSize": "53"
  },
  "ft54": {
    "fontSize": "54"
  },
  "ft55": {
    "fontSize": "55"
  },
  "ft56": {
    "fontSize": "56"
  },
  "ft57": {
    "fontSize": "57"
  },
  "ft58": {
    "fontSize": "58"
  },
  "ft59": {
    "fontSize": "59"
  },
  "ft60": {
    "fontSize": "60"
  },
  "ft61": {
    "fontSize": "61"
  },
  "ft62": {
    "fontSize": "62"
  },
  "ft63": {
    "fontSize": "63"
  },
  "ft64": {
    "fontSize": "64"
  },
  "ft65": {
    "fontSize": "65"
  },
  "ft66": {
    "fontSize": "66"
  },
  "ft67": {
    "fontSize": "67"
  },
  "ft68": {
    "fontSize": "68"
  },
  "ft69": {
    "fontSize": "69"
  },
  "ft70": {
    "fontSize": "70"
  },
  "ft71": {
    "fontSize": "71"
  },
  "ft72": {
    "fontSize": "72"
  },
  "ft73": {
    "fontSize": "73"
  },
  "ft74": {
    "fontSize": "74"
  },
  "ft75": {
    "fontSize": "75"
  },
  "ft76": {
    "fontSize": "76"
  },
  "ft77": {
    "fontSize": "77"
  },
  "ft78": {
    "fontSize": "78"
  },
  "ft79": {
    "fontSize": "79"
  },
  "ft80": {
    "fontSize": "80"
  },
  "ft81": {
    "fontSize": "81"
  },
  "ft82": {
    "fontSize": "82"
  },
  "ft83": {
    "fontSize": "83"
  },
  "ft84": {
    "fontSize": "84"
  },
  "ft85": {
    "fontSize": "85"
  },
  "ft86": {
    "fontSize": "86"
  },
  "ft87": {
    "fontSize": "87"
  },
  "ft88": {
    "fontSize": "88"
  },
  "ft89": {
    "fontSize": "89"
  },
  "ft90": {
    "fontSize": "90"
  },
  "ft91": {
    "fontSize": "91"
  },
  "ft92": {
    "fontSize": "92"
  },
  "ft93": {
    "fontSize": "93"
  },
  "ft94": {
    "fontSize": "94"
  },
  "ft95": {
    "fontSize": "95"
  },
  "ft96": {
    "fontSize": "96"
  },
  "ft97": {
    "fontSize": "97"
  },
  "ft98": {
    "fontSize": "98"
  },
  "ft99": {
    "fontSize": "99"
  },
  "ft100": {
    "fontSize": "100"
  },
  "mgt2": {
    "marginTop": "2"
  },
  "mgb2": {
    "marginBottom": "2"
  },
  "mgl2": {
    "marginLeft": "2"
  },
  "mgr2": {
    "marginRight": "2"
  },
  "pdt2": {
    "paddingTop": "2"
  },
  "pdb2": {
    "paddingBottom": "2"
  },
  "pdl2": {
    "paddingLeft": "2"
  },
  "pdr2": {
    "paddingRight": "2"
  },
  "mgt4": {
    "marginTop": "4"
  },
  "mgb4": {
    "marginBottom": "4"
  },
  "mgl4": {
    "marginLeft": "4"
  },
  "mgr4": {
    "marginRight": "4"
  },
  "pdt4": {
    "paddingTop": "4"
  },
  "pdb4": {
    "paddingBottom": "4"
  },
  "pdl4": {
    "paddingLeft": "4"
  },
  "pdr4": {
    "paddingRight": "4"
  },
  "mgt5": {
    "marginTop": "5"
  },
  "mgb5": {
    "marginBottom": "5"
  },
  "mgl5": {
    "marginLeft": "5"
  },
  "mgr5": {
    "marginRight": "5"
  },
  "pdt5": {
    "paddingTop": "5"
  },
  "pdb5": {
    "paddingBottom": "5"
  },
  "pdl5": {
    "paddingLeft": "5"
  },
  "pdr5": {
    "paddingRight": "5"
  },
  "mgt6": {
    "marginTop": "6"
  },
  "mgb6": {
    "marginBottom": "6"
  },
  "mgl6": {
    "marginLeft": "6"
  },
  "mgr6": {
    "marginRight": "6"
  },
  "pdt6": {
    "paddingTop": "6"
  },
  "pdb6": {
    "paddingBottom": "6"
  },
  "pdl6": {
    "paddingLeft": "6"
  },
  "pdr6": {
    "paddingRight": "6"
  },
  "mgt8": {
    "marginTop": "8"
  },
  "mgb8": {
    "marginBottom": "8"
  },
  "mgl8": {
    "marginLeft": "8"
  },
  "mgr8": {
    "marginRight": "8"
  },
  "pdt8": {
    "paddingTop": "8"
  },
  "pdb8": {
    "paddingBottom": "8"
  },
  "pdl8": {
    "paddingLeft": "8"
  },
  "pdr8": {
    "paddingRight": "8"
  },
  "mgt10": {
    "marginTop": "10"
  },
  "mgb10": {
    "marginBottom": "10"
  },
  "mgl10": {
    "marginLeft": "10"
  },
  "mgr10": {
    "marginRight": "10"
  },
  "pdt10": {
    "paddingTop": "10"
  },
  "pdb10": {
    "paddingBottom": "10"
  },
  "pdl10": {
    "paddingLeft": "10"
  },
  "pdr10": {
    "paddingRight": "10"
  },
  "mgt12": {
    "marginTop": "12"
  },
  "mgb12": {
    "marginBottom": "12"
  },
  "mgl12": {
    "marginLeft": "12"
  },
  "mgr12": {
    "marginRight": "12"
  },
  "pdt12": {
    "paddingTop": "12"
  },
  "pdb12": {
    "paddingBottom": "12"
  },
  "pdl12": {
    "paddingLeft": "12"
  },
  "pdr12": {
    "paddingRight": "12"
  },
  "mgt14": {
    "marginTop": "14"
  },
  "mgb14": {
    "marginBottom": "14"
  },
  "mgl14": {
    "marginLeft": "14"
  },
  "mgr14": {
    "marginRight": "14"
  },
  "pdt14": {
    "paddingTop": "14"
  },
  "pdb14": {
    "paddingBottom": "14"
  },
  "pdl14": {
    "paddingLeft": "14"
  },
  "pdr14": {
    "paddingRight": "14"
  },
  "mgt15": {
    "marginTop": "15"
  },
  "mgb15": {
    "marginBottom": "15"
  },
  "mgl15": {
    "marginLeft": "15"
  },
  "mgr15": {
    "marginRight": "15"
  },
  "pdt15": {
    "paddingTop": "15"
  },
  "pdb15": {
    "paddingBottom": "15"
  },
  "pdl15": {
    "paddingLeft": "15"
  },
  "pdr15": {
    "paddingRight": "15"
  },
  "mgt16": {
    "marginTop": "16"
  },
  "mgb16": {
    "marginBottom": "16"
  },
  "mgl16": {
    "marginLeft": "16"
  },
  "mgr16": {
    "marginRight": "16"
  },
  "pdt16": {
    "paddingTop": "16"
  },
  "pdb16": {
    "paddingBottom": "16"
  },
  "pdl16": {
    "paddingLeft": "16"
  },
  "pdr16": {
    "paddingRight": "16"
  },
  "mgt18": {
    "marginTop": "18"
  },
  "mgb18": {
    "marginBottom": "18"
  },
  "mgl18": {
    "marginLeft": "18"
  },
  "mgr18": {
    "marginRight": "18"
  },
  "pdt18": {
    "paddingTop": "18"
  },
  "pdb18": {
    "paddingBottom": "18"
  },
  "pdl18": {
    "paddingLeft": "18"
  },
  "pdr18": {
    "paddingRight": "18"
  },
  "mgt20": {
    "marginTop": "20"
  },
  "mgb20": {
    "marginBottom": "20"
  },
  "mgl20": {
    "marginLeft": "20"
  },
  "mgr20": {
    "marginRight": "20"
  },
  "pdt20": {
    "paddingTop": "20"
  },
  "pdb20": {
    "paddingBottom": "20"
  },
  "pdl20": {
    "paddingLeft": "20"
  },
  "pdr20": {
    "paddingRight": "20"
  },
  "mgt22": {
    "marginTop": "22"
  },
  "mgb22": {
    "marginBottom": "22"
  },
  "mgl22": {
    "marginLeft": "22"
  },
  "mgr22": {
    "marginRight": "22"
  },
  "pdt22": {
    "paddingTop": "22"
  },
  "pdb22": {
    "paddingBottom": "22"
  },
  "pdl22": {
    "paddingLeft": "22"
  },
  "pdr22": {
    "paddingRight": "22"
  },
  "mgt24": {
    "marginTop": "24"
  },
  "mgb24": {
    "marginBottom": "24"
  },
  "mgl24": {
    "marginLeft": "24"
  },
  "mgr24": {
    "marginRight": "24"
  },
  "pdt24": {
    "paddingTop": "24"
  },
  "pdb24": {
    "paddingBottom": "24"
  },
  "pdl24": {
    "paddingLeft": "24"
  },
  "pdr24": {
    "paddingRight": "24"
  },
  "mgt25": {
    "marginTop": "25"
  },
  "mgb25": {
    "marginBottom": "25"
  },
  "mgl25": {
    "marginLeft": "25"
  },
  "mgr25": {
    "marginRight": "25"
  },
  "pdt25": {
    "paddingTop": "25"
  },
  "pdb25": {
    "paddingBottom": "25"
  },
  "pdl25": {
    "paddingLeft": "25"
  },
  "pdr25": {
    "paddingRight": "25"
  },
  "mgt26": {
    "marginTop": "26"
  },
  "mgb26": {
    "marginBottom": "26"
  },
  "mgl26": {
    "marginLeft": "26"
  },
  "mgr26": {
    "marginRight": "26"
  },
  "pdt26": {
    "paddingTop": "26"
  },
  "pdb26": {
    "paddingBottom": "26"
  },
  "pdl26": {
    "paddingLeft": "26"
  },
  "pdr26": {
    "paddingRight": "26"
  },
  "mgt28": {
    "marginTop": "28"
  },
  "mgb28": {
    "marginBottom": "28"
  },
  "mgl28": {
    "marginLeft": "28"
  },
  "mgr28": {
    "marginRight": "28"
  },
  "pdt28": {
    "paddingTop": "28"
  },
  "pdb28": {
    "paddingBottom": "28"
  },
  "pdl28": {
    "paddingLeft": "28"
  },
  "pdr28": {
    "paddingRight": "28"
  },
  "mgt30": {
    "marginTop": "30"
  },
  "mgb30": {
    "marginBottom": "30"
  },
  "mgl30": {
    "marginLeft": "30"
  },
  "mgr30": {
    "marginRight": "30"
  },
  "pdt30": {
    "paddingTop": "30"
  },
  "pdb30": {
    "paddingBottom": "30"
  },
  "pdl30": {
    "paddingLeft": "30"
  },
  "pdr30": {
    "paddingRight": "30"
  },
  "mgt32": {
    "marginTop": "32"
  },
  "mgb32": {
    "marginBottom": "32"
  },
  "mgl32": {
    "marginLeft": "32"
  },
  "mgr32": {
    "marginRight": "32"
  },
  "pdt32": {
    "paddingTop": "32"
  },
  "pdb32": {
    "paddingBottom": "32"
  },
  "pdl32": {
    "paddingLeft": "32"
  },
  "pdr32": {
    "paddingRight": "32"
  },
  "mgt34": {
    "marginTop": "34"
  },
  "mgb34": {
    "marginBottom": "34"
  },
  "mgl34": {
    "marginLeft": "34"
  },
  "mgr34": {
    "marginRight": "34"
  },
  "pdt34": {
    "paddingTop": "34"
  },
  "pdb34": {
    "paddingBottom": "34"
  },
  "pdl34": {
    "paddingLeft": "34"
  },
  "pdr34": {
    "paddingRight": "34"
  },
  "mgt35": {
    "marginTop": "35"
  },
  "mgb35": {
    "marginBottom": "35"
  },
  "mgl35": {
    "marginLeft": "35"
  },
  "mgr35": {
    "marginRight": "35"
  },
  "pdt35": {
    "paddingTop": "35"
  },
  "pdb35": {
    "paddingBottom": "35"
  },
  "pdl35": {
    "paddingLeft": "35"
  },
  "pdr35": {
    "paddingRight": "35"
  },
  "mgt36": {
    "marginTop": "36"
  },
  "mgb36": {
    "marginBottom": "36"
  },
  "mgl36": {
    "marginLeft": "36"
  },
  "mgr36": {
    "marginRight": "36"
  },
  "pdt36": {
    "paddingTop": "36"
  },
  "pdb36": {
    "paddingBottom": "36"
  },
  "pdl36": {
    "paddingLeft": "36"
  },
  "pdr36": {
    "paddingRight": "36"
  },
  "mgt38": {
    "marginTop": "38"
  },
  "mgb38": {
    "marginBottom": "38"
  },
  "mgl38": {
    "marginLeft": "38"
  },
  "mgr38": {
    "marginRight": "38"
  },
  "pdt38": {
    "paddingTop": "38"
  },
  "pdb38": {
    "paddingBottom": "38"
  },
  "pdl38": {
    "paddingLeft": "38"
  },
  "pdr38": {
    "paddingRight": "38"
  },
  "mgt40": {
    "marginTop": "40"
  },
  "mgb40": {
    "marginBottom": "40"
  },
  "mgl40": {
    "marginLeft": "40"
  },
  "mgr40": {
    "marginRight": "40"
  },
  "pdt40": {
    "paddingTop": "40"
  },
  "pdb40": {
    "paddingBottom": "40"
  },
  "pdl40": {
    "paddingLeft": "40"
  },
  "pdr40": {
    "paddingRight": "40"
  },
  "mgt42": {
    "marginTop": "42"
  },
  "mgb42": {
    "marginBottom": "42"
  },
  "mgl42": {
    "marginLeft": "42"
  },
  "mgr42": {
    "marginRight": "42"
  },
  "pdt42": {
    "paddingTop": "42"
  },
  "pdb42": {
    "paddingBottom": "42"
  },
  "pdl42": {
    "paddingLeft": "42"
  },
  "pdr42": {
    "paddingRight": "42"
  },
  "mgt44": {
    "marginTop": "44"
  },
  "mgb44": {
    "marginBottom": "44"
  },
  "mgl44": {
    "marginLeft": "44"
  },
  "mgr44": {
    "marginRight": "44"
  },
  "pdt44": {
    "paddingTop": "44"
  },
  "pdb44": {
    "paddingBottom": "44"
  },
  "pdl44": {
    "paddingLeft": "44"
  },
  "pdr44": {
    "paddingRight": "44"
  },
  "mgt45": {
    "marginTop": "45"
  },
  "mgb45": {
    "marginBottom": "45"
  },
  "mgl45": {
    "marginLeft": "45"
  },
  "mgr45": {
    "marginRight": "45"
  },
  "pdt45": {
    "paddingTop": "45"
  },
  "pdb45": {
    "paddingBottom": "45"
  },
  "pdl45": {
    "paddingLeft": "45"
  },
  "pdr45": {
    "paddingRight": "45"
  },
  "mgt46": {
    "marginTop": "46"
  },
  "mgb46": {
    "marginBottom": "46"
  },
  "mgl46": {
    "marginLeft": "46"
  },
  "mgr46": {
    "marginRight": "46"
  },
  "pdt46": {
    "paddingTop": "46"
  },
  "pdb46": {
    "paddingBottom": "46"
  },
  "pdl46": {
    "paddingLeft": "46"
  },
  "pdr46": {
    "paddingRight": "46"
  },
  "mgt48": {
    "marginTop": "48"
  },
  "mgb48": {
    "marginBottom": "48"
  },
  "mgl48": {
    "marginLeft": "48"
  },
  "mgr48": {
    "marginRight": "48"
  },
  "pdt48": {
    "paddingTop": "48"
  },
  "pdb48": {
    "paddingBottom": "48"
  },
  "pdl48": {
    "paddingLeft": "48"
  },
  "pdr48": {
    "paddingRight": "48"
  },
  "mgt50": {
    "marginTop": "50"
  },
  "mgb50": {
    "marginBottom": "50"
  },
  "mgl50": {
    "marginLeft": "50"
  },
  "mgr50": {
    "marginRight": "50"
  },
  "pdt50": {
    "paddingTop": "50"
  },
  "pdb50": {
    "paddingBottom": "50"
  },
  "pdl50": {
    "paddingLeft": "50"
  },
  "pdr50": {
    "paddingRight": "50"
  },
  "mgt52": {
    "marginTop": "52"
  },
  "mgb52": {
    "marginBottom": "52"
  },
  "mgl52": {
    "marginLeft": "52"
  },
  "mgr52": {
    "marginRight": "52"
  },
  "pdt52": {
    "paddingTop": "52"
  },
  "pdb52": {
    "paddingBottom": "52"
  },
  "pdl52": {
    "paddingLeft": "52"
  },
  "pdr52": {
    "paddingRight": "52"
  },
  "mgt54": {
    "marginTop": "54"
  },
  "mgb54": {
    "marginBottom": "54"
  },
  "mgl54": {
    "marginLeft": "54"
  },
  "mgr54": {
    "marginRight": "54"
  },
  "pdt54": {
    "paddingTop": "54"
  },
  "pdb54": {
    "paddingBottom": "54"
  },
  "pdl54": {
    "paddingLeft": "54"
  },
  "pdr54": {
    "paddingRight": "54"
  },
  "mgt55": {
    "marginTop": "55"
  },
  "mgb55": {
    "marginBottom": "55"
  },
  "mgl55": {
    "marginLeft": "55"
  },
  "mgr55": {
    "marginRight": "55"
  },
  "pdt55": {
    "paddingTop": "55"
  },
  "pdb55": {
    "paddingBottom": "55"
  },
  "pdl55": {
    "paddingLeft": "55"
  },
  "pdr55": {
    "paddingRight": "55"
  },
  "mgt56": {
    "marginTop": "56"
  },
  "mgb56": {
    "marginBottom": "56"
  },
  "mgl56": {
    "marginLeft": "56"
  },
  "mgr56": {
    "marginRight": "56"
  },
  "pdt56": {
    "paddingTop": "56"
  },
  "pdb56": {
    "paddingBottom": "56"
  },
  "pdl56": {
    "paddingLeft": "56"
  },
  "pdr56": {
    "paddingRight": "56"
  },
  "mgt58": {
    "marginTop": "58"
  },
  "mgb58": {
    "marginBottom": "58"
  },
  "mgl58": {
    "marginLeft": "58"
  },
  "mgr58": {
    "marginRight": "58"
  },
  "pdt58": {
    "paddingTop": "58"
  },
  "pdb58": {
    "paddingBottom": "58"
  },
  "pdl58": {
    "paddingLeft": "58"
  },
  "pdr58": {
    "paddingRight": "58"
  },
  "mgt60": {
    "marginTop": "60"
  },
  "mgb60": {
    "marginBottom": "60"
  },
  "mgl60": {
    "marginLeft": "60"
  },
  "mgr60": {
    "marginRight": "60"
  },
  "pdt60": {
    "paddingTop": "60"
  },
  "pdb60": {
    "paddingBottom": "60"
  },
  "pdl60": {
    "paddingLeft": "60"
  },
  "pdr60": {
    "paddingRight": "60"
  },
  "mgt62": {
    "marginTop": "62"
  },
  "mgb62": {
    "marginBottom": "62"
  },
  "mgl62": {
    "marginLeft": "62"
  },
  "mgr62": {
    "marginRight": "62"
  },
  "pdt62": {
    "paddingTop": "62"
  },
  "pdb62": {
    "paddingBottom": "62"
  },
  "pdl62": {
    "paddingLeft": "62"
  },
  "pdr62": {
    "paddingRight": "62"
  },
  "mgt64": {
    "marginTop": "64"
  },
  "mgb64": {
    "marginBottom": "64"
  },
  "mgl64": {
    "marginLeft": "64"
  },
  "mgr64": {
    "marginRight": "64"
  },
  "pdt64": {
    "paddingTop": "64"
  },
  "pdb64": {
    "paddingBottom": "64"
  },
  "pdl64": {
    "paddingLeft": "64"
  },
  "pdr64": {
    "paddingRight": "64"
  },
  "mgt65": {
    "marginTop": "65"
  },
  "mgb65": {
    "marginBottom": "65"
  },
  "mgl65": {
    "marginLeft": "65"
  },
  "mgr65": {
    "marginRight": "65"
  },
  "pdt65": {
    "paddingTop": "65"
  },
  "pdb65": {
    "paddingBottom": "65"
  },
  "pdl65": {
    "paddingLeft": "65"
  },
  "pdr65": {
    "paddingRight": "65"
  },
  "mgt66": {
    "marginTop": "66"
  },
  "mgb66": {
    "marginBottom": "66"
  },
  "mgl66": {
    "marginLeft": "66"
  },
  "mgr66": {
    "marginRight": "66"
  },
  "pdt66": {
    "paddingTop": "66"
  },
  "pdb66": {
    "paddingBottom": "66"
  },
  "pdl66": {
    "paddingLeft": "66"
  },
  "pdr66": {
    "paddingRight": "66"
  },
  "mgt68": {
    "marginTop": "68"
  },
  "mgb68": {
    "marginBottom": "68"
  },
  "mgl68": {
    "marginLeft": "68"
  },
  "mgr68": {
    "marginRight": "68"
  },
  "pdt68": {
    "paddingTop": "68"
  },
  "pdb68": {
    "paddingBottom": "68"
  },
  "pdl68": {
    "paddingLeft": "68"
  },
  "pdr68": {
    "paddingRight": "68"
  },
  "mgt70": {
    "marginTop": "70"
  },
  "mgb70": {
    "marginBottom": "70"
  },
  "mgl70": {
    "marginLeft": "70"
  },
  "mgr70": {
    "marginRight": "70"
  },
  "pdt70": {
    "paddingTop": "70"
  },
  "pdb70": {
    "paddingBottom": "70"
  },
  "pdl70": {
    "paddingLeft": "70"
  },
  "pdr70": {
    "paddingRight": "70"
  },
  "mgt72": {
    "marginTop": "72"
  },
  "mgb72": {
    "marginBottom": "72"
  },
  "mgl72": {
    "marginLeft": "72"
  },
  "mgr72": {
    "marginRight": "72"
  },
  "pdt72": {
    "paddingTop": "72"
  },
  "pdb72": {
    "paddingBottom": "72"
  },
  "pdl72": {
    "paddingLeft": "72"
  },
  "pdr72": {
    "paddingRight": "72"
  },
  "mgt74": {
    "marginTop": "74"
  },
  "mgb74": {
    "marginBottom": "74"
  },
  "mgl74": {
    "marginLeft": "74"
  },
  "mgr74": {
    "marginRight": "74"
  },
  "pdt74": {
    "paddingTop": "74"
  },
  "pdb74": {
    "paddingBottom": "74"
  },
  "pdl74": {
    "paddingLeft": "74"
  },
  "pdr74": {
    "paddingRight": "74"
  },
  "mgt75": {
    "marginTop": "75"
  },
  "mgb75": {
    "marginBottom": "75"
  },
  "mgl75": {
    "marginLeft": "75"
  },
  "mgr75": {
    "marginRight": "75"
  },
  "pdt75": {
    "paddingTop": "75"
  },
  "pdb75": {
    "paddingBottom": "75"
  },
  "pdl75": {
    "paddingLeft": "75"
  },
  "pdr75": {
    "paddingRight": "75"
  },
  "mgt76": {
    "marginTop": "76"
  },
  "mgb76": {
    "marginBottom": "76"
  },
  "mgl76": {
    "marginLeft": "76"
  },
  "mgr76": {
    "marginRight": "76"
  },
  "pdt76": {
    "paddingTop": "76"
  },
  "pdb76": {
    "paddingBottom": "76"
  },
  "pdl76": {
    "paddingLeft": "76"
  },
  "pdr76": {
    "paddingRight": "76"
  },
  "mgt78": {
    "marginTop": "78"
  },
  "mgb78": {
    "marginBottom": "78"
  },
  "mgl78": {
    "marginLeft": "78"
  },
  "mgr78": {
    "marginRight": "78"
  },
  "pdt78": {
    "paddingTop": "78"
  },
  "pdb78": {
    "paddingBottom": "78"
  },
  "pdl78": {
    "paddingLeft": "78"
  },
  "pdr78": {
    "paddingRight": "78"
  },
  "mgt80": {
    "marginTop": "80"
  },
  "mgb80": {
    "marginBottom": "80"
  },
  "mgl80": {
    "marginLeft": "80"
  },
  "mgr80": {
    "marginRight": "80"
  },
  "pdt80": {
    "paddingTop": "80"
  },
  "pdb80": {
    "paddingBottom": "80"
  },
  "pdl80": {
    "paddingLeft": "80"
  },
  "pdr80": {
    "paddingRight": "80"
  },
  "clr-red01": {
    "color": "#ff0000"
  },
  "clr-red02": {
    "color": "#ea3f29"
  },
  "clr-red03": {
    "color": "#cc0000"
  },
  "clr-red04": {
    "color": "#ff6666"
  },
  "clr-orange01": {
    "color": "#f58220"
  },
  "clr-orange02": {
    "color": "#ff9933"
  },
  "clr-orange03": {
    "color": "#ff6600"
  },
  "clr-orange04": {
    "color": "#ed4200"
  },
  "clr-yellow01": {
    "color": "#ffff00"
  },
  "clr-green01": {
    "color": "#008000"
  },
  "clr-cyan01": {
    "color": "#00ffff"
  },
  "clr-cyan02": {
    "color": "#00c1a0"
  },
  "clr-blue01": {
    "color": "#0000ff"
  },
  "clr-purple01": {
    "color": "#800080"
  },
  "clr-black": {
    "color": "#000000"
  },
  "clr-grey-0": {
    "color": "#000000"
  },
  "clr-grey-1": {
    "color": "#111111"
  },
  "clr-grey-2": {
    "color": "#222222"
  },
  "clr-grey-3": {
    "color": "#333333"
  },
  "clr-grey-4": {
    "color": "#444444"
  },
  "clr-grey-5": {
    "color": "#555555"
  },
  "clr-grey-6": {
    "color": "#666666"
  },
  "clr-grey-7": {
    "color": "#777777"
  },
  "clr-grey-8": {
    "color": "#888888"
  },
  "clr-grey-9": {
    "color": "#999999"
  },
  "clr-grey-a": {
    "color": "#aaaaaa"
  },
  "clr-grey-b": {
    "color": "#bbbbbb"
  },
  "clr-grey-c": {
    "color": "#cccccc"
  },
  "clr-grey-d": {
    "color": "#dddddd"
  },
  "clr-grey-e": {
    "color": "#eeeeee"
  },
  "clr-grey-f": {
    "color": "#ffffff"
  },
  "clr-white": {
    "color": "#ffffff"
  },
  "clr-grey01": {
    "color": "#e4e4e4"
  },
  "clr-grey02": {
    "color": "#7a7a7a"
  },
  "clr-grey03": {
    "color": "#757575"
  },
  "clr-grey04": {
    "color": "#7e7e7e"
  },
  "clr-grey05": {
    "color": "#e3e3e3"
  },
  "clr-grey06": {
    "color": "#fafafa"
  },
  "bg-clr-red01": {
    "backgroundColor": "#ff0000"
  },
  "bg-clr-red02": {
    "backgroundColor": "#cc0000"
  },
  "bg-clr-orange01": {
    "backgroundColor": "#f58220"
  },
  "bg-clr-orange02": {
    "backgroundColor": "#ff9900"
  },
  "bg-clr-orange03": {
    "backgroundColor": "#e6a067"
  },
  "bg-clr-yellow01": {
    "backgroundColor": "#ffff00"
  },
  "bg-clr-green01": {
    "backgroundColor": "#008000"
  },
  "bg-clr-cyan01": {
    "backgroundColor": "#00ffff"
  },
  "bg-clr-blue01": {
    "backgroundColor": "#0000ff"
  },
  "bg-clr-purple01": {
    "backgroundColor": "#800080"
  },
  "bg-clr-black": {
    "backgroundColor": "#000000"
  },
  "bg-clr-grey-0": {
    "backgroundColor": "#000000"
  },
  "bg-clr-grey-1": {
    "backgroundColor": "#111111"
  },
  "bg-clr-grey-2": {
    "backgroundColor": "#222222"
  },
  "bg-clr-grey-3": {
    "backgroundColor": "#333333"
  },
  "bg-clr-grey-4": {
    "backgroundColor": "#444444"
  },
  "bg-clr-grey-5": {
    "backgroundColor": "#555555"
  },
  "bg-clr-grey-6": {
    "backgroundColor": "#666666"
  },
  "bg-clr-grey-7": {
    "backgroundColor": "#777777"
  },
  "bg-clr-grey-8": {
    "backgroundColor": "#888888"
  },
  "bg-clr-grey-9": {
    "backgroundColor": "#999999"
  },
  "bg-clr-grey-a": {
    "backgroundColor": "#aaaaaa"
  },
  "bg-clr-grey-b": {
    "backgroundColor": "#bbbbbb"
  },
  "bg-clr-grey-c": {
    "backgroundColor": "#cccccc"
  },
  "bg-clr-grey-d": {
    "backgroundColor": "#dddddd"
  },
  "bg-clr-grey-e": {
    "backgroundColor": "#eeeeee"
  },
  "bg-clr-grey-f": {
    "backgroundColor": "#ffffff"
  },
  "bg-clr-white": {
    "backgroundColor": "#ffffff"
  },
  "wxcell-line": {
    "height": "90",
    "flexDirection": "row",
    "justifyContent": "space-between",
    "alignItems": "center",
    "paddingLeft": "20",
    "paddingRight": "20"
  },
  "wxcell-line-sm": {
    "height": "78"
  },
  "wxcell-line__bd": {
    "flex": 1
  },
  "wxcell-line__ft": {
    "textAlign": "right"
  },
  "ttbd": {
    "fontWeight": "bold"
  },
  "ttnm": {
    "fontWeight": "normal"
  },
  "ttct": {
    "textAlign": "center"
  },
  "ttl": {
    "textAlign": "left"
  },
  "ttr": {
    "textAlign": "right"
  },
  "dirrow": {
    "flexDirection": "row"
  },
  "dircol": {
    "flexDirection": "column"
  },
  "jcct": {
    "justifyContent": "center"
  },
  "aict": {
    "alignItems": "center"
  },
  "wrapper": {
    "position": "absolute",
    "top": 0,
    "left": 0,
    "right": 0,
    "bottom": 0,
    "width": "750",
    "backgroundColor": "#f5f5f5"
  },
  "line": {
    "width": "750",
    "height": "20",
    "backgroundColor": "#f2f2f2"
  },
  "nav_title": {
    "fontSize": "38",
    "color": "#ffffff",
    "lineHeight": "38"
  },
  "header-common-title": {
    "fontSize": "38",
    "color": "#ffffff",
    "lineHeight": "38"
  },
  "title": {
    "fontSize": "32",
    "color": "#000000"
  },
  "icon_title": {
    "fontSize": "30",
    "color": "#999999"
  },
  "sub_title": {
    "fontSize": "30",
    "color": "#999999"
  },
  "sub_date": {
    "fontSize": "26",
    "color": "#999999"
  },
  "fz26": {
    "fontSize": "26"
  },
  "fz28": {
    "fontSize": "28"
  },
  "fz30": {
    "fontSize": "30"
  },
  "fz32": {
    "fontSize": "32"
  },
  "fz35": {
    "fontSize": "35"
  },
  "fz40": {
    "fontSize": "40"
  },
  "boder-bottom": {
    "borderStyle": "solid",
    "borderBottomWidth": "1",
    "borderColor": "#e6e6e6"
  },
  "boder-top": {
    "borderStyle": "solid",
    "borderTopWidth": "1",
    "borderColor": "#e6e6e6"
  },
  "boder-right": {
    "borderStyle": "solid",
    "borderRightWidth": "1",
    "borderColor": "#e6e6e6"
  },
  "boder-left": {
    "borderStyle": "solid",
    "borderLeftWidth": "1",
    "borderColor": "#e6e6e6"
  },
  "pl10": {
    "paddingLeft": "10"
  },
  "pl5": {
    "paddingLeft": "5"
  },
  "pt0": {
    "paddingTop": "0"
  },
  "pt10": {
    "paddingTop": "10"
  },
  "pt15": {
    "paddingTop": "15"
  },
  "pb10": {
    "paddingBottom": "10"
  },
  "pl20": {
    "paddingLeft": "20"
  },
  "pt20": {
    "paddingTop": "20"
  },
  "pb15": {
    "paddingBottom": "15"
  },
  "pb20": {
    "paddingBottom": "20"
  },
  "pt25": {
    "paddingTop": "25"
  },
  "pt30": {
    "paddingTop": "30"
  },
  "pt40": {
    "paddingTop": "40"
  },
  "pb40": {
    "paddingBottom": "40"
  },
  "pb30": {
    "paddingBottom": "30"
  },
  "pb25": {
    "paddingBottom": "25"
  },
  "pl25": {
    "paddingLeft": "25"
  },
  "pl30": {
    "paddingLeft": "30"
  },
  "pr5": {
    "paddingRight": "5"
  },
  "pr10": {
    "paddingRight": "10"
  },
  "pr20": {
    "paddingRight": "20"
  },
  "pr25": {
    "paddingRight": "25"
  },
  "pr30": {
    "paddingRight": "30"
  },
  "pl35": {
    "paddingLeft": "35"
  },
  "pr35": {
    "paddingRight": "35"
  },
  "bgWhite": {
    "backgroundColor": "#ffffff"
  },
  "textActive": {
    "backgroundColor:active": "#cccccc"
  },
  "mt0": {
    "marginTop": "0"
  },
  "mt10": {
    "marginTop": "10"
  },
  "mt20": {
    "marginTop": "20"
  },
  "mt30": {
    "marginTop": "30"
  },
  "mt40": {
    "marginTop": "40"
  },
  "mt50": {
    "marginTop": "50"
  },
  "bt0": {
    "marginBottom": "0"
  },
  "bt5": {
    "marginBottom": "5"
  },
  "bt10": {
    "marginBottom": "10"
  },
  "bt15": {
    "marginBottom": "15"
  },
  "bt20": {
    "marginBottom": "20"
  },
  "bt30": {
    "marginBottom": "30"
  },
  "bt45": {
    "marginBottom": "45"
  },
  "bt50": {
    "marginBottom": "50"
  },
  "mr5": {
    "marginRight": "5"
  },
  "mr10": {
    "marginRight": "10"
  },
  "mr15": {
    "marginRight": "15"
  },
  "mr30": {
    "marginRight": "30"
  },
  "ml5": {
    "marginLeft": "5"
  },
  "ml10": {
    "marginLeft": "10"
  },
  "ml20": {
    "marginLeft": "20"
  },
  "ml30": {
    "marginLeft": "30"
  },
  "header": {
    "height": "136",
    "paddingTop": "44",
    "flexDirection": "row",
    "position": "sticky",
    "backgroundColor": "#00c1a0"
  },
  "topbar": {
    "height": "136",
    "paddingTop": "44",
    "flexDirection": "row",
    "position": "sticky",
    "backgroundColor": "#00c1a0"
  },
  "topbar-common-actual": {
    "flex": 1,
    "width": "750",
    "flexDirection": "row",
    "justifyContent": "space-between",
    "alignItems": "center"
  },
  "topbar-common-hd": {
    "width": "100",
    "flexDirection": "row",
    "justifyContent": "flex-start",
    "alignItems": "center"
  },
  "topbar-common-bd": {
    "flex": 1,
    "flexDirection": "row",
    "justifyContent": "center",
    "alignItems": "center"
  },
  "topbar-common-ft": {
    "width": "100",
    "flexDirection": "row",
    "justifyContent": "flex-end",
    "alignItems": "center"
  },
  "topbar-common-icon": {
    "fontSize": "38",
    "color": "#ffffff"
  },
  "baseNavBg": {
    "backgroundColor": "#00c1a0"
  },
  "baseNavColor": {
    "color": "#00c1a0"
  },
  "nav": {
    "width": "654",
    "justifyContent": "space-between",
    "flexDirection": "row",
    "height": "92",
    "alignItems": "center",
    "marginTop": "0"
  },
  "nav_back": {
    "marginTop": "0",
    "flexDirection": "row",
    "width": "92",
    "height": "92",
    "alignItems": "center",
    "justifyContent": "center"
  },
  "corpusActive": {
    "color": "#00c1a0",
    "borderColor": "#00c1a0",
    "borderStyle": "solid",
    "borderBottomWidth": "4"
  },
  "footer": {
    "position": "fixed",
    "bottom": "0",
    "left": "0",
    "right": "0",
    "height": "100"
  },
  "fill": {
    "height": "500",
    "width": "750",
    "backgroundColor": "#f5f5f5"
  },
  "iconImg": {
    "width": "60",
    "height": "60",
    "fontSize": "60"
  },
  "cell-header": {
    "height": "70",
    "flexDirection": "row",
    "backgroundColor": "#dddddd",
    "paddingLeft": "20"
  },
  "cell-row": {
    "minHeight": "100",
    "flexDirection": "column",
    "backgroundColor": "#ffffff",
    "paddingLeft": "20",
    "marginTop": "20"
  },
  "cell-row-1": {
    "flexDirection": "column",
    "backgroundColor": "#ffffff",
    "paddingLeft": "20",
    "marginTop": "20"
  },
  "cell-row-row": {
    "minHeight": "100",
    "flexDirection": "row",
    "justifyContent": "space-between",
    "backgroundColor": "#ffffff",
    "paddingLeft": "20",
    "paddingRight": "20",
    "alignItems": "center",
    "marginTop": "20"
  },
  "cell-line": {
    "borderTopWidth": "1",
    "borderTopColor": "#e6e6e6",
    "borderTopStyle": "solid",
    "borderBottomWidth": "1",
    "borderBottomColor": "#e6e6e6",
    "borderBottomStyle": "solid"
  },
  "borderTop": {
    "borderTopWidth": "1",
    "borderTopColor": "#e6e6e6",
    "borderTopStyle": "solid"
  },
  "border-top": {
    "borderTopWidth": "1",
    "borderTopStyle": "solid",
    "borderTopColor": "#e6e6e6"
  },
  "borderBottom": {
    "borderBottomWidth": "1",
    "borderBottomColor": "#e6e6e6",
    "borderBottomStyle": "solid"
  },
  "border-bottom": {
    "borderBottomWidth": "1",
    "borderBottomStyle": "solid",
    "borderBottomColor": "#e6e6e6"
  },
  "border-left": {
    "borderLeftWidth": "1",
    "borderLeftStyle": "solid",
    "borderLeftColor": "#e6e6e6"
  },
  "border-right": {
    "borderRightWidth": "1",
    "borderRightStyle": "solid",
    "borderRightColor": "#e6e6e6"
  },
  "cell-panel": {
    "height": "98",
    "minHeight": "98",
    "flexDirection": "row",
    "alignItems": "center",
    "borderBottomWidth": "1",
    "borderBottomColor": "#e6e6e6",
    "borderBottomStyle": "solid"
  },
  "cell-panel-column": {
    "height": "98",
    "minHeight": "98",
    "flexDirection": "column",
    "justifyContent": "space-around",
    "borderBottomWidth": "1",
    "borderBottomColor": "#e6e6e6",
    "borderBottomStyle": "solid",
    "paddingTop": "10",
    "paddingBottom": "10"
  },
  "cell-bottom-clear": {
    "borderBottomWidth": "0"
  },
  "cell-clear": {
    "marginTop": "0",
    "marginBottom": "0",
    "borderBottomWidth": "0",
    "borderTopWidth": "0"
  },
  "space-between": {
    "justifyContent": "space-between",
    "flexDirection": "row",
    "alignItems": "center"
  },
  "flex-start": {
    "justifyContent": "flex-start",
    "flexDirection": "row",
    "alignItems": "center"
  },
  "flex-end": {
    "justifyContent": "flex-end",
    "flexDirection": "row",
    "alignItems": "center"
  },
  "flex-center": {
    "justifyContent": "center",
    "flexDirection": "row",
    "alignItems": "center"
  },
  "space-around": {
    "justifyContent": "space-around",
    "flexDirection": "row",
    "alignItems": "center"
  },
  "flex-row": {
    "flexDirection": "row",
    "alignItems": "center"
  },
  "flex-column": {
    "flexDirection": "column",
    "alignItems": "center"
  },
  "flex1": {
    "flex": 1
  },
  "flex2": {
    "flex": 2
  },
  "flex3": {
    "flex": 3
  },
  "flex4": {
    "flex": 4
  },
  "flex5": {
    "flex": 6
  },
  "flex6": {
    "flex": 6
  },
  "bkg-white": {
    "backgroundColor": "#ffffff"
  },
  "bkg-primary": {
    "backgroundColor": "#00c1a0"
  },
  "bkg-gray": {
    "backgroundColor": "#f5f5f5"
  },
  "bd-primary": {
    "borderColor": "#00c1a0"
  },
  "bkg-delete": {
    "backgroundColor": "#ff0000"
  },
  "white": {
    "color": "#ffffff"
  },
  "primary": {
    "color": "#00c1a0"
  },
  "gray": {
    "color": "#999999"
  },
  "ico": {
    "fontSize": "48",
    "color": "#00c1a0",
    "marginTop": "2"
  },
  "ico_big": {
    "fontSize": "72",
    "color": "#00c1a0",
    "marginTop": "4"
  },
  "ico_small": {
    "fontSize": "32",
    "color": "#00c1a0",
    "marginTop": "1"
  },
  "arrow": {
    "fontSize": "40",
    "color": "#cccccc",
    "width": "40",
    "marginLeft": "20"
  },
  "check": {
    "fontSize": "32",
    "color": "#00c1a0",
    "width": "40"
  },
  "shopCheck": {
    "fontSize": "32",
    "color": "#00c1a0",
    "width": "40",
    "marginLeft": "150"
  },
  "button": {
    "fontSize": "32",
    "textAlign": "center",
    "color": "#ffffff",
    "paddingTop": "15",
    "paddingBottom": "15",
    "backgroundColor": "#00c1a0",
    "borderRadius": "15",
    "height": "80",
    "lineHeight": "50",
    "alignItems": "center",
    "justifyContent": "center",
    "backgroundColor:active": "#e6e6e6",
    "color:active": "#00c1a0",
    "backgroundColor:disabled": "#00c1a0",
    "color:disabled": "#999999"
  },
  "refresh": {
    "flexDirection": "column",
    "alignItems": "center",
    "paddingTop": "10"
  },
  "loading": {
    "flexDirection": "column",
    "alignItems": "center",
    "paddingTop": "10"
  },
  "noLoading": {
    "height": "999"
  },
  "gif": {
    "width": "50",
    "height": "50"
  },
  "indicator": {
    "fontSize": "36",
    "color": "#00c1a0",
    "width": "750",
    "textAlign": "center",
    "marginTop": "20",
    "marginBottom": "20"
  },
  "lines-ellipsis": {
    "lines": 1,
    "textOverflow": "ellipsis"
  },
  "V1": {
    "height": "146",
    "paddingTop": "54"
  },
  "IPhoneX": {
    "height": "156",
    "paddingTop": "64"
  },
  "addTopV1": {
    "top": "54"
  },
  "addTopIPhoneX": {
    "top": "64"
  },
  "addInfoV1": {
    "height": "430",
    "paddingTop": "50"
  },
  "addInfoIPhoneX": {
    "height": "440",
    "paddingTop": "60"
  },
  "addBgImgV1": {
    "height": "430"
  },
  "addBgImgIPhoneX": {
    "height": "440"
  },
  "hideCorpusV1": {
    "top": "146"
  },
  "hideCorpusIPhoneX": {
    "top": "156"
  },
  "pageTopV1": {
    "top": "226"
  },
  "pageTopIPhoneX": {
    "top": "236"
  },
  "maskLayer": {
    "position": "fixed",
    "top": "0",
    "left": "0",
    "right": "0",
    "bottom": "0",
    "backgroundColor": "#000000",
    "opacity": 0.4
  },
  "showBox": {
    "position": "fixed",
    "top": "150",
    "right": "15",
    "paddingTop": "20",
    "paddingBottom": "20"
  },
  "showBg": {
    "position": "absolute",
    "top": 0,
    "bottom": 0,
    "left": 0,
    "right": 0,
    "backgroundColor": "#ffffff",
    "borderRadius": "20"
  },
  "arrowUp": {
    "position": "fixed",
    "top": "148",
    "right": "30"
  },
  "refreshImg": {
    "width": "60",
    "height": "60",
    "borderRadius": "30"
  },
  "refreshBox": {
    "height": "120",
    "width": "750",
    "alignItems": "center",
    "justifyContent": "center"
  },
  "indexMtIPhoneX": {
    "marginTop": "124"
  },
  "indexSliderMtIPhone": {
    "marginTop": "44"
  },
  "indexSliderMtIPhoneX": {
    "marginTop": "124"
  },
  "artOutBoxTopIPhoneX": {
    "top": "156"
  },
  "processTotal": {
    "position": "absolute",
    "bottom": "40",
    "right": "50",
    "fontSize": "28",
    "color": "#888888"
  },
  "processBg": {
    "backgroundColor": "#cccccc",
    "width": "500"
  },
  "processStyle": {
    "height": "10",
    "position": "absolute",
    "left": "50",
    "bottom": "100"
  },
  "processText": {
    "position": "absolute",
    "top": "40",
    "left": "50",
    "fontSize": "32"
  },
  "processBox": {
    "height": "250",
    "borderRadius": "5",
    "width": "600",
    "backgroundColor": "#ffffff",
    "justifyContent": "space-between"
  },
  "sendMask": {
    "position": "absolute",
    "top": 0,
    "bottom": 0,
    "left": 0,
    "right": 0,
    "backgroundColor": "rgba(0,0,0,0.8)",
    "alignItems": "center",
    "justifyContent": "center"
  },
  "placeholder-blue-bg": {
    "position": "absolute",
    "top": 0,
    "backgroundColor": "rgba(136,136,136,0.1)"
  }
}

/***/ }),

/***/ 68:
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var addToUnscopables = __webpack_require__(69);
var step = __webpack_require__(54);
var Iterators = __webpack_require__(11);
var toIObject = __webpack_require__(15);

// 22.1.3.4 Array.prototype.entries()
// 22.1.3.13 Array.prototype.keys()
// 22.1.3.29 Array.prototype.values()
// 22.1.3.30 Array.prototype[@@iterator]()
module.exports = __webpack_require__(34)(Array, 'Array', function (iterated, kind) {
  this._t = toIObject(iterated); // target
  this._i = 0;                   // next index
  this._k = kind;                // kind
// 22.1.5.2.1 %ArrayIteratorPrototype%.next()
}, function () {
  var O = this._t;
  var kind = this._k;
  var index = this._i++;
  if (!O || index >= O.length) {
    this._t = undefined;
    return step(1);
  }
  if (kind == 'keys') return step(0, index);
  if (kind == 'values') return step(0, O[index]);
  return step(0, [index, O[index]]);
}, 'values');

// argumentsList[@@iterator] is %ArrayProto_values% (9.4.4.6, 9.4.4.7)
Iterators.Arguments = Iterators.Array;

addToUnscopables('keys');
addToUnscopables('values');
addToUnscopables('entries');


/***/ }),

/***/ 680:
/***/ (function(module, exports) {

module.exports = {
  "headTitle": {
    "height": "50",
    "flexDirection": "row",
    "alignItems": "center",
    "marginLeft": "10",
    "marginBottom": "20",
    "marginTop": "20"
  },
  "shareBox": {
    "height": "750",
    "borderTopRightRadius": "15",
    "borderTopLeftRadius": "15",
    "borderWidth": "1",
    "borderColor": "#cccccc",
    "backgroundColor": "#f5f4f5",
    "position": "fixed",
    "bottom": "0",
    "left": "10",
    "right": "10"
  },
  "message": {
    "flexDirection": "row",
    "alignItems": "center",
    "width": "750",
    "backgroundColor": "#ffffff",
    "borderColor": "#cccccc",
    "borderBottomWidth": "1"
  },
  "shopLogo": {
    "marginLeft": "20",
    "flexDirection": "row",
    "alignItems": "center"
  },
  "shopCheck": {
    "fontSize": "48",
    "color": "#ff0000"
  },
  "shopInformation": {
    "height": "170",
    "marginLeft": "20"
  },
  "shopNameDiv": {
    "flexDirection": "row",
    "marginTop": "10"
  },
  "shopAddressDiv": {
    "flexDirection": "row",
    "marginTop": "10"
  },
  "shopName": {
    "fontWeight": "bold",
    "fontSize": "32"
  },
  "fullName": {
    "fontSize": "32"
  },
  "shopAddress": {
    "fontWeight": "bold",
    "fontSize": "32"
  },
  "concretely": {
    "fontSize": "32"
  },
  "cancelBox": {
    "width": "730",
    "alignItems": "center",
    "height": "100",
    "backgroundColor": "#eeeeee",
    "justifyContent": "center"
  }
}

/***/ }),

/***/ 681:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _fetch = __webpack_require__(79);

var _utils = __webpack_require__(18);

var utils = _interopRequireWildcard(_utils);

var _weex = __webpack_require__(99);

var _navbar = __webpack_require__(83);

var _navbar2 = _interopRequireDefault(_navbar);

var _throttle = __webpack_require__(142);

var _throttle2 = _interopRequireDefault(_throttle);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

var modal = weex.requireModule('modal');
var picker = weex.requireModule('picker');
exports.default = {
  components: {
    navbar: _navbar2.default
  },
  data: function data() {
    return {
      shops: [],
      roles: [{ id: 0, name: "4e" }],
      isPopup: false,
      storeId: '',
      id: '',
      shopId: '',
      shopName: '',
      roleName: '',
      mobile: '',
      roleId: ''
    };
  },

  props: {
    title: { default: "员工设置" }
  },
  created: function created() {
    this.id = utils.getUrlParameter('id');
    this.shopId = utils.getUrlParameter('shopId');
    this.shopName = utils.getUrlParameter('shopName');
    this.roleName = utils.getUrlParameter('roleName');
    if (/undefined/.test(this.roleName)) {
      this.roleName = '';
    }
    this.mobile = utils.getUrlParameter('mobile');
    this.roleId = utils.getUrlParameter('roleId');
    this.name = utils.getUrlParameter('name');
    this.open();
    this.huoqu();
    this.openlist();
  },

  methods: {
    roleof: function roleof(id) {
      var _this = this;
      for (var i = 0; i < _this.roles.length; i++) {
        if (_this.roles[i].id === id) {
          return i;
        }
      }
      return -1;
    },
    rolePicker: function rolePicker() {
      var _this = this;
      var rs = [];
      for (var i = 0; i < this.roles.length; i++) {
        rs.push(_this.roles[i].name);
      }
      return rs;
    },
    //            店铺列表
    open: function open() {
      var _this = this;
      (0, _fetch.GET)('farmer/member/shop/list.jhtml?pageStart=0&pageSize=500', function (mes) {
        if (mes.type === 'success') {
          _this.shops = mes.data.data;
        } else {
          _weex.event.toast(mes.content);
        }
      }, function (err) {
        _weex.event.toast(err.content);
      });
    },
    // 获取员工信息
    openlist: function openlist() {
      var _this = this;
      (0, _fetch.GET)('farmer/member/employee/list.jhtml', function (mes) {
        if (mes.type === 'success') {
          _this.lists = mes.data.data;
        } else {
          _weex.event.toast(mes.content);
        }
      }, function (err) {
        _weex.event.toast(err.content);
      });
    },
    // 获取员工角色
    huoqu: function huoqu() {
      var _this = this;
      (0, _fetch.GET)('farmer/member/role/list.jhtml', function (mes) {
        if (mes.type === 'success') {
          _this.roles = mes.data.data;
          // event.toast(JSON.stringify(mes.data));          
        } else {
          _weex.event.toast(mes.content);
        }
      }, function (err) {
        _weex.event.toast(err.content);
      });
    },
    // 选择职位
    selectPosition: (0, _throttle2.default)(500, true, function () {
      var _this = this;
      if (!_this.rolePicker().length) {
        _weex.event.toast('您还未添加角色');
        return;
      }
      picker.pick({
        index: _this.roleof(_this.roleId),
        items: _this.rolePicker()
      }, function (e) {
        if (e.result === 'success') {
          (0, _fetch.GET)('farmer/member/employee/update.jhtml?id=' + _this.id + '&roleId=' + _this.roles[e.data].id + '&shopId=' + _this.shopId, function (mes) {
            if (mes.type === "success") {
              _this.lists.forEach(function (item) {
                if (item.id == mes.data.id) {
                  _this.roleId = mes.data.roleId;
                  _this.roleName = mes.data.roleName;
                }
              });
            } else {
              _weex.event.toast(mes.content);
            }
          }, function (err) {
            _weex.event.toast("网络不稳定");
          });
        }
      });
    }),
    //  分配店铺
    allotment: (0, _throttle2.default)(500, true, function (id) {
      var _this = this;
      // let upData = {
      //   id: _this.id,
      //   shopId: id,
      //   roleId:_this.roleId
      // }
      // modal.alert({message:`${JSON.stringify(upData)}`,duration:2})
      // return
      (0, _fetch.GET)('farmer/member/employee/update.jhtml?id=' + _this.id + '&shopId=' + id + '&roleId=' + _this.roleId, function (mes) {
        if (mes.type === "success") {
          _this.lists.forEach(function (item) {
            if (item.id === mes.data.id) {
              _this.shopName = mes.data.shopName;
            }
          });
          _this.isPopup = false;
          modal.alert({
            message: mes.content,
            okTitle: '确定'
          });
        } else {
          // modal.alert({message:'进入小店铺',duration:2})
          _weex.event.toast(mes.content);
        }
      }, function (err) {
        _weex.event.toast("网络不稳定");
      });
    }),
    //            触发店铺列表
    popup: (0, _throttle2.default)(500, true, function () {
      this.storeId = this.shopId;
      if (this.isPopup === false) {
        this.isPopup = true;
      }
    }),
    //            关闭店铺列表
    doCancel: (0, _throttle2.default)(500, true, function () {
      this.isPopup = false;
    }),
    goback: (0, _throttle2.default)(500, true, function () {
      _weex.event.closeURL();
    })
  }
};

/***/ }),

/***/ 682:
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: ["wrapper"]
  }, [_c('navbar', {
    attrs: {
      "title": _vm.title
    },
    on: {
      "goback": _vm.goback
    }
  }), _c('div', {
    staticStyle: {
      backgroundColor: "white"
    }
  }, [_vm._m(0), _c('div', {
    staticClass: ["cell-panel", "space-between"]
  }, [_vm._m(1), _c('div', {
    staticClass: ["flex-row", "flex-end"]
  }, [_c('text', {
    staticClass: ["sub_title"]
  }, [_vm._v(_vm._s(_vm.name))]), _c('text', {
    staticClass: ["arrow"],
    style: {
      fontFamily: 'iconfont'
    }
  })])]), _c('div', {
    staticClass: ["cell-panel", "space-between"]
  }, [_vm._m(2), _c('div', {
    staticClass: ["flex-row", "flex-end"]
  }, [_c('text', {
    staticClass: ["sub_title"]
  }, [_vm._v(_vm._s(_vm.mobile))]), _c('text', {
    staticClass: ["arrow"],
    style: {
      fontFamily: 'iconfont'
    }
  })])]), _c('div', {
    staticClass: ["cell-panel", "space-between"],
    on: {
      "click": _vm.popup
    }
  }, [_vm._m(3), _c('div', {
    staticClass: ["flex-row", "flex-end"]
  }, [_c('text', {
    staticClass: ["sub_title"]
  }, [_vm._v(_vm._s(_vm.shopName))]), _c('text', {
    staticClass: ["arrow"],
    style: {
      fontFamily: 'iconfont'
    }
  }, [_vm._v("")])])]), _c('div', {
    staticClass: ["cell-panel", "space-between"],
    on: {
      "click": _vm.selectPosition
    }
  }, [_vm._m(4), _c('div', {
    staticClass: ["flex-row", "flex-end"]
  }, [(_vm.roleName) ? _c('text', {
    staticClass: ["sub_title"]
  }, [_vm._v(_vm._s(_vm.roleName))]) : _vm._e(), _c('text', {
    staticClass: ["arrow"],
    style: {
      fontFamily: 'iconfont'
    }
  }, [_vm._v("")])])])]), (_vm.isPopup) ? _c('div', {
    staticClass: ["shareBox"]
  }, [_vm._m(5), _c('list', _vm._l((_vm.shops), function(num) {
    return (num.status) ? _c('cell', {
      staticClass: ["message"],
      appendAsTree: true,
      attrs: {
        "append": "tree"
      },
      on: {
        "click": function($event) {
          _vm.allotment(num.id)
        }
      }
    }, [_c('div', {
      staticClass: ["shopLogo"]
    }, [(_vm.storeId == num.id) ? _c('text', {
      staticClass: ["shopCheck"],
      style: {
        fontFamily: 'iconfont'
      }
    }, [_vm._v("")]) : _vm._e(), _c('image', {
      staticClass: ["img"],
      staticStyle: {
        width: "150px",
        height: "150px"
      },
      attrs: {
        "src": num.thedoor
      }
    })]), _c('div', {
      staticClass: ["shopInformation"]
    }, [_c('div', {
      staticClass: ["shopNameDiv"]
    }, [_c('text', {
      staticClass: ["shopName"]
    }, [_vm._v("店名：")]), _c('text', {
      staticClass: ["fullName"]
    }, [_vm._v(_vm._s(num.name))])]), _c('div', {
      staticClass: ["shopAddressDiv"]
    }, [_c('text', {
      staticClass: ["shopAddress"]
    }, [_vm._v("地址：")]), _c('text', {
      staticClass: ["concretely"]
    }, [_vm._v(_vm._s(num.address))])]), _c('div', {
      staticClass: ["shopAddressDiv"]
    }, [_c('text', {
      staticClass: ["shopAddress"]
    }, [_vm._v("店长：")]), _c('text', {
      staticClass: ["concretely"]
    }, [_vm._v(_vm._s(num.linkman))])])])]) : _vm._e()
  })), _c('div', {
    staticClass: ["cancelBox"],
    on: {
      "click": _vm.doCancel
    }
  }, [_c('text', {
    staticClass: ["fz32"]
  }, [_vm._v("取消")])])]) : _vm._e()], 1)
},staticRenderFns: [function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: ["cell-panel", "space-between"]
  }, [_c('div', {
    staticClass: ["flex-row"]
  }, [_c('text', {
    staticClass: ["title", "ml10"]
  }, [_vm._v("管理员工职位与所属店铺")])]), _c('div', {
    staticClass: ["flex-row", "flex-end"]
  })])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: ["flex-row"]
  }, [_c('text', {
    staticClass: ["title", "ml10"]
  }, [_vm._v("姓名")])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: ["flex-row"]
  }, [_c('text', {
    staticClass: ["title", "ml10"]
  }, [_vm._v("联系方式")])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: ["flex-row"]
  }, [_c('text', {
    staticClass: ["title", "ml10"]
  }, [_vm._v("设置店铺:")])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: ["flex-row"]
  }, [_c('text', {
    staticClass: ["title", "ml10"]
  }, [_vm._v("设置职位:")])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticStyle: {
      width: "750px",
      alignItems: "center",
      justifyContent: "center",
      height: "70px"
    }
  }, [_c('text', {
    staticClass: ["fz30"],
    staticStyle: {
      color: "#444"
    }
  }, [_vm._v("选择所在店铺")])])
}]}
module.exports.render._withStripped = true

/***/ }),

/***/ 69:
/***/ (function(module, exports) {

module.exports = function () { /* empty */ };


/***/ }),

/***/ 7:
/***/ (function(module, exports, __webpack_require__) {

// Thank's IE8 for his funny defineProperty
module.exports = !__webpack_require__(12)(function () {
  return Object.defineProperty({}, 'a', { get: function () { return 7; } }).a != 7;
});


/***/ }),

/***/ 70:
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var LIBRARY = __webpack_require__(16);
var global = __webpack_require__(0);
var ctx = __webpack_require__(10);
var classof = __webpack_require__(36);
var $export = __webpack_require__(5);
var isObject = __webpack_require__(4);
var aFunction = __webpack_require__(14);
var anInstance = __webpack_require__(38);
var forOf = __webpack_require__(21);
var speciesConstructor = __webpack_require__(41);
var task = __webpack_require__(42).set;
var microtask = __webpack_require__(74)();
var newPromiseCapabilityModule = __webpack_require__(26);
var perform = __webpack_require__(43);
var userAgent = __webpack_require__(75);
var promiseResolve = __webpack_require__(44);
var PROMISE = 'Promise';
var TypeError = global.TypeError;
var process = global.process;
var versions = process && process.versions;
var v8 = versions && versions.v8 || '';
var $Promise = global[PROMISE];
var isNode = classof(process) == 'process';
var empty = function () { /* empty */ };
var Internal, newGenericPromiseCapability, OwnPromiseCapability, Wrapper;
var newPromiseCapability = newGenericPromiseCapability = newPromiseCapabilityModule.f;

var USE_NATIVE = !!function () {
  try {
    // correct subclassing with @@species support
    var promise = $Promise.resolve(1);
    var FakePromise = (promise.constructor = {})[__webpack_require__(1)('species')] = function (exec) {
      exec(empty, empty);
    };
    // unhandled rejections tracking support, NodeJS Promise without it fails @@species test
    return (isNode || typeof PromiseRejectionEvent == 'function')
      && promise.then(empty) instanceof FakePromise
      // v8 6.6 (Node 10 and Chrome 66) have a bug with resolving custom thenables
      // https://bugs.chromium.org/p/chromium/issues/detail?id=830565
      // we can't detect it synchronously, so just check versions
      && v8.indexOf('6.6') !== 0
      && userAgent.indexOf('Chrome/66') === -1;
  } catch (e) { /* empty */ }
}();

// helpers
var isThenable = function (it) {
  var then;
  return isObject(it) && typeof (then = it.then) == 'function' ? then : false;
};
var notify = function (promise, isReject) {
  if (promise._n) return;
  promise._n = true;
  var chain = promise._c;
  microtask(function () {
    var value = promise._v;
    var ok = promise._s == 1;
    var i = 0;
    var run = function (reaction) {
      var handler = ok ? reaction.ok : reaction.fail;
      var resolve = reaction.resolve;
      var reject = reaction.reject;
      var domain = reaction.domain;
      var result, then, exited;
      try {
        if (handler) {
          if (!ok) {
            if (promise._h == 2) onHandleUnhandled(promise);
            promise._h = 1;
          }
          if (handler === true) result = value;
          else {
            if (domain) domain.enter();
            result = handler(value); // may throw
            if (domain) {
              domain.exit();
              exited = true;
            }
          }
          if (result === reaction.promise) {
            reject(TypeError('Promise-chain cycle'));
          } else if (then = isThenable(result)) {
            then.call(result, resolve, reject);
          } else resolve(result);
        } else reject(value);
      } catch (e) {
        if (domain && !exited) domain.exit();
        reject(e);
      }
    };
    while (chain.length > i) run(chain[i++]); // variable length - can't use forEach
    promise._c = [];
    promise._n = false;
    if (isReject && !promise._h) onUnhandled(promise);
  });
};
var onUnhandled = function (promise) {
  task.call(global, function () {
    var value = promise._v;
    var unhandled = isUnhandled(promise);
    var result, handler, console;
    if (unhandled) {
      result = perform(function () {
        if (isNode) {
          process.emit('unhandledRejection', value, promise);
        } else if (handler = global.onunhandledrejection) {
          handler({ promise: promise, reason: value });
        } else if ((console = global.console) && console.error) {
          console.error('Unhandled promise rejection', value);
        }
      });
      // Browsers should not trigger `rejectionHandled` event if it was handled here, NodeJS - should
      promise._h = isNode || isUnhandled(promise) ? 2 : 1;
    } promise._a = undefined;
    if (unhandled && result.e) throw result.v;
  });
};
var isUnhandled = function (promise) {
  return promise._h !== 1 && (promise._a || promise._c).length === 0;
};
var onHandleUnhandled = function (promise) {
  task.call(global, function () {
    var handler;
    if (isNode) {
      process.emit('rejectionHandled', promise);
    } else if (handler = global.onrejectionhandled) {
      handler({ promise: promise, reason: promise._v });
    }
  });
};
var $reject = function (value) {
  var promise = this;
  if (promise._d) return;
  promise._d = true;
  promise = promise._w || promise; // unwrap
  promise._v = value;
  promise._s = 2;
  if (!promise._a) promise._a = promise._c.slice();
  notify(promise, true);
};
var $resolve = function (value) {
  var promise = this;
  var then;
  if (promise._d) return;
  promise._d = true;
  promise = promise._w || promise; // unwrap
  try {
    if (promise === value) throw TypeError("Promise can't be resolved itself");
    if (then = isThenable(value)) {
      microtask(function () {
        var wrapper = { _w: promise, _d: false }; // wrap
        try {
          then.call(value, ctx($resolve, wrapper, 1), ctx($reject, wrapper, 1));
        } catch (e) {
          $reject.call(wrapper, e);
        }
      });
    } else {
      promise._v = value;
      promise._s = 1;
      notify(promise, false);
    }
  } catch (e) {
    $reject.call({ _w: promise, _d: false }, e); // wrap
  }
};

// constructor polyfill
if (!USE_NATIVE) {
  // 25.4.3.1 Promise(executor)
  $Promise = function Promise(executor) {
    anInstance(this, $Promise, PROMISE, '_h');
    aFunction(executor);
    Internal.call(this);
    try {
      executor(ctx($resolve, this, 1), ctx($reject, this, 1));
    } catch (err) {
      $reject.call(this, err);
    }
  };
  // eslint-disable-next-line no-unused-vars
  Internal = function Promise(executor) {
    this._c = [];             // <- awaiting reactions
    this._a = undefined;      // <- checked in isUnhandled reactions
    this._s = 0;              // <- state
    this._d = false;          // <- done
    this._v = undefined;      // <- value
    this._h = 0;              // <- rejection state, 0 - default, 1 - handled, 2 - unhandled
    this._n = false;          // <- notify
  };
  Internal.prototype = __webpack_require__(39)($Promise.prototype, {
    // 25.4.5.3 Promise.prototype.then(onFulfilled, onRejected)
    then: function then(onFulfilled, onRejected) {
      var reaction = newPromiseCapability(speciesConstructor(this, $Promise));
      reaction.ok = typeof onFulfilled == 'function' ? onFulfilled : true;
      reaction.fail = typeof onRejected == 'function' && onRejected;
      reaction.domain = isNode ? process.domain : undefined;
      this._c.push(reaction);
      if (this._a) this._a.push(reaction);
      if (this._s) notify(this, false);
      return reaction.promise;
    },
    // 25.4.5.1 Promise.prototype.catch(onRejected)
    'catch': function (onRejected) {
      return this.then(undefined, onRejected);
    }
  });
  OwnPromiseCapability = function () {
    var promise = new Internal();
    this.promise = promise;
    this.resolve = ctx($resolve, promise, 1);
    this.reject = ctx($reject, promise, 1);
  };
  newPromiseCapabilityModule.f = newPromiseCapability = function (C) {
    return C === $Promise || C === Wrapper
      ? new OwnPromiseCapability(C)
      : newGenericPromiseCapability(C);
  };
}

$export($export.G + $export.W + $export.F * !USE_NATIVE, { Promise: $Promise });
__webpack_require__(17)($Promise, PROMISE);
__webpack_require__(56)(PROMISE);
Wrapper = __webpack_require__(2)[PROMISE];

// statics
$export($export.S + $export.F * !USE_NATIVE, PROMISE, {
  // 25.4.4.5 Promise.reject(r)
  reject: function reject(r) {
    var capability = newPromiseCapability(this);
    var $$reject = capability.reject;
    $$reject(r);
    return capability.promise;
  }
});
$export($export.S + $export.F * (LIBRARY || !USE_NATIVE), PROMISE, {
  // 25.4.4.6 Promise.resolve(x)
  resolve: function resolve(x) {
    return promiseResolve(LIBRARY && this === Wrapper ? $Promise : this, x);
  }
});
$export($export.S + $export.F * !(USE_NATIVE && __webpack_require__(76)(function (iter) {
  $Promise.all(iter)['catch'](empty);
})), PROMISE, {
  // 25.4.4.1 Promise.all(iterable)
  all: function all(iterable) {
    var C = this;
    var capability = newPromiseCapability(C);
    var resolve = capability.resolve;
    var reject = capability.reject;
    var result = perform(function () {
      var values = [];
      var index = 0;
      var remaining = 1;
      forOf(iterable, false, function (promise) {
        var $index = index++;
        var alreadyCalled = false;
        values.push(undefined);
        remaining++;
        C.resolve(promise).then(function (value) {
          if (alreadyCalled) return;
          alreadyCalled = true;
          values[$index] = value;
          --remaining || resolve(values);
        }, reject);
      });
      --remaining || resolve(values);
    });
    if (result.e) reject(result.v);
    return capability.promise;
  },
  // 25.4.4.4 Promise.race(iterable)
  race: function race(iterable) {
    var C = this;
    var capability = newPromiseCapability(C);
    var reject = capability.reject;
    var result = perform(function () {
      forOf(iterable, false, function (promise) {
        C.resolve(promise).then(capability.resolve, reject);
      });
    });
    if (result.e) reject(result.v);
    return capability.promise;
  }
});


/***/ }),

/***/ 71:
/***/ (function(module, exports, __webpack_require__) {

// call something on iterator step with safe closing on error
var anObject = __webpack_require__(3);
module.exports = function (iterator, fn, value, entries) {
  try {
    return entries ? fn(anObject(value)[0], value[1]) : fn(value);
  // 7.4.6 IteratorClose(iterator, completion)
  } catch (e) {
    var ret = iterator['return'];
    if (ret !== undefined) anObject(ret.call(iterator));
    throw e;
  }
};


/***/ }),

/***/ 72:
/***/ (function(module, exports, __webpack_require__) {

// check on default Array iterator
var Iterators = __webpack_require__(11);
var ITERATOR = __webpack_require__(1)('iterator');
var ArrayProto = Array.prototype;

module.exports = function (it) {
  return it !== undefined && (Iterators.Array === it || ArrayProto[ITERATOR] === it);
};


/***/ }),

/***/ 73:
/***/ (function(module, exports) {

// fast apply, http://jsperf.lnkit.com/fast-apply/5
module.exports = function (fn, args, that) {
  var un = that === undefined;
  switch (args.length) {
    case 0: return un ? fn()
                      : fn.call(that);
    case 1: return un ? fn(args[0])
                      : fn.call(that, args[0]);
    case 2: return un ? fn(args[0], args[1])
                      : fn.call(that, args[0], args[1]);
    case 3: return un ? fn(args[0], args[1], args[2])
                      : fn.call(that, args[0], args[1], args[2]);
    case 4: return un ? fn(args[0], args[1], args[2], args[3])
                      : fn.call(that, args[0], args[1], args[2], args[3]);
  } return fn.apply(that, args);
};


/***/ }),

/***/ 74:
/***/ (function(module, exports, __webpack_require__) {

var global = __webpack_require__(0);
var macrotask = __webpack_require__(42).set;
var Observer = global.MutationObserver || global.WebKitMutationObserver;
var process = global.process;
var Promise = global.Promise;
var isNode = __webpack_require__(13)(process) == 'process';

module.exports = function () {
  var head, last, notify;

  var flush = function () {
    var parent, fn;
    if (isNode && (parent = process.domain)) parent.exit();
    while (head) {
      fn = head.fn;
      head = head.next;
      try {
        fn();
      } catch (e) {
        if (head) notify();
        else last = undefined;
        throw e;
      }
    } last = undefined;
    if (parent) parent.enter();
  };

  // Node.js
  if (isNode) {
    notify = function () {
      process.nextTick(flush);
    };
  // browsers with MutationObserver, except iOS Safari - https://github.com/zloirock/core-js/issues/339
  } else if (Observer && !(global.navigator && global.navigator.standalone)) {
    var toggle = true;
    var node = document.createTextNode('');
    new Observer(flush).observe(node, { characterData: true }); // eslint-disable-line no-new
    notify = function () {
      node.data = toggle = !toggle;
    };
  // environments with maybe non-completely correct, but existent Promise
  } else if (Promise && Promise.resolve) {
    // Promise.resolve without an argument throws an error in LG WebOS 2
    var promise = Promise.resolve(undefined);
    notify = function () {
      promise.then(flush);
    };
  // for other environments - macrotask based on:
  // - setImmediate
  // - MessageChannel
  // - window.postMessag
  // - onreadystatechange
  // - setTimeout
  } else {
    notify = function () {
      // strange IE + webpack dev server bug - use .call(global)
      macrotask.call(global, flush);
    };
  }

  return function (fn) {
    var task = { fn: fn, next: undefined };
    if (last) last.next = task;
    if (!head) {
      head = task;
      notify();
    } last = task;
  };
};


/***/ }),

/***/ 75:
/***/ (function(module, exports, __webpack_require__) {

var global = __webpack_require__(0);
var navigator = global.navigator;

module.exports = navigator && navigator.userAgent || '';


/***/ }),

/***/ 76:
/***/ (function(module, exports, __webpack_require__) {

var ITERATOR = __webpack_require__(1)('iterator');
var SAFE_CLOSING = false;

try {
  var riter = [7][ITERATOR]();
  riter['return'] = function () { SAFE_CLOSING = true; };
  // eslint-disable-next-line no-throw-literal
  Array.from(riter, function () { throw 2; });
} catch (e) { /* empty */ }

module.exports = function (exec, skipClosing) {
  if (!skipClosing && !SAFE_CLOSING) return false;
  var safe = false;
  try {
    var arr = [7];
    var iter = arr[ITERATOR]();
    iter.next = function () { return { done: safe = true }; };
    arr[ITERATOR] = function () { return iter; };
    exec(arr);
  } catch (e) { /* empty */ }
  return safe;
};


/***/ }),

/***/ 77:
/***/ (function(module, exports, __webpack_require__) {

"use strict";
// https://github.com/tc39/proposal-promise-finally

var $export = __webpack_require__(5);
var core = __webpack_require__(2);
var global = __webpack_require__(0);
var speciesConstructor = __webpack_require__(41);
var promiseResolve = __webpack_require__(44);

$export($export.P + $export.R, 'Promise', { 'finally': function (onFinally) {
  var C = speciesConstructor(this, core.Promise || global.Promise);
  var isFunction = typeof onFinally == 'function';
  return this.then(
    isFunction ? function (x) {
      return promiseResolve(C, onFinally()).then(function () { return x; });
    } : onFinally,
    isFunction ? function (e) {
      return promiseResolve(C, onFinally()).then(function () { throw e; });
    } : onFinally
  );
} });


/***/ }),

/***/ 78:
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// https://github.com/tc39/proposal-promise-try
var $export = __webpack_require__(5);
var newPromiseCapability = __webpack_require__(26);
var perform = __webpack_require__(43);

$export($export.S, 'Promise', { 'try': function (callbackfn) {
  var promiseCapability = newPromiseCapability.f(this);
  var result = perform(callbackfn);
  (result.e ? promiseCapability.reject : promiseCapability.resolve)(result.v);
  return promiseCapability.promise;
} });


/***/ }),

/***/ 79:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _promise = __webpack_require__(37);

var _promise2 = _interopRequireDefault(_promise);

exports.POST = POST;
exports.GET = GET;
exports.SCAN = SCAN;

var _utils = __webpack_require__(18);

var _utils2 = _interopRequireDefault(_utils);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var stream = weex.requireModule('stream');
var modal = weex.requireModule('modal');
var baseURL = '';
var event = weex.requireModule('event');
function POST(path, body) {
  return new _promise2.default(function (resolve, reject) {
    stream.fetch({
      method: 'POST',
      url: '' + baseURL + path,
      type: 'json',
      body: '' + body
    }, function (response) {
      if (response.status == 200) {
        resolve(response.data);
      } else {
        reject({
          type: "error",
          content: "网络不稳定"
        });
      }
    }, function () {});
  });
}
function GET(path, resolve, reject) {
  // let cacheParams = {
  //     type:'httpCache',//类型
  //     key:`${baseURL}${path}`,//关键址
  // }
  // event.find(cacheParams,function (cache) {
  //    if (cache.type=='success') {
  //        if (cache.data != '') {
  //            resolve(JSON.parse(cache.data.value));
  //        }
  //    }
  // })
  stream.fetch({
    method: 'GET',
    url: '' + baseURL + path,
    type: 'json'
  }, function (response) {
    // 请求 type=success 或 warn 或 error（没缓存） 时返回，都能正常获取数据
    if (response.status == 200) {
      resolve(response.data);
    } else
      // 请求 type= error 网络正常，但服务器返回错误，有缓存，也需要给数据，并提示出错了  statusText=服务器返回的 content
      // 网络异常，有缓存，需要给出缓存数据，并且   statusText 固定为 "网络不稳定"
      if (response.status == 304) {
        resolve(response.data);
        reject({
          type: "error",
          content: response.statusText
        });
      } else {
        // 网络异常，没有缓存
        reject({
          type: "error",
          content: '网络不稳定'
        });
      }
  }, function () {});
}
// 二维码扫描
function SCAN(message, resolve, reject) {
  if (message.type == 'success') {
    _utils2.default.readScan(message.data, function (data) {
      if (data.type == 'success') {
        if (data.data.type == '865380') {
          var userId = parseInt(data.data.code, 10) - 10200;
          POST('weex/member/friends/add.jhtml?friendId=' + userId).then(function (mes) {
            if (mes.type == "success") {
              event.toast('添加好友请求已发送,请等待对方验证');
            } else {
              event.toast(mes.content);
            }
            resolve(mes);
          }, function (err) {
            reject(err);
            event.toast(err.content);
          });
        } else if (data.data.type == '818803') {
          GET('weex/member/coupon/code/use.jhtml?code=' + data.data.code, function (mes) {
            modal.alert({
              message: mes.content,
              duration: 0.3
            }, function (value) {});
          }, function (err) {
            event.toast(err.content);
          });
        } else if (data.data.type == 'webView') {
          event.openURL(message.data, function () {});
        } else {
          event.toast('无效验证码');
        }
      } else {
        event.toast(data.content);
      }
    });
  } else {}
}

/***/ }),

/***/ 8:
/***/ (function(module, exports, __webpack_require__) {

var anObject = __webpack_require__(3);
var IE8_DOM_DEFINE = __webpack_require__(51);
var toPrimitive = __webpack_require__(46);
var dP = Object.defineProperty;

exports.f = __webpack_require__(7) ? Object.defineProperty : function defineProperty(O, P, Attributes) {
  anObject(O);
  P = toPrimitive(P, true);
  anObject(Attributes);
  if (IE8_DOM_DEFINE) try {
    return dP(O, P, Attributes);
  } catch (e) { /* empty */ }
  if ('get' in Attributes || 'set' in Attributes) throw TypeError('Accessors not supported!');
  if ('value' in Attributes) O[P] = Attributes.value;
  return O;
};


/***/ }),

/***/ 83:
/***/ (function(module, exports, __webpack_require__) {

var __vue_exports__, __vue_options__
var __vue_styles__ = []

/* styles */
__vue_styles__.push(__webpack_require__(84)
)
__vue_styles__.push(__webpack_require__(85)
)

/* script */
__vue_exports__ = __webpack_require__(86)

/* template */
var __vue_template__ = __webpack_require__(87)
__vue_options__ = __vue_exports__ = __vue_exports__ || {}
if (
  typeof __vue_exports__.default === "object" ||
  typeof __vue_exports__.default === "function"
) {
if (Object.keys(__vue_exports__).some(function (key) { return key !== "default" && key !== "__esModule" })) {console.error("named exports are not supported in *.vue files.")}
__vue_options__ = __vue_exports__ = __vue_exports__.default
}
if (typeof __vue_options__ === "function") {
  __vue_options__ = __vue_options__.options
}
__vue_options__.__file = "D:\\farmer\\src\\include\\navbar.vue"
__vue_options__.render = __vue_template__.render
__vue_options__.staticRenderFns = __vue_template__.staticRenderFns
__vue_options__._scopeId = "data-v-261a126c"
__vue_options__.style = __vue_options__.style || {}
__vue_styles__.forEach(function (module) {
  for (var name in module) {
    __vue_options__.style[name] = module[name]
  }
})
if (typeof __register_static_styles__ === "function") {
  __register_static_styles__(__vue_options__._scopeId, __vue_styles__)
}

module.exports = __vue_exports__


/***/ }),

/***/ 84:
/***/ (function(module, exports) {

module.exports = {
  "ft6": {
    "fontSize": "6"
  },
  "ft7": {
    "fontSize": "7"
  },
  "ft8": {
    "fontSize": "8"
  },
  "ft9": {
    "fontSize": "9"
  },
  "ft10": {
    "fontSize": "10"
  },
  "ft11": {
    "fontSize": "11"
  },
  "ft12": {
    "fontSize": "12"
  },
  "ft13": {
    "fontSize": "13"
  },
  "ft14": {
    "fontSize": "14"
  },
  "ft15": {
    "fontSize": "15"
  },
  "ft16": {
    "fontSize": "16"
  },
  "ft17": {
    "fontSize": "17"
  },
  "ft18": {
    "fontSize": "18"
  },
  "ft19": {
    "fontSize": "19"
  },
  "ft20": {
    "fontSize": "20"
  },
  "ft21": {
    "fontSize": "21"
  },
  "ft22": {
    "fontSize": "22"
  },
  "ft23": {
    "fontSize": "23"
  },
  "ft24": {
    "fontSize": "24"
  },
  "ft25": {
    "fontSize": "25"
  },
  "ft26": {
    "fontSize": "26"
  },
  "ft27": {
    "fontSize": "27"
  },
  "ft28": {
    "fontSize": "28"
  },
  "ft29": {
    "fontSize": "29"
  },
  "ft30": {
    "fontSize": "30"
  },
  "ft31": {
    "fontSize": "31"
  },
  "ft32": {
    "fontSize": "32"
  },
  "ft33": {
    "fontSize": "33"
  },
  "ft34": {
    "fontSize": "34"
  },
  "ft35": {
    "fontSize": "35"
  },
  "ft36": {
    "fontSize": "36"
  },
  "ft37": {
    "fontSize": "37"
  },
  "ft38": {
    "fontSize": "38"
  },
  "ft39": {
    "fontSize": "39"
  },
  "ft40": {
    "fontSize": "40"
  },
  "ft41": {
    "fontSize": "41"
  },
  "ft42": {
    "fontSize": "42"
  },
  "ft43": {
    "fontSize": "43"
  },
  "ft44": {
    "fontSize": "44"
  },
  "ft45": {
    "fontSize": "45"
  },
  "ft46": {
    "fontSize": "46"
  },
  "ft47": {
    "fontSize": "47"
  },
  "ft48": {
    "fontSize": "48"
  },
  "ft49": {
    "fontSize": "49"
  },
  "ft50": {
    "fontSize": "50"
  },
  "ft51": {
    "fontSize": "51"
  },
  "ft52": {
    "fontSize": "52"
  },
  "ft53": {
    "fontSize": "53"
  },
  "ft54": {
    "fontSize": "54"
  },
  "ft55": {
    "fontSize": "55"
  },
  "ft56": {
    "fontSize": "56"
  },
  "ft57": {
    "fontSize": "57"
  },
  "ft58": {
    "fontSize": "58"
  },
  "ft59": {
    "fontSize": "59"
  },
  "ft60": {
    "fontSize": "60"
  },
  "ft61": {
    "fontSize": "61"
  },
  "ft62": {
    "fontSize": "62"
  },
  "ft63": {
    "fontSize": "63"
  },
  "ft64": {
    "fontSize": "64"
  },
  "ft65": {
    "fontSize": "65"
  },
  "ft66": {
    "fontSize": "66"
  },
  "ft67": {
    "fontSize": "67"
  },
  "ft68": {
    "fontSize": "68"
  },
  "ft69": {
    "fontSize": "69"
  },
  "ft70": {
    "fontSize": "70"
  },
  "ft71": {
    "fontSize": "71"
  },
  "ft72": {
    "fontSize": "72"
  },
  "ft73": {
    "fontSize": "73"
  },
  "ft74": {
    "fontSize": "74"
  },
  "ft75": {
    "fontSize": "75"
  },
  "ft76": {
    "fontSize": "76"
  },
  "ft77": {
    "fontSize": "77"
  },
  "ft78": {
    "fontSize": "78"
  },
  "ft79": {
    "fontSize": "79"
  },
  "ft80": {
    "fontSize": "80"
  },
  "ft81": {
    "fontSize": "81"
  },
  "ft82": {
    "fontSize": "82"
  },
  "ft83": {
    "fontSize": "83"
  },
  "ft84": {
    "fontSize": "84"
  },
  "ft85": {
    "fontSize": "85"
  },
  "ft86": {
    "fontSize": "86"
  },
  "ft87": {
    "fontSize": "87"
  },
  "ft88": {
    "fontSize": "88"
  },
  "ft89": {
    "fontSize": "89"
  },
  "ft90": {
    "fontSize": "90"
  },
  "ft91": {
    "fontSize": "91"
  },
  "ft92": {
    "fontSize": "92"
  },
  "ft93": {
    "fontSize": "93"
  },
  "ft94": {
    "fontSize": "94"
  },
  "ft95": {
    "fontSize": "95"
  },
  "ft96": {
    "fontSize": "96"
  },
  "ft97": {
    "fontSize": "97"
  },
  "ft98": {
    "fontSize": "98"
  },
  "ft99": {
    "fontSize": "99"
  },
  "ft100": {
    "fontSize": "100"
  },
  "mgt2": {
    "marginTop": "2"
  },
  "mgb2": {
    "marginBottom": "2"
  },
  "mgl2": {
    "marginLeft": "2"
  },
  "mgr2": {
    "marginRight": "2"
  },
  "pdt2": {
    "paddingTop": "2"
  },
  "pdb2": {
    "paddingBottom": "2"
  },
  "pdl2": {
    "paddingLeft": "2"
  },
  "pdr2": {
    "paddingRight": "2"
  },
  "mgt4": {
    "marginTop": "4"
  },
  "mgb4": {
    "marginBottom": "4"
  },
  "mgl4": {
    "marginLeft": "4"
  },
  "mgr4": {
    "marginRight": "4"
  },
  "pdt4": {
    "paddingTop": "4"
  },
  "pdb4": {
    "paddingBottom": "4"
  },
  "pdl4": {
    "paddingLeft": "4"
  },
  "pdr4": {
    "paddingRight": "4"
  },
  "mgt5": {
    "marginTop": "5"
  },
  "mgb5": {
    "marginBottom": "5"
  },
  "mgl5": {
    "marginLeft": "5"
  },
  "mgr5": {
    "marginRight": "5"
  },
  "pdt5": {
    "paddingTop": "5"
  },
  "pdb5": {
    "paddingBottom": "5"
  },
  "pdl5": {
    "paddingLeft": "5"
  },
  "pdr5": {
    "paddingRight": "5"
  },
  "mgt6": {
    "marginTop": "6"
  },
  "mgb6": {
    "marginBottom": "6"
  },
  "mgl6": {
    "marginLeft": "6"
  },
  "mgr6": {
    "marginRight": "6"
  },
  "pdt6": {
    "paddingTop": "6"
  },
  "pdb6": {
    "paddingBottom": "6"
  },
  "pdl6": {
    "paddingLeft": "6"
  },
  "pdr6": {
    "paddingRight": "6"
  },
  "mgt8": {
    "marginTop": "8"
  },
  "mgb8": {
    "marginBottom": "8"
  },
  "mgl8": {
    "marginLeft": "8"
  },
  "mgr8": {
    "marginRight": "8"
  },
  "pdt8": {
    "paddingTop": "8"
  },
  "pdb8": {
    "paddingBottom": "8"
  },
  "pdl8": {
    "paddingLeft": "8"
  },
  "pdr8": {
    "paddingRight": "8"
  },
  "mgt10": {
    "marginTop": "10"
  },
  "mgb10": {
    "marginBottom": "10"
  },
  "mgl10": {
    "marginLeft": "10"
  },
  "mgr10": {
    "marginRight": "10"
  },
  "pdt10": {
    "paddingTop": "10"
  },
  "pdb10": {
    "paddingBottom": "10"
  },
  "pdl10": {
    "paddingLeft": "10"
  },
  "pdr10": {
    "paddingRight": "10"
  },
  "mgt12": {
    "marginTop": "12"
  },
  "mgb12": {
    "marginBottom": "12"
  },
  "mgl12": {
    "marginLeft": "12"
  },
  "mgr12": {
    "marginRight": "12"
  },
  "pdt12": {
    "paddingTop": "12"
  },
  "pdb12": {
    "paddingBottom": "12"
  },
  "pdl12": {
    "paddingLeft": "12"
  },
  "pdr12": {
    "paddingRight": "12"
  },
  "mgt14": {
    "marginTop": "14"
  },
  "mgb14": {
    "marginBottom": "14"
  },
  "mgl14": {
    "marginLeft": "14"
  },
  "mgr14": {
    "marginRight": "14"
  },
  "pdt14": {
    "paddingTop": "14"
  },
  "pdb14": {
    "paddingBottom": "14"
  },
  "pdl14": {
    "paddingLeft": "14"
  },
  "pdr14": {
    "paddingRight": "14"
  },
  "mgt15": {
    "marginTop": "15"
  },
  "mgb15": {
    "marginBottom": "15"
  },
  "mgl15": {
    "marginLeft": "15"
  },
  "mgr15": {
    "marginRight": "15"
  },
  "pdt15": {
    "paddingTop": "15"
  },
  "pdb15": {
    "paddingBottom": "15"
  },
  "pdl15": {
    "paddingLeft": "15"
  },
  "pdr15": {
    "paddingRight": "15"
  },
  "mgt16": {
    "marginTop": "16"
  },
  "mgb16": {
    "marginBottom": "16"
  },
  "mgl16": {
    "marginLeft": "16"
  },
  "mgr16": {
    "marginRight": "16"
  },
  "pdt16": {
    "paddingTop": "16"
  },
  "pdb16": {
    "paddingBottom": "16"
  },
  "pdl16": {
    "paddingLeft": "16"
  },
  "pdr16": {
    "paddingRight": "16"
  },
  "mgt18": {
    "marginTop": "18"
  },
  "mgb18": {
    "marginBottom": "18"
  },
  "mgl18": {
    "marginLeft": "18"
  },
  "mgr18": {
    "marginRight": "18"
  },
  "pdt18": {
    "paddingTop": "18"
  },
  "pdb18": {
    "paddingBottom": "18"
  },
  "pdl18": {
    "paddingLeft": "18"
  },
  "pdr18": {
    "paddingRight": "18"
  },
  "mgt20": {
    "marginTop": "20"
  },
  "mgb20": {
    "marginBottom": "20"
  },
  "mgl20": {
    "marginLeft": "20"
  },
  "mgr20": {
    "marginRight": "20"
  },
  "pdt20": {
    "paddingTop": "20"
  },
  "pdb20": {
    "paddingBottom": "20"
  },
  "pdl20": {
    "paddingLeft": "20"
  },
  "pdr20": {
    "paddingRight": "20"
  },
  "mgt22": {
    "marginTop": "22"
  },
  "mgb22": {
    "marginBottom": "22"
  },
  "mgl22": {
    "marginLeft": "22"
  },
  "mgr22": {
    "marginRight": "22"
  },
  "pdt22": {
    "paddingTop": "22"
  },
  "pdb22": {
    "paddingBottom": "22"
  },
  "pdl22": {
    "paddingLeft": "22"
  },
  "pdr22": {
    "paddingRight": "22"
  },
  "mgt24": {
    "marginTop": "24"
  },
  "mgb24": {
    "marginBottom": "24"
  },
  "mgl24": {
    "marginLeft": "24"
  },
  "mgr24": {
    "marginRight": "24"
  },
  "pdt24": {
    "paddingTop": "24"
  },
  "pdb24": {
    "paddingBottom": "24"
  },
  "pdl24": {
    "paddingLeft": "24"
  },
  "pdr24": {
    "paddingRight": "24"
  },
  "mgt25": {
    "marginTop": "25"
  },
  "mgb25": {
    "marginBottom": "25"
  },
  "mgl25": {
    "marginLeft": "25"
  },
  "mgr25": {
    "marginRight": "25"
  },
  "pdt25": {
    "paddingTop": "25"
  },
  "pdb25": {
    "paddingBottom": "25"
  },
  "pdl25": {
    "paddingLeft": "25"
  },
  "pdr25": {
    "paddingRight": "25"
  },
  "mgt26": {
    "marginTop": "26"
  },
  "mgb26": {
    "marginBottom": "26"
  },
  "mgl26": {
    "marginLeft": "26"
  },
  "mgr26": {
    "marginRight": "26"
  },
  "pdt26": {
    "paddingTop": "26"
  },
  "pdb26": {
    "paddingBottom": "26"
  },
  "pdl26": {
    "paddingLeft": "26"
  },
  "pdr26": {
    "paddingRight": "26"
  },
  "mgt28": {
    "marginTop": "28"
  },
  "mgb28": {
    "marginBottom": "28"
  },
  "mgl28": {
    "marginLeft": "28"
  },
  "mgr28": {
    "marginRight": "28"
  },
  "pdt28": {
    "paddingTop": "28"
  },
  "pdb28": {
    "paddingBottom": "28"
  },
  "pdl28": {
    "paddingLeft": "28"
  },
  "pdr28": {
    "paddingRight": "28"
  },
  "mgt30": {
    "marginTop": "30"
  },
  "mgb30": {
    "marginBottom": "30"
  },
  "mgl30": {
    "marginLeft": "30"
  },
  "mgr30": {
    "marginRight": "30"
  },
  "pdt30": {
    "paddingTop": "30"
  },
  "pdb30": {
    "paddingBottom": "30"
  },
  "pdl30": {
    "paddingLeft": "30"
  },
  "pdr30": {
    "paddingRight": "30"
  },
  "mgt32": {
    "marginTop": "32"
  },
  "mgb32": {
    "marginBottom": "32"
  },
  "mgl32": {
    "marginLeft": "32"
  },
  "mgr32": {
    "marginRight": "32"
  },
  "pdt32": {
    "paddingTop": "32"
  },
  "pdb32": {
    "paddingBottom": "32"
  },
  "pdl32": {
    "paddingLeft": "32"
  },
  "pdr32": {
    "paddingRight": "32"
  },
  "mgt34": {
    "marginTop": "34"
  },
  "mgb34": {
    "marginBottom": "34"
  },
  "mgl34": {
    "marginLeft": "34"
  },
  "mgr34": {
    "marginRight": "34"
  },
  "pdt34": {
    "paddingTop": "34"
  },
  "pdb34": {
    "paddingBottom": "34"
  },
  "pdl34": {
    "paddingLeft": "34"
  },
  "pdr34": {
    "paddingRight": "34"
  },
  "mgt35": {
    "marginTop": "35"
  },
  "mgb35": {
    "marginBottom": "35"
  },
  "mgl35": {
    "marginLeft": "35"
  },
  "mgr35": {
    "marginRight": "35"
  },
  "pdt35": {
    "paddingTop": "35"
  },
  "pdb35": {
    "paddingBottom": "35"
  },
  "pdl35": {
    "paddingLeft": "35"
  },
  "pdr35": {
    "paddingRight": "35"
  },
  "mgt36": {
    "marginTop": "36"
  },
  "mgb36": {
    "marginBottom": "36"
  },
  "mgl36": {
    "marginLeft": "36"
  },
  "mgr36": {
    "marginRight": "36"
  },
  "pdt36": {
    "paddingTop": "36"
  },
  "pdb36": {
    "paddingBottom": "36"
  },
  "pdl36": {
    "paddingLeft": "36"
  },
  "pdr36": {
    "paddingRight": "36"
  },
  "mgt38": {
    "marginTop": "38"
  },
  "mgb38": {
    "marginBottom": "38"
  },
  "mgl38": {
    "marginLeft": "38"
  },
  "mgr38": {
    "marginRight": "38"
  },
  "pdt38": {
    "paddingTop": "38"
  },
  "pdb38": {
    "paddingBottom": "38"
  },
  "pdl38": {
    "paddingLeft": "38"
  },
  "pdr38": {
    "paddingRight": "38"
  },
  "mgt40": {
    "marginTop": "40"
  },
  "mgb40": {
    "marginBottom": "40"
  },
  "mgl40": {
    "marginLeft": "40"
  },
  "mgr40": {
    "marginRight": "40"
  },
  "pdt40": {
    "paddingTop": "40"
  },
  "pdb40": {
    "paddingBottom": "40"
  },
  "pdl40": {
    "paddingLeft": "40"
  },
  "pdr40": {
    "paddingRight": "40"
  },
  "mgt42": {
    "marginTop": "42"
  },
  "mgb42": {
    "marginBottom": "42"
  },
  "mgl42": {
    "marginLeft": "42"
  },
  "mgr42": {
    "marginRight": "42"
  },
  "pdt42": {
    "paddingTop": "42"
  },
  "pdb42": {
    "paddingBottom": "42"
  },
  "pdl42": {
    "paddingLeft": "42"
  },
  "pdr42": {
    "paddingRight": "42"
  },
  "mgt44": {
    "marginTop": "44"
  },
  "mgb44": {
    "marginBottom": "44"
  },
  "mgl44": {
    "marginLeft": "44"
  },
  "mgr44": {
    "marginRight": "44"
  },
  "pdt44": {
    "paddingTop": "44"
  },
  "pdb44": {
    "paddingBottom": "44"
  },
  "pdl44": {
    "paddingLeft": "44"
  },
  "pdr44": {
    "paddingRight": "44"
  },
  "mgt45": {
    "marginTop": "45"
  },
  "mgb45": {
    "marginBottom": "45"
  },
  "mgl45": {
    "marginLeft": "45"
  },
  "mgr45": {
    "marginRight": "45"
  },
  "pdt45": {
    "paddingTop": "45"
  },
  "pdb45": {
    "paddingBottom": "45"
  },
  "pdl45": {
    "paddingLeft": "45"
  },
  "pdr45": {
    "paddingRight": "45"
  },
  "mgt46": {
    "marginTop": "46"
  },
  "mgb46": {
    "marginBottom": "46"
  },
  "mgl46": {
    "marginLeft": "46"
  },
  "mgr46": {
    "marginRight": "46"
  },
  "pdt46": {
    "paddingTop": "46"
  },
  "pdb46": {
    "paddingBottom": "46"
  },
  "pdl46": {
    "paddingLeft": "46"
  },
  "pdr46": {
    "paddingRight": "46"
  },
  "mgt48": {
    "marginTop": "48"
  },
  "mgb48": {
    "marginBottom": "48"
  },
  "mgl48": {
    "marginLeft": "48"
  },
  "mgr48": {
    "marginRight": "48"
  },
  "pdt48": {
    "paddingTop": "48"
  },
  "pdb48": {
    "paddingBottom": "48"
  },
  "pdl48": {
    "paddingLeft": "48"
  },
  "pdr48": {
    "paddingRight": "48"
  },
  "mgt50": {
    "marginTop": "50"
  },
  "mgb50": {
    "marginBottom": "50"
  },
  "mgl50": {
    "marginLeft": "50"
  },
  "mgr50": {
    "marginRight": "50"
  },
  "pdt50": {
    "paddingTop": "50"
  },
  "pdb50": {
    "paddingBottom": "50"
  },
  "pdl50": {
    "paddingLeft": "50"
  },
  "pdr50": {
    "paddingRight": "50"
  },
  "mgt52": {
    "marginTop": "52"
  },
  "mgb52": {
    "marginBottom": "52"
  },
  "mgl52": {
    "marginLeft": "52"
  },
  "mgr52": {
    "marginRight": "52"
  },
  "pdt52": {
    "paddingTop": "52"
  },
  "pdb52": {
    "paddingBottom": "52"
  },
  "pdl52": {
    "paddingLeft": "52"
  },
  "pdr52": {
    "paddingRight": "52"
  },
  "mgt54": {
    "marginTop": "54"
  },
  "mgb54": {
    "marginBottom": "54"
  },
  "mgl54": {
    "marginLeft": "54"
  },
  "mgr54": {
    "marginRight": "54"
  },
  "pdt54": {
    "paddingTop": "54"
  },
  "pdb54": {
    "paddingBottom": "54"
  },
  "pdl54": {
    "paddingLeft": "54"
  },
  "pdr54": {
    "paddingRight": "54"
  },
  "mgt55": {
    "marginTop": "55"
  },
  "mgb55": {
    "marginBottom": "55"
  },
  "mgl55": {
    "marginLeft": "55"
  },
  "mgr55": {
    "marginRight": "55"
  },
  "pdt55": {
    "paddingTop": "55"
  },
  "pdb55": {
    "paddingBottom": "55"
  },
  "pdl55": {
    "paddingLeft": "55"
  },
  "pdr55": {
    "paddingRight": "55"
  },
  "mgt56": {
    "marginTop": "56"
  },
  "mgb56": {
    "marginBottom": "56"
  },
  "mgl56": {
    "marginLeft": "56"
  },
  "mgr56": {
    "marginRight": "56"
  },
  "pdt56": {
    "paddingTop": "56"
  },
  "pdb56": {
    "paddingBottom": "56"
  },
  "pdl56": {
    "paddingLeft": "56"
  },
  "pdr56": {
    "paddingRight": "56"
  },
  "mgt58": {
    "marginTop": "58"
  },
  "mgb58": {
    "marginBottom": "58"
  },
  "mgl58": {
    "marginLeft": "58"
  },
  "mgr58": {
    "marginRight": "58"
  },
  "pdt58": {
    "paddingTop": "58"
  },
  "pdb58": {
    "paddingBottom": "58"
  },
  "pdl58": {
    "paddingLeft": "58"
  },
  "pdr58": {
    "paddingRight": "58"
  },
  "mgt60": {
    "marginTop": "60"
  },
  "mgb60": {
    "marginBottom": "60"
  },
  "mgl60": {
    "marginLeft": "60"
  },
  "mgr60": {
    "marginRight": "60"
  },
  "pdt60": {
    "paddingTop": "60"
  },
  "pdb60": {
    "paddingBottom": "60"
  },
  "pdl60": {
    "paddingLeft": "60"
  },
  "pdr60": {
    "paddingRight": "60"
  },
  "mgt62": {
    "marginTop": "62"
  },
  "mgb62": {
    "marginBottom": "62"
  },
  "mgl62": {
    "marginLeft": "62"
  },
  "mgr62": {
    "marginRight": "62"
  },
  "pdt62": {
    "paddingTop": "62"
  },
  "pdb62": {
    "paddingBottom": "62"
  },
  "pdl62": {
    "paddingLeft": "62"
  },
  "pdr62": {
    "paddingRight": "62"
  },
  "mgt64": {
    "marginTop": "64"
  },
  "mgb64": {
    "marginBottom": "64"
  },
  "mgl64": {
    "marginLeft": "64"
  },
  "mgr64": {
    "marginRight": "64"
  },
  "pdt64": {
    "paddingTop": "64"
  },
  "pdb64": {
    "paddingBottom": "64"
  },
  "pdl64": {
    "paddingLeft": "64"
  },
  "pdr64": {
    "paddingRight": "64"
  },
  "mgt65": {
    "marginTop": "65"
  },
  "mgb65": {
    "marginBottom": "65"
  },
  "mgl65": {
    "marginLeft": "65"
  },
  "mgr65": {
    "marginRight": "65"
  },
  "pdt65": {
    "paddingTop": "65"
  },
  "pdb65": {
    "paddingBottom": "65"
  },
  "pdl65": {
    "paddingLeft": "65"
  },
  "pdr65": {
    "paddingRight": "65"
  },
  "mgt66": {
    "marginTop": "66"
  },
  "mgb66": {
    "marginBottom": "66"
  },
  "mgl66": {
    "marginLeft": "66"
  },
  "mgr66": {
    "marginRight": "66"
  },
  "pdt66": {
    "paddingTop": "66"
  },
  "pdb66": {
    "paddingBottom": "66"
  },
  "pdl66": {
    "paddingLeft": "66"
  },
  "pdr66": {
    "paddingRight": "66"
  },
  "mgt68": {
    "marginTop": "68"
  },
  "mgb68": {
    "marginBottom": "68"
  },
  "mgl68": {
    "marginLeft": "68"
  },
  "mgr68": {
    "marginRight": "68"
  },
  "pdt68": {
    "paddingTop": "68"
  },
  "pdb68": {
    "paddingBottom": "68"
  },
  "pdl68": {
    "paddingLeft": "68"
  },
  "pdr68": {
    "paddingRight": "68"
  },
  "mgt70": {
    "marginTop": "70"
  },
  "mgb70": {
    "marginBottom": "70"
  },
  "mgl70": {
    "marginLeft": "70"
  },
  "mgr70": {
    "marginRight": "70"
  },
  "pdt70": {
    "paddingTop": "70"
  },
  "pdb70": {
    "paddingBottom": "70"
  },
  "pdl70": {
    "paddingLeft": "70"
  },
  "pdr70": {
    "paddingRight": "70"
  },
  "mgt72": {
    "marginTop": "72"
  },
  "mgb72": {
    "marginBottom": "72"
  },
  "mgl72": {
    "marginLeft": "72"
  },
  "mgr72": {
    "marginRight": "72"
  },
  "pdt72": {
    "paddingTop": "72"
  },
  "pdb72": {
    "paddingBottom": "72"
  },
  "pdl72": {
    "paddingLeft": "72"
  },
  "pdr72": {
    "paddingRight": "72"
  },
  "mgt74": {
    "marginTop": "74"
  },
  "mgb74": {
    "marginBottom": "74"
  },
  "mgl74": {
    "marginLeft": "74"
  },
  "mgr74": {
    "marginRight": "74"
  },
  "pdt74": {
    "paddingTop": "74"
  },
  "pdb74": {
    "paddingBottom": "74"
  },
  "pdl74": {
    "paddingLeft": "74"
  },
  "pdr74": {
    "paddingRight": "74"
  },
  "mgt75": {
    "marginTop": "75"
  },
  "mgb75": {
    "marginBottom": "75"
  },
  "mgl75": {
    "marginLeft": "75"
  },
  "mgr75": {
    "marginRight": "75"
  },
  "pdt75": {
    "paddingTop": "75"
  },
  "pdb75": {
    "paddingBottom": "75"
  },
  "pdl75": {
    "paddingLeft": "75"
  },
  "pdr75": {
    "paddingRight": "75"
  },
  "mgt76": {
    "marginTop": "76"
  },
  "mgb76": {
    "marginBottom": "76"
  },
  "mgl76": {
    "marginLeft": "76"
  },
  "mgr76": {
    "marginRight": "76"
  },
  "pdt76": {
    "paddingTop": "76"
  },
  "pdb76": {
    "paddingBottom": "76"
  },
  "pdl76": {
    "paddingLeft": "76"
  },
  "pdr76": {
    "paddingRight": "76"
  },
  "mgt78": {
    "marginTop": "78"
  },
  "mgb78": {
    "marginBottom": "78"
  },
  "mgl78": {
    "marginLeft": "78"
  },
  "mgr78": {
    "marginRight": "78"
  },
  "pdt78": {
    "paddingTop": "78"
  },
  "pdb78": {
    "paddingBottom": "78"
  },
  "pdl78": {
    "paddingLeft": "78"
  },
  "pdr78": {
    "paddingRight": "78"
  },
  "mgt80": {
    "marginTop": "80"
  },
  "mgb80": {
    "marginBottom": "80"
  },
  "mgl80": {
    "marginLeft": "80"
  },
  "mgr80": {
    "marginRight": "80"
  },
  "pdt80": {
    "paddingTop": "80"
  },
  "pdb80": {
    "paddingBottom": "80"
  },
  "pdl80": {
    "paddingLeft": "80"
  },
  "pdr80": {
    "paddingRight": "80"
  },
  "clr-red01": {
    "color": "#ff0000"
  },
  "clr-red02": {
    "color": "#ea3f29"
  },
  "clr-red03": {
    "color": "#cc0000"
  },
  "clr-red04": {
    "color": "#ff6666"
  },
  "clr-orange01": {
    "color": "#f58220"
  },
  "clr-orange02": {
    "color": "#ff9933"
  },
  "clr-orange03": {
    "color": "#ff6600"
  },
  "clr-orange04": {
    "color": "#ed4200"
  },
  "clr-yellow01": {
    "color": "#ffff00"
  },
  "clr-green01": {
    "color": "#008000"
  },
  "clr-cyan01": {
    "color": "#00ffff"
  },
  "clr-cyan02": {
    "color": "#00c1a0"
  },
  "clr-blue01": {
    "color": "#0000ff"
  },
  "clr-purple01": {
    "color": "#800080"
  },
  "clr-black": {
    "color": "#000000"
  },
  "clr-grey-0": {
    "color": "#000000"
  },
  "clr-grey-1": {
    "color": "#111111"
  },
  "clr-grey-2": {
    "color": "#222222"
  },
  "clr-grey-3": {
    "color": "#333333"
  },
  "clr-grey-4": {
    "color": "#444444"
  },
  "clr-grey-5": {
    "color": "#555555"
  },
  "clr-grey-6": {
    "color": "#666666"
  },
  "clr-grey-7": {
    "color": "#777777"
  },
  "clr-grey-8": {
    "color": "#888888"
  },
  "clr-grey-9": {
    "color": "#999999"
  },
  "clr-grey-a": {
    "color": "#aaaaaa"
  },
  "clr-grey-b": {
    "color": "#bbbbbb"
  },
  "clr-grey-c": {
    "color": "#cccccc"
  },
  "clr-grey-d": {
    "color": "#dddddd"
  },
  "clr-grey-e": {
    "color": "#eeeeee"
  },
  "clr-grey-f": {
    "color": "#ffffff"
  },
  "clr-white": {
    "color": "#ffffff"
  },
  "clr-grey01": {
    "color": "#e4e4e4"
  },
  "clr-grey02": {
    "color": "#7a7a7a"
  },
  "clr-grey03": {
    "color": "#757575"
  },
  "clr-grey04": {
    "color": "#7e7e7e"
  },
  "clr-grey05": {
    "color": "#e3e3e3"
  },
  "clr-grey06": {
    "color": "#fafafa"
  },
  "bg-clr-red01": {
    "backgroundColor": "#ff0000"
  },
  "bg-clr-red02": {
    "backgroundColor": "#cc0000"
  },
  "bg-clr-orange01": {
    "backgroundColor": "#f58220"
  },
  "bg-clr-orange02": {
    "backgroundColor": "#ff9900"
  },
  "bg-clr-orange03": {
    "backgroundColor": "#e6a067"
  },
  "bg-clr-yellow01": {
    "backgroundColor": "#ffff00"
  },
  "bg-clr-green01": {
    "backgroundColor": "#008000"
  },
  "bg-clr-cyan01": {
    "backgroundColor": "#00ffff"
  },
  "bg-clr-blue01": {
    "backgroundColor": "#0000ff"
  },
  "bg-clr-purple01": {
    "backgroundColor": "#800080"
  },
  "bg-clr-black": {
    "backgroundColor": "#000000"
  },
  "bg-clr-grey-0": {
    "backgroundColor": "#000000"
  },
  "bg-clr-grey-1": {
    "backgroundColor": "#111111"
  },
  "bg-clr-grey-2": {
    "backgroundColor": "#222222"
  },
  "bg-clr-grey-3": {
    "backgroundColor": "#333333"
  },
  "bg-clr-grey-4": {
    "backgroundColor": "#444444"
  },
  "bg-clr-grey-5": {
    "backgroundColor": "#555555"
  },
  "bg-clr-grey-6": {
    "backgroundColor": "#666666"
  },
  "bg-clr-grey-7": {
    "backgroundColor": "#777777"
  },
  "bg-clr-grey-8": {
    "backgroundColor": "#888888"
  },
  "bg-clr-grey-9": {
    "backgroundColor": "#999999"
  },
  "bg-clr-grey-a": {
    "backgroundColor": "#aaaaaa"
  },
  "bg-clr-grey-b": {
    "backgroundColor": "#bbbbbb"
  },
  "bg-clr-grey-c": {
    "backgroundColor": "#cccccc"
  },
  "bg-clr-grey-d": {
    "backgroundColor": "#dddddd"
  },
  "bg-clr-grey-e": {
    "backgroundColor": "#eeeeee"
  },
  "bg-clr-grey-f": {
    "backgroundColor": "#ffffff"
  },
  "bg-clr-white": {
    "backgroundColor": "#ffffff"
  },
  "wxcell-line": {
    "height": "90",
    "flexDirection": "row",
    "justifyContent": "space-between",
    "alignItems": "center",
    "paddingLeft": "20",
    "paddingRight": "20"
  },
  "wxcell-line-sm": {
    "height": "78"
  },
  "wxcell-line__bd": {
    "flex": 1
  },
  "wxcell-line__ft": {
    "textAlign": "right"
  },
  "ttbd": {
    "fontWeight": "bold"
  },
  "ttnm": {
    "fontWeight": "normal"
  },
  "ttct": {
    "textAlign": "center"
  },
  "ttl": {
    "textAlign": "left"
  },
  "ttr": {
    "textAlign": "right"
  },
  "dirrow": {
    "flexDirection": "row"
  },
  "dircol": {
    "flexDirection": "column"
  },
  "jcct": {
    "justifyContent": "center"
  },
  "aict": {
    "alignItems": "center"
  },
  "wrapper": {
    "position": "absolute",
    "top": 0,
    "left": 0,
    "right": 0,
    "bottom": 0,
    "width": "750",
    "backgroundColor": "#f5f5f5"
  },
  "line": {
    "width": "750",
    "height": "20",
    "backgroundColor": "#f2f2f2"
  },
  "nav_title": {
    "fontSize": "38",
    "color": "#ffffff",
    "lineHeight": "38"
  },
  "header-common-title": {
    "fontSize": "38",
    "color": "#ffffff",
    "lineHeight": "38"
  },
  "title": {
    "fontSize": "32",
    "color": "#000000"
  },
  "icon_title": {
    "fontSize": "30",
    "color": "#999999"
  },
  "sub_title": {
    "fontSize": "30",
    "color": "#999999"
  },
  "sub_date": {
    "fontSize": "26",
    "color": "#999999"
  },
  "fz26": {
    "fontSize": "26"
  },
  "fz28": {
    "fontSize": "28"
  },
  "fz30": {
    "fontSize": "30"
  },
  "fz32": {
    "fontSize": "32"
  },
  "fz35": {
    "fontSize": "35"
  },
  "fz40": {
    "fontSize": "40"
  },
  "boder-bottom": {
    "borderStyle": "solid",
    "borderBottomWidth": "1",
    "borderColor": "#e6e6e6"
  },
  "boder-top": {
    "borderStyle": "solid",
    "borderTopWidth": "1",
    "borderColor": "#e6e6e6"
  },
  "boder-right": {
    "borderStyle": "solid",
    "borderRightWidth": "1",
    "borderColor": "#e6e6e6"
  },
  "boder-left": {
    "borderStyle": "solid",
    "borderLeftWidth": "1",
    "borderColor": "#e6e6e6"
  },
  "pl10": {
    "paddingLeft": "10"
  },
  "pl5": {
    "paddingLeft": "5"
  },
  "pt0": {
    "paddingTop": "0"
  },
  "pt10": {
    "paddingTop": "10"
  },
  "pt15": {
    "paddingTop": "15"
  },
  "pb10": {
    "paddingBottom": "10"
  },
  "pl20": {
    "paddingLeft": "20"
  },
  "pt20": {
    "paddingTop": "20"
  },
  "pb15": {
    "paddingBottom": "15"
  },
  "pb20": {
    "paddingBottom": "20"
  },
  "pt25": {
    "paddingTop": "25"
  },
  "pt30": {
    "paddingTop": "30"
  },
  "pt40": {
    "paddingTop": "40"
  },
  "pb40": {
    "paddingBottom": "40"
  },
  "pb30": {
    "paddingBottom": "30"
  },
  "pb25": {
    "paddingBottom": "25"
  },
  "pl25": {
    "paddingLeft": "25"
  },
  "pl30": {
    "paddingLeft": "30"
  },
  "pr5": {
    "paddingRight": "5"
  },
  "pr10": {
    "paddingRight": "10"
  },
  "pr20": {
    "paddingRight": "20"
  },
  "pr25": {
    "paddingRight": "25"
  },
  "pr30": {
    "paddingRight": "30"
  },
  "pl35": {
    "paddingLeft": "35"
  },
  "pr35": {
    "paddingRight": "35"
  },
  "bgWhite": {
    "backgroundColor": "#ffffff"
  },
  "textActive": {
    "backgroundColor:active": "#cccccc"
  },
  "mt0": {
    "marginTop": "0"
  },
  "mt10": {
    "marginTop": "10"
  },
  "mt20": {
    "marginTop": "20"
  },
  "mt30": {
    "marginTop": "30"
  },
  "mt40": {
    "marginTop": "40"
  },
  "mt50": {
    "marginTop": "50"
  },
  "bt0": {
    "marginBottom": "0"
  },
  "bt5": {
    "marginBottom": "5"
  },
  "bt10": {
    "marginBottom": "10"
  },
  "bt15": {
    "marginBottom": "15"
  },
  "bt20": {
    "marginBottom": "20"
  },
  "bt30": {
    "marginBottom": "30"
  },
  "bt45": {
    "marginBottom": "45"
  },
  "bt50": {
    "marginBottom": "50"
  },
  "mr5": {
    "marginRight": "5"
  },
  "mr10": {
    "marginRight": "10"
  },
  "mr15": {
    "marginRight": "15"
  },
  "mr30": {
    "marginRight": "30"
  },
  "ml5": {
    "marginLeft": "5"
  },
  "ml10": {
    "marginLeft": "10"
  },
  "ml20": {
    "marginLeft": "20"
  },
  "ml30": {
    "marginLeft": "30"
  },
  "header": {
    "height": "136",
    "paddingTop": "44",
    "flexDirection": "row",
    "position": "sticky",
    "backgroundColor": "#00c1a0"
  },
  "topbar": {
    "height": "136",
    "paddingTop": "44",
    "flexDirection": "row",
    "position": "sticky",
    "backgroundColor": "#00c1a0"
  },
  "topbar-common-actual": {
    "flex": 1,
    "width": "750",
    "flexDirection": "row",
    "justifyContent": "space-between",
    "alignItems": "center"
  },
  "topbar-common-hd": {
    "width": "100",
    "flexDirection": "row",
    "justifyContent": "flex-start",
    "alignItems": "center"
  },
  "topbar-common-bd": {
    "flex": 1,
    "flexDirection": "row",
    "justifyContent": "center",
    "alignItems": "center"
  },
  "topbar-common-ft": {
    "width": "100",
    "flexDirection": "row",
    "justifyContent": "flex-end",
    "alignItems": "center"
  },
  "topbar-common-icon": {
    "fontSize": "38",
    "color": "#ffffff"
  },
  "baseNavBg": {
    "backgroundColor": "#00c1a0"
  },
  "baseNavColor": {
    "color": "#00c1a0"
  },
  "nav": {
    "width": "654",
    "justifyContent": "space-between",
    "flexDirection": "row",
    "height": "92",
    "alignItems": "center",
    "marginTop": "0"
  },
  "nav_back": {
    "marginTop": "0",
    "flexDirection": "row",
    "width": "92",
    "height": "92",
    "alignItems": "center",
    "justifyContent": "center"
  },
  "corpusActive": {
    "color": "#00c1a0",
    "borderColor": "#00c1a0",
    "borderStyle": "solid",
    "borderBottomWidth": "4"
  },
  "footer": {
    "position": "fixed",
    "bottom": "0",
    "left": "0",
    "right": "0",
    "height": "100"
  },
  "fill": {
    "height": "500",
    "width": "750",
    "backgroundColor": "#f5f5f5"
  },
  "iconImg": {
    "width": "60",
    "height": "60",
    "fontSize": "60"
  },
  "cell-header": {
    "height": "70",
    "flexDirection": "row",
    "backgroundColor": "#dddddd",
    "paddingLeft": "20"
  },
  "cell-row": {
    "minHeight": "100",
    "flexDirection": "column",
    "backgroundColor": "#ffffff",
    "paddingLeft": "20",
    "marginTop": "20"
  },
  "cell-row-1": {
    "flexDirection": "column",
    "backgroundColor": "#ffffff",
    "paddingLeft": "20",
    "marginTop": "20"
  },
  "cell-row-row": {
    "minHeight": "100",
    "flexDirection": "row",
    "justifyContent": "space-between",
    "backgroundColor": "#ffffff",
    "paddingLeft": "20",
    "paddingRight": "20",
    "alignItems": "center",
    "marginTop": "20"
  },
  "cell-line": {
    "borderTopWidth": "1",
    "borderTopColor": "#e6e6e6",
    "borderTopStyle": "solid",
    "borderBottomWidth": "1",
    "borderBottomColor": "#e6e6e6",
    "borderBottomStyle": "solid"
  },
  "borderTop": {
    "borderTopWidth": "1",
    "borderTopColor": "#e6e6e6",
    "borderTopStyle": "solid"
  },
  "border-top": {
    "borderTopWidth": "1",
    "borderTopStyle": "solid",
    "borderTopColor": "#e6e6e6"
  },
  "borderBottom": {
    "borderBottomWidth": "1",
    "borderBottomColor": "#e6e6e6",
    "borderBottomStyle": "solid"
  },
  "border-bottom": {
    "borderBottomWidth": "1",
    "borderBottomStyle": "solid",
    "borderBottomColor": "#e6e6e6"
  },
  "border-left": {
    "borderLeftWidth": "1",
    "borderLeftStyle": "solid",
    "borderLeftColor": "#e6e6e6"
  },
  "border-right": {
    "borderRightWidth": "1",
    "borderRightStyle": "solid",
    "borderRightColor": "#e6e6e6"
  },
  "cell-panel": {
    "height": "98",
    "minHeight": "98",
    "flexDirection": "row",
    "alignItems": "center",
    "borderBottomWidth": "1",
    "borderBottomColor": "#e6e6e6",
    "borderBottomStyle": "solid"
  },
  "cell-panel-column": {
    "height": "98",
    "minHeight": "98",
    "flexDirection": "column",
    "justifyContent": "space-around",
    "borderBottomWidth": "1",
    "borderBottomColor": "#e6e6e6",
    "borderBottomStyle": "solid",
    "paddingTop": "10",
    "paddingBottom": "10"
  },
  "cell-bottom-clear": {
    "borderBottomWidth": "0"
  },
  "cell-clear": {
    "marginTop": "0",
    "marginBottom": "0",
    "borderBottomWidth": "0",
    "borderTopWidth": "0"
  },
  "space-between": {
    "justifyContent": "space-between",
    "flexDirection": "row",
    "alignItems": "center"
  },
  "flex-start": {
    "justifyContent": "flex-start",
    "flexDirection": "row",
    "alignItems": "center"
  },
  "flex-end": {
    "justifyContent": "flex-end",
    "flexDirection": "row",
    "alignItems": "center"
  },
  "flex-center": {
    "justifyContent": "center",
    "flexDirection": "row",
    "alignItems": "center"
  },
  "space-around": {
    "justifyContent": "space-around",
    "flexDirection": "row",
    "alignItems": "center"
  },
  "flex-row": {
    "flexDirection": "row",
    "alignItems": "center"
  },
  "flex-column": {
    "flexDirection": "column",
    "alignItems": "center"
  },
  "flex1": {
    "flex": 1
  },
  "flex2": {
    "flex": 2
  },
  "flex3": {
    "flex": 3
  },
  "flex4": {
    "flex": 4
  },
  "flex5": {
    "flex": 6
  },
  "flex6": {
    "flex": 6
  },
  "bkg-white": {
    "backgroundColor": "#ffffff"
  },
  "bkg-primary": {
    "backgroundColor": "#00c1a0"
  },
  "bkg-gray": {
    "backgroundColor": "#f5f5f5"
  },
  "bd-primary": {
    "borderColor": "#00c1a0"
  },
  "bkg-delete": {
    "backgroundColor": "#ff0000"
  },
  "white": {
    "color": "#ffffff"
  },
  "primary": {
    "color": "#00c1a0"
  },
  "gray": {
    "color": "#999999"
  },
  "ico": {
    "fontSize": "48",
    "color": "#00c1a0",
    "marginTop": "2"
  },
  "ico_big": {
    "fontSize": "72",
    "color": "#00c1a0",
    "marginTop": "4"
  },
  "ico_small": {
    "fontSize": "32",
    "color": "#00c1a0",
    "marginTop": "1"
  },
  "arrow": {
    "fontSize": "40",
    "color": "#cccccc",
    "width": "40",
    "marginLeft": "20"
  },
  "check": {
    "fontSize": "32",
    "color": "#00c1a0",
    "width": "40"
  },
  "shopCheck": {
    "fontSize": "32",
    "color": "#00c1a0",
    "width": "40",
    "marginLeft": "150"
  },
  "button": {
    "fontSize": "32",
    "textAlign": "center",
    "color": "#ffffff",
    "paddingTop": "15",
    "paddingBottom": "15",
    "backgroundColor": "#00c1a0",
    "borderRadius": "15",
    "height": "80",
    "lineHeight": "50",
    "alignItems": "center",
    "justifyContent": "center",
    "backgroundColor:active": "#e6e6e6",
    "color:active": "#00c1a0",
    "backgroundColor:disabled": "#00c1a0",
    "color:disabled": "#999999"
  },
  "refresh": {
    "flexDirection": "column",
    "alignItems": "center",
    "paddingTop": "10"
  },
  "loading": {
    "flexDirection": "column",
    "alignItems": "center",
    "paddingTop": "10"
  },
  "noLoading": {
    "height": "999"
  },
  "gif": {
    "width": "50",
    "height": "50"
  },
  "indicator": {
    "fontSize": "36",
    "color": "#00c1a0",
    "width": "750",
    "textAlign": "center",
    "marginTop": "20",
    "marginBottom": "20"
  },
  "lines-ellipsis": {
    "lines": 1,
    "textOverflow": "ellipsis"
  },
  "V1": {
    "height": "146",
    "paddingTop": "54"
  },
  "IPhoneX": {
    "height": "156",
    "paddingTop": "64"
  },
  "addTopV1": {
    "top": "54"
  },
  "addTopIPhoneX": {
    "top": "64"
  },
  "addInfoV1": {
    "height": "430",
    "paddingTop": "50"
  },
  "addInfoIPhoneX": {
    "height": "440",
    "paddingTop": "60"
  },
  "addBgImgV1": {
    "height": "430"
  },
  "addBgImgIPhoneX": {
    "height": "440"
  },
  "hideCorpusV1": {
    "top": "146"
  },
  "hideCorpusIPhoneX": {
    "top": "156"
  },
  "pageTopV1": {
    "top": "226"
  },
  "pageTopIPhoneX": {
    "top": "236"
  },
  "maskLayer": {
    "position": "fixed",
    "top": "0",
    "left": "0",
    "right": "0",
    "bottom": "0",
    "backgroundColor": "#000000",
    "opacity": 0.4
  },
  "showBox": {
    "position": "fixed",
    "top": "150",
    "right": "15",
    "paddingTop": "20",
    "paddingBottom": "20"
  },
  "showBg": {
    "position": "absolute",
    "top": 0,
    "bottom": 0,
    "left": 0,
    "right": 0,
    "backgroundColor": "#ffffff",
    "borderRadius": "20"
  },
  "arrowUp": {
    "position": "fixed",
    "top": "148",
    "right": "30"
  },
  "refreshImg": {
    "width": "60",
    "height": "60",
    "borderRadius": "30"
  },
  "refreshBox": {
    "height": "120",
    "width": "750",
    "alignItems": "center",
    "justifyContent": "center"
  },
  "indexMtIPhoneX": {
    "marginTop": "124"
  },
  "indexSliderMtIPhone": {
    "marginTop": "44"
  },
  "indexSliderMtIPhoneX": {
    "marginTop": "124"
  },
  "artOutBoxTopIPhoneX": {
    "top": "156"
  },
  "processTotal": {
    "position": "absolute",
    "bottom": "40",
    "right": "50",
    "fontSize": "28",
    "color": "#888888"
  },
  "processBg": {
    "backgroundColor": "#cccccc",
    "width": "500"
  },
  "processStyle": {
    "height": "10",
    "position": "absolute",
    "left": "50",
    "bottom": "100"
  },
  "processText": {
    "position": "absolute",
    "top": "40",
    "left": "50",
    "fontSize": "32"
  },
  "processBox": {
    "height": "250",
    "borderRadius": "5",
    "width": "600",
    "backgroundColor": "#ffffff",
    "justifyContent": "space-between"
  },
  "sendMask": {
    "position": "absolute",
    "top": 0,
    "bottom": 0,
    "left": 0,
    "right": 0,
    "backgroundColor": "rgba(0,0,0,0.8)",
    "alignItems": "center",
    "justifyContent": "center"
  },
  "placeholder-blue-bg": {
    "position": "absolute",
    "top": 0,
    "backgroundColor": "rgba(136,136,136,0.1)"
  }
}

/***/ }),

/***/ 85:
/***/ (function(module, exports) {

module.exports = {
  "cb": {
    "borderBottomWidth": "0"
  },
  "navRightBox": {
    "minWidth": "92",
    "height": "92",
    "alignItems": "center",
    "justifyContent": "center"
  },
  "nav_bg": {
    "width": "750",
    "height": "156",
    "backgroundSize": "cover",
    "position": "absolute",
    "top": 0
  },
  "nav_ico": {
    "fontSize": "38",
    "color": "#ffffff",
    "marginTop": "2"
  },
  "nav_CompleteIcon": {
    "paddingLeft": "27",
    "paddingRight": "27",
    "fontSize": "44",
    "lineHeight": "44",
    "color": "#FFFFFF"
  },
  "nav_Complete": {
    "paddingLeft": "27",
    "paddingRight": "27"
  }
}

/***/ }),

/***/ 86:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _utils = __webpack_require__(18);

var utils = _interopRequireWildcard(_utils);

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

exports.default = {
  props: {
    title: { default: "navbar" },
    complete: { default: '' },
    showComplete: { default: true },
    border: { default: true }
  },
  methods: {
    classHeader: function classHeader() {
      var dc = utils.device();
      return dc;
    },
    goback: function goback(e) {
      this.$emit('goback');
    },
    goComplete: function goComplete(e) {
      this.$emit('goComplete');
    }
  }
}; //
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/***/ }),

/***/ 87:
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: ["header"],
    class: [_vm.classHeader(), _vm.border == true ? '' : 'cb']
  }, [_c('div', {
    staticClass: ["nav_back"],
    on: {
      "click": function($event) {
        _vm.goback('/')
      }
    }
  }, [_c('text', {
    staticClass: ["nav_ico"],
    style: {
      fontFamily: 'iconfont'
    }
  }, [_vm._v("")])]), _c('div', {
    staticClass: ["nav"]
  }, [_c('text', {
    staticClass: ["nav_title"]
  }, [_vm._v(_vm._s(_vm.title))]), (_vm.showComplete) ? _c('div', {
    staticClass: ["navRightBox"],
    on: {
      "click": function($event) {
        _vm.goComplete('/')
      }
    }
  }, [(_vm.complete != 'textIcon') ? _c('text', {
    staticClass: ["nav_Complete", "nav_title"]
  }, [_vm._v(_vm._s(_vm.complete))]) : _c('text', {
    staticClass: ["nav_CompleteIcon"],
    style: {
      fontFamily: 'iconfont'
    }
  }, [_vm._v("")])]) : _vm._e()])])
},staticRenderFns: []}
module.exports.render._withStripped = true

/***/ }),

/***/ 9:
/***/ (function(module, exports) {

var hasOwnProperty = {}.hasOwnProperty;
module.exports = function (it, key) {
  return hasOwnProperty.call(it, key);
};


/***/ }),

/***/ 99:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
var dom = weex.requireModule('dom');
var event = weex.requireModule('event');
var stream = weex.requireModule('stream');
var storage = weex.requireModule('storage');
var animation = weex.requireModule('animation');
exports.dom = dom;
exports.event = event;
exports.stream = stream;
exports.storage = storage;
exports.animation = animation;

/***/ })

/******/ });