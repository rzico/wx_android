// { "framework": "Vue" }
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};

/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {

/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId])
/******/ 			return installedModules[moduleId].exports;

/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			exports: {},
/******/ 			id: moduleId,
/******/ 			loaded: false
/******/ 		};

/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);

/******/ 		// Flag the module as loaded
/******/ 		module.loaded = true;

/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}


/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;

/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;

/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";

/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(0);
/******/ })
/************************************************************************/
/******/ ({

/***/ 0:
/***/ (function(module, exports, __webpack_require__) {

	var __vue_exports__, __vue_options__
	var __vue_styles__ = []

	/* styles */
	__vue_styles__.push(__webpack_require__(127)
	)
	__vue_styles__.push(__webpack_require__(128)
	)

	/* script */
	__vue_exports__ = __webpack_require__(129)

	/* template */
	var __vue_template__ = __webpack_require__(132)
	__vue_options__ = __vue_exports__ = __vue_exports__ || {}
	if (
	  typeof __vue_exports__.default === "object" ||
	  typeof __vue_exports__.default === "function"
	) {
	if (Object.keys(__vue_exports__).some(function (key) { return key !== "default" && key !== "__esModule" })) {console.error("named exports are not supported in *.vue files.")}
	__vue_options__ = __vue_exports__ = __vue_exports__.default
	}
	if (typeof __vue_options__ === "function") {
	  __vue_options__ = __vue_options__.options
	}
	__vue_options__.__file = "/Users/leistercheung/Documents/mopian/mp/src/view/cashier/deposit.vue"
	__vue_options__.render = __vue_template__.render
	__vue_options__.staticRenderFns = __vue_template__.staticRenderFns
	__vue_options__._scopeId = "data-v-3689238a"
	__vue_options__.style = __vue_options__.style || {}
	__vue_styles__.forEach(function (module) {
	  for (var name in module) {
	    __vue_options__.style[name] = module[name]
	  }
	})
	if (typeof __register_static_styles__ === "function") {
	  __register_static_styles__(__vue_options__._scopeId, __vue_styles__)
	}

	module.exports = __vue_exports__
	module.exports.el = 'true'
	new Vue(module.exports)


/***/ }),

/***/ 94:
/***/ (function(module, exports) {

	module.exports = {
	  "wrapper": {
	    "position": "absolute",
	    "top": 0,
	    "left": 0,
	    "right": 0,
	    "bottom": 0,
	    "width": 750,
	    "backgroundColor": "#eeeeee"
	  },
	  "nav_title": {
	    "fontSize": 38,
	    "color": "#ffffff",
	    "lineHeight": 38
	  },
	  "title": {
	    "fontSize": 32,
	    "color": "#000000"
	  },
	  "sub_title": {
	    "fontSize": 30,
	    "color": "#bbbbbb"
	  },
	  "sub_date": {
	    "fontSize": 26,
	    "color": "#bbbbbb"
	  },
	  "fz28": {
	    "fontSize": 28
	  },
	  "fz30": {
	    "fontSize": 30
	  },
	  "fz32": {
	    "fontSize": 32
	  },
	  "fz35": {
	    "fontSize": 35
	  },
	  "fz40": {
	    "fontSize": 40
	  },
	  "boder-bottom": {
	    "borderStyle": "solid",
	    "borderBottomWidth": 1,
	    "borderColor": "#DCDCDC"
	  },
	  "pl10": {
	    "paddingLeft": 10
	  },
	  "pt10": {
	    "paddingTop": 10
	  },
	  "pb10": {
	    "paddingBottom": 10
	  },
	  "pl20": {
	    "paddingLeft": 20
	  },
	  "pt20": {
	    "paddingTop": 20
	  },
	  "pb15": {
	    "paddingBottom": 15
	  },
	  "pb20": {
	    "paddingBottom": 20
	  },
	  "pt25": {
	    "paddingTop": 25
	  },
	  "pt30": {
	    "paddingTop": 30
	  },
	  "pt40": {
	    "paddingTop": 40
	  },
	  "bt40": {
	    "paddingBottom": 40
	  },
	  "pb30": {
	    "paddingBottom": 30
	  },
	  "pb25": {
	    "paddingBottom": 25
	  },
	  "pl30": {
	    "paddingLeft": 30
	  },
	  "pr30": {
	    "paddingRight": 30
	  },
	  "pl35": {
	    "paddingLeft": 35
	  },
	  "pr35": {
	    "paddingRight": 35
	  },
	  "bgWhite": {
	    "backgroundColor": "#ffffff"
	  },
	  "textActive": {
	    "backgroundColor:active": "#cccccc"
	  },
	  "mt0": {
	    "marginTop": 0
	  },
	  "mt10": {
	    "marginTop": 10
	  },
	  "mt20": {
	    "marginTop": 20
	  },
	  "mt30": {
	    "marginTop": 30
	  },
	  "mt50": {
	    "marginTop": 50
	  },
	  "bt0": {
	    "marginBottom": 0
	  },
	  "bt10": {
	    "marginBottom": 10
	  },
	  "bt20": {
	    "marginBottom": 20
	  },
	  "bt30": {
	    "marginBottom": 30
	  },
	  "bt50": {
	    "marginBottom": 50
	  },
	  "ml10": {
	    "marginLeft": 10
	  },
	  "ml20": {
	    "marginLeft": 20
	  },
	  "ml30": {
	    "marginLeft": 30
	  },
	  "header": {
	    "height": 136,
	    "flexDirection": "row",
	    "position": "sticky",
	    "borderBottomWidth": 1,
	    "borderBottomStyle": "solid",
	    "borderBottomColor": "#cccccc",
	    "backgroundColor": "#99CCFF"
	  },
	  "corpusActive": {
	    "color": "#99CCFF",
	    "borderColor": "#99CCFF",
	    "borderStyle": "solid",
	    "borderBottomWidth": 4
	  },
	  "footer": {
	    "position": "fixed",
	    "bottom": 0,
	    "left": 0,
	    "right": 0,
	    "height": 100
	  },
	  "fill": {
	    "height": 500,
	    "width": 750,
	    "backgroundColor": "#eeeeee"
	  },
	  "iconImg": {
	    "width": 60,
	    "height": 60,
	    "fontSize": 60
	  },
	  "cell-header": {
	    "height": 70,
	    "flexDirection": "row",
	    "backgroundColor": "#dddddd",
	    "paddingLeft": 20
	  },
	  "cell-row": {
	    "minHeight": 100,
	    "flexDirection": "column",
	    "backgroundColor": "#ffffff",
	    "paddingLeft": 20,
	    "marginTop": 20
	  },
	  "cell-row-row": {
	    "minHeight": 100,
	    "flexDirection": "row",
	    "justifyContent": "space-between",
	    "backgroundColor": "#ffffff",
	    "paddingLeft": 20,
	    "paddingRight": 20,
	    "alignItems": "center",
	    "marginTop": 20
	  },
	  "cell-line": {
	    "borderTopWidth": 1,
	    "borderTopColor": "#cccccc",
	    "borderTopStyle": "solid",
	    "borderBottomWidth": 1,
	    "borderBottomColor": "#cccccc",
	    "borderBottomStyle": "solid"
	  },
	  "borderTop": {
	    "borderTopWidth": 1,
	    "borderTopColor": "#cccccc",
	    "borderTopStyle": "solid"
	  },
	  "borderBottom": {
	    "borderBottomWidth": 1,
	    "borderBottomColor": "#cccccc",
	    "borderBottomStyle": "solid"
	  },
	  "cell-panel": {
	    "height": 98,
	    "minHeight": 98,
	    "flexDirection": "row",
	    "alignItems": "center",
	    "borderBottomWidth": 1,
	    "borderBottomColor": "#cccccc",
	    "borderBottomStyle": "solid"
	  },
	  "cell-panel-column": {
	    "height": 98,
	    "minHeight": 98,
	    "flexDirection": "column",
	    "justifyContent": "space-around",
	    "borderBottomWidth": 1,
	    "borderBottomColor": "#cccccc",
	    "borderBottomStyle": "solid",
	    "paddingTop": 10,
	    "paddingBottom": 10
	  },
	  "cell-bottom-clear": {
	    "borderBottomWidth": 0
	  },
	  "cell-clear": {
	    "marginTop": 0,
	    "marginBottom": 0,
	    "borderTopWidth": 0,
	    "borderBottomWidth": 0
	  },
	  "space-between": {
	    "justifyContent": "space-between",
	    "flexDirection": "row",
	    "alignItems": "center"
	  },
	  "flex-start": {
	    "justifyContent": "flex-start",
	    "flexDirection": "row",
	    "alignItems": "center"
	  },
	  "flex-end": {
	    "justifyContent": "flex-end",
	    "flexDirection": "row",
	    "alignItems": "center"
	  },
	  "flex-center": {
	    "justifyContent": "center",
	    "flexDirection": "row",
	    "alignItems": "center"
	  },
	  "space-around": {
	    "justifyContent": "space-around",
	    "flexDirection": "row",
	    "alignItems": "center"
	  },
	  "flex-row": {
	    "flexDirection": "row",
	    "alignItems": "center"
	  },
	  "flex-column": {
	    "flexDirection": "column",
	    "alignItems": "center"
	  },
	  "flex1": {
	    "flex": 1
	  },
	  "flex2": {
	    "flex": 2
	  },
	  "flex3": {
	    "flex": 3
	  },
	  "flex4": {
	    "flex": 4
	  },
	  "flex5": {
	    "flex": 6
	  },
	  "bkg-white": {
	    "backgroundColor": "#FFFFFF"
	  },
	  "bkg-primary": {
	    "backgroundColor": "#99CCFF"
	  },
	  "bkg-gray": {
	    "backgroundColor": "#eeeeee"
	  },
	  "bd-primary": {
	    "borderColor": "#99CCFF"
	  },
	  "white": {
	    "color": "#FFFFFF"
	  },
	  "primary": {
	    "color": "#99CCFF"
	  },
	  "gray": {
	    "color": "#bbbbbb"
	  },
	  "ico": {
	    "fontSize": 48,
	    "color": "#99CCFF",
	    "marginTop": 4
	  },
	  "ico_big": {
	    "fontSize": 72,
	    "color": "#99CCFF",
	    "marginTop": 6
	  },
	  "ico_small": {
	    "fontSize": 32,
	    "color": "#99CCFF",
	    "marginTop": 2
	  },
	  "arrow": {
	    "fontSize": 32,
	    "color": "#cccccc",
	    "width": 40
	  },
	  "check": {
	    "fontSize": 32,
	    "color": "#99CCFF",
	    "width": 40
	  },
	  "button": {
	    "fontSize": 36,
	    "textAlign": "center",
	    "color": "#ffffff",
	    "paddingTop": 15,
	    "paddingBottom": 15,
	    "backgroundColor": "#99CCFF",
	    "borderRadius": 15,
	    "height": 80,
	    "backgroundColor:active": "#cccccc",
	    "color:active": "#99CCFF",
	    "backgroundColor:disabled": "#99CCFF",
	    "color:disabled": "#999999"
	  },
	  "refresh": {
	    "flexDirection": "column",
	    "alignItems": "center",
	    "paddingTop": 10
	  },
	  "loading": {
	    "flexDirection": "column",
	    "alignItems": "center",
	    "paddingTop": 10
	  },
	  "noLoading": {
	    "height": 999
	  },
	  "gif": {
	    "width": 50,
	    "height": 50
	  },
	  "indicator": {
	    "fontSize": 36,
	    "color": "#99CCFF",
	    "width": 750,
	    "textAlign": "center",
	    "marginTop": 20,
	    "marginBottom": 20
	  },
	  "lines-ellipsis": {
	    "lines": 1,
	    "textOverflow": "ellipsis"
	  }
	}

/***/ }),

/***/ 95:
/***/ (function(module, exports) {

	module.exports = {
	  "cb": {
	    "borderBottomWidth": 0
	  },
	  "nav_back": {
	    "marginTop": 44,
	    "flexDirection": "row",
	    "width": 92,
	    "height": 92,
	    "alignItems": "center",
	    "justifyContent": "center"
	  },
	  "navRightBox": {
	    "width": 110,
	    "height": 92,
	    "alignItems": "center",
	    "justifyContent": "center"
	  },
	  "nav_ico": {
	    "fontSize": 38,
	    "color": "#ffffff",
	    "marginTop": 2
	  },
	  "nav": {
	    "width": 654,
	    "justifyContent": "space-between",
	    "flexDirection": "row",
	    "alignItems": "center",
	    "marginTop": 44
	  },
	  "nav_CompleteIcon": {
	    "paddingLeft": 16,
	    "fontFamily": "Verdana, Geneva, sans-serif",
	    "fontSize": 44,
	    "lineHeight": 44,
	    "color": "#FFFFFF"
	  },
	  "nav_Complete": {
	    "paddingLeft": 16,
	    "fontFamily": "Verdana, Geneva, sans-serif",
	    "fontSize": 34,
	    "lineHeight": 34,
	    "color": "#FFFFFF"
	  }
	}

/***/ }),

/***/ 96:
/***/ (function(module, exports) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	    value: true
	});
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//

	exports.default = {
	    props: {
	        title: { default: "navbar" },
	        complete: { default: '' },
	        showComplete: { default: true },
	        border: { default: true }
	    },
	    methods: {
	        goback: function goback(e) {
	            this.$emit('goback');
	        },
	        goComplete: function goComplete(e) {
	            this.$emit('goComplete');
	        }
	    }
	};
	module.exports = exports['default'];

/***/ }),

/***/ 97:
/***/ (function(module, exports) {

	module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
	  return _c('div', {
	    staticClass: ["header"],
	    class: [_vm.border == true ? '' : 'cb']
	  }, [_c('div', {
	    staticClass: ["nav_back"],
	    on: {
	      "click": function($event) {
	        _vm.goback('/')
	      }
	    }
	  }, [_c('text', {
	    staticClass: ["nav_ico"],
	    style: {
	      fontFamily: 'iconfont'
	    }
	  }, [_vm._v("")])]), _c('div', {
	    staticClass: ["nav"]
	  }, [_c('text', {
	    staticClass: ["nav_title"]
	  }, [_vm._v(_vm._s(_vm.title))]), (_vm.showComplete) ? _c('div', {
	    staticClass: ["navRightBox"],
	    on: {
	      "click": function($event) {
	        _vm.goComplete('/')
	      }
	    }
	  }, [(_vm.complete != 'textIcon') ? _c('text', {
	    staticClass: ["nav_Complete"]
	  }, [_vm._v(_vm._s(_vm.complete))]) : _c('text', {
	    staticClass: ["nav_CompleteIcon"],
	    style: {
	      fontFamily: 'iconfont'
	    }
	  }, [_vm._v("")])]) : _vm._e()])])
	},staticRenderFns: []}
	module.exports.render._withStripped = true

/***/ }),

/***/ 127:
/***/ (function(module, exports) {

	module.exports = {
	  "wrapper": {
	    "position": "absolute",
	    "top": 0,
	    "left": 0,
	    "right": 0,
	    "bottom": 0,
	    "width": 750,
	    "backgroundColor": "#eeeeee"
	  },
	  "nav_title": {
	    "fontSize": 38,
	    "color": "#ffffff",
	    "lineHeight": 38
	  },
	  "title": {
	    "fontSize": 32,
	    "color": "#000000"
	  },
	  "sub_title": {
	    "fontSize": 30,
	    "color": "#bbbbbb"
	  },
	  "sub_date": {
	    "fontSize": 26,
	    "color": "#bbbbbb"
	  },
	  "fz28": {
	    "fontSize": 28
	  },
	  "fz30": {
	    "fontSize": 30
	  },
	  "fz32": {
	    "fontSize": 32
	  },
	  "fz35": {
	    "fontSize": 35
	  },
	  "fz40": {
	    "fontSize": 40
	  },
	  "boder-bottom": {
	    "borderStyle": "solid",
	    "borderBottomWidth": 1,
	    "borderColor": "#DCDCDC"
	  },
	  "pl10": {
	    "paddingLeft": 10
	  },
	  "pt10": {
	    "paddingTop": 10
	  },
	  "pb10": {
	    "paddingBottom": 10
	  },
	  "pl20": {
	    "paddingLeft": 20
	  },
	  "pt20": {
	    "paddingTop": 20
	  },
	  "pb15": {
	    "paddingBottom": 15
	  },
	  "pb20": {
	    "paddingBottom": 20
	  },
	  "pt25": {
	    "paddingTop": 25
	  },
	  "pt30": {
	    "paddingTop": 30
	  },
	  "pt40": {
	    "paddingTop": 40
	  },
	  "bt40": {
	    "paddingBottom": 40
	  },
	  "pb30": {
	    "paddingBottom": 30
	  },
	  "pb25": {
	    "paddingBottom": 25
	  },
	  "pl30": {
	    "paddingLeft": 30
	  },
	  "pr30": {
	    "paddingRight": 30
	  },
	  "pl35": {
	    "paddingLeft": 35
	  },
	  "pr35": {
	    "paddingRight": 35
	  },
	  "bgWhite": {
	    "backgroundColor": "#ffffff"
	  },
	  "textActive": {
	    "backgroundColor:active": "#cccccc"
	  },
	  "mt0": {
	    "marginTop": 0
	  },
	  "mt10": {
	    "marginTop": 10
	  },
	  "mt20": {
	    "marginTop": 20
	  },
	  "mt30": {
	    "marginTop": 30
	  },
	  "mt50": {
	    "marginTop": 50
	  },
	  "bt0": {
	    "marginBottom": 0
	  },
	  "bt10": {
	    "marginBottom": 10
	  },
	  "bt20": {
	    "marginBottom": 20
	  },
	  "bt30": {
	    "marginBottom": 30
	  },
	  "bt50": {
	    "marginBottom": 50
	  },
	  "ml10": {
	    "marginLeft": 10
	  },
	  "ml20": {
	    "marginLeft": 20
	  },
	  "ml30": {
	    "marginLeft": 30
	  },
	  "header": {
	    "height": 136,
	    "flexDirection": "row",
	    "position": "sticky",
	    "borderBottomWidth": 1,
	    "borderBottomStyle": "solid",
	    "borderBottomColor": "#cccccc",
	    "backgroundColor": "#99CCFF"
	  },
	  "corpusActive": {
	    "color": "#99CCFF",
	    "borderColor": "#99CCFF",
	    "borderStyle": "solid",
	    "borderBottomWidth": 4
	  },
	  "footer": {
	    "position": "fixed",
	    "bottom": 0,
	    "left": 0,
	    "right": 0,
	    "height": 100
	  },
	  "fill": {
	    "height": 500,
	    "width": 750,
	    "backgroundColor": "#eeeeee"
	  },
	  "iconImg": {
	    "width": 60,
	    "height": 60,
	    "fontSize": 60
	  },
	  "cell-header": {
	    "height": 70,
	    "flexDirection": "row",
	    "backgroundColor": "#dddddd",
	    "paddingLeft": 20
	  },
	  "cell-row": {
	    "minHeight": 100,
	    "flexDirection": "column",
	    "backgroundColor": "#ffffff",
	    "paddingLeft": 20,
	    "marginTop": 20
	  },
	  "cell-row-row": {
	    "minHeight": 100,
	    "flexDirection": "row",
	    "justifyContent": "space-between",
	    "backgroundColor": "#ffffff",
	    "paddingLeft": 20,
	    "paddingRight": 20,
	    "alignItems": "center",
	    "marginTop": 20
	  },
	  "cell-line": {
	    "borderTopWidth": 1,
	    "borderTopColor": "#cccccc",
	    "borderTopStyle": "solid",
	    "borderBottomWidth": 1,
	    "borderBottomColor": "#cccccc",
	    "borderBottomStyle": "solid"
	  },
	  "borderTop": {
	    "borderTopWidth": 1,
	    "borderTopColor": "#cccccc",
	    "borderTopStyle": "solid"
	  },
	  "borderBottom": {
	    "borderBottomWidth": 1,
	    "borderBottomColor": "#cccccc",
	    "borderBottomStyle": "solid"
	  },
	  "cell-panel": {
	    "height": 98,
	    "minHeight": 98,
	    "flexDirection": "row",
	    "alignItems": "center",
	    "borderBottomWidth": 1,
	    "borderBottomColor": "#cccccc",
	    "borderBottomStyle": "solid"
	  },
	  "cell-panel-column": {
	    "height": 98,
	    "minHeight": 98,
	    "flexDirection": "column",
	    "justifyContent": "space-around",
	    "borderBottomWidth": 1,
	    "borderBottomColor": "#cccccc",
	    "borderBottomStyle": "solid",
	    "paddingTop": 10,
	    "paddingBottom": 10
	  },
	  "cell-bottom-clear": {
	    "borderBottomWidth": 0
	  },
	  "cell-clear": {
	    "marginTop": 0,
	    "marginBottom": 0,
	    "borderTopWidth": 0,
	    "borderBottomWidth": 0
	  },
	  "space-between": {
	    "justifyContent": "space-between",
	    "flexDirection": "row",
	    "alignItems": "center"
	  },
	  "flex-start": {
	    "justifyContent": "flex-start",
	    "flexDirection": "row",
	    "alignItems": "center"
	  },
	  "flex-end": {
	    "justifyContent": "flex-end",
	    "flexDirection": "row",
	    "alignItems": "center"
	  },
	  "flex-center": {
	    "justifyContent": "center",
	    "flexDirection": "row",
	    "alignItems": "center"
	  },
	  "space-around": {
	    "justifyContent": "space-around",
	    "flexDirection": "row",
	    "alignItems": "center"
	  },
	  "flex-row": {
	    "flexDirection": "row",
	    "alignItems": "center"
	  },
	  "flex-column": {
	    "flexDirection": "column",
	    "alignItems": "center"
	  },
	  "flex1": {
	    "flex": 1
	  },
	  "flex2": {
	    "flex": 2
	  },
	  "flex3": {
	    "flex": 3
	  },
	  "flex4": {
	    "flex": 4
	  },
	  "flex5": {
	    "flex": 6
	  },
	  "bkg-white": {
	    "backgroundColor": "#FFFFFF"
	  },
	  "bkg-primary": {
	    "backgroundColor": "#99CCFF"
	  },
	  "bkg-gray": {
	    "backgroundColor": "#eeeeee"
	  },
	  "bd-primary": {
	    "borderColor": "#99CCFF"
	  },
	  "white": {
	    "color": "#FFFFFF"
	  },
	  "primary": {
	    "color": "#99CCFF"
	  },
	  "gray": {
	    "color": "#bbbbbb"
	  },
	  "ico": {
	    "fontSize": 48,
	    "color": "#99CCFF",
	    "marginTop": 4
	  },
	  "ico_big": {
	    "fontSize": 72,
	    "color": "#99CCFF",
	    "marginTop": 6
	  },
	  "ico_small": {
	    "fontSize": 32,
	    "color": "#99CCFF",
	    "marginTop": 2
	  },
	  "arrow": {
	    "fontSize": 32,
	    "color": "#cccccc",
	    "width": 40
	  },
	  "check": {
	    "fontSize": 32,
	    "color": "#99CCFF",
	    "width": 40
	  },
	  "button": {
	    "fontSize": 36,
	    "textAlign": "center",
	    "color": "#ffffff",
	    "paddingTop": 15,
	    "paddingBottom": 15,
	    "backgroundColor": "#99CCFF",
	    "borderRadius": 15,
	    "height": 80,
	    "backgroundColor:active": "#cccccc",
	    "color:active": "#99CCFF",
	    "backgroundColor:disabled": "#99CCFF",
	    "color:disabled": "#999999"
	  },
	  "refresh": {
	    "flexDirection": "column",
	    "alignItems": "center",
	    "paddingTop": 10
	  },
	  "loading": {
	    "flexDirection": "column",
	    "alignItems": "center",
	    "paddingTop": 10
	  },
	  "noLoading": {
	    "height": 999
	  },
	  "gif": {
	    "width": 50,
	    "height": 50
	  },
	  "indicator": {
	    "fontSize": 36,
	    "color": "#99CCFF",
	    "width": 750,
	    "textAlign": "center",
	    "marginTop": 20,
	    "marginBottom": 20
	  },
	  "lines-ellipsis": {
	    "lines": 1,
	    "textOverflow": "ellipsis"
	  }
	}

/***/ }),

/***/ 128:
/***/ (function(module, exports) {

	module.exports = {
	  "newHeight": {
	    "height": 130
	  },
	  "cell-row": {
	    "minHeight": 120,
	    "flexDirection": "column",
	    "backgroundColor": "#ffffff",
	    "paddingLeft": 20,
	    "marginTop": 20
	  },
	  "logo": {
	    "height": 100,
	    "width": 100,
	    "borderRadius": 50,
	    "overflow": "hidden"
	  },
	  "align-bottom": {
	    "alignItems": "flex-end",
	    "width": 615
	  },
	  "content": {
	    "marginLeft": 10,
	    "flexDirection": "column",
	    "alignItems": "flex-start"
	  },
	  "datetime": {
	    "color": "#cccccc",
	    "fontSize": 28
	  },
	  "money": {
	    "fontWeight": "700",
	    "marginRight": 20
	  }
	}

/***/ }),

/***/ 129:
/***/ (function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	    value: true
	});

	var _navbar = __webpack_require__(130);

	var _navbar2 = _interopRequireDefault(_navbar);

	var _filters = __webpack_require__(131);

	var _filters2 = _interopRequireDefault(_filters);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//

	var modal = weex.requireModule('modal');
	var navigator = weex.requireModule('navigator');

	var stream = weex.requireModule('stream');

	var event = weex.requireModule('event');
	var pageNumber = 1;
	exports.default = {
	    data: function data() {
	        return {
	            depositList: [],
	            refreshing: false,
	            showLoading: 'hide'
	        };
	    },
	    components: {
	        navbar: _navbar2.default
	    },
	    props: {
	        title: { default: "账单" }
	    },
	    created: function created() {
	        var _this = this;

	        //              页面创建时请求数据
	        this.open(pageNumber, function (res) {
	            if (res.data.message.type == 'success') {
	                _this.depositList = res.data.data;
	                modal.toast({ message: res.data.data, duration: 3 });
	            } else {
	                modal.alert({
	                    message: '系统繁忙',
	                    duration: 0.3
	                });
	            }
	        });
	    },

	    methods: {
	        //            是否添加底部边框
	        addBorder: function addBorder(index) {
	            var listLength = this.depositList.length;
	            //                判断是否最后一个元素并且是否每月的结尾
	            if (index != listLength - 1) {
	                if (this.getDate(this.depositList[index].create_date) == this.getDate(this.depositList[index + 1].create_date)) {
	                    return {
	                        borderBottomWidth: '1px'
	                    };
	                } else {
	                    return {
	                        borderBottomWidth: '0px'
	                    };
	                }
	            } else {
	                return {
	                    borderBottomWidth: '0px'
	                };
	            }
	        },
	        //判断月份是否重复
	        isRepeat: function isRepeat(index) {
	            if (index != 0) {
	                if (this.getDate(this.depositList[index].create_date) == this.getDate(this.depositList[index - 1].create_date)) {
	                    return false;
	                }
	            }
	            return true;
	        },

	        goback: function goback(e) {
	            event.closeURL();
	        },
	        setup: function setup(e) {
	            toPage(e);
	        },
	        open: function open(pageNumber, callback) {
	            return stream.fetch({
	                method: 'GET',
	                type: 'json',
	                url: 'http://www.rzico.com/applet/member/wallet/bill.jhtml?begin_date=2017-01-01%2000:00:00&end_date=2018-01-01%2000:00:00&pageNumber=' + pageNumber + '&pageSize=10'
	            }, callback);
	        },

	        //            上拉加载
	        onloading: function onloading(event) {
	            var _this2 = this;

	            pageNumber++;
	            modal.toast({ message: '加载中...', duration: 0.5 });
	            this.showLoading = 'show';
	            this.open(pageNumber, function (res) {
	                if (res.data.message.type == 'success') {
	                    _this2.depositList = _this2.depositList.concat(res.data.data);
	                } else {
	                    modal.toast({ message: '系统繁忙', duration: 1 });
	                }
	                _this2.showLoading = 'hide';
	            });
	        },

	        //            下拉刷新
	        onrefresh: function onrefresh(event) {
	            var _this3 = this;

	            pageNumber = 1;
	            modal.toast({ message: '加载中...', duration: 1 });
	            this.refreshing = true;
	            this.open(pageNumber, function (res) {
	                if (res.data.message.type == 'success') {
	                    _this3.depositList = res.data.data;
	                } else {
	                    modal.toast({ message: '系统繁忙', duration: 1 });
	                }
	                _this3.refreshing = false;
	            });
	        },

	        //            获取月份
	        getDate: function getDate(value) {
	            var date = new Date(value);
	            var m = date.getMonth() + 1;
	            return m;
	        }
	    }
	};
	module.exports = exports['default'];

/***/ }),

/***/ 130:
/***/ (function(module, exports, __webpack_require__) {

	var __vue_exports__, __vue_options__
	var __vue_styles__ = []

	/* styles */
	__vue_styles__.push(__webpack_require__(94)
	)
	__vue_styles__.push(__webpack_require__(95)
	)

	/* script */
	__vue_exports__ = __webpack_require__(96)

	/* template */
	var __vue_template__ = __webpack_require__(97)
	__vue_options__ = __vue_exports__ = __vue_exports__ || {}
	if (
	  typeof __vue_exports__.default === "object" ||
	  typeof __vue_exports__.default === "function"
	) {
	if (Object.keys(__vue_exports__).some(function (key) { return key !== "default" && key !== "__esModule" })) {console.error("named exports are not supported in *.vue files.")}
	__vue_options__ = __vue_exports__ = __vue_exports__.default
	}
	if (typeof __vue_options__ === "function") {
	  __vue_options__ = __vue_options__.options
	}
	__vue_options__.__file = "/Users/leistercheung/Documents/mopian/mp/src/include/navbar.vue"
	__vue_options__.render = __vue_template__.render
	__vue_options__.staticRenderFns = __vue_template__.staticRenderFns
	__vue_options__._scopeId = "data-v-cc5bb20e"
	__vue_options__.style = __vue_options__.style || {}
	__vue_styles__.forEach(function (module) {
	  for (var name in module) {
	    __vue_options__.style[name] = module[name]
	  }
	})
	if (typeof __register_static_styles__ === "function") {
	  __register_static_styles__(__vue_options__._scopeId, __vue_styles__)
	}

	module.exports = __vue_exports__


/***/ }),

/***/ 131:
/***/ (function(module, exports) {

	'use strict';

	//时间格式化 今天 近三天 近七天  七天前
	Vue.filter('dayfmt', function (value) {
	    //value 传进来是个整数型，要判断是10位还是13位需要转成字符串。这边的方法是检测13位的时间戳 所以要*1000；并且转回整型。安卓下，时间早了8个小时
	    value = value + '';
	    if (value.length == 10) {
	        value = parseInt(value) * 1000;
	    } else {
	        value = parseInt(value);
	    }
	    var date = new Date(value);
	    var tody = new Date();
	    var m = tody.getDate() - date.getDate();
	    if (m < 1) {
	        return "今天";
	    }
	    if (m < 3) {
	        return "近三天";
	    }
	    if (m < 7) {
	        return "近七天";
	    }
	    return "七天前";
	});
	// 时间格式化 10:30 昨天 前天 2017年09月01日 09月01日
	Vue.filter('timefmt', function (value) {
	    //value 传进来是个整数型，要判断是10位还是13位需要转成字符串。这边的方法是检测13位的时间戳 所以要*1000；并且转回整型。安卓下，时间早了8个小时
	    value = value + '';
	    if (value.length == 10) {
	        value = parseInt(value) * 1000;
	    } else {
	        value = parseInt(value);
	    }
	    var date = new Date(value);
	    var tody = new Date();
	    var y = date.getFullYear();
	    var nowy = tody.getFullYear();
	    var m = date.getMonth() + 1;
	    var w = tody.getDate() - date.getDate();
	    if (w < 1) {
	        var h = date.getUTCHours() + 8;
	        h = h >= 24 ? h - 24 : h;
	        var i = date.getMinutes();
	        if (h < 10) {
	            h = '0' + h;
	        }
	        if (i < 10) {
	            i = '0' + i;
	        }
	        return h + ":" + i;
	        // return value;
	    }
	    if (w < 2) {
	        return "昨天";
	    }
	    if (w < 3) {
	        return "前天";
	    }
	    if (m < 10) {
	        m = '0' + m;
	    }
	    var d = date.getDate();
	    if (d < 10) {
	        d = '0' + d;
	    }
	    //如果是今年 就不返回年份
	    if (nowy == y) {
	        return m + '月' + d + '日';
	    } else {
	        return y + '年' + m + '月' + d + '日';
	    }
	});

	// 时间格式化 10:30 昨天 前天 2017-09-01 09-01
	Vue.filter('timefmtOther', function (value) {
	    //value 传进来是个整数型，要判断是10位还是13位需要转成字符串。这边的方法是检测13位的时间戳 所以要*1000；并且转回整型。安卓下，时间早了8个小时
	    value = value + '';
	    if (value.length == 10) {
	        value = parseInt(value) * 1000;
	    } else {
	        value = parseInt(value);
	    }
	    var date = new Date(value);
	    var tody = new Date();
	    var y = date.getFullYear();
	    var nowy = tody.getFullYear();
	    var m = date.getMonth() + 1;
	    var w = tody.getDate() - date.getDate();
	    if (w < 1) {
	        var h = date.getUTCHours() + 8;
	        h = h >= 24 ? h - 24 : h;
	        var i = date.getMinutes();
	        if (h < 10) {
	            h = '0' + h;
	        }
	        if (i < 10) {
	            i = '0' + i;
	        }
	        return h + ":" + i;
	        // return value;
	    }
	    if (w < 2) {
	        return "昨天";
	    }
	    if (w < 3) {
	        return "前天";
	    }
	    if (m < 10) {
	        m = '0' + m;
	    }
	    var d = date.getDate();
	    if (d < 10) {
	        d = '0' + d;
	    }
	    //如果是今年 就不返回年份
	    if (nowy == y) {
	        return m + '-' + d;
	    } else {
	        return y + '-' + m + '-' + d;
	    }
	});

	// 时间格式化  2017-09-01
	Vue.filter('timeDatefmt', function (value) {
	    //value 传进来是个整数型，要判断是10位还是13位需要转成字符串。这边的方法是检测13位的时间戳 所以要*1000；并且转回整型。安卓下，时间早了8个小时
	    value = value + '';
	    if (value.length == 10) {
	        value = parseInt(value) * 1000;
	    } else {
	        value = parseInt(value);
	    }
	    var date = new Date(value);
	    var tody = new Date();
	    var y = date.getFullYear();
	    var m = date.getMonth() + 1;
	    var d = date.getDate();
	    if (m < 10) {
	        m = '0' + m;
	    }
	    if (d < 10) {
	        d = '0' + d;
	    }
	    return y + '-' + m + '-' + d;
	});

	//月份格式化 本月 上月 2..12月  2016年1月..
	Vue.filter('monthfmt', function (value) {
	    //value 传进来是个整数型，要判断是10位还是13位需要转成字符串。这边的方法是检测13位的时间戳 所以要*1000；并且转回整型。安卓下，时间早了8个小时
	    value = value + '';
	    if (value.length == 10) {
	        value = parseInt(value) * 1000;
	    } else {
	        value = parseInt(value);
	    }
	    // 返回处理后的值
	    var date = new Date(value);
	    var tody = new Date();
	    var m = tody.getMonth() - date.getMonth();
	    var y = tody.getYear() - date.getYear();
	    if (m < 1) {
	        return "本月";
	    }
	    if (m < 2) {
	        return "上月";
	    }
	    if (y < 1) {
	        return date.getMonth() + "月";
	    }
	    return date.getYear() + "年" + date.getMonth() + "月";
	});

	//2017-01-01
	Vue.filter('datefmt', function (value) {
	    //value 传进来是个整数型，要判断是10位还是13位需要转成字符串。这边的方法是检测13位的时间戳 所以要*1000；并且转回整型。安卓下，时间早了8个小时
	    value = value + '';
	    if (value.length == 10) {
	        value = parseInt(value) * 1000;
	    } else {
	        value = parseInt(value);
	    }
	    // 返回处理后的值
	    var date = new Date(value);
	    return date.getYear() + "年" + date.getMonth() + "月" + date.getDay() + "日";
	});

	//返回月份 7 8 9 单数字
	Vue.filter('detailMonth', function (value) {
	    //value 传进来是个整数型，要判断是10位还是13位需要转成字符串。这边的方法是检测13位的时间戳 所以要*1000；并且转回整型。安卓下，时间早了8个小时
	    value = value + '';
	    if (value.length == 10) {
	        value = parseInt(value) * 1000;
	    } else {
	        value = parseInt(value);
	    }
	    // 返回处理后的值
	    var date = new Date(value);
	    var m = date.getMonth() + 1;
	    return m;
	});

	//时间格式化 返回 09-30 03:07
	Vue.filter('datetimefmt', function (value) {
	    //value 传进来是个整数型，要判断是10位还是13位需要转成字符串。这边的方法是检测13位的时间戳 所以要*1000；并且转回整型。安卓下，时间早了8个小时
	    value = value + '';
	    if (value.length == 10) {
	        value = parseInt(value) * 1000;
	    } else {
	        value = parseInt(value);
	    }
	    // 返回处理后的值
	    var date = new Date(value);
	    var y = date.getFullYear();
	    var tody = new Date();
	    var nowy = tody.getFullYear();
	    var m = date.getMonth() + 1;
	    var d = date.getDate();
	    var h = date.getUTCHours() + 8;
	    h = h >= 24 ? h - 24 : h;
	    var i = date.getMinutes();
	    if (m < 10) {
	        m = '0' + m;
	    }
	    if (d < 10) {
	        d = '0' + d;
	    }
	    if (h < 10) {
	        h = '0' + h;
	    }
	    if (i < 10) {
	        i = '0' + i;
	    }
	    //如果是今年 就不返回年份
	    if (nowy == y) {
	        return m + '-' + d + '  ' + h + ':' + i;
	    } else {
	        return y + '-' + m + '-' + d + '  ' + h + ':' + i;
	    }
	});

	//时间格式化 返回 09-30 03:07:56 2017-09-30 03:07:56
	Vue.filter('datemoretimefmt', function (value) {
	    //value 传进来是个整数型，要判断是10位还是13位需要转成字符串。这边的方法是检测13位的时间戳 所以要*1000；并且转回整型。安卓下，时间早了8个小时
	    value = value + '';
	    if (value.length == 10) {
	        value = parseInt(value) * 1000;
	    } else {
	        value = parseInt(value);
	    }

	    // 返回处理后的值
	    var date = new Date(value);
	    var y = date.getFullYear();
	    var tody = new Date();
	    var nowy = tody.getFullYear();
	    var m = date.getMonth() + 1;
	    var d = date.getDate();
	    var h = date.getUTCHours() + 8;
	    h = h >= 24 ? h - 24 : h;
	    var i = date.getMinutes();
	    var s = date.getSeconds();
	    if (m < 10) {
	        m = '0' + m;
	    }
	    if (d < 10) {
	        d = '0' + d;
	    }
	    if (h < 10) {
	        h = '0' + h;
	    }
	    if (i < 10) {
	        i = '0' + i;
	    }
	    if (s < 10) {
	        s = '0' + s;
	    }
	    //如果是今年 就不返回年份
	    if (nowy == y) {
	        return m + '-' + d + '  ' + h + ':' + i + ':' + s;
	    } else {
	        return y + '-' + m + '-' + d + '  ' + h + ':' + i + ':' + s;
	    }
	});
	//时间格式化 返回 03:07
	Vue.filter('hitimefmt', function (value) {
	    //value 传进来是个整数型，要判断是10位还是13位需要转成字符串。这边的方法是检测13位的时间戳 所以要*1000；并且转回整型。安卓下，时间早了8个小时
	    value = value + '';
	    if (value.length == 10) {
	        value = parseInt(value) * 1000;
	    } else {
	        value = parseInt(value);
	    }
	    // 返回处理后的值
	    var date = new Date(value);
	    var h = date.getUTCHours() + 8;
	    h = h >= 24 ? h - 24 : h;
	    var i = date.getMinutes();
	    if (h < 10) {
	        h = '0' + h;
	    }
	    if (i < 10) {
	        i = '0' + i;
	    }
	    var t = h + ':' + i;
	    return t;
	});

	//金额保留两位小数点
	Vue.filter('currencyfmt', function (value) {
	    // 返回处理后的值
	    if (value != null) {
	        if (value == 0) {
	            return value;
	        } else {
	            var price = (Math.round(value * Math.pow(10, 2)) / Math.pow(10, 2)).toFixed(2);
	            return price;
	        }
	    }
	});

/***/ }),

/***/ 132:
/***/ (function(module, exports) {

	module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
	  return _c('div', {
	    staticClass: ["wrapper"]
	  }, [_c('list', {
	    staticClass: ["list"]
	  }, [_c('refresh', {
	    staticClass: ["refresh"],
	    attrs: {
	      "display": _vm.refreshing ? 'show' : 'hide'
	    },
	    on: {
	      "refresh": _vm.onrefresh
	    }
	  }, [_c('text', {
	    staticClass: ["indicator"]
	  }, [_vm._v("下拉刷新 ...")])]), _vm._l((_vm.depositList), function(deposit, index) {
	    return _c('cell', {
	      appendAsTree: true,
	      attrs: {
	        "append": "tree"
	      }
	    }, [(_vm.isRepeat(index)) ? _c('div', {
	      staticClass: ["cell-header", "cell-line", "space-between"]
	    }, [_c('div', {
	      staticClass: ["flex-row", "flex-start"]
	    }, [_c('text', {
	      staticClass: ["title"]
	    }, [_vm._v(_vm._s(_vm._f("monthfmt")(deposit.create_date)))])]), _c('div', {
	      staticClass: ["flex-row", "flex-end"]
	    }, [_c('text', {
	      staticClass: ["sub_title"]
	    }, [_vm._v("查看账单")]), _c('text', {
	      staticClass: ["arrow"],
	      style: {
	        fontFamily: 'iconfont'
	      }
	    }, [_vm._v("")])])]) : _vm._e(), _c('div', {
	      staticClass: ["cell-row", "cell-clear"]
	    }, [_c('div', {
	      staticClass: ["cell-panel", "newHeight"],
	      style: _vm.addBorder(index)
	    }, [_vm._m(0, true), _c('div', {
	      staticClass: ["content", "flex5"]
	    }, [_c('text', {
	      staticClass: ["title", "lines-ellipsis"]
	    }, [_vm._v(_vm._s(deposit.memo))]), _c('div', {
	      staticClass: ["flex-row", "space-between", "align-bottom"]
	    }, [_c('text', {
	      staticClass: ["datetime"]
	    }, [_vm._v(_vm._s(_vm._f("datetimefmt")(deposit.create_date)))]), _c('text', {
	      staticClass: ["money"]
	    }, [_vm._v(_vm._s(_vm._f("currencyfmt")(deposit.amount)))])])])])])])
	  }), _c('loading', {
	    staticClass: ["loading"],
	    attrs: {
	      "display": _vm.showLoading
	    },
	    on: {
	      "loading": _vm.onloading
	    }
	  }, [_c('text', {
	    staticClass: ["indicator"]
	  }, [_vm._v("Loading ...")])])], 2)])
	},staticRenderFns: [function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
	  return _c('div', {
	    staticClass: ["flex1"]
	  }, [_c('image', {
	    staticClass: ["logo"],
	    attrs: {
	      "resize": "cover",
	      "src": "https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg"
	    }
	  })])
	}]}
	module.exports.render._withStripped = true

/***/ })

/******/ });