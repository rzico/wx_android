// { "framework": "Vue"} 

/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// identity function for calling harmony imports with the correct context
/******/ 	__webpack_require__.i = function(value) { return value; };
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 545);
/******/ })
/************************************************************************/
/******/ ({

/***/ 0:
/***/ (function(module, exports) {

/*
	MIT License http://www.opensource.org/licenses/mit-license.php
	Author Tobias Koppers @sokra
*/
// css base code, injected by the css-loader
module.exports = function() {
	var list = [];

	// return the list of modules as css string
	list.toString = function toString() {
		var result = [];
		for(var i = 0; i < this.length; i++) {
			var item = this[i];
			if(item[2]) {
				result.push("@media " + item[2] + "{" + item[1] + "}");
			} else {
				result.push(item[1]);
			}
		}
		return result.join("");
	};

	// import a list of modules into the list
	list.i = function(modules, mediaQuery) {
		if(typeof modules === "string")
			modules = [[null, modules, ""]];
		var alreadyImportedModules = {};
		for(var i = 0; i < this.length; i++) {
			var id = this[i][0];
			if(typeof id === "number")
				alreadyImportedModules[id] = true;
		}
		for(i = 0; i < modules.length; i++) {
			var item = modules[i];
			// skip already imported module
			// this implementation is not 100% perfect for weird media query combinations
			//  when a module is imported multiple times with different media queries.
			//  I hope this will never occur (Hey this way we have smaller bundles)
			if(typeof item[0] !== "number" || !alreadyImportedModules[item[0]]) {
				if(mediaQuery && !item[2]) {
					item[2] = mediaQuery;
				} else if(mediaQuery) {
					item[2] = "(" + item[2] + ") and (" + mediaQuery + ")";
				}
				list.push(item);
			}
		}
	};
	return list;
};


/***/ }),

/***/ 1:
/***/ (function(module, exports, __webpack_require__) {

/*
  MIT License http://www.opensource.org/licenses/mit-license.php
  Author Tobias Koppers @sokra
  Modified by Evan You @yyx990803
*/

var hasDocument = typeof document !== 'undefined'

if (typeof DEBUG !== 'undefined' && DEBUG) {
  if (!hasDocument) {
    throw new Error(
    'vue-style-loader cannot be used in a non-browser environment. ' +
    "Use { target: 'node' } in your Webpack config to indicate a server-rendering environment."
  ) }
}

var listToStyles = __webpack_require__(5)

/*
type StyleObject = {
  id: number;
  parts: Array<StyleObjectPart>
}

type StyleObjectPart = {
  css: string;
  media: string;
  sourceMap: ?string
}
*/

var stylesInDom = {/*
  [id: number]: {
    id: number,
    refs: number,
    parts: Array<(obj?: StyleObjectPart) => void>
  }
*/}

var head = hasDocument && (document.head || document.getElementsByTagName('head')[0])
var singletonElement = null
var singletonCounter = 0
var isProduction = false
var noop = function () {}

// Force single-tag solution on IE6-9, which has a hard limit on the # of <style>
// tags it will allow on a page
var isOldIE = typeof navigator !== 'undefined' && /msie [6-9]\b/.test(navigator.userAgent.toLowerCase())

module.exports = function (parentId, list, _isProduction) {
  isProduction = _isProduction

  var styles = listToStyles(parentId, list)
  addStylesToDom(styles)

  return function update (newList) {
    var mayRemove = []
    for (var i = 0; i < styles.length; i++) {
      var item = styles[i]
      var domStyle = stylesInDom[item.id]
      domStyle.refs--
      mayRemove.push(domStyle)
    }
    if (newList) {
      styles = listToStyles(parentId, newList)
      addStylesToDom(styles)
    } else {
      styles = []
    }
    for (var i = 0; i < mayRemove.length; i++) {
      var domStyle = mayRemove[i]
      if (domStyle.refs === 0) {
        for (var j = 0; j < domStyle.parts.length; j++) {
          domStyle.parts[j]()
        }
        delete stylesInDom[domStyle.id]
      }
    }
  }
}

function addStylesToDom (styles /* Array<StyleObject> */) {
  for (var i = 0; i < styles.length; i++) {
    var item = styles[i]
    var domStyle = stylesInDom[item.id]
    if (domStyle) {
      domStyle.refs++
      for (var j = 0; j < domStyle.parts.length; j++) {
        domStyle.parts[j](item.parts[j])
      }
      for (; j < item.parts.length; j++) {
        domStyle.parts.push(addStyle(item.parts[j]))
      }
      if (domStyle.parts.length > item.parts.length) {
        domStyle.parts.length = item.parts.length
      }
    } else {
      var parts = []
      for (var j = 0; j < item.parts.length; j++) {
        parts.push(addStyle(item.parts[j]))
      }
      stylesInDom[item.id] = { id: item.id, refs: 1, parts: parts }
    }
  }
}

function createStyleElement () {
  var styleElement = document.createElement('style')
  styleElement.type = 'text/css'
  head.appendChild(styleElement)
  return styleElement
}

function addStyle (obj /* StyleObjectPart */) {
  var update, remove
  var styleElement = document.querySelector('style[data-vue-ssr-id~="' + obj.id + '"]')

  if (styleElement) {
    if (isProduction) {
      // has SSR styles and in production mode.
      // simply do nothing.
      return noop
    } else {
      // has SSR styles but in dev mode.
      // for some reason Chrome can't handle source map in server-rendered
      // style tags - source maps in <style> only works if the style tag is
      // created and inserted dynamically. So we remove the server rendered
      // styles and inject new ones.
      styleElement.parentNode.removeChild(styleElement)
    }
  }

  if (isOldIE) {
    // use singleton mode for IE9.
    var styleIndex = singletonCounter++
    styleElement = singletonElement || (singletonElement = createStyleElement())
    update = applyToSingletonTag.bind(null, styleElement, styleIndex, false)
    remove = applyToSingletonTag.bind(null, styleElement, styleIndex, true)
  } else {
    // use multi-style-tag mode in all other cases
    styleElement = createStyleElement()
    update = applyToTag.bind(null, styleElement)
    remove = function () {
      styleElement.parentNode.removeChild(styleElement)
    }
  }

  update(obj)

  return function updateStyle (newObj /* StyleObjectPart */) {
    if (newObj) {
      if (newObj.css === obj.css &&
          newObj.media === obj.media &&
          newObj.sourceMap === obj.sourceMap) {
        return
      }
      update(obj = newObj)
    } else {
      remove()
    }
  }
}

var replaceText = (function () {
  var textStore = []

  return function (index, replacement) {
    textStore[index] = replacement
    return textStore.filter(Boolean).join('\n')
  }
})()

function applyToSingletonTag (styleElement, index, remove, obj) {
  var css = remove ? '' : obj.css

  if (styleElement.styleSheet) {
    styleElement.styleSheet.cssText = replaceText(index, css)
  } else {
    var cssNode = document.createTextNode(css)
    var childNodes = styleElement.childNodes
    if (childNodes[index]) styleElement.removeChild(childNodes[index])
    if (childNodes.length) {
      styleElement.insertBefore(cssNode, childNodes[index])
    } else {
      styleElement.appendChild(cssNode)
    }
  }
}

function applyToTag (styleElement, obj) {
  var css = obj.css
  var media = obj.media
  var sourceMap = obj.sourceMap

  if (media) {
    styleElement.setAttribute('media', media)
  }

  if (sourceMap) {
    // https://developer.chrome.com/devtools/docs/javascript-debugging
    // this makes source maps inside style tags work properly in Chrome
    css += '\n/*# sourceURL=' + sourceMap.sources[0] + ' */'
    // http://stackoverflow.com/a/26603875
    css += '\n/*# sourceMappingURL=data:application/json;base64,' + btoa(unescape(encodeURIComponent(JSON.stringify(sourceMap)))) + ' */'
  }

  if (styleElement.styleSheet) {
    styleElement.styleSheet.cssText = css
  } else {
    while (styleElement.firstChild) {
      styleElement.removeChild(styleElement.firstChild)
    }
    styleElement.appendChild(document.createTextNode(css))
  }
}


/***/ }),

/***/ 10:
/***/ (function(module, exports, __webpack_require__) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "header",
    class: [_vm.classHeader(), _vm.border == true ? '' : 'cb']
  }, [_c('div', {
    staticClass: "nav_back",
    on: {
      "click": function($event) {
        _vm.goback('/')
      }
    }
  }, [_c('text', {
    staticClass: "nav_ico",
    style: ({
      fontFamily: 'iconfont'
    })
  }, [_vm._v("")])]), _vm._v(" "), _c('div', {
    staticClass: "nav"
  }, [_c('text', {
    staticClass: "nav_title"
  }, [_vm._v(_vm._s(_vm.title))]), _vm._v(" "), (_vm.showComplete) ? _c('div', {
    staticClass: "navRightBox",
    on: {
      "click": function($event) {
        _vm.goComplete('/')
      }
    }
  }, [(_vm.complete != 'textIcon') ? _c('text', {
    staticClass: "nav_Complete nav_title"
  }, [_vm._v(_vm._s(_vm.complete))]) : _c('text', {
    staticClass: "nav_CompleteIcon",
    style: ({
      fontFamily: 'iconfont'
    })
  }, [_vm._v("")])]) : _vm._e()])])
},staticRenderFns: []}
module.exports.render._withStripped = true
if (false) {
  module.hot.accept()
  if (module.hot.data) {
     require("vue-loader/node_modules/vue-hot-reload-api").rerender("data-v-019a21a0", module.exports)
  }
}

/***/ }),

/***/ 11:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(8);
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var update = __webpack_require__(1)("ebebfb4a", content, false);
// Hot Module Replacement
if(false) {
 // When the styles change, update the <style> tags
 if(!content.locals) {
   module.hot.accept("!!../../node_modules/_css-loader@0.26.4@css-loader/index.js!../../node_modules/_vue-loader@10.3.0@vue-loader/lib/style-rewriter.js?id=data-v-019a21a0!../../node_modules/less-loader/dist/cjs.js!./wx.less", function() {
     var newContent = require("!!../../node_modules/_css-loader@0.26.4@css-loader/index.js!../../node_modules/_vue-loader@10.3.0@vue-loader/lib/style-rewriter.js?id=data-v-019a21a0!../../node_modules/less-loader/dist/cjs.js!./wx.less");
     if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
     update(newContent);
   });
 }
 // When the module is disposed, remove the <style> tags
 module.hot.dispose(function() { update(); });
}

/***/ }),

/***/ 1146:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(730);
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var update = __webpack_require__(1)("00575692", content, false);
// Hot Module Replacement
if(false) {
 // When the styles change, update the <style> tags
 if(!content.locals) {
   module.hot.accept("!!../../../node_modules/_css-loader@0.26.4@css-loader/index.js!../../../node_modules/_vue-loader@10.3.0@vue-loader/lib/style-rewriter.js?id=data-v-45e47c12!../../../node_modules/_vue-loader@10.3.0@vue-loader/lib/selector.js?type=styles&index=1!./inform.vue", function() {
     var newContent = require("!!../../../node_modules/_css-loader@0.26.4@css-loader/index.js!../../../node_modules/_vue-loader@10.3.0@vue-loader/lib/style-rewriter.js?id=data-v-45e47c12!../../../node_modules/_vue-loader@10.3.0@vue-loader/lib/selector.js?type=styles&index=1!./inform.vue");
     if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
     update(newContent);
   });
 }
 // When the module is disposed, remove the <style> tags
 module.hot.dispose(function() { update(); });
}

/***/ }),

/***/ 1147:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(731);
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var update = __webpack_require__(1)("0d908fc1", content, false);
// Hot Module Replacement
if(false) {
 // When the styles change, update the <style> tags
 if(!content.locals) {
   module.hot.accept("!!../../node_modules/_css-loader@0.26.4@css-loader/index.js!../../node_modules/_vue-loader@10.3.0@vue-loader/lib/style-rewriter.js?id=data-v-45e47c12!../../node_modules/less-loader/dist/cjs.js!./wx.less", function() {
     var newContent = require("!!../../node_modules/_css-loader@0.26.4@css-loader/index.js!../../node_modules/_vue-loader@10.3.0@vue-loader/lib/style-rewriter.js?id=data-v-45e47c12!../../node_modules/less-loader/dist/cjs.js!./wx.less");
     if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
     update(newContent);
   });
 }
 // When the module is disposed, remove the <style> tags
 module.hot.dispose(function() { update(); });
}

/***/ }),

/***/ 12:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(9);
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var update = __webpack_require__(1)("5944172c", content, false);
// Hot Module Replacement
if(false) {
 // When the styles change, update the <style> tags
 if(!content.locals) {
   module.hot.accept("!!../../node_modules/_css-loader@0.26.4@css-loader/index.js!../../node_modules/_vue-loader@10.3.0@vue-loader/lib/style-rewriter.js?id=data-v-019a21a0&scoped=true!../../node_modules/_vue-loader@10.3.0@vue-loader/lib/selector.js?type=styles&index=1!./navbar.vue", function() {
     var newContent = require("!!../../node_modules/_css-loader@0.26.4@css-loader/index.js!../../node_modules/_vue-loader@10.3.0@vue-loader/lib/style-rewriter.js?id=data-v-019a21a0&scoped=true!../../node_modules/_vue-loader@10.3.0@vue-loader/lib/selector.js?type=styles&index=1!./navbar.vue");
     if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
     update(newContent);
   });
 }
 // When the module is disposed, remove the <style> tags
 module.hot.dispose(function() { update(); });
}

/***/ }),

/***/ 13:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
const dom = weex.requireModule('dom');
const event = weex.requireModule('event');
const stream = weex.requireModule('stream');
const storage = weex.requireModule('storage');
const animation = weex.requireModule('animation');
/* unused harmony default export */ var _unused_webpack_default_export = ({ dom, event, stream, storage, animation });

/***/ }),

/***/ 14:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__assets_utils_js__ = __webpack_require__(2);

//时间格式化 今天 昨天 前天  年月日
Vue.filter('daydayfmt', function (value) {
    let res = __WEBPACK_IMPORTED_MODULE_0__assets_utils_js__["a" /* default */].resolvetimefmt(value);
    let tds = __WEBPACK_IMPORTED_MODULE_0__assets_utils_js__["a" /* default */].resolvetimefmt(Math.round(new Date().getTime()));

    let d1 = Date.parse(__WEBPACK_IMPORTED_MODULE_0__assets_utils_js__["a" /* default */].ymdtimefmt(value));
    let d2 = Date.parse(__WEBPACK_IMPORTED_MODULE_0__assets_utils_js__["a" /* default */].ymdtimefmt(Math.round(new Date().getTime())));
    let span = Math.abs(d2 - d1);
    let daySub = Math.floor(span / (24 * 3600 * 1000));

    if (daySub < 1) {
        return "今天";
    } else if (daySub < 2) {
        return "昨天";
    } else if (daySub < 3) {
        return "前天";
    } else {
        return res.y + '年' + res.m + '月' + res.d + '日';
    }
});

//时间格式化 今天 近三天 近七天  七天前
Vue.filter('dayfmt', function (value) {
    let res = __WEBPACK_IMPORTED_MODULE_0__assets_utils_js__["a" /* default */].resolvetimefmt(value);
    let tds = __WEBPACK_IMPORTED_MODULE_0__assets_utils_js__["a" /* default */].resolvetimefmt(Math.round(new Date().getTime()));

    let d1 = Date.parse(__WEBPACK_IMPORTED_MODULE_0__assets_utils_js__["a" /* default */].ymdtimefmt(value));
    let d2 = Date.parse(__WEBPACK_IMPORTED_MODULE_0__assets_utils_js__["a" /* default */].ymdtimefmt(Math.round(new Date().getTime())));
    let span = Math.abs(d2 - d1);
    let daySub = Math.floor(span / (24 * 3600 * 1000));
    if (daySub < 1) {
        return "今天";
    }
    if (daySub < 3) {
        return "近三天";
    }
    if (daySub < 7) {
        return "近七天";
    }
    return "七天前";
});
// 时间格式化 10:30 昨天 前天 2017年09月01日 09月01日
Vue.filter('timefmt', function (value) {
    let res = __WEBPACK_IMPORTED_MODULE_0__assets_utils_js__["a" /* default */].resolvetimefmt(value);
    let tds = __WEBPACK_IMPORTED_MODULE_0__assets_utils_js__["a" /* default */].resolvetimefmt(Math.round(new Date().getTime()));

    let d1 = Date.parse(__WEBPACK_IMPORTED_MODULE_0__assets_utils_js__["a" /* default */].ymdtimefmt(value));
    let d2 = Date.parse(__WEBPACK_IMPORTED_MODULE_0__assets_utils_js__["a" /* default */].ymdtimefmt(Math.round(new Date().getTime())));
    let span = Math.abs(d2 - d1);
    let daySub = Math.floor(span / (24 * 3600 * 1000));
    if (daySub < 1) {
        return res.h + ":" + res.i;
    }
    if (daySub < 2) {
        return "昨天";
    }
    if (daySub < 3) {
        return "前天";
    }
    if (res.y == tds.y) {
        return res.m + '月' + res.d + '日';
    } else {
        return res.y + '年' + res.m + '月' + res.d + '日';
    }
});

// 时间格式化  2017年09月01日 09月01日
Vue.filter('ymdtimefmt', function (value) {
    let res = __WEBPACK_IMPORTED_MODULE_0__assets_utils_js__["a" /* default */].resolvetimefmt(value);
    let tds = __WEBPACK_IMPORTED_MODULE_0__assets_utils_js__["a" /* default */].resolvetimefmt(Math.round(new Date().getTime()));
    if (res.y == tds.y) {
        return res.m + '月' + res.d + '日';
    } else {
        return res.y + '年' + res.m + '月' + res.d + '日';
    }
});

// 时间格式化 10:30 昨天10:30  2017年09月01日10:30 09月01日10:30
Vue.filter('timefmtMore', function (value) {
    let res = __WEBPACK_IMPORTED_MODULE_0__assets_utils_js__["a" /* default */].resolvetimefmt(value);
    let tds = __WEBPACK_IMPORTED_MODULE_0__assets_utils_js__["a" /* default */].resolvetimefmt(Math.round(new Date().getTime()));

    let d1 = Date.parse(__WEBPACK_IMPORTED_MODULE_0__assets_utils_js__["a" /* default */].ymdtimefmt(value));
    let d2 = Date.parse(__WEBPACK_IMPORTED_MODULE_0__assets_utils_js__["a" /* default */].ymdtimefmt(Math.round(new Date().getTime())));
    let span = Math.abs(d2 - d1);
    let daySub = Math.floor(span / (24 * 3600 * 1000));
    if (daySub < 1) {
        return res.h + ":" + res.i;
    }
    if (daySub < 2) {
        return "昨天" + ' ' + res.h + ":" + res.i;
    }
    if (res.y == tds.y) {
        return res.m + '月' + res.d + '日' + ' ' + res.h + ":" + res.i;
    } else {
        return res.y + '年' + res.m + '月' + res.d + '日' + ' ' + res.h + ":" + res.i;
    }
});

// 时间格式化 10:30 昨天 前天 2017-09-01 09-01
Vue.filter('timefmtOther', function (value) {
    let res = __WEBPACK_IMPORTED_MODULE_0__assets_utils_js__["a" /* default */].resolvetimefmt(value);
    let tds = __WEBPACK_IMPORTED_MODULE_0__assets_utils_js__["a" /* default */].resolvetimefmt(Math.round(new Date().getTime()));

    let d1 = Date.parse(__WEBPACK_IMPORTED_MODULE_0__assets_utils_js__["a" /* default */].ymdtimefmt(value));
    let d2 = Date.parse(__WEBPACK_IMPORTED_MODULE_0__assets_utils_js__["a" /* default */].ymdtimefmt(Math.round(new Date().getTime())));
    let span = Math.abs(d2 - d1);
    let daySub = Math.floor(span / (24 * 3600 * 1000));
    if (daySub < 1) {
        return res.h + ":" + res.i;
    }
    if (daySub < 2) {
        return "昨天";
    }
    if (daySub < 3) {
        return "前天";
    }
    //如果是今年 就不返回年份
    if (res.y == tds.y) {
        return res.m + '-' + res.d;
    } else {
        return res.y + '-' + res.m + '-' + res.d;
    }
});

// 时间格式化  2017-09-01
Vue.filter('timeDatefmt', function (value) {
    if (__WEBPACK_IMPORTED_MODULE_0__assets_utils_js__["a" /* default */].isNull(value)) {
        return value;
    }
    let res = __WEBPACK_IMPORTED_MODULE_0__assets_utils_js__["a" /* default */].resolvetimefmt(value);
    return res.y + '-' + res.m + '-' + res.d;
});

//时间格式化 返回 2017-09-30 03:07:56
Vue.filter('timeDatefmtMinutes', function (value) {
    let res = __WEBPACK_IMPORTED_MODULE_0__assets_utils_js__["a" /* default */].resolvetimefmt(value);
    let tds = __WEBPACK_IMPORTED_MODULE_0__assets_utils_js__["a" /* default */].resolvetimefmt(Math.round(new Date().getTime()));

    return res.y + '-' + res.m + '-' + res.d + '  ' + res.h + ':' + res.i + ':' + res.s;
});

//月份格式化 本月 上月 2..12月  2016年1月..
Vue.filter('monthfmt', function (value) {
    let res = __WEBPACK_IMPORTED_MODULE_0__assets_utils_js__["a" /* default */].resolvetimefmt(value);
    let tds = __WEBPACK_IMPORTED_MODULE_0__assets_utils_js__["a" /* default */].resolvetimefmt(Math.round(new Date().getTime()));

    let m = tds.m - res.m;
    let y = tds.y - tds.y;
    if (y < 1 && m < 1) {
        return "本月";
    }
    if (y < 1 && m < 2) {
        return "上月";
    }
    if (y < 1) {
        return res.m + "月";
    }
    return res.y + "年" + res.m + "月";
});

//2017-01-01
Vue.filter('datefmt', function (value) {
    let res = __WEBPACK_IMPORTED_MODULE_0__assets_utils_js__["a" /* default */].resolvetimefmt(value);
    return res.y + "年" + res.m + "月" + res.d + "日";
});

//返回月份 7 8 9 单数字
Vue.filter('detailMonth', function (value) {
    let res = __WEBPACK_IMPORTED_MODULE_0__assets_utils_js__["a" /* default */].resolvetimefmt(value);
    return res.m;
});

//时间格式化 返回 09-30 03:07
Vue.filter('datetimefmt', function (value) {

    let res = __WEBPACK_IMPORTED_MODULE_0__assets_utils_js__["a" /* default */].resolvetimefmt(value);
    let tds = __WEBPACK_IMPORTED_MODULE_0__assets_utils_js__["a" /* default */].resolvetimefmt(Math.round(new Date().getTime()));

    //如果是今年 就不返回年份
    if (res.y == tds.y) {
        return res.m + '-' + res.d + '  ' + res.h + ':' + res.i;
    } else {
        return res.y + '-' + res.m + '-' + res.d + '  ' + res.h + ':' + res.i;
    }
});

//时间格式化 返回 09-30 03:07:56 2017-09-30 03:07:56
Vue.filter('datemoretimefmt', function (value) {
    let res = __WEBPACK_IMPORTED_MODULE_0__assets_utils_js__["a" /* default */].resolvetimefmt(value);
    let tds = __WEBPACK_IMPORTED_MODULE_0__assets_utils_js__["a" /* default */].resolvetimefmt(Math.round(new Date().getTime()));

    //如果是今年 就不返回年份
    if (res.y == tds.y) {
        return res.m + '-' + res.d + '  ' + res.h + ':' + res.i + ':' + res.s;
    } else {
        return res.y + '-' + res.m + '-' + res.d + '  ' + res.h + ':' + res.i + ':' + res.s;
    }
});
//时间格式化 返回 09-30 03:07周日 2017-09-30 03:07周日
Vue.filter('dateweektimefmt', function (value) {
    let res = __WEBPACK_IMPORTED_MODULE_0__assets_utils_js__["a" /* default */].resolvetimefmt(value);
    let tds = __WEBPACK_IMPORTED_MODULE_0__assets_utils_js__["a" /* default */].resolvetimefmt(Math.round(new Date().getTime()));
    // 返回处理后的值
    var date = new Date(value);
    var d2 = Date.UTC(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate(), date.getUTCHours(), date.getUTCMinutes(), date.getUTCSeconds());
    date = new Date(d2 + 28800000);
    var day = date.getUTCDay();
    switch (day) {
        case 0:
            day = "周日";
            break;
        case 1:
            day = "周一";
            break;
        case 2:
            day = "周二";
            break;
        case 3:
            day = "周三";
            break;
        case 4:
            day = "周四";
            break;
        case 5:
            day = "周五";
            break;
        case 6:
            day = "周六";
            break;
    }

    //如果是今年 就不返回年份
    if (res.y == tds.y) {
        return res.m + '-' + res.d + '  ' + res.h + ':' + res.i + day;
    } else {
        return res.y + '-' + res.m + '-' + res.d + '  ' + res.h + ':' + res.i + day;
    }
});
//时间格式化 返回 03:07
Vue.filter('hitimefmt', function (value) {
    let res = __WEBPACK_IMPORTED_MODULE_0__assets_utils_js__["a" /* default */].resolvetimefmt(value);
    return res.h + ':' + res.i;
});

//金额保留两位小数点
Vue.filter('currencyfmt', function (value) {
    if (value == '' || value == null || value == undefined) {
        return value;
    }
    // 返回处理后的值
    if (value != null) {
        value = parseFloat(value);
        if (value == 0) {
            return value.toFixed(2);
        } else {
            var price = (Math.round(value * Math.pow(10, 2)) / Math.pow(10, 2)).toFixed(2);
            return price;
        }
    }
});

/***/ }),

/***/ 15:
/***/ (function(module, exports, __webpack_require__) {


/* styles */
__webpack_require__(20)
__webpack_require__(21)

var Component = __webpack_require__(3)(
  /* script */
  __webpack_require__(16),
  /* template */
  __webpack_require__(19),
  /* scopeId */
  "data-v-88e6f2aa",
  /* cssModules */
  null
)
Component.options.__file = "/Users/zhangsr/Documents/GitHub/weex/mp/src/include/noData.vue"
if (Component.esModule && Object.keys(Component.esModule).some(function (key) {return key !== "default" && key !== "__esModule"})) {console.error("named exports are not supported in *.vue files.")}
if (Component.options.functional) {console.error("[vue-loader] noData.vue: functional components are not supported with templates, they should use render functions.")}

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-loader/node_modules/vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-88e6f2aa", Component.options)
  } else {
    hotAPI.reload("data-v-88e6f2aa", Component.options)
  }
})()}

module.exports = Component.exports


/***/ }),

/***/ 16:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ __webpack_exports__["default"] = ({
    props: {
        ndBgColor: { default: '#eee' },
        noDataHint: { default: '没有数据' },
        pdNumber: { default: 200 }
    }
});

/***/ }),

/***/ 17:
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(0)();
// imports


// module
exports.push([module.i, "/**每个页面都必须的，墙纸**/\n.wrapper {\n  position: absolute;\n  top: 0;\n  left: 0;\n  right: 0;\n  bottom: 0;\n  width: 750px;\n  background-color: #eee;\n}\n/**默认标题字体**/\n.nav_title {\n  font-size: 38px;\n  color: #fff;\n  line-height: 38px;\n}\n.title {\n  font-size: 32px;\n  color: #000;\n}\n/**默认子标题字体**/\n.sub_title {\n  font-size: 30px;\n  color: #999;\n}\n.sub_date {\n  font-size: 26px;\n  color: #999;\n}\n.fz22 {\n  font-size: 22px;\n}\n.fz24 {\n  font-size: 24px;\n}\n.fz26 {\n  font-size: 26px;\n}\n.fz28 {\n  font-size: 28px;\n}\n.fz30 {\n  font-size: 30px;\n}\n.fz32 {\n  font-size: 32px;\n}\n.fz35 {\n  font-size: 35px;\n}\n.fz40 {\n  font-size: 40px;\n}\n.boder-bottom {\n  border-style: solid;\n  border-bottom-width: 1px;\n  border-color: #ccc;\n}\n.boder-top {\n  border-style: solid;\n  border-top-width: 1px;\n  border-color: #ccc;\n}\n.boder-right {\n  border-style: solid;\n  border-right-width: 1px;\n  border-color: #ccc;\n}\n.boder-left {\n  border-style: solid;\n  border-left-width: 1px;\n  border-color: #ccc;\n}\n.pl10 {\n  padding-left: 10px;\n}\n.pl5 {\n  padding-left: 5px;\n}\n.pt0 {\n  padding-top: 0px;\n}\n.pt10 {\n  padding-top: 10px;\n}\n.pt15 {\n  padding-top: 15px;\n}\n.pb0 {\n  padding-bottom: 0px;\n}\n.pb10 {\n  padding-bottom: 10px;\n}\n.pl20 {\n  padding-left: 20px;\n}\n.pt20 {\n  padding-top: 20px;\n}\n.pb15 {\n  padding-bottom: 15px;\n}\n.pb20 {\n  padding-bottom: 20px;\n}\n.pt25 {\n  padding-top: 25px;\n}\n.pt30 {\n  padding-top: 30px;\n}\n.pt40 {\n  padding-top: 40px;\n}\n.pb40 {\n  padding-bottom: 40px;\n}\n.pb30 {\n  padding-bottom: 30px;\n}\n.pb25 {\n  padding-bottom: 25px;\n}\n.pl25 {\n  padding-left: 25px;\n}\n.pl30 {\n  padding-left: 30px;\n}\n.pr5 {\n  padding-right: 5px;\n}\n.pr10 {\n  padding-right: 10px;\n}\n.pr20 {\n  padding-right: 20px;\n}\n.pr25 {\n  padding-right: 25px;\n}\n.pr30 {\n  padding-right: 30px;\n}\n.pl35 {\n  padding-left: 35px;\n}\n.pr35 {\n  padding-right: 35px;\n}\n.bgWhite {\n  background-color: #ffffff;\n}\n.textActive:active {\n  background-color: #ccc;\n}\n/**top 大小**/\n.mt0 {\n  margin-top: 0px;\n}\n.mt10 {\n  margin-top: 10px;\n}\n.mt15 {\n  margin-top: 15px;\n}\n.mt20 {\n  margin-top: 20px;\n}\n.mt30 {\n  margin-top: 30px;\n}\n.mt40 {\n  margin-top: 40px;\n}\n.mt50 {\n  margin-top: 50px;\n}\n/**bottom 大小**/\n.bt0 {\n  margin-bottom: 0px;\n}\n.bt5 {\n  margin-bottom: 5px;\n}\n.bt10 {\n  margin-bottom: 10px;\n}\n.bt15 {\n  margin-bottom: 15px;\n}\n.bt20 {\n  margin-bottom: 20px;\n}\n.bt30 {\n  margin-bottom: 30px;\n}\n.bt45 {\n  margin-bottom: 45px;\n}\n.bt50 {\n  margin-bottom: 50px;\n}\n.mr5 {\n  margin-right: 5px;\n}\n.mr10 {\n  margin-right: 10px;\n}\n.mr15 {\n  margin-right: 15px;\n}\n.mr20 {\n  margin-right: 20px;\n}\n.mr30 {\n  margin-right: 30px;\n}\n/**left 大小**/\n.ml5 {\n  margin-left: 5px;\n}\n.ml10 {\n  margin-left: 10px;\n}\n.ml20 {\n  margin-left: 20px;\n}\n.ml30 {\n  margin-left: 30px;\n}\n.header {\n  height: 136px;\n  padding-top: 44px;\n  flex-direction: row;\n  position: sticky;\n  background-color: #068F3D;\n}\n.baseNavBg {\n  background-color: #068F3D;\n}\n.baseNavColor {\n  color: #068F3D;\n}\n.nav {\n  width: 654px;\n  justify-content: space-between;\n  flex-direction: row;\n  height: 92px;\n  align-items: center;\n  margin-top: 0px;\n}\n.nav_back {\n  margin-top: 0px;\n  flex-direction: row;\n  width: 92px;\n  height: 92px;\n  align-items: center;\n  justify-content: center;\n}\n.corpusActive {\n  color: #068F3D;\n  border-color: #068F3D;\n  border-style: solid;\n  border-bottom-width: 4px;\n}\n.footer {\n  position: fixed;\n  bottom: 0px;\n  left: 0px;\n  right: 0px;\n  height: 100px;\n}\n.fill {\n  height: 500px;\n  width: 750px;\n  background-color: #eee;\n}\n/** 图标图像 **/\n.iconImg {\n  width: 60px;\n  height: 60px;\n  font-size: 60px;\n}\n/**cell 分组头**/\n.cell-header {\n  height: 70px;\n  flex-direction: row;\n  background-color: #ddd;\n  padding-left: 20px;\n}\n/**cell 行**/\n.cell-row {\n  min-height: 100px;\n  flex-direction: column;\n  background-color: #ffffff;\n  padding-left: 20px;\n  margin-top: 20px;\n}\n.cell-row-row {\n  min-height: 100px;\n  flex-direction: row;\n  justify-content: space-between;\n  background-color: #ffffff;\n  padding-left: 20px;\n  padding-right: 20px;\n  align-items: center;\n  margin-top: 20px;\n}\n.cell-line {\n  border-top-width: 1px;\n  border-top-color: #ccc;\n  border-top-style: solid;\n  border-bottom-width: 1px;\n  border-bottom-color: #ccc;\n  border-bottom-style: solid;\n}\n.borderTop {\n  border-top-width: 1px;\n  border-top-color: #ccc;\n  border-top-style: solid;\n}\n.borderBottom {\n  border-bottom-width: 1px;\n  border-bottom-color: #ccc;\n  border-bottom-style: solid;\n}\n/**cell 内面行**/\n.cell-panel {\n  height: 98px;\n  min-height: 98px;\n  flex-direction: row;\n  align-items: center;\n  border-bottom-width: 1px;\n  border-bottom-color: #ccc;\n  border-bottom-style: solid;\n}\n.cell-panel-column {\n  height: 98px;\n  min-height: 98px;\n  flex-direction: column;\n  justify-content: space-around;\n  border-bottom-width: 1px;\n  border-bottom-color: #ccc;\n  border-bottom-style: solid;\n  padding-top: 10px;\n  padding-bottom: 10px;\n}\n.cell-panel-column :last-child {\n  border-bottom-width: 0px;\n}\n.cell-panel :last-child {\n  border-bottom-width: 0px;\n}\n.cell-bottom-clear {\n  border-bottom-width: 0px;\n}\n.cell-clear {\n  margin-top: 0px;\n  margin-bottom: 0px;\n  border-top-width: 0px;\n  border-bottom-width: 0px;\n}\n/**两边对齐**/\n.space-between {\n  justify-content: space-between;\n  flex-direction: row;\n  align-items: center;\n}\n.flex-start {\n  justify-content: flex-start;\n  flex-direction: row;\n  align-items: center;\n}\n.flex-end {\n  justify-content: flex-end;\n  flex-direction: row;\n  align-items: center;\n}\n.flex-center {\n  justify-content: center;\n  flex-direction: row;\n  align-items: center;\n}\n.space-around {\n  justify-content: space-around;\n  flex-direction: row;\n  align-items: center;\n}\n/**横向部局居中对齐**/\n.flex-row {\n  flex-direction: row;\n  align-items: center;\n}\n.flex-column {\n  flex-direction: column;\n  align-items: center;\n}\n/**flex 部局比例**/\n.flex1 {\n  flex: 1;\n}\n.flex2 {\n  flex: 2;\n}\n.flex3 {\n  flex: 3;\n}\n.flex4 {\n  flex: 4;\n}\n.flex5 {\n  flex: 6;\n}\n.flex6 {\n  flex: 6;\n}\n/**常用背景颜色**/\n.bkg-white {\n  background-color: white;\n}\n.bkg-primary {\n  background-color: #068F3D;\n}\n.bkg-gray {\n  background-color: #eee;\n}\n.bd-primary {\n  border-color: #068F3D;\n}\n.bkg-delete {\n  background-color: red;\n}\n/**常用字体颜色**/\n.white {\n  color: white;\n}\n.primary {\n  color: #068F3D;\n}\n.gray {\n  color: #999;\n}\n/**ico 字体大小与颜色**/\n.ico {\n  font-size: 48px;\n  color: #068F3D;\n  margin-top: 2px;\n}\n.ico_big {\n  font-size: 72px;\n  color: #068F3D;\n  margin-top: 4px;\n}\n.ico_small {\n  font-size: 32px;\n  color: #068F3D;\n  margin-top: 1px;\n}\n/**右箭头 字体大小与颜色**/\n.arrow {\n  font-size: 32px;\n  color: #ccc;\n  width: 40px;\n}\n/**打勾 字体大小与颜色**/\n.check {\n  font-size: 32px;\n  color: #068F3D;\n  width: 40px;\n}\n.shopCheck {\n  font-size: 32px;\n  color: #068F3D;\n  width: 40px;\n  margin-left: 150px;\n}\n/**默认按钮类型**/\n.button {\n  font-size: 32px;\n  text-align: center;\n  color: #fff;\n  padding-top: 15px;\n  padding-bottom: 15px;\n  background-color: #068F3D;\n  border-radius: 15px;\n  height: 80px;\n  line-height: 50px;\n  align-items: center;\n  justify-content: center;\n}\n.button:active {\n  background-color: #ccc;\n  color: #068F3D;\n}\n.button:disabled {\n  background-color: #068F3D;\n  color: #999;\n}\n/**上拉刷新，下拉加载样式**/\n.refresh {\n  flex-direction: column;\n  align-items: center;\n  padding-top: 10px;\n}\n.loading {\n  flex-direction: column;\n  align-items: center;\n  padding-top: 10px;\n}\n.noLoading {\n  height: 999px;\n}\n.gif {\n  width: 50px;\n  height: 50px;\n}\n.indicator {\n  font-size: 36px;\n  color: #068F3D;\n  width: 750px;\n  text-align: center;\n  margin-top: 20px;\n  margin-bottom: 20px;\n}\n/**超长用省略号**/\n.lines-ellipsis {\n  lines: 1;\n  text-overflow: ellipsis;\n}\n.V1 {\n  height: 146px;\n  padding-top: 54px;\n}\n.IPhoneX {\n  height: 156px;\n  padding-top: 64px;\n}\n.addTopV1 {\n  top: 54px;\n}\n.addTopIPhoneX {\n  top: 64px;\n}\n.addInfoV1 {\n  height: 430px;\n  padding-top: 50px;\n}\n.addInfoIPhoneX {\n  height: 440px;\n  padding-top: 60px;\n}\n.addBgImgV1 {\n  height: 430px;\n}\n.addBgImgIPhoneX {\n  height: 440px;\n}\n.hideCorpusV1 {\n  top: 146px;\n}\n.hideCorpusIPhoneX {\n  top: 156px;\n}\n.pageTopV1 {\n  top: 226px;\n}\n.pageTopIPhoneX {\n  top: 236px;\n}\n.maskLayer {\n  position: fixed;\n  top: 0px;\n  left: 0px;\n  right: 0px;\n  bottom: 0px;\n  background-color: #000;\n  opacity: 0.4;\n}\n.showBox {\n  position: fixed;\n  top: 150px;\n  right: 15px;\n  padding-top: 20px;\n  padding-bottom: 20px;\n}\n.showBg {\n  position: absolute;\n  top: 0;\n  bottom: 0;\n  left: 0;\n  right: 0;\n  background-color: #fff;\n  border-radius: 20px;\n}\n.arrowUp {\n  position: fixed;\n  top: 148px;\n  right: 30px;\n}\n.refreshImg {\n  width: 60px;\n  height: 60px;\n  border-radius: 30px;\n}\n.refreshBox {\n  height: 120px;\n  width: 750px;\n  align-items: center;\n  justify-content: center;\n}\n.indexMtIPhoneX {\n  margin-top: 124px;\n}\n.indexSliderMtIPhone {\n  margin-top: 44px;\n}\n.indexSliderMtIPhoneX {\n  margin-top: 124px;\n}\n.artOutBoxTopIPhoneX {\n  top: 156px;\n}\n.processTotal {\n  position: absolute;\n  bottom: 40px;\n  right: 50px;\n  font-size: 28px;\n  color: #888;\n}\n.processBg {\n  background-color: #ccc;\n  width: 500px;\n}\n.processStyle {\n  height: 10px;\n  position: absolute;\n  left: 50px;\n  bottom: 100px;\n}\n.processText {\n  position: absolute;\n  top: 40px;\n  left: 50px;\n  font-size: 32px;\n}\n.processBox {\n  height: 250px;\n  border-radius: 5px;\n  width: 600px;\n  background-color: #fff;\n  justify-content: space-between;\n}\n.sendMask {\n  position: absolute;\n  top: 0;\n  bottom: 0;\n  left: 0;\n  right: 0;\n  background-color: rgba(0, 0, 0, 0.8);\n  align-items: center;\n  justify-content: center;\n}\n.coverAbsoTop {\n  position: absolute;\n  top: 0;\n  background-color: rgba(136, 136, 136, 0.1);\n}\n", ""]);

// exports


/***/ }),

/***/ 18:
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(0)();
// imports


// module
exports.push([module.i, "\n.noData[data-v-88e6f2aa] {\n    padding-top:250px;\n    align-items: center;\n}\n.noData_ico[data-v-88e6f2aa] {\n    color:#ccc;\n    font-size: 72px;\n}\n.noData_hint[data-v-88e6f2aa] {\n    color:#ccc;\n    margin-top: 30px;\n}\n", ""]);

// exports


/***/ }),

/***/ 19:
/***/ (function(module, exports, __webpack_require__) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "noData",
    style: ({
      backgroundColor: _vm.ndBgColor,
      paddingBottom: _vm.pbNumbe + 'px'
    })
  }, [_c('text', {
    staticClass: "noData_ico",
    style: ({
      fontFamily: 'iconfont'
    })
  }, [_vm._v("")]), _vm._v(" "), _c('text', {
    staticClass: "noData_hint"
  }, [_vm._v(_vm._s(_vm.noDataHint))])])
},staticRenderFns: []}
module.exports.render._withStripped = true
if (false) {
  module.hot.accept()
  if (module.hot.data) {
     require("vue-loader/node_modules/vue-hot-reload-api").rerender("data-v-88e6f2aa", module.exports)
  }
}

/***/ }),

/***/ 2:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/**
 * Created by zwwill on 2017/8/27.
 */
var modal = weex.requireModule('modal');
const resLocateURL = 'file://';
const resRemoteURL = 'http://cdn.rzico.com/weex/';
const websiteURL = 'https://small.rzico.com';
const event = weex.requireModule('event');
const debug = false; //删掉该属性时请查找该页所有debug变量并删除变量
const appName = 'yundian'; // app类型  water 或 yundian
let utilsFunc = {
    //0 标准版 1生鲜版 2桶装水
    version: 0,
    // app类型
    appType() {
        return appName;
    },
    initIconFont() {
        let domModule = weex.requireModule('dom');
        domModule.addRule('fontFace', {
            'fontFamily': "iconfont",
            'src': "url('" + resLocateURL + "resources/fonts/iconfont.ttf')"
        });
    },
    //获取本地资源
    locate(url) {
        const newUrl = resLocateURL + url;
        return newUrl;
    },
    //获取远程资源
    remote(url) {
        const newUrl = resRemoteURL + url;
        return newUrl;
    },
    //获取网站资源
    website(url) {
        const newUrl = websiteURL + url;
        return newUrl;
    },
    //获取URL参数
    getUrlParameter(name, dataUrl) {
        let url;
        if (dataUrl == null || dataUrl == undefined || dataUrl == '') {
            url = weex.config.bundleUrl;
        } else {
            url = dataUrl;
        }
        let reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
        let r = url.slice(url.indexOf('?') + 1).match(reg);
        if (r != null) {
            try {
                return decodeURIComponent(r[2]);
            } catch (_e) {
                return null;
            }
        }
        return null;
    },
    message(_type, _content, _data) {
        return {
            type: _type,
            content: _content,
            data: _data
        };
    },
    //判空
    isNull(value) {
        if (value == null || value == undefined || value == '' || value == 'undefined') {
            return true;
        } else {
            return false;
        }
    },
    //把缩略图过滤为原图
    filterThumbnail(url) {

        if (this.isNull(url)) {
            return url;
        }
        if (url.indexOf('?x-oss-') != -1) {
            url = url.substring(0, url.indexOf('?x-oss-'));
        } else if (url.indexOf('@') != -1) {
            url = url.substring(0, url.indexOf('@'));
        }
        return url;
    },
    //获取缩略图
    thumbnail(url, w, h) {
        if (this.isNull(url)) {
            return url;
        }
        //获取屏幕宽度计算得出比例
        let proportion = weex.config.env.deviceWidth / 750;
        //                获取缩略图的宽高
        w = parseInt(w * proportion);
        h = parseInt(h * proportion);
        if (url.substring(0, 11) == "http://cdnx") {
            return url + "?x-oss-process=image/resize,m_fill,w_" + w + ",h_" + h + "";
        } else if (url.substring(0, 10) == "http://cdn") {
            return url + "@" + w + "w_" + h + "h_1e_1c_100Q";
        } else {
            return url;
        }
    },
    //获取全屏的高度尺寸,可传入父组件的导航栏高度进行适配
    fullScreen(topHeight) {
        //减1是为了能触发loading，不能够高度刚刚好
        topHeight = topHeight == '' ? 0 : topHeight - 1;
        return 750 / weex.config.env.deviceWidth * weex.config.env.deviceHeight - topHeight;
    },
    //模糊图片，r, s  为 1-50，超大超模糊
    blur(url, r, s) {
        if (this.isNull(url)) {
            return url;
        }
        if (url.substring(0, 10) == "http://cdn") {
            return url + "@" + r + "-" + s + "bl";
        } else {
            return url;
        }
    },
    //获取文章URL地址
    articleUrl(template, id) {
        template = template == '' ? 't1001' : template;
        return websiteURL + "/#/" + template + "?id=" + id;
    },
    debug(msg) {
        if (debug) {
            event.toast(msg);
        }
    },
    isRoles(roles, all) {
        for (var i = 0; i < roles.length; i++) {
            let role = roles.substring(i, i + 1);
            if (all.indexOf(role) >= 0) {
                return true;
            }
        }
        return false;
    },
    //  获取字符串的字符总长度
    getLength(e) {
        var name = e;
        var len = 0;
        for (let i = 0; i < name.length; i++) {
            var a = name.charAt(i);
            if (a.match(/[^\x00-\xff]/ig) != null) {
                len += 2;
            } else {
                len += 1;
            }
        }
        return len;
    },
    //    将过长的字符串换成 XXX...格式 默认取前7个字符
    changeStrLast(value, length, maxLength) {
        length = this.isNull(length) ? 7 : length;
        maxLength = this.isNull(maxLength) ? 16 : maxLength;
        //              如果用户名称过长，便截取拼成名字
        if (this.getLength(value) > maxLength) {
            value = value.substr(0, length) + '...';
        }
        return value;
    },

    //    将过长的字符串换成 XXX...XXX格式
    changeStr(e) {
        return e.substr(0, 4) + '...' + e.substr(-4);
    },
    //js中用正则表达式 过滤特殊字符, 校验所有输入域是否含有特殊符号 (无法过滤 \ )
    //  searchFilter(s) {
    //         event.toast(s);
    //         var pattern = new RegExp("[`~!@#$^&*()=|{}':;',\\[\\].<>/?~！@#￥……&*（）&mdash;—|{}【】‘；：”“'。，、？]");
    //         var rs = "";
    //         for (var i = 0; i < s.length; i++) {
    //             rs = rs + s.substr(i, 1).replace(pattern,'');
    //         }
    //         return rs;
    //     }

    //老的二维码转换成新格式
    qr2scan(e) {
        let type = this.getUrlParameter("type", e);
        let code = this.getUrlParameter("no", e);
        if (type == "paybill") {
            return websiteURL + "/q/818804" + code + ".jhtml";
        } else if (type == "card_active") {
            return websiteURL + "/q/818801" + code + ".jhtml";
        } else {
            return e;
        }
    },
    //    二维码读取内容
    readScan(e, callback) {
        e = this.qr2scan(e);
        let backData = {};
        //二维码字段截取. indexOf 没找到时返回-1， 此时如果2个indexof都没找到 那么 e.substring（-1 + 3 ，-1）,e的长度会变为2
        // let subData = e.substring(e.indexOf("/q/8") + 3,e.indexOf(".jhtml"));

        let start = e.indexOf("/q/8");
        let end = e.indexOf(".jhtml");
        var subData = null;
        if (start != -1 && end != -1) {
            subData = e.substring(start + 3, end);
        }
        //判断是不是web  code'000000'为无效二维码 '999999'为webView；
        if (subData == null) {
            //如果没有找到q/ 和 .jhtml中的字端，就执行该段代码
            if (e.substring(0, 4) == 'http' && debug) {
                let data = {
                    type: 'webView',
                    code: '999999'
                };
                backData = this.message('success', 'webView', data);
            } else {
                let data = {
                    type: 'error',
                    code: '000000'
                };
                backData = this.message('error', '无效二维码', data);
            }
            callback(backData);
        } else {
            //截取11位的判断码
            let type = subData.substring(0, 6);
            let code = subData.slice(6);
            let data = {
                type: type,
                code: code
            };
            if (code == '000000') {
                backData = this.message('error', '无效二维码', data);
            } else {
                backData = this.message('success', '扫描成功', data);
            }
            callback(backData);
        }
    },
    //判断用户是否只输入了空格
    isAllEmpty(str) {
        if (str.replace(/ /g, "").length == 0) {
            return true;
        } else {
            return false;
        }
    },
    //判断设备型号
    device: function () {
        let s = weex.config.env.deviceModel;
        if (this.isNull(s)) {
            return "";
        } else {
            if (s.indexOf("V1") > 0) {
                return "V1";
            } else if (s.indexOf("10,3") > 0 || s.indexOf("10,6") > 0) {
                return 'IPhoneX';
            } else {
                return s;
            }
        }
    },

    //    登录主页的轮播图控制
    indexMt() {
        let s = this.device();
        if (this.isNull(s)) {
            return "";
        } else {
            if (s == 'V1') {
                return 'indexMtV1';
            } else if (s == 'IPhoneX') {
                return 'indexMtIPhoneX';
            } else {
                return s;
            }
        }
    },

    //    登录主页的轮播图slider控制
    indexMtSlider() {
        let s = this.device();
        if (this.isNull(s)) {
            return "";
        } else {
            if (s == 'IPhoneX') {
                return 'indexSliderMtIPhoneX';
            } else if (this.isIosSystem()) {
                return 'indexSliderMtIPhone';
            } else {
                return s;
            }
        }
    },

    //    判断设备型号为fix定位的元素添加高度 (会员首页 作者专栏 顶部设置跟返回按钮)
    addTop: function () {
        let s = this.device();
        if (this.isNull(s)) {
            return "";
        } else {
            if (s == 'V1') {
                return 'addTopV1';
            } else if (s == 'IPhoneX') {
                return 'addTopIPhoneX';
            } else {
                return s;
            }
        }
    },
    //   会员首页 作者专栏 顶部信息栏
    addInfo: function () {
        let s = this.device();
        if (this.isNull(s)) {
            return "";
        } else {
            if (s == 'V1') {
                return 'addInfoV1';
            } else if (s == 'IPhoneX') {
                return 'addInfoIPhoneX';
            } else {
                return s;
            }
        }
    },

    //   新会员首页 专栏 顶部信息栏
    topicInfo: function () {
        let s = this.device();
        if (this.isNull(s)) {
            return "";
        } else {
            if (s == 'V1') {
                return 'memberBox';
            } else if (s == 'IPhoneX') {
                return 'memberBoxIPHONEX';
            } else {
                return s;
            }
        }
    },
    //   新会员首页 专栏 顶部粉丝栏
    topicFans: function () {
        let s = this.device();
        if (this.isNull(s)) {
            return "";
        } else {
            if (s == 'V1') {
                return 'fansBox';
            } else if (s == 'IPhoneX') {
                return 'fansBoxIPHONEX';
            } else {
                return s;
            }
        }
    },
    //   新会员首页 专栏 顶部操作栏
    topicOperation: function () {
        let s = this.device();
        if (this.isNull(s)) {
            return "";
        } else {
            if (s == 'V1') {
                return 'operationBox';
            } else if (s == 'IPhoneX') {
                return 'operationBoxIPHONEX';
            } else {
                return s;
            }
        }
    },

    //    判断设备型号为fix定位的元素添加高度 (会员首页 作者专栏 顶部设置跟返回按钮)
    addBgImg: function () {
        let s = this.device();
        if (this.isNull(s)) {
            return "";
        } else {
            if (s == 'V1') {
                return 'headerBox';
            } else if (s == 'IPhoneX') {
                return 'headerBoxIPHONEX';
            } else {
                return s;
            }
        }
    },
    //    判断设备型号为fix定位的元素添加高度 (会员首页 作者专栏 顶部设置跟返回按钮)
    topicBgImg: function () {
        let s = this.device();
        if (this.isNull(s)) {
            return "";
        } else {
            if (s == 'V1') {
                return 'topicBgImg';
            } else if (s == 'IPhoneX') {
                return 'addBgImgIPhoneX';
            } else {
                return s;
            }
        }
    },
    //    控制滑动时文集box的显示
    hideCorpus: function () {
        let s = this.device();
        if (this.isNull(s)) {
            return "";
        } else {
            if (s == 'V1') {
                return 'hideCorpusV1';
            } else if (s == 'IPhoneX') {
                return 'hideCorpusIPhoneX';
            } else {
                return s;
            }
        }
    },
    //    控制滑动时文集box的显示
    pageTop: function () {
        let s = this.device();
        if (this.isNull(s)) {
            return "";
        } else {
            if (s == 'V1') {
                return 'pageTopV1';
            } else if (s == 'IPhoneX') {
                return 'pageTopIPhoneX';
            } else {
                return s;
            }
        }
    },
    //    控制preview文章box的top
    artOutTop: function () {
        let s = this.device();
        if (this.isNull(s)) {
            return "";
        } else {
            if (s == 'V1') {
                return 'artOutBoxTopV1';
            } else if (s == 'IPhoneX') {
                return 'artOutBoxTopIPhoneX';
            } else {
                return s;
            }
        }
    },
    //    控制预览文章页底部栏的bottom高度
    previewBottom: function () {
        let s = this.device();
        if (this.isNull(s)) {
            return '';
        } else {
            if (s == 'IPhoneX') {
                return s;
            } else {
                return '';
            }
        }
    },

    //判断设备系统是不是ios
    isIosSystem: function () {
        let s = weex.config.env.osName;
        if (s == 'iOS') {
            return true;
        } else {
            return false;
        }
    },

    resolvetimefmt: function (value) {
        if (this.isNull(value)) {
            return value;
        }
        //value 传进来是个整数型，要判断是10位还是13位需要转成字符串。这边的方法是检测13位的时间戳 所以要*1000；并且转回整型。安卓下，时间早了8个小时
        if (value.toString().length == 10) {
            value = parseInt(value) * 1000;
        } else {
            value = parseInt(value);
        }
        // 返回处理后的值
        var date = new Date(value);

        var d2 = Date.UTC(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate(), date.getUTCHours(), date.getUTCMinutes(), date.getUTCSeconds());

        date = new Date(d2 + 28800000);

        var y = date.getUTCFullYear();
        var m = date.getUTCMonth() + 1;
        var d = date.getUTCDate();
        var h = date.getUTCHours();
        var i = date.getUTCMinutes();
        var s = date.getUTCSeconds();
        if (m < 10) {
            m = '0' + m;
        }
        if (d < 10) {
            d = '0' + d;
        }
        if (h < 10) {
            h = '0' + h;
        }
        if (i < 10) {
            i = '0' + i;
        }
        if (s < 10) {
            s = '0' + s;
        }
        let timeObj = {
            y: y,
            m: m,
            d: d,
            h: h,
            i: i,
            s: s
        };
        return timeObj;
    },
    resolvetime: function (value) {
        if (this.isNull(value)) {
            return value;
        }
        //value 传进来是个整数型，要判断是10位还是13位需要转成字符串。这边的方法是检测13位的时间戳 所以要*1000；并且转回整型。安卓下，时间早了8个小时
        if (value.toString().length == 10) {
            value = parseInt(value) * 1000;
        } else {
            value = parseInt(value);
        }
        // 返回处理后的值
        var date = new Date(value);

        var d2 = Date.UTC(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate(), date.getUTCHours(), date.getUTCMinutes(), date.getUTCSeconds());

        date = new Date(d2 + 28800000);

        var y = date.getUTCFullYear();
        var m = date.getUTCMonth() + 1;
        var d = date.getUTCDate();
        var h = date.getUTCHours();
        var i = date.getUTCMinutes();
        var s = date.getUTCSeconds();

        let timeObj = {
            y: y,
            m: m,
            d: d,
            h: h,
            i: i,
            s: s
        };
        return timeObj;
    },
    resolveTimeObj: function (obj) {
        return new Date(obj.y, obj.m - 1, obj.d).getTime();
    },
    // 点击一次增加一月
    incMonth: function (date) {
        var obj = this.resolvetime(date);
        // 必须转为整型，否则快速点击会出现问题
        obj.m = parseInt(obj.m);
        obj.y = parseInt(obj.y);
        if (obj.m >= 12) {
            obj.y = obj.y + 1;
            obj.m = 1;
        } else {
            obj.m = obj.m + 1;
        }

        return this.resolveTimeObj(obj);
    },
    // 点击一次减一月
    decMonth: function (date) {
        var obj = this.resolvetime(date);
        // 必须转为整型，否则快速点击会出现问题
        obj.m = parseInt(obj.m);
        obj.y = parseInt(obj.y);
        if (obj.m <= 1) {
            obj.y = obj.y - 1;
            obj.m = 12;
        } else {
            obj.m = obj.m - 1;
        }
        return this.resolveTimeObj(obj);
    },
    trunceDate: function (date) {
        var obj = this.resolvetime(date);

        obj.d = 1;
        obj.h = 0;
        obj.i = 0;
        obj.s = 0;
        return this.resolveTimeObj(obj);
    },
    trunceMonth: function (date) {
        var obj = this.resolvetime(date);
        obj.m = 1;
        obj.d = 1;
        obj.h = 0;
        obj.i = 0;
        obj.s = 0;
        return this.resolveTimeObj(obj);
    },
    // 减一天
    decDate: function (date) {

        return (date / 1000 - 86400) * 1000;
    },
    // 增一天
    incDate: function (date) {

        return (date / 1000 + 86400) * 1000;
    },
    // 点击一次减一年
    decYears: function (date) {
        var obj = this.resolvetime(date);

        // 必须要先转为整型，否者快速操作时会出错
        obj.y = obj.y - 1;

        return this.resolveTimeObj(obj);
    },
    // 点击一次增加一年
    incYears: function (date) {
        var obj = this.resolvetime(date);
        // 必须要先转为整型，否者快速操作时会出错
        obj.y = obj.y + 1;

        return this.resolveTimeObj(obj);
    },
    //返回格式 2017-09-01
    ymdtimefmt: function (value) {
        if (value == '' || value == null || value == undefined) {
            return value;
        }
        let timeObj = this.resolvetimefmt(value);
        var d = JSON.stringify(timeObj);
        return timeObj.y + '-' + timeObj.m + '-' + timeObj.d;
    },
    //返回格式 2017-09
    ymtimefmt: function (value) {
        if (value == '' || value == null || value == undefined) {
            return value;
        }
        let timeObj = this.resolvetimefmt(value);
        return timeObj.y + '-' + timeObj.m;
    },
    //返回格式 2017
    ytimefmt: function (value) {
        if (value == '' || value == null || value == undefined) {
            return value;
        }
        let timeObj = this.resolvetimefmt(value);
        return timeObj.y;
    },
    //返回格式 2017-09-01 06:35:59
    ymdhistimefmt: function (value) {
        if (value == '' || value == null || value == undefined) {
            return value;
        }
        let timeObj = this.resolvetimefmt(value);

        return timeObj.y + '-' + timeObj.m + '-' + timeObj.d + ' ' + timeObj.h + ':' + timeObj.i + ':' + timeObj.s;
    },
    //返回格式 2017年09月01日 06:35:59
    ymdhisdayfmt: function (value) {
        if (value == '' || value == null || value == undefined) {
            return value;
        }
        let timeObj = this.resolvetimefmt(value);

        return timeObj.y + '年' + timeObj.m + '月' + timeObj.d + '日' + ' ' + timeObj.h + ':' + timeObj.i + ':' + timeObj.s;
    },
    //返回格式 06:35:59
    histimefmt: function (value) {
        if (value == '' || value == null || value == undefined) {
            return value;
        }
        let timeObj = this.resolvetimefmt(value);
        return timeObj.h + ':' + timeObj.i + ':' + timeObj.s;
    },
    //过滤表情
    filteremoji(text, type) {
        var ranges = ['\ud83c[\udf00-\udfff]', '\ud83d[\udc00-\ude4f]', '\ud83d[\ude80-\udeff]'];
        text = text.replace(new RegExp(ranges.join('|'), 'g'), '');
        if (this.isNull(text) && type == 'article') {
            return '点击设置标题';
        }
        return text;
    },
    //金额保留两位小数点
    currencyfmt(value) {
        if (value == '' || value == null || value == undefined) {
            return value;
        }
        // 返回处理后的值
        if (value != null) {
            if (value == 0) {
                return value;
            } else {
                var price = (Math.round(value * Math.pow(10, 2)) / Math.pow(10, 2)).toFixed(2);
                return price;
            }
        }
    }
};

/* harmony default export */ __webpack_exports__["a"] = (utilsFunc);

/***/ }),

/***/ 20:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(17);
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var update = __webpack_require__(1)("2e337f81", content, false);
// Hot Module Replacement
if(false) {
 // When the styles change, update the <style> tags
 if(!content.locals) {
   module.hot.accept("!!../../node_modules/_css-loader@0.26.4@css-loader/index.js!../../node_modules/_vue-loader@10.3.0@vue-loader/lib/style-rewriter.js?id=data-v-88e6f2aa!../../node_modules/less-loader/dist/cjs.js!./wx.less", function() {
     var newContent = require("!!../../node_modules/_css-loader@0.26.4@css-loader/index.js!../../node_modules/_vue-loader@10.3.0@vue-loader/lib/style-rewriter.js?id=data-v-88e6f2aa!../../node_modules/less-loader/dist/cjs.js!./wx.less");
     if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
     update(newContent);
   });
 }
 // When the module is disposed, remove the <style> tags
 module.hot.dispose(function() { update(); });
}

/***/ }),

/***/ 21:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(18);
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var update = __webpack_require__(1)("679000ab", content, false);
// Hot Module Replacement
if(false) {
 // When the styles change, update the <style> tags
 if(!content.locals) {
   module.hot.accept("!!../../node_modules/_css-loader@0.26.4@css-loader/index.js!../../node_modules/_vue-loader@10.3.0@vue-loader/lib/style-rewriter.js?id=data-v-88e6f2aa&scoped=true!../../node_modules/_vue-loader@10.3.0@vue-loader/lib/selector.js?type=styles&index=1!./noData.vue", function() {
     var newContent = require("!!../../node_modules/_css-loader@0.26.4@css-loader/index.js!../../node_modules/_vue-loader@10.3.0@vue-loader/lib/style-rewriter.js?id=data-v-88e6f2aa&scoped=true!../../node_modules/_vue-loader@10.3.0@vue-loader/lib/selector.js?type=styles&index=1!./noData.vue");
     if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
     update(newContent);
   });
 }
 // When the module is disposed, remove the <style> tags
 module.hot.dispose(function() { update(); });
}

/***/ }),

/***/ 22:
/***/ (function(module, exports) {

var g;

// This works in non-strict mode
g = (function() {
	return this;
})();

try {
	// This works if eval is allowed (see CSP)
	g = g || Function("return this")() || (1,eval)("this");
} catch(e) {
	// This works if the window reference is available
	if(typeof window === "object")
		g = window;
}

// g can still be undefined, but nothing to do about it...
// We return undefined, instead of nothing here, so it's
// easier to handle this case. if(!global) { ...}

module.exports = g;


/***/ }),

/***/ 259:
/***/ (function(module, exports, __webpack_require__) {


/* styles */
__webpack_require__(1147)
__webpack_require__(1146)

var Component = __webpack_require__(3)(
  /* script */
  __webpack_require__(398),
  /* template */
  __webpack_require__(952),
  /* scopeId */
  null,
  /* cssModules */
  null
)
Component.options.__file = "/Users/zhangsr/Documents/GitHub/weex/mp/src/view/message/inform.vue"
if (Component.esModule && Object.keys(Component.esModule).some(function (key) {return key !== "default" && key !== "__esModule"})) {console.error("named exports are not supported in *.vue files.")}
if (Component.options.functional) {console.error("[vue-loader] inform.vue: functional components are not supported with templates, they should use render functions.")}

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-loader/node_modules/vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-45e47c12", Component.options)
  } else {
    hotAPI.reload("data-v-45e47c12", Component.options)
  }
})()}

module.exports = Component.exports


/***/ }),

/***/ 3:
/***/ (function(module, exports) {

module.exports = function normalizeComponent (
  rawScriptExports,
  compiledTemplate,
  scopeId,
  cssModules
) {
  var esModule
  var scriptExports = rawScriptExports = rawScriptExports || {}

  // ES6 modules interop
  var type = typeof rawScriptExports.default
  if (type === 'object' || type === 'function') {
    esModule = rawScriptExports
    scriptExports = rawScriptExports.default
  }

  // Vue.extend constructor export interop
  var options = typeof scriptExports === 'function'
    ? scriptExports.options
    : scriptExports

  // render functions
  if (compiledTemplate) {
    options.render = compiledTemplate.render
    options.staticRenderFns = compiledTemplate.staticRenderFns
  }

  // scopedId
  if (scopeId) {
    options._scopeId = scopeId
  }

  // inject cssModules
  if (cssModules) {
    var computed = options.computed || (options.computed = {})
    Object.keys(cssModules).forEach(function (key) {
      var module = cssModules[key]
      computed[key] = function () { return module }
    })
  }

  return {
    esModule: esModule,
    exports: scriptExports,
    options: options
  }
}


/***/ }),

/***/ 398:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__include_navbar_vue__ = __webpack_require__(6);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__include_navbar_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__include_navbar_vue__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__weex_js__ = __webpack_require__(13);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__assets_utils__ = __webpack_require__(2);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__assets_fetch__ = __webpack_require__(4);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__include_noData_vue__ = __webpack_require__(15);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__include_noData_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_4__include_noData_vue__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__filters_filters_js__ = __webpack_require__(14);
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//




let Base64 = __webpack_require__(896).Base64;



/* harmony default export */ __webpack_exports__["default"] = ({
    data() {
        return {
            messageType: '',
            bgWhite: true,
            dataList: [],
            refreshing: false,
            pageStart: 0,
            pageSize: 15,
            refreshImg: __WEBPACK_IMPORTED_MODULE_2__assets_utils__["a" /* default */].locate('resources/images/loading.png'),
            clicked: false
        };
    },
    components: {
        navbar: __WEBPACK_IMPORTED_MODULE_0__include_navbar_vue___default.a
    },
    props: {
        title: { default: '支付助手' }
    },
    filters: {
        //            logo
        watchLogo: function (value) {
            //                    没过滤前是原图
            return __WEBPACK_IMPORTED_MODULE_2__assets_utils__["a" /* default */].thumbnail(value, 90, 90);
        },
        //            文章封面
        watchThumbnail: function (value) {
            //                    没过滤前是原图
            return __WEBPACK_IMPORTED_MODULE_2__assets_utils__["a" /* default */].thumbnail(value, 110, 110);
        }
    },
    created() {
        let _this = this;
        __WEBPACK_IMPORTED_MODULE_2__assets_utils__["a" /* default */].initIconFont();
        this.messageType = __WEBPACK_IMPORTED_MODULE_2__assets_utils__["a" /* default */].getUrlParameter('type');
        switch (this.messageType) {
            case 'gm_10200':
                this.title = '订单提醒';
                this.bgWhite = false;
                break;
            case 'gm_10201':
                this.title = '账单提醒';
                this.bgWhite = false;
                break;
            case 'gm_10202':
                this.title = '系统消息';
                this.bgWhite = true;
                break;
            case 'gm_10203':
                this.title = '评论回复';
                this.bgWhite = true;
                break;
            case 'gm_10204':
                this.title = '点赞提醒';
                this.bgWhite = true;
                break;
            case 'gm_10205':
                this.title = '关注提醒';
                this.bgWhite = true;
                break;
            case 'gm_10206':
                this.title = '收藏提醒';
                this.bgWhite = true;
                break;
            case 'gm_10207':
                this.title = '赞赏提醒';
                this.bgWhite = true;
                break;
            case 'gm_10208':
                this.title = '文章提醒';
                this.bgWhite = true;
                break;
            case 'gm_10209':
                this.title = '添加好友';
                this.bgWhite = true;
                break;
            case 'gm_10210':
                this.title = '同意好友';
                this.bgWhite = true;
                break;
            case 'gm_10211':
                this.title = '客服消息';
                this.bgWhite = true;
                break;
            case 'gm_10212':
                this.title = '线下收款';
                this.bgWhite = false;
                break;
            case 'gm_10213':
                this.title = '运单提醒';
                this.bgWhite = false;
                break;
            default:
                this.title = '消息助手';
                this.bgWhite = true;
                break;
        }
        this.getAllInform();
    },
    methods: {
        //            获取所以消息
        getAllInform() {
            let _this = this;
            __webpack_require__.i(__WEBPACK_IMPORTED_MODULE_3__assets_fetch__["a" /* GET */])('weex/member/message/list.jhtml?userId=' + this.messageType + '&pageStart=' + this.pageStart + '&pageSize=' + this.pageSize, function (data) {
                if (data.type == 'success' && data.data.data != '') {
                    if (_this.pageStart == 0) {
                        data.data.data.forEach(function (item) {
                            if (!__WEBPACK_IMPORTED_MODULE_2__assets_utils__["a" /* default */].isNull(item.ext)) {
                                var b = Base64.decode(item.ext);
                                if (!__WEBPACK_IMPORTED_MODULE_2__assets_utils__["a" /* default */].isNull(b)) {
                                    item.ext = JSON.parse(b);
                                }
                            }
                            //                                    手机用户登录可能未设置logo和nickName
                            if (__WEBPACK_IMPORTED_MODULE_2__assets_utils__["a" /* default */].isNull(item.nickName)) {
                                item.nickName = '未填写';
                            }
                            //                                    手机用户登录可能未设置logo和nickName
                            if (__WEBPACK_IMPORTED_MODULE_2__assets_utils__["a" /* default */].isNull(item.logo)) {
                                item.logo = __WEBPACK_IMPORTED_MODULE_2__assets_utils__["a" /* default */].locate('resources/images/background.png');
                            }
                        });

                        _this.dataList = data.data.data;
                    } else {
                        data.data.data.forEach(function (item) {
                            if (!__WEBPACK_IMPORTED_MODULE_2__assets_utils__["a" /* default */].isNull(item.ext)) {
                                item.ext = Base64.decode(item.ext);
                                item.ext = JSON.parse(item.ext);
                            }
                            _this.dataList.push(item);
                        });
                    }
                    _this.pageStart = data.data.start + data.data.data.length;
                } else if (data.type == 'success' && data.data.data == '') {} else {
                    __WEBPACK_IMPORTED_MODULE_1__weex_js__["event"].toast(data.content);
                }
            }, function (err) {
                __WEBPACK_IMPORTED_MODULE_1__weex_js__["event"].toast(err.content);
            });
        },
        goback() {
            __WEBPACK_IMPORTED_MODULE_1__weex_js__["event"].closeURL();
        },
        //            作者主页
        goAuthor: function (id) {
            if (this.clicked) {
                return;
            }
            this.clicked = true;
            let _this = this;
            id = parseInt(id.substr(-5)) - 10200;
            __WEBPACK_IMPORTED_MODULE_1__weex_js__["event"].openURL(__WEBPACK_IMPORTED_MODULE_2__assets_utils__["a" /* default */].locate("view/topic/index.js?id=" + id), function (message) {
                _this.clicked = false;
            });
        },
        onrefresh: function () {
            var _this = this;

            _this.pageStart = 0;
            this.refreshing = true;
            __WEBPACK_IMPORTED_MODULE_1__weex_js__["animation"].transition(_this.$refs.refreshImg, {
                styles: {
                    transform: 'rotate(360deg)'
                },
                duration: 1000, //ms
                timingFunction: 'linear', //350 duration配合这个效果目前较好
                needLayout: false,
                delay: 0 //ms
            });
            setTimeout(() => {
                __WEBPACK_IMPORTED_MODULE_1__weex_js__["animation"].transition(_this.$refs.refreshImg, {
                    styles: {
                        transform: 'rotate(0)'
                    },
                    duration: 10, //ms
                    timingFunction: 'linear', //350 duration配合这个效果目前较好
                    needLayout: false,
                    delay: 0 //ms
                });
                this.refreshing = false;
                _this.getAllInform();
            }, 1000);
        },
        onloading: function () {
            this.getAllInform();
        },
        //            前往链接
        goLink(id) {
            if (this.clicked) {
                return;
            }
            this.clicked = true;
            let _this = this;
            __webpack_require__.i(__WEBPACK_IMPORTED_MODULE_3__assets_fetch__["b" /* POST */])('weex/member/message/go.jhtml?id=' + id).then(function (data) {
                if (data.type == 'success') {
                    if (!__WEBPACK_IMPORTED_MODULE_2__assets_utils__["a" /* default */].isNull(data.data)) {
                        __WEBPACK_IMPORTED_MODULE_1__weex_js__["event"].openURL(data.data, function () {});
                    }
                } else {
                    __WEBPACK_IMPORTED_MODULE_1__weex_js__["event"].toast(data.content);
                }
                _this.clicked = false;
            }, function (err) {
                _this.clicked = false;
                __WEBPACK_IMPORTED_MODULE_1__weex_js__["event"].toast(err.content);
            });
        }
    }

});

/***/ }),

/***/ 4:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (immutable) */ __webpack_exports__["b"] = POST;
/* harmony export (immutable) */ __webpack_exports__["a"] = GET;
/* harmony export (immutable) */ __webpack_exports__["c"] = SCAN;
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__utils_js__ = __webpack_require__(2);
const stream = weex.requireModule('stream');
const modal = weex.requireModule('modal');
const baseURL = '';

const event = weex.requireModule('event');
function POST(path, body) {
    return new Promise((resolve, reject) => {
        stream.fetch({
            method: 'POST',
            url: `${baseURL}${path}`,
            type: 'json',
            body: `${body}`
        }, response => {
            if (response.status == 200) {
                resolve(response.data);
            } else {
                reject({
                    type: "error",
                    content: "网络不稳定"
                });
            }
        }, () => {});
    });
}

function GET(path, resolve, reject) {

    // let cacheParams = {
    //     type:'httpCache',//类型
    //     key:`${baseURL}${path}`,//关键址
    // }
    // event.find(cacheParams,function (cache) {
    //    if (cache.type=='success') {
    //        if (cache.data != '') {
    //            resolve(JSON.parse(cache.data.value));
    //        }
    //    }
    // })

    stream.fetch({
        method: 'GET',
        url: `${baseURL}${path}`,
        type: 'json'
    }, response => {
        //请求 type=success 或 warn 或 error（没缓存） 时返回，都能正常获取数据
        if (response.status == 200) {
            resolve(response.data);
        } else
            //请求 type= error 网络正常，但服务器返回错误，有缓存，也需要给数据，并提示出错了  statusText=服务器返回的 content
            //网络异常，有缓存，需要给出缓存数据，并且   statusText 固定为 "网络不稳定"
            if (response.status == 304) {
                resolve(response.data);
                reject({
                    type: "error",
                    content: response.statusText
                });
            } else
                //网络异常，没有缓存
                {
                    reject({
                        type: "error",
                        content: '网络不稳定'
                    });
                }
    }, () => {});
}
//二维码扫描
function SCAN(message, resolve, reject) {
    if (message.type == 'success') {
        __WEBPACK_IMPORTED_MODULE_0__utils_js__["a" /* default */].readScan(message.data, function (data) {
            if (data.type == 'success') {
                if (data.data.type == '865380') {
                    let userId = parseInt(data.data.code) - 10200;
                    POST('weex/member/friends/add.jhtml?friendId=' + userId).then(function (mes) {
                        if (mes.type == "success") {
                            event.toast('添加好友请求已发送,请等待对方验证');
                        } else {
                            event.toast(mes.content);
                        }
                        resolve(mes);
                    }, function (err) {
                        reject(err);
                        event.toast(err.content);
                    });
                } else if (data.data.type == '818803') {
                    GET('weex/member/couponCode/use.jhtml?code=' + data.data.code, function (mes) {
                        modal.alert({
                            message: mes.content,
                            duration: 0.3
                        }, function (value) {});
                    }, function (err) {
                        event.toast(err.content);
                    });
                } else if (data.data.type == 'webView') {
                    event.openURL(message.data, function () {});
                } else {
                    event.toast('无效验证码');
                }
            } else {
                event.toast(data.content);
            }
        });
    } else {}
}

/***/ }),

/***/ 5:
/***/ (function(module, exports) {

/**
 * Translates the list format produced by css-loader into something
 * easier to manipulate.
 */
module.exports = function listToStyles (parentId, list) {
  var styles = []
  var newStyles = {}
  for (var i = 0; i < list.length; i++) {
    var item = list[i]
    var id = item[0]
    var css = item[1]
    var media = item[2]
    var sourceMap = item[3]
    var part = {
      id: parentId + ':' + i,
      css: css,
      media: media,
      sourceMap: sourceMap
    }
    if (!newStyles[id]) {
      styles.push(newStyles[id] = { id: id, parts: [part] })
    } else {
      newStyles[id].parts.push(part)
    }
  }
  return styles
}


/***/ }),

/***/ 545:
/***/ (function(module, exports, __webpack_require__) {

var App = __webpack_require__(259);
App.el = '#root';
new Vue(App);

/***/ }),

/***/ 6:
/***/ (function(module, exports, __webpack_require__) {


/* styles */
__webpack_require__(11)
__webpack_require__(12)

var Component = __webpack_require__(3)(
  /* script */
  __webpack_require__(7),
  /* template */
  __webpack_require__(10),
  /* scopeId */
  "data-v-019a21a0",
  /* cssModules */
  null
)
Component.options.__file = "/Users/zhangsr/Documents/GitHub/weex/mp/src/include/navbar.vue"
if (Component.esModule && Object.keys(Component.esModule).some(function (key) {return key !== "default" && key !== "__esModule"})) {console.error("named exports are not supported in *.vue files.")}
if (Component.options.functional) {console.error("[vue-loader] navbar.vue: functional components are not supported with templates, they should use render functions.")}

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-loader/node_modules/vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-019a21a0", Component.options)
  } else {
    hotAPI.reload("data-v-019a21a0", Component.options)
  }
})()}

module.exports = Component.exports


/***/ }),

/***/ 618:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.byteLength = byteLength
exports.toByteArray = toByteArray
exports.fromByteArray = fromByteArray

var lookup = []
var revLookup = []
var Arr = typeof Uint8Array !== 'undefined' ? Uint8Array : Array

var code = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'
for (var i = 0, len = code.length; i < len; ++i) {
  lookup[i] = code[i]
  revLookup[code.charCodeAt(i)] = i
}

revLookup['-'.charCodeAt(0)] = 62
revLookup['_'.charCodeAt(0)] = 63

function placeHoldersCount (b64) {
  var len = b64.length
  if (len % 4 > 0) {
    throw new Error('Invalid string. Length must be a multiple of 4')
  }

  // the number of equal signs (place holders)
  // if there are two placeholders, than the two characters before it
  // represent one byte
  // if there is only one, then the three characters before it represent 2 bytes
  // this is just a cheap hack to not do indexOf twice
  return b64[len - 2] === '=' ? 2 : b64[len - 1] === '=' ? 1 : 0
}

function byteLength (b64) {
  // base64 is 4/3 + up to two characters of the original data
  return (b64.length * 3 / 4) - placeHoldersCount(b64)
}

function toByteArray (b64) {
  var i, l, tmp, placeHolders, arr
  var len = b64.length
  placeHolders = placeHoldersCount(b64)

  arr = new Arr((len * 3 / 4) - placeHolders)

  // if there are placeholders, only get up to the last complete 4 chars
  l = placeHolders > 0 ? len - 4 : len

  var L = 0

  for (i = 0; i < l; i += 4) {
    tmp = (revLookup[b64.charCodeAt(i)] << 18) | (revLookup[b64.charCodeAt(i + 1)] << 12) | (revLookup[b64.charCodeAt(i + 2)] << 6) | revLookup[b64.charCodeAt(i + 3)]
    arr[L++] = (tmp >> 16) & 0xFF
    arr[L++] = (tmp >> 8) & 0xFF
    arr[L++] = tmp & 0xFF
  }

  if (placeHolders === 2) {
    tmp = (revLookup[b64.charCodeAt(i)] << 2) | (revLookup[b64.charCodeAt(i + 1)] >> 4)
    arr[L++] = tmp & 0xFF
  } else if (placeHolders === 1) {
    tmp = (revLookup[b64.charCodeAt(i)] << 10) | (revLookup[b64.charCodeAt(i + 1)] << 4) | (revLookup[b64.charCodeAt(i + 2)] >> 2)
    arr[L++] = (tmp >> 8) & 0xFF
    arr[L++] = tmp & 0xFF
  }

  return arr
}

function tripletToBase64 (num) {
  return lookup[num >> 18 & 0x3F] + lookup[num >> 12 & 0x3F] + lookup[num >> 6 & 0x3F] + lookup[num & 0x3F]
}

function encodeChunk (uint8, start, end) {
  var tmp
  var output = []
  for (var i = start; i < end; i += 3) {
    tmp = (uint8[i] << 16) + (uint8[i + 1] << 8) + (uint8[i + 2])
    output.push(tripletToBase64(tmp))
  }
  return output.join('')
}

function fromByteArray (uint8) {
  var tmp
  var len = uint8.length
  var extraBytes = len % 3 // if we have 1 byte left, pad 2 bytes
  var output = ''
  var parts = []
  var maxChunkLength = 16383 // must be multiple of 3

  // go through the array every three bytes, we'll deal with trailing stuff later
  for (var i = 0, len2 = len - extraBytes; i < len2; i += maxChunkLength) {
    parts.push(encodeChunk(uint8, i, (i + maxChunkLength) > len2 ? len2 : (i + maxChunkLength)))
  }

  // pad the end with zeros, but make sure to not forget the extra bytes
  if (extraBytes === 1) {
    tmp = uint8[len - 1]
    output += lookup[tmp >> 2]
    output += lookup[(tmp << 4) & 0x3F]
    output += '=='
  } else if (extraBytes === 2) {
    tmp = (uint8[len - 2] << 8) + (uint8[len - 1])
    output += lookup[tmp >> 10]
    output += lookup[(tmp >> 4) & 0x3F]
    output += lookup[(tmp << 2) & 0x3F]
    output += '='
  }

  parts.push(output)

  return parts.join('')
}


/***/ }),

/***/ 619:
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/* WEBPACK VAR INJECTION */(function(global) {/*!
 * The buffer module from node.js, for the browser.
 *
 * @author   Feross Aboukhadijeh <feross@feross.org> <http://feross.org>
 * @license  MIT
 */
/* eslint-disable no-proto */



var base64 = __webpack_require__(618)
var ieee754 = __webpack_require__(894)
var isArray = __webpack_require__(895)

exports.Buffer = Buffer
exports.SlowBuffer = SlowBuffer
exports.INSPECT_MAX_BYTES = 50

/**
 * If `Buffer.TYPED_ARRAY_SUPPORT`:
 *   === true    Use Uint8Array implementation (fastest)
 *   === false   Use Object implementation (most compatible, even IE6)
 *
 * Browsers that support typed arrays are IE 10+, Firefox 4+, Chrome 7+, Safari 5.1+,
 * Opera 11.6+, iOS 4.2+.
 *
 * Due to various browser bugs, sometimes the Object implementation will be used even
 * when the browser supports typed arrays.
 *
 * Note:
 *
 *   - Firefox 4-29 lacks support for adding new properties to `Uint8Array` instances,
 *     See: https://bugzilla.mozilla.org/show_bug.cgi?id=695438.
 *
 *   - Chrome 9-10 is missing the `TypedArray.prototype.subarray` function.
 *
 *   - IE10 has a broken `TypedArray.prototype.subarray` function which returns arrays of
 *     incorrect length in some situations.

 * We detect these buggy browsers and set `Buffer.TYPED_ARRAY_SUPPORT` to `false` so they
 * get the Object implementation, which is slower but behaves correctly.
 */
Buffer.TYPED_ARRAY_SUPPORT = global.TYPED_ARRAY_SUPPORT !== undefined
  ? global.TYPED_ARRAY_SUPPORT
  : typedArraySupport()

/*
 * Export kMaxLength after typed array support is determined.
 */
exports.kMaxLength = kMaxLength()

function typedArraySupport () {
  try {
    var arr = new Uint8Array(1)
    arr.__proto__ = {__proto__: Uint8Array.prototype, foo: function () { return 42 }}
    return arr.foo() === 42 && // typed array instances can be augmented
        typeof arr.subarray === 'function' && // chrome 9-10 lack `subarray`
        arr.subarray(1, 1).byteLength === 0 // ie10 has broken `subarray`
  } catch (e) {
    return false
  }
}

function kMaxLength () {
  return Buffer.TYPED_ARRAY_SUPPORT
    ? 0x7fffffff
    : 0x3fffffff
}

function createBuffer (that, length) {
  if (kMaxLength() < length) {
    throw new RangeError('Invalid typed array length')
  }
  if (Buffer.TYPED_ARRAY_SUPPORT) {
    // Return an augmented `Uint8Array` instance, for best performance
    that = new Uint8Array(length)
    that.__proto__ = Buffer.prototype
  } else {
    // Fallback: Return an object instance of the Buffer class
    if (that === null) {
      that = new Buffer(length)
    }
    that.length = length
  }

  return that
}

/**
 * The Buffer constructor returns instances of `Uint8Array` that have their
 * prototype changed to `Buffer.prototype`. Furthermore, `Buffer` is a subclass of
 * `Uint8Array`, so the returned instances will have all the node `Buffer` methods
 * and the `Uint8Array` methods. Square bracket notation works as expected -- it
 * returns a single octet.
 *
 * The `Uint8Array` prototype remains unmodified.
 */

function Buffer (arg, encodingOrOffset, length) {
  if (!Buffer.TYPED_ARRAY_SUPPORT && !(this instanceof Buffer)) {
    return new Buffer(arg, encodingOrOffset, length)
  }

  // Common case.
  if (typeof arg === 'number') {
    if (typeof encodingOrOffset === 'string') {
      throw new Error(
        'If encoding is specified then the first argument must be a string'
      )
    }
    return allocUnsafe(this, arg)
  }
  return from(this, arg, encodingOrOffset, length)
}

Buffer.poolSize = 8192 // not used by this implementation

// TODO: Legacy, not needed anymore. Remove in next major version.
Buffer._augment = function (arr) {
  arr.__proto__ = Buffer.prototype
  return arr
}

function from (that, value, encodingOrOffset, length) {
  if (typeof value === 'number') {
    throw new TypeError('"value" argument must not be a number')
  }

  if (typeof ArrayBuffer !== 'undefined' && value instanceof ArrayBuffer) {
    return fromArrayBuffer(that, value, encodingOrOffset, length)
  }

  if (typeof value === 'string') {
    return fromString(that, value, encodingOrOffset)
  }

  return fromObject(that, value)
}

/**
 * Functionally equivalent to Buffer(arg, encoding) but throws a TypeError
 * if value is a number.
 * Buffer.from(str[, encoding])
 * Buffer.from(array)
 * Buffer.from(buffer)
 * Buffer.from(arrayBuffer[, byteOffset[, length]])
 **/
Buffer.from = function (value, encodingOrOffset, length) {
  return from(null, value, encodingOrOffset, length)
}

if (Buffer.TYPED_ARRAY_SUPPORT) {
  Buffer.prototype.__proto__ = Uint8Array.prototype
  Buffer.__proto__ = Uint8Array
  if (typeof Symbol !== 'undefined' && Symbol.species &&
      Buffer[Symbol.species] === Buffer) {
    // Fix subarray() in ES2016. See: https://github.com/feross/buffer/pull/97
    Object.defineProperty(Buffer, Symbol.species, {
      value: null,
      configurable: true
    })
  }
}

function assertSize (size) {
  if (typeof size !== 'number') {
    throw new TypeError('"size" argument must be a number')
  } else if (size < 0) {
    throw new RangeError('"size" argument must not be negative')
  }
}

function alloc (that, size, fill, encoding) {
  assertSize(size)
  if (size <= 0) {
    return createBuffer(that, size)
  }
  if (fill !== undefined) {
    // Only pay attention to encoding if it's a string. This
    // prevents accidentally sending in a number that would
    // be interpretted as a start offset.
    return typeof encoding === 'string'
      ? createBuffer(that, size).fill(fill, encoding)
      : createBuffer(that, size).fill(fill)
  }
  return createBuffer(that, size)
}

/**
 * Creates a new filled Buffer instance.
 * alloc(size[, fill[, encoding]])
 **/
Buffer.alloc = function (size, fill, encoding) {
  return alloc(null, size, fill, encoding)
}

function allocUnsafe (that, size) {
  assertSize(size)
  that = createBuffer(that, size < 0 ? 0 : checked(size) | 0)
  if (!Buffer.TYPED_ARRAY_SUPPORT) {
    for (var i = 0; i < size; ++i) {
      that[i] = 0
    }
  }
  return that
}

/**
 * Equivalent to Buffer(num), by default creates a non-zero-filled Buffer instance.
 * */
Buffer.allocUnsafe = function (size) {
  return allocUnsafe(null, size)
}
/**
 * Equivalent to SlowBuffer(num), by default creates a non-zero-filled Buffer instance.
 */
Buffer.allocUnsafeSlow = function (size) {
  return allocUnsafe(null, size)
}

function fromString (that, string, encoding) {
  if (typeof encoding !== 'string' || encoding === '') {
    encoding = 'utf8'
  }

  if (!Buffer.isEncoding(encoding)) {
    throw new TypeError('"encoding" must be a valid string encoding')
  }

  var length = byteLength(string, encoding) | 0
  that = createBuffer(that, length)

  var actual = that.write(string, encoding)

  if (actual !== length) {
    // Writing a hex string, for example, that contains invalid characters will
    // cause everything after the first invalid character to be ignored. (e.g.
    // 'abxxcd' will be treated as 'ab')
    that = that.slice(0, actual)
  }

  return that
}

function fromArrayLike (that, array) {
  var length = array.length < 0 ? 0 : checked(array.length) | 0
  that = createBuffer(that, length)
  for (var i = 0; i < length; i += 1) {
    that[i] = array[i] & 255
  }
  return that
}

function fromArrayBuffer (that, array, byteOffset, length) {
  array.byteLength // this throws if `array` is not a valid ArrayBuffer

  if (byteOffset < 0 || array.byteLength < byteOffset) {
    throw new RangeError('\'offset\' is out of bounds')
  }

  if (array.byteLength < byteOffset + (length || 0)) {
    throw new RangeError('\'length\' is out of bounds')
  }

  if (byteOffset === undefined && length === undefined) {
    array = new Uint8Array(array)
  } else if (length === undefined) {
    array = new Uint8Array(array, byteOffset)
  } else {
    array = new Uint8Array(array, byteOffset, length)
  }

  if (Buffer.TYPED_ARRAY_SUPPORT) {
    // Return an augmented `Uint8Array` instance, for best performance
    that = array
    that.__proto__ = Buffer.prototype
  } else {
    // Fallback: Return an object instance of the Buffer class
    that = fromArrayLike(that, array)
  }
  return that
}

function fromObject (that, obj) {
  if (Buffer.isBuffer(obj)) {
    var len = checked(obj.length) | 0
    that = createBuffer(that, len)

    if (that.length === 0) {
      return that
    }

    obj.copy(that, 0, 0, len)
    return that
  }

  if (obj) {
    if ((typeof ArrayBuffer !== 'undefined' &&
        obj.buffer instanceof ArrayBuffer) || 'length' in obj) {
      if (typeof obj.length !== 'number' || isnan(obj.length)) {
        return createBuffer(that, 0)
      }
      return fromArrayLike(that, obj)
    }

    if (obj.type === 'Buffer' && isArray(obj.data)) {
      return fromArrayLike(that, obj.data)
    }
  }

  throw new TypeError('First argument must be a string, Buffer, ArrayBuffer, Array, or array-like object.')
}

function checked (length) {
  // Note: cannot use `length < kMaxLength()` here because that fails when
  // length is NaN (which is otherwise coerced to zero.)
  if (length >= kMaxLength()) {
    throw new RangeError('Attempt to allocate Buffer larger than maximum ' +
                         'size: 0x' + kMaxLength().toString(16) + ' bytes')
  }
  return length | 0
}

function SlowBuffer (length) {
  if (+length != length) { // eslint-disable-line eqeqeq
    length = 0
  }
  return Buffer.alloc(+length)
}

Buffer.isBuffer = function isBuffer (b) {
  return !!(b != null && b._isBuffer)
}

Buffer.compare = function compare (a, b) {
  if (!Buffer.isBuffer(a) || !Buffer.isBuffer(b)) {
    throw new TypeError('Arguments must be Buffers')
  }

  if (a === b) return 0

  var x = a.length
  var y = b.length

  for (var i = 0, len = Math.min(x, y); i < len; ++i) {
    if (a[i] !== b[i]) {
      x = a[i]
      y = b[i]
      break
    }
  }

  if (x < y) return -1
  if (y < x) return 1
  return 0
}

Buffer.isEncoding = function isEncoding (encoding) {
  switch (String(encoding).toLowerCase()) {
    case 'hex':
    case 'utf8':
    case 'utf-8':
    case 'ascii':
    case 'latin1':
    case 'binary':
    case 'base64':
    case 'ucs2':
    case 'ucs-2':
    case 'utf16le':
    case 'utf-16le':
      return true
    default:
      return false
  }
}

Buffer.concat = function concat (list, length) {
  if (!isArray(list)) {
    throw new TypeError('"list" argument must be an Array of Buffers')
  }

  if (list.length === 0) {
    return Buffer.alloc(0)
  }

  var i
  if (length === undefined) {
    length = 0
    for (i = 0; i < list.length; ++i) {
      length += list[i].length
    }
  }

  var buffer = Buffer.allocUnsafe(length)
  var pos = 0
  for (i = 0; i < list.length; ++i) {
    var buf = list[i]
    if (!Buffer.isBuffer(buf)) {
      throw new TypeError('"list" argument must be an Array of Buffers')
    }
    buf.copy(buffer, pos)
    pos += buf.length
  }
  return buffer
}

function byteLength (string, encoding) {
  if (Buffer.isBuffer(string)) {
    return string.length
  }
  if (typeof ArrayBuffer !== 'undefined' && typeof ArrayBuffer.isView === 'function' &&
      (ArrayBuffer.isView(string) || string instanceof ArrayBuffer)) {
    return string.byteLength
  }
  if (typeof string !== 'string') {
    string = '' + string
  }

  var len = string.length
  if (len === 0) return 0

  // Use a for loop to avoid recursion
  var loweredCase = false
  for (;;) {
    switch (encoding) {
      case 'ascii':
      case 'latin1':
      case 'binary':
        return len
      case 'utf8':
      case 'utf-8':
      case undefined:
        return utf8ToBytes(string).length
      case 'ucs2':
      case 'ucs-2':
      case 'utf16le':
      case 'utf-16le':
        return len * 2
      case 'hex':
        return len >>> 1
      case 'base64':
        return base64ToBytes(string).length
      default:
        if (loweredCase) return utf8ToBytes(string).length // assume utf8
        encoding = ('' + encoding).toLowerCase()
        loweredCase = true
    }
  }
}
Buffer.byteLength = byteLength

function slowToString (encoding, start, end) {
  var loweredCase = false

  // No need to verify that "this.length <= MAX_UINT32" since it's a read-only
  // property of a typed array.

  // This behaves neither like String nor Uint8Array in that we set start/end
  // to their upper/lower bounds if the value passed is out of range.
  // undefined is handled specially as per ECMA-262 6th Edition,
  // Section 13.3.3.7 Runtime Semantics: KeyedBindingInitialization.
  if (start === undefined || start < 0) {
    start = 0
  }
  // Return early if start > this.length. Done here to prevent potential uint32
  // coercion fail below.
  if (start > this.length) {
    return ''
  }

  if (end === undefined || end > this.length) {
    end = this.length
  }

  if (end <= 0) {
    return ''
  }

  // Force coersion to uint32. This will also coerce falsey/NaN values to 0.
  end >>>= 0
  start >>>= 0

  if (end <= start) {
    return ''
  }

  if (!encoding) encoding = 'utf8'

  while (true) {
    switch (encoding) {
      case 'hex':
        return hexSlice(this, start, end)

      case 'utf8':
      case 'utf-8':
        return utf8Slice(this, start, end)

      case 'ascii':
        return asciiSlice(this, start, end)

      case 'latin1':
      case 'binary':
        return latin1Slice(this, start, end)

      case 'base64':
        return base64Slice(this, start, end)

      case 'ucs2':
      case 'ucs-2':
      case 'utf16le':
      case 'utf-16le':
        return utf16leSlice(this, start, end)

      default:
        if (loweredCase) throw new TypeError('Unknown encoding: ' + encoding)
        encoding = (encoding + '').toLowerCase()
        loweredCase = true
    }
  }
}

// The property is used by `Buffer.isBuffer` and `is-buffer` (in Safari 5-7) to detect
// Buffer instances.
Buffer.prototype._isBuffer = true

function swap (b, n, m) {
  var i = b[n]
  b[n] = b[m]
  b[m] = i
}

Buffer.prototype.swap16 = function swap16 () {
  var len = this.length
  if (len % 2 !== 0) {
    throw new RangeError('Buffer size must be a multiple of 16-bits')
  }
  for (var i = 0; i < len; i += 2) {
    swap(this, i, i + 1)
  }
  return this
}

Buffer.prototype.swap32 = function swap32 () {
  var len = this.length
  if (len % 4 !== 0) {
    throw new RangeError('Buffer size must be a multiple of 32-bits')
  }
  for (var i = 0; i < len; i += 4) {
    swap(this, i, i + 3)
    swap(this, i + 1, i + 2)
  }
  return this
}

Buffer.prototype.swap64 = function swap64 () {
  var len = this.length
  if (len % 8 !== 0) {
    throw new RangeError('Buffer size must be a multiple of 64-bits')
  }
  for (var i = 0; i < len; i += 8) {
    swap(this, i, i + 7)
    swap(this, i + 1, i + 6)
    swap(this, i + 2, i + 5)
    swap(this, i + 3, i + 4)
  }
  return this
}

Buffer.prototype.toString = function toString () {
  var length = this.length | 0
  if (length === 0) return ''
  if (arguments.length === 0) return utf8Slice(this, 0, length)
  return slowToString.apply(this, arguments)
}

Buffer.prototype.equals = function equals (b) {
  if (!Buffer.isBuffer(b)) throw new TypeError('Argument must be a Buffer')
  if (this === b) return true
  return Buffer.compare(this, b) === 0
}

Buffer.prototype.inspect = function inspect () {
  var str = ''
  var max = exports.INSPECT_MAX_BYTES
  if (this.length > 0) {
    str = this.toString('hex', 0, max).match(/.{2}/g).join(' ')
    if (this.length > max) str += ' ... '
  }
  return '<Buffer ' + str + '>'
}

Buffer.prototype.compare = function compare (target, start, end, thisStart, thisEnd) {
  if (!Buffer.isBuffer(target)) {
    throw new TypeError('Argument must be a Buffer')
  }

  if (start === undefined) {
    start = 0
  }
  if (end === undefined) {
    end = target ? target.length : 0
  }
  if (thisStart === undefined) {
    thisStart = 0
  }
  if (thisEnd === undefined) {
    thisEnd = this.length
  }

  if (start < 0 || end > target.length || thisStart < 0 || thisEnd > this.length) {
    throw new RangeError('out of range index')
  }

  if (thisStart >= thisEnd && start >= end) {
    return 0
  }
  if (thisStart >= thisEnd) {
    return -1
  }
  if (start >= end) {
    return 1
  }

  start >>>= 0
  end >>>= 0
  thisStart >>>= 0
  thisEnd >>>= 0

  if (this === target) return 0

  var x = thisEnd - thisStart
  var y = end - start
  var len = Math.min(x, y)

  var thisCopy = this.slice(thisStart, thisEnd)
  var targetCopy = target.slice(start, end)

  for (var i = 0; i < len; ++i) {
    if (thisCopy[i] !== targetCopy[i]) {
      x = thisCopy[i]
      y = targetCopy[i]
      break
    }
  }

  if (x < y) return -1
  if (y < x) return 1
  return 0
}

// Finds either the first index of `val` in `buffer` at offset >= `byteOffset`,
// OR the last index of `val` in `buffer` at offset <= `byteOffset`.
//
// Arguments:
// - buffer - a Buffer to search
// - val - a string, Buffer, or number
// - byteOffset - an index into `buffer`; will be clamped to an int32
// - encoding - an optional encoding, relevant is val is a string
// - dir - true for indexOf, false for lastIndexOf
function bidirectionalIndexOf (buffer, val, byteOffset, encoding, dir) {
  // Empty buffer means no match
  if (buffer.length === 0) return -1

  // Normalize byteOffset
  if (typeof byteOffset === 'string') {
    encoding = byteOffset
    byteOffset = 0
  } else if (byteOffset > 0x7fffffff) {
    byteOffset = 0x7fffffff
  } else if (byteOffset < -0x80000000) {
    byteOffset = -0x80000000
  }
  byteOffset = +byteOffset  // Coerce to Number.
  if (isNaN(byteOffset)) {
    // byteOffset: it it's undefined, null, NaN, "foo", etc, search whole buffer
    byteOffset = dir ? 0 : (buffer.length - 1)
  }

  // Normalize byteOffset: negative offsets start from the end of the buffer
  if (byteOffset < 0) byteOffset = buffer.length + byteOffset
  if (byteOffset >= buffer.length) {
    if (dir) return -1
    else byteOffset = buffer.length - 1
  } else if (byteOffset < 0) {
    if (dir) byteOffset = 0
    else return -1
  }

  // Normalize val
  if (typeof val === 'string') {
    val = Buffer.from(val, encoding)
  }

  // Finally, search either indexOf (if dir is true) or lastIndexOf
  if (Buffer.isBuffer(val)) {
    // Special case: looking for empty string/buffer always fails
    if (val.length === 0) {
      return -1
    }
    return arrayIndexOf(buffer, val, byteOffset, encoding, dir)
  } else if (typeof val === 'number') {
    val = val & 0xFF // Search for a byte value [0-255]
    if (Buffer.TYPED_ARRAY_SUPPORT &&
        typeof Uint8Array.prototype.indexOf === 'function') {
      if (dir) {
        return Uint8Array.prototype.indexOf.call(buffer, val, byteOffset)
      } else {
        return Uint8Array.prototype.lastIndexOf.call(buffer, val, byteOffset)
      }
    }
    return arrayIndexOf(buffer, [ val ], byteOffset, encoding, dir)
  }

  throw new TypeError('val must be string, number or Buffer')
}

function arrayIndexOf (arr, val, byteOffset, encoding, dir) {
  var indexSize = 1
  var arrLength = arr.length
  var valLength = val.length

  if (encoding !== undefined) {
    encoding = String(encoding).toLowerCase()
    if (encoding === 'ucs2' || encoding === 'ucs-2' ||
        encoding === 'utf16le' || encoding === 'utf-16le') {
      if (arr.length < 2 || val.length < 2) {
        return -1
      }
      indexSize = 2
      arrLength /= 2
      valLength /= 2
      byteOffset /= 2
    }
  }

  function read (buf, i) {
    if (indexSize === 1) {
      return buf[i]
    } else {
      return buf.readUInt16BE(i * indexSize)
    }
  }

  var i
  if (dir) {
    var foundIndex = -1
    for (i = byteOffset; i < arrLength; i++) {
      if (read(arr, i) === read(val, foundIndex === -1 ? 0 : i - foundIndex)) {
        if (foundIndex === -1) foundIndex = i
        if (i - foundIndex + 1 === valLength) return foundIndex * indexSize
      } else {
        if (foundIndex !== -1) i -= i - foundIndex
        foundIndex = -1
      }
    }
  } else {
    if (byteOffset + valLength > arrLength) byteOffset = arrLength - valLength
    for (i = byteOffset; i >= 0; i--) {
      var found = true
      for (var j = 0; j < valLength; j++) {
        if (read(arr, i + j) !== read(val, j)) {
          found = false
          break
        }
      }
      if (found) return i
    }
  }

  return -1
}

Buffer.prototype.includes = function includes (val, byteOffset, encoding) {
  return this.indexOf(val, byteOffset, encoding) !== -1
}

Buffer.prototype.indexOf = function indexOf (val, byteOffset, encoding) {
  return bidirectionalIndexOf(this, val, byteOffset, encoding, true)
}

Buffer.prototype.lastIndexOf = function lastIndexOf (val, byteOffset, encoding) {
  return bidirectionalIndexOf(this, val, byteOffset, encoding, false)
}

function hexWrite (buf, string, offset, length) {
  offset = Number(offset) || 0
  var remaining = buf.length - offset
  if (!length) {
    length = remaining
  } else {
    length = Number(length)
    if (length > remaining) {
      length = remaining
    }
  }

  // must be an even number of digits
  var strLen = string.length
  if (strLen % 2 !== 0) throw new TypeError('Invalid hex string')

  if (length > strLen / 2) {
    length = strLen / 2
  }
  for (var i = 0; i < length; ++i) {
    var parsed = parseInt(string.substr(i * 2, 2), 16)
    if (isNaN(parsed)) return i
    buf[offset + i] = parsed
  }
  return i
}

function utf8Write (buf, string, offset, length) {
  return blitBuffer(utf8ToBytes(string, buf.length - offset), buf, offset, length)
}

function asciiWrite (buf, string, offset, length) {
  return blitBuffer(asciiToBytes(string), buf, offset, length)
}

function latin1Write (buf, string, offset, length) {
  return asciiWrite(buf, string, offset, length)
}

function base64Write (buf, string, offset, length) {
  return blitBuffer(base64ToBytes(string), buf, offset, length)
}

function ucs2Write (buf, string, offset, length) {
  return blitBuffer(utf16leToBytes(string, buf.length - offset), buf, offset, length)
}

Buffer.prototype.write = function write (string, offset, length, encoding) {
  // Buffer#write(string)
  if (offset === undefined) {
    encoding = 'utf8'
    length = this.length
    offset = 0
  // Buffer#write(string, encoding)
  } else if (length === undefined && typeof offset === 'string') {
    encoding = offset
    length = this.length
    offset = 0
  // Buffer#write(string, offset[, length][, encoding])
  } else if (isFinite(offset)) {
    offset = offset | 0
    if (isFinite(length)) {
      length = length | 0
      if (encoding === undefined) encoding = 'utf8'
    } else {
      encoding = length
      length = undefined
    }
  // legacy write(string, encoding, offset, length) - remove in v0.13
  } else {
    throw new Error(
      'Buffer.write(string, encoding, offset[, length]) is no longer supported'
    )
  }

  var remaining = this.length - offset
  if (length === undefined || length > remaining) length = remaining

  if ((string.length > 0 && (length < 0 || offset < 0)) || offset > this.length) {
    throw new RangeError('Attempt to write outside buffer bounds')
  }

  if (!encoding) encoding = 'utf8'

  var loweredCase = false
  for (;;) {
    switch (encoding) {
      case 'hex':
        return hexWrite(this, string, offset, length)

      case 'utf8':
      case 'utf-8':
        return utf8Write(this, string, offset, length)

      case 'ascii':
        return asciiWrite(this, string, offset, length)

      case 'latin1':
      case 'binary':
        return latin1Write(this, string, offset, length)

      case 'base64':
        // Warning: maxLength not taken into account in base64Write
        return base64Write(this, string, offset, length)

      case 'ucs2':
      case 'ucs-2':
      case 'utf16le':
      case 'utf-16le':
        return ucs2Write(this, string, offset, length)

      default:
        if (loweredCase) throw new TypeError('Unknown encoding: ' + encoding)
        encoding = ('' + encoding).toLowerCase()
        loweredCase = true
    }
  }
}

Buffer.prototype.toJSON = function toJSON () {
  return {
    type: 'Buffer',
    data: Array.prototype.slice.call(this._arr || this, 0)
  }
}

function base64Slice (buf, start, end) {
  if (start === 0 && end === buf.length) {
    return base64.fromByteArray(buf)
  } else {
    return base64.fromByteArray(buf.slice(start, end))
  }
}

function utf8Slice (buf, start, end) {
  end = Math.min(buf.length, end)
  var res = []

  var i = start
  while (i < end) {
    var firstByte = buf[i]
    var codePoint = null
    var bytesPerSequence = (firstByte > 0xEF) ? 4
      : (firstByte > 0xDF) ? 3
      : (firstByte > 0xBF) ? 2
      : 1

    if (i + bytesPerSequence <= end) {
      var secondByte, thirdByte, fourthByte, tempCodePoint

      switch (bytesPerSequence) {
        case 1:
          if (firstByte < 0x80) {
            codePoint = firstByte
          }
          break
        case 2:
          secondByte = buf[i + 1]
          if ((secondByte & 0xC0) === 0x80) {
            tempCodePoint = (firstByte & 0x1F) << 0x6 | (secondByte & 0x3F)
            if (tempCodePoint > 0x7F) {
              codePoint = tempCodePoint
            }
          }
          break
        case 3:
          secondByte = buf[i + 1]
          thirdByte = buf[i + 2]
          if ((secondByte & 0xC0) === 0x80 && (thirdByte & 0xC0) === 0x80) {
            tempCodePoint = (firstByte & 0xF) << 0xC | (secondByte & 0x3F) << 0x6 | (thirdByte & 0x3F)
            if (tempCodePoint > 0x7FF && (tempCodePoint < 0xD800 || tempCodePoint > 0xDFFF)) {
              codePoint = tempCodePoint
            }
          }
          break
        case 4:
          secondByte = buf[i + 1]
          thirdByte = buf[i + 2]
          fourthByte = buf[i + 3]
          if ((secondByte & 0xC0) === 0x80 && (thirdByte & 0xC0) === 0x80 && (fourthByte & 0xC0) === 0x80) {
            tempCodePoint = (firstByte & 0xF) << 0x12 | (secondByte & 0x3F) << 0xC | (thirdByte & 0x3F) << 0x6 | (fourthByte & 0x3F)
            if (tempCodePoint > 0xFFFF && tempCodePoint < 0x110000) {
              codePoint = tempCodePoint
            }
          }
      }
    }

    if (codePoint === null) {
      // we did not generate a valid codePoint so insert a
      // replacement char (U+FFFD) and advance only 1 byte
      codePoint = 0xFFFD
      bytesPerSequence = 1
    } else if (codePoint > 0xFFFF) {
      // encode to utf16 (surrogate pair dance)
      codePoint -= 0x10000
      res.push(codePoint >>> 10 & 0x3FF | 0xD800)
      codePoint = 0xDC00 | codePoint & 0x3FF
    }

    res.push(codePoint)
    i += bytesPerSequence
  }

  return decodeCodePointsArray(res)
}

// Based on http://stackoverflow.com/a/22747272/680742, the browser with
// the lowest limit is Chrome, with 0x10000 args.
// We go 1 magnitude less, for safety
var MAX_ARGUMENTS_LENGTH = 0x1000

function decodeCodePointsArray (codePoints) {
  var len = codePoints.length
  if (len <= MAX_ARGUMENTS_LENGTH) {
    return String.fromCharCode.apply(String, codePoints) // avoid extra slice()
  }

  // Decode in chunks to avoid "call stack size exceeded".
  var res = ''
  var i = 0
  while (i < len) {
    res += String.fromCharCode.apply(
      String,
      codePoints.slice(i, i += MAX_ARGUMENTS_LENGTH)
    )
  }
  return res
}

function asciiSlice (buf, start, end) {
  var ret = ''
  end = Math.min(buf.length, end)

  for (var i = start; i < end; ++i) {
    ret += String.fromCharCode(buf[i] & 0x7F)
  }
  return ret
}

function latin1Slice (buf, start, end) {
  var ret = ''
  end = Math.min(buf.length, end)

  for (var i = start; i < end; ++i) {
    ret += String.fromCharCode(buf[i])
  }
  return ret
}

function hexSlice (buf, start, end) {
  var len = buf.length

  if (!start || start < 0) start = 0
  if (!end || end < 0 || end > len) end = len

  var out = ''
  for (var i = start; i < end; ++i) {
    out += toHex(buf[i])
  }
  return out
}

function utf16leSlice (buf, start, end) {
  var bytes = buf.slice(start, end)
  var res = ''
  for (var i = 0; i < bytes.length; i += 2) {
    res += String.fromCharCode(bytes[i] + bytes[i + 1] * 256)
  }
  return res
}

Buffer.prototype.slice = function slice (start, end) {
  var len = this.length
  start = ~~start
  end = end === undefined ? len : ~~end

  if (start < 0) {
    start += len
    if (start < 0) start = 0
  } else if (start > len) {
    start = len
  }

  if (end < 0) {
    end += len
    if (end < 0) end = 0
  } else if (end > len) {
    end = len
  }

  if (end < start) end = start

  var newBuf
  if (Buffer.TYPED_ARRAY_SUPPORT) {
    newBuf = this.subarray(start, end)
    newBuf.__proto__ = Buffer.prototype
  } else {
    var sliceLen = end - start
    newBuf = new Buffer(sliceLen, undefined)
    for (var i = 0; i < sliceLen; ++i) {
      newBuf[i] = this[i + start]
    }
  }

  return newBuf
}

/*
 * Need to make sure that buffer isn't trying to write out of bounds.
 */
function checkOffset (offset, ext, length) {
  if ((offset % 1) !== 0 || offset < 0) throw new RangeError('offset is not uint')
  if (offset + ext > length) throw new RangeError('Trying to access beyond buffer length')
}

Buffer.prototype.readUIntLE = function readUIntLE (offset, byteLength, noAssert) {
  offset = offset | 0
  byteLength = byteLength | 0
  if (!noAssert) checkOffset(offset, byteLength, this.length)

  var val = this[offset]
  var mul = 1
  var i = 0
  while (++i < byteLength && (mul *= 0x100)) {
    val += this[offset + i] * mul
  }

  return val
}

Buffer.prototype.readUIntBE = function readUIntBE (offset, byteLength, noAssert) {
  offset = offset | 0
  byteLength = byteLength | 0
  if (!noAssert) {
    checkOffset(offset, byteLength, this.length)
  }

  var val = this[offset + --byteLength]
  var mul = 1
  while (byteLength > 0 && (mul *= 0x100)) {
    val += this[offset + --byteLength] * mul
  }

  return val
}

Buffer.prototype.readUInt8 = function readUInt8 (offset, noAssert) {
  if (!noAssert) checkOffset(offset, 1, this.length)
  return this[offset]
}

Buffer.prototype.readUInt16LE = function readUInt16LE (offset, noAssert) {
  if (!noAssert) checkOffset(offset, 2, this.length)
  return this[offset] | (this[offset + 1] << 8)
}

Buffer.prototype.readUInt16BE = function readUInt16BE (offset, noAssert) {
  if (!noAssert) checkOffset(offset, 2, this.length)
  return (this[offset] << 8) | this[offset + 1]
}

Buffer.prototype.readUInt32LE = function readUInt32LE (offset, noAssert) {
  if (!noAssert) checkOffset(offset, 4, this.length)

  return ((this[offset]) |
      (this[offset + 1] << 8) |
      (this[offset + 2] << 16)) +
      (this[offset + 3] * 0x1000000)
}

Buffer.prototype.readUInt32BE = function readUInt32BE (offset, noAssert) {
  if (!noAssert) checkOffset(offset, 4, this.length)

  return (this[offset] * 0x1000000) +
    ((this[offset + 1] << 16) |
    (this[offset + 2] << 8) |
    this[offset + 3])
}

Buffer.prototype.readIntLE = function readIntLE (offset, byteLength, noAssert) {
  offset = offset | 0
  byteLength = byteLength | 0
  if (!noAssert) checkOffset(offset, byteLength, this.length)

  var val = this[offset]
  var mul = 1
  var i = 0
  while (++i < byteLength && (mul *= 0x100)) {
    val += this[offset + i] * mul
  }
  mul *= 0x80

  if (val >= mul) val -= Math.pow(2, 8 * byteLength)

  return val
}

Buffer.prototype.readIntBE = function readIntBE (offset, byteLength, noAssert) {
  offset = offset | 0
  byteLength = byteLength | 0
  if (!noAssert) checkOffset(offset, byteLength, this.length)

  var i = byteLength
  var mul = 1
  var val = this[offset + --i]
  while (i > 0 && (mul *= 0x100)) {
    val += this[offset + --i] * mul
  }
  mul *= 0x80

  if (val >= mul) val -= Math.pow(2, 8 * byteLength)

  return val
}

Buffer.prototype.readInt8 = function readInt8 (offset, noAssert) {
  if (!noAssert) checkOffset(offset, 1, this.length)
  if (!(this[offset] & 0x80)) return (this[offset])
  return ((0xff - this[offset] + 1) * -1)
}

Buffer.prototype.readInt16LE = function readInt16LE (offset, noAssert) {
  if (!noAssert) checkOffset(offset, 2, this.length)
  var val = this[offset] | (this[offset + 1] << 8)
  return (val & 0x8000) ? val | 0xFFFF0000 : val
}

Buffer.prototype.readInt16BE = function readInt16BE (offset, noAssert) {
  if (!noAssert) checkOffset(offset, 2, this.length)
  var val = this[offset + 1] | (this[offset] << 8)
  return (val & 0x8000) ? val | 0xFFFF0000 : val
}

Buffer.prototype.readInt32LE = function readInt32LE (offset, noAssert) {
  if (!noAssert) checkOffset(offset, 4, this.length)

  return (this[offset]) |
    (this[offset + 1] << 8) |
    (this[offset + 2] << 16) |
    (this[offset + 3] << 24)
}

Buffer.prototype.readInt32BE = function readInt32BE (offset, noAssert) {
  if (!noAssert) checkOffset(offset, 4, this.length)

  return (this[offset] << 24) |
    (this[offset + 1] << 16) |
    (this[offset + 2] << 8) |
    (this[offset + 3])
}

Buffer.prototype.readFloatLE = function readFloatLE (offset, noAssert) {
  if (!noAssert) checkOffset(offset, 4, this.length)
  return ieee754.read(this, offset, true, 23, 4)
}

Buffer.prototype.readFloatBE = function readFloatBE (offset, noAssert) {
  if (!noAssert) checkOffset(offset, 4, this.length)
  return ieee754.read(this, offset, false, 23, 4)
}

Buffer.prototype.readDoubleLE = function readDoubleLE (offset, noAssert) {
  if (!noAssert) checkOffset(offset, 8, this.length)
  return ieee754.read(this, offset, true, 52, 8)
}

Buffer.prototype.readDoubleBE = function readDoubleBE (offset, noAssert) {
  if (!noAssert) checkOffset(offset, 8, this.length)
  return ieee754.read(this, offset, false, 52, 8)
}

function checkInt (buf, value, offset, ext, max, min) {
  if (!Buffer.isBuffer(buf)) throw new TypeError('"buffer" argument must be a Buffer instance')
  if (value > max || value < min) throw new RangeError('"value" argument is out of bounds')
  if (offset + ext > buf.length) throw new RangeError('Index out of range')
}

Buffer.prototype.writeUIntLE = function writeUIntLE (value, offset, byteLength, noAssert) {
  value = +value
  offset = offset | 0
  byteLength = byteLength | 0
  if (!noAssert) {
    var maxBytes = Math.pow(2, 8 * byteLength) - 1
    checkInt(this, value, offset, byteLength, maxBytes, 0)
  }

  var mul = 1
  var i = 0
  this[offset] = value & 0xFF
  while (++i < byteLength && (mul *= 0x100)) {
    this[offset + i] = (value / mul) & 0xFF
  }

  return offset + byteLength
}

Buffer.prototype.writeUIntBE = function writeUIntBE (value, offset, byteLength, noAssert) {
  value = +value
  offset = offset | 0
  byteLength = byteLength | 0
  if (!noAssert) {
    var maxBytes = Math.pow(2, 8 * byteLength) - 1
    checkInt(this, value, offset, byteLength, maxBytes, 0)
  }

  var i = byteLength - 1
  var mul = 1
  this[offset + i] = value & 0xFF
  while (--i >= 0 && (mul *= 0x100)) {
    this[offset + i] = (value / mul) & 0xFF
  }

  return offset + byteLength
}

Buffer.prototype.writeUInt8 = function writeUInt8 (value, offset, noAssert) {
  value = +value
  offset = offset | 0
  if (!noAssert) checkInt(this, value, offset, 1, 0xff, 0)
  if (!Buffer.TYPED_ARRAY_SUPPORT) value = Math.floor(value)
  this[offset] = (value & 0xff)
  return offset + 1
}

function objectWriteUInt16 (buf, value, offset, littleEndian) {
  if (value < 0) value = 0xffff + value + 1
  for (var i = 0, j = Math.min(buf.length - offset, 2); i < j; ++i) {
    buf[offset + i] = (value & (0xff << (8 * (littleEndian ? i : 1 - i)))) >>>
      (littleEndian ? i : 1 - i) * 8
  }
}

Buffer.prototype.writeUInt16LE = function writeUInt16LE (value, offset, noAssert) {
  value = +value
  offset = offset | 0
  if (!noAssert) checkInt(this, value, offset, 2, 0xffff, 0)
  if (Buffer.TYPED_ARRAY_SUPPORT) {
    this[offset] = (value & 0xff)
    this[offset + 1] = (value >>> 8)
  } else {
    objectWriteUInt16(this, value, offset, true)
  }
  return offset + 2
}

Buffer.prototype.writeUInt16BE = function writeUInt16BE (value, offset, noAssert) {
  value = +value
  offset = offset | 0
  if (!noAssert) checkInt(this, value, offset, 2, 0xffff, 0)
  if (Buffer.TYPED_ARRAY_SUPPORT) {
    this[offset] = (value >>> 8)
    this[offset + 1] = (value & 0xff)
  } else {
    objectWriteUInt16(this, value, offset, false)
  }
  return offset + 2
}

function objectWriteUInt32 (buf, value, offset, littleEndian) {
  if (value < 0) value = 0xffffffff + value + 1
  for (var i = 0, j = Math.min(buf.length - offset, 4); i < j; ++i) {
    buf[offset + i] = (value >>> (littleEndian ? i : 3 - i) * 8) & 0xff
  }
}

Buffer.prototype.writeUInt32LE = function writeUInt32LE (value, offset, noAssert) {
  value = +value
  offset = offset | 0
  if (!noAssert) checkInt(this, value, offset, 4, 0xffffffff, 0)
  if (Buffer.TYPED_ARRAY_SUPPORT) {
    this[offset + 3] = (value >>> 24)
    this[offset + 2] = (value >>> 16)
    this[offset + 1] = (value >>> 8)
    this[offset] = (value & 0xff)
  } else {
    objectWriteUInt32(this, value, offset, true)
  }
  return offset + 4
}

Buffer.prototype.writeUInt32BE = function writeUInt32BE (value, offset, noAssert) {
  value = +value
  offset = offset | 0
  if (!noAssert) checkInt(this, value, offset, 4, 0xffffffff, 0)
  if (Buffer.TYPED_ARRAY_SUPPORT) {
    this[offset] = (value >>> 24)
    this[offset + 1] = (value >>> 16)
    this[offset + 2] = (value >>> 8)
    this[offset + 3] = (value & 0xff)
  } else {
    objectWriteUInt32(this, value, offset, false)
  }
  return offset + 4
}

Buffer.prototype.writeIntLE = function writeIntLE (value, offset, byteLength, noAssert) {
  value = +value
  offset = offset | 0
  if (!noAssert) {
    var limit = Math.pow(2, 8 * byteLength - 1)

    checkInt(this, value, offset, byteLength, limit - 1, -limit)
  }

  var i = 0
  var mul = 1
  var sub = 0
  this[offset] = value & 0xFF
  while (++i < byteLength && (mul *= 0x100)) {
    if (value < 0 && sub === 0 && this[offset + i - 1] !== 0) {
      sub = 1
    }
    this[offset + i] = ((value / mul) >> 0) - sub & 0xFF
  }

  return offset + byteLength
}

Buffer.prototype.writeIntBE = function writeIntBE (value, offset, byteLength, noAssert) {
  value = +value
  offset = offset | 0
  if (!noAssert) {
    var limit = Math.pow(2, 8 * byteLength - 1)

    checkInt(this, value, offset, byteLength, limit - 1, -limit)
  }

  var i = byteLength - 1
  var mul = 1
  var sub = 0
  this[offset + i] = value & 0xFF
  while (--i >= 0 && (mul *= 0x100)) {
    if (value < 0 && sub === 0 && this[offset + i + 1] !== 0) {
      sub = 1
    }
    this[offset + i] = ((value / mul) >> 0) - sub & 0xFF
  }

  return offset + byteLength
}

Buffer.prototype.writeInt8 = function writeInt8 (value, offset, noAssert) {
  value = +value
  offset = offset | 0
  if (!noAssert) checkInt(this, value, offset, 1, 0x7f, -0x80)
  if (!Buffer.TYPED_ARRAY_SUPPORT) value = Math.floor(value)
  if (value < 0) value = 0xff + value + 1
  this[offset] = (value & 0xff)
  return offset + 1
}

Buffer.prototype.writeInt16LE = function writeInt16LE (value, offset, noAssert) {
  value = +value
  offset = offset | 0
  if (!noAssert) checkInt(this, value, offset, 2, 0x7fff, -0x8000)
  if (Buffer.TYPED_ARRAY_SUPPORT) {
    this[offset] = (value & 0xff)
    this[offset + 1] = (value >>> 8)
  } else {
    objectWriteUInt16(this, value, offset, true)
  }
  return offset + 2
}

Buffer.prototype.writeInt16BE = function writeInt16BE (value, offset, noAssert) {
  value = +value
  offset = offset | 0
  if (!noAssert) checkInt(this, value, offset, 2, 0x7fff, -0x8000)
  if (Buffer.TYPED_ARRAY_SUPPORT) {
    this[offset] = (value >>> 8)
    this[offset + 1] = (value & 0xff)
  } else {
    objectWriteUInt16(this, value, offset, false)
  }
  return offset + 2
}

Buffer.prototype.writeInt32LE = function writeInt32LE (value, offset, noAssert) {
  value = +value
  offset = offset | 0
  if (!noAssert) checkInt(this, value, offset, 4, 0x7fffffff, -0x80000000)
  if (Buffer.TYPED_ARRAY_SUPPORT) {
    this[offset] = (value & 0xff)
    this[offset + 1] = (value >>> 8)
    this[offset + 2] = (value >>> 16)
    this[offset + 3] = (value >>> 24)
  } else {
    objectWriteUInt32(this, value, offset, true)
  }
  return offset + 4
}

Buffer.prototype.writeInt32BE = function writeInt32BE (value, offset, noAssert) {
  value = +value
  offset = offset | 0
  if (!noAssert) checkInt(this, value, offset, 4, 0x7fffffff, -0x80000000)
  if (value < 0) value = 0xffffffff + value + 1
  if (Buffer.TYPED_ARRAY_SUPPORT) {
    this[offset] = (value >>> 24)
    this[offset + 1] = (value >>> 16)
    this[offset + 2] = (value >>> 8)
    this[offset + 3] = (value & 0xff)
  } else {
    objectWriteUInt32(this, value, offset, false)
  }
  return offset + 4
}

function checkIEEE754 (buf, value, offset, ext, max, min) {
  if (offset + ext > buf.length) throw new RangeError('Index out of range')
  if (offset < 0) throw new RangeError('Index out of range')
}

function writeFloat (buf, value, offset, littleEndian, noAssert) {
  if (!noAssert) {
    checkIEEE754(buf, value, offset, 4, 3.4028234663852886e+38, -3.4028234663852886e+38)
  }
  ieee754.write(buf, value, offset, littleEndian, 23, 4)
  return offset + 4
}

Buffer.prototype.writeFloatLE = function writeFloatLE (value, offset, noAssert) {
  return writeFloat(this, value, offset, true, noAssert)
}

Buffer.prototype.writeFloatBE = function writeFloatBE (value, offset, noAssert) {
  return writeFloat(this, value, offset, false, noAssert)
}

function writeDouble (buf, value, offset, littleEndian, noAssert) {
  if (!noAssert) {
    checkIEEE754(buf, value, offset, 8, 1.7976931348623157E+308, -1.7976931348623157E+308)
  }
  ieee754.write(buf, value, offset, littleEndian, 52, 8)
  return offset + 8
}

Buffer.prototype.writeDoubleLE = function writeDoubleLE (value, offset, noAssert) {
  return writeDouble(this, value, offset, true, noAssert)
}

Buffer.prototype.writeDoubleBE = function writeDoubleBE (value, offset, noAssert) {
  return writeDouble(this, value, offset, false, noAssert)
}

// copy(targetBuffer, targetStart=0, sourceStart=0, sourceEnd=buffer.length)
Buffer.prototype.copy = function copy (target, targetStart, start, end) {
  if (!start) start = 0
  if (!end && end !== 0) end = this.length
  if (targetStart >= target.length) targetStart = target.length
  if (!targetStart) targetStart = 0
  if (end > 0 && end < start) end = start

  // Copy 0 bytes; we're done
  if (end === start) return 0
  if (target.length === 0 || this.length === 0) return 0

  // Fatal error conditions
  if (targetStart < 0) {
    throw new RangeError('targetStart out of bounds')
  }
  if (start < 0 || start >= this.length) throw new RangeError('sourceStart out of bounds')
  if (end < 0) throw new RangeError('sourceEnd out of bounds')

  // Are we oob?
  if (end > this.length) end = this.length
  if (target.length - targetStart < end - start) {
    end = target.length - targetStart + start
  }

  var len = end - start
  var i

  if (this === target && start < targetStart && targetStart < end) {
    // descending copy from end
    for (i = len - 1; i >= 0; --i) {
      target[i + targetStart] = this[i + start]
    }
  } else if (len < 1000 || !Buffer.TYPED_ARRAY_SUPPORT) {
    // ascending copy from start
    for (i = 0; i < len; ++i) {
      target[i + targetStart] = this[i + start]
    }
  } else {
    Uint8Array.prototype.set.call(
      target,
      this.subarray(start, start + len),
      targetStart
    )
  }

  return len
}

// Usage:
//    buffer.fill(number[, offset[, end]])
//    buffer.fill(buffer[, offset[, end]])
//    buffer.fill(string[, offset[, end]][, encoding])
Buffer.prototype.fill = function fill (val, start, end, encoding) {
  // Handle string cases:
  if (typeof val === 'string') {
    if (typeof start === 'string') {
      encoding = start
      start = 0
      end = this.length
    } else if (typeof end === 'string') {
      encoding = end
      end = this.length
    }
    if (val.length === 1) {
      var code = val.charCodeAt(0)
      if (code < 256) {
        val = code
      }
    }
    if (encoding !== undefined && typeof encoding !== 'string') {
      throw new TypeError('encoding must be a string')
    }
    if (typeof encoding === 'string' && !Buffer.isEncoding(encoding)) {
      throw new TypeError('Unknown encoding: ' + encoding)
    }
  } else if (typeof val === 'number') {
    val = val & 255
  }

  // Invalid ranges are not set to a default, so can range check early.
  if (start < 0 || this.length < start || this.length < end) {
    throw new RangeError('Out of range index')
  }

  if (end <= start) {
    return this
  }

  start = start >>> 0
  end = end === undefined ? this.length : end >>> 0

  if (!val) val = 0

  var i
  if (typeof val === 'number') {
    for (i = start; i < end; ++i) {
      this[i] = val
    }
  } else {
    var bytes = Buffer.isBuffer(val)
      ? val
      : utf8ToBytes(new Buffer(val, encoding).toString())
    var len = bytes.length
    for (i = 0; i < end - start; ++i) {
      this[i + start] = bytes[i % len]
    }
  }

  return this
}

// HELPER FUNCTIONS
// ================

var INVALID_BASE64_RE = /[^+\/0-9A-Za-z-_]/g

function base64clean (str) {
  // Node strips out invalid characters like \n and \t from the string, base64-js does not
  str = stringtrim(str).replace(INVALID_BASE64_RE, '')
  // Node converts strings with length < 2 to ''
  if (str.length < 2) return ''
  // Node allows for non-padded base64 strings (missing trailing ===), base64-js does not
  while (str.length % 4 !== 0) {
    str = str + '='
  }
  return str
}

function stringtrim (str) {
  if (str.trim) return str.trim()
  return str.replace(/^\s+|\s+$/g, '')
}

function toHex (n) {
  if (n < 16) return '0' + n.toString(16)
  return n.toString(16)
}

function utf8ToBytes (string, units) {
  units = units || Infinity
  var codePoint
  var length = string.length
  var leadSurrogate = null
  var bytes = []

  for (var i = 0; i < length; ++i) {
    codePoint = string.charCodeAt(i)

    // is surrogate component
    if (codePoint > 0xD7FF && codePoint < 0xE000) {
      // last char was a lead
      if (!leadSurrogate) {
        // no lead yet
        if (codePoint > 0xDBFF) {
          // unexpected trail
          if ((units -= 3) > -1) bytes.push(0xEF, 0xBF, 0xBD)
          continue
        } else if (i + 1 === length) {
          // unpaired lead
          if ((units -= 3) > -1) bytes.push(0xEF, 0xBF, 0xBD)
          continue
        }

        // valid lead
        leadSurrogate = codePoint

        continue
      }

      // 2 leads in a row
      if (codePoint < 0xDC00) {
        if ((units -= 3) > -1) bytes.push(0xEF, 0xBF, 0xBD)
        leadSurrogate = codePoint
        continue
      }

      // valid surrogate pair
      codePoint = (leadSurrogate - 0xD800 << 10 | codePoint - 0xDC00) + 0x10000
    } else if (leadSurrogate) {
      // valid bmp char, but last char was a lead
      if ((units -= 3) > -1) bytes.push(0xEF, 0xBF, 0xBD)
    }

    leadSurrogate = null

    // encode utf8
    if (codePoint < 0x80) {
      if ((units -= 1) < 0) break
      bytes.push(codePoint)
    } else if (codePoint < 0x800) {
      if ((units -= 2) < 0) break
      bytes.push(
        codePoint >> 0x6 | 0xC0,
        codePoint & 0x3F | 0x80
      )
    } else if (codePoint < 0x10000) {
      if ((units -= 3) < 0) break
      bytes.push(
        codePoint >> 0xC | 0xE0,
        codePoint >> 0x6 & 0x3F | 0x80,
        codePoint & 0x3F | 0x80
      )
    } else if (codePoint < 0x110000) {
      if ((units -= 4) < 0) break
      bytes.push(
        codePoint >> 0x12 | 0xF0,
        codePoint >> 0xC & 0x3F | 0x80,
        codePoint >> 0x6 & 0x3F | 0x80,
        codePoint & 0x3F | 0x80
      )
    } else {
      throw new Error('Invalid code point')
    }
  }

  return bytes
}

function asciiToBytes (str) {
  var byteArray = []
  for (var i = 0; i < str.length; ++i) {
    // Node's code seems to be doing this and not & 0x7F..
    byteArray.push(str.charCodeAt(i) & 0xFF)
  }
  return byteArray
}

function utf16leToBytes (str, units) {
  var c, hi, lo
  var byteArray = []
  for (var i = 0; i < str.length; ++i) {
    if ((units -= 2) < 0) break

    c = str.charCodeAt(i)
    hi = c >> 8
    lo = c % 256
    byteArray.push(lo)
    byteArray.push(hi)
  }

  return byteArray
}

function base64ToBytes (str) {
  return base64.toByteArray(base64clean(str))
}

function blitBuffer (src, dst, offset, length) {
  for (var i = 0; i < length; ++i) {
    if ((i + offset >= dst.length) || (i >= src.length)) break
    dst[i + offset] = src[i]
  }
  return i
}

function isnan (val) {
  return val !== val // eslint-disable-line no-self-compare
}

/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__(22)))

/***/ }),

/***/ 7:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__assets_utils__ = __webpack_require__(2);
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//


/* harmony default export */ __webpack_exports__["default"] = ({
    props: {
        title: { default: "navbar" },
        complete: { default: '' },
        showComplete: { default: true },
        border: { default: true }
    },
    methods: {
        classHeader: function () {
            let dc = __WEBPACK_IMPORTED_MODULE_0__assets_utils__["a" /* default */].device();

            return dc;
        },
        goback: function (e) {
            this.$emit('goback');
        },
        goComplete: function (e) {
            this.$emit('goComplete');
        }
    }
});

/***/ }),

/***/ 730:
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(0)();
// imports


// module
exports.push([module.i, "\n.contentLimit{\n    width:450px;\n    lines:2;\n    text-overflow: ellipsis;\n    line-height:40px;\n}\n.black{\n    color: #444;\n}\n.whiteColor{\n    background-color: #fff;\n}\n.infoText{\n    font-size: 32px;color: #444;\n    width: 480px;\n    lines:1;\n    text-overflow: ellipsis;\n}\n.commentsText{\n    font-size: 32px;color: #444;\n    width: 480px;\n    text-overflow: ellipsis;\n    margin-top: 10px;\n    margin-bottom: 10px;\n}\n.nameColor{\n    color: steelblue;\n}\n.userInfo{\n    margin-left: 20px;\n    height: 120px;\n    justify-content: space-between;\n}\n.commentsInfo{\n    margin-left: 20px;\n    justify-content: space-between;\n}\n.coverImg{\n    height: 110px;\n    width: 110px;\n    border-radius: 10px;\n}\n.headImg{\n    height: 90px;\n    width: 90px;\n    border-radius: 45px;\n}\n.lineBox{\n    flex-direction: row;\n    padding-right: 20px;\n    justify-content: space-between;\n    width: 725px;\n    margin-left: 25px;\n    background-color: #fff;\n}\n.lineBoxBorder{\n\n    border-color: gainsboro;\n    border-style: solid;\n    border-bottom-width:1px;\n    width: 725px;\n    margin-left: 25px;\n}\n.lineBoxHeight{\n    height: 150px;\n    align-items: center;\n}\n.bottomBtn{\n    width: 650px;\n    padding-top: 20px;\n    padding-bottom: 20px;\n    margin-top: 10px;\n    align-items: center;\n    border-color: gainsboro;\n    border-style: solid;\n    border-top-width:1px;\n}\n.contentLine{\n    margin-top: 10px;\n    margin-bottom: 10px;\n    flex-direction: row;\n}\n.fz45{\n    font-size: 38px;\n}\n.fz65{\n    font-size: 65px;\n    color: #444;\n}\n.fz28{\n}\n.fz30{\n    font-size: 30px;\n}\n.moneyBox{\n    padding-top: 0px;\n    padding-bottom: 25px;\n    align-items: center;\n    flex-direction: row;\n    justify-content: center;\n    border-color: #ccc;\n    border-style: solid;\n    border-bottom-width:1px;\n    margin-bottom: 10px;\n}\n.contentBox{\n    width:700px;\n    margin-left: 25px;\n    background-color: #fff;\n    padding-top: 25px;\n    padding-left: 25px;\n    padding-right: 25px;\n    border-radius: 10px;\n    border-color:gainsboro;\n    border-width: 1px;\n    border-style: solid;\n    margin-bottom: 20px;\n}\n.dateBox{\n    width: 750px;\n    align-items: center;\n    margin-top: 30px;\n    margin-bottom: 30px;\n}\n.dateText{\n    font-size: 24px;\n    padding-left: 30px;\n    padding-right: 30px;\n    padding-top: 5px;\n    padding-bottom: 5px;\n    color: #fff;\n    background-color: #ccc;\n    border-radius: 5px;\n}\n", ""]);

// exports


/***/ }),

/***/ 731:
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(0)();
// imports


// module
exports.push([module.i, "/**每个页面都必须的，墙纸**/\n.wrapper {\n  position: absolute;\n  top: 0;\n  left: 0;\n  right: 0;\n  bottom: 0;\n  width: 750px;\n  background-color: #eee;\n}\n/**默认标题字体**/\n.nav_title {\n  font-size: 38px;\n  color: #fff;\n  line-height: 38px;\n}\n.title {\n  font-size: 32px;\n  color: #000;\n}\n/**默认子标题字体**/\n.sub_title {\n  font-size: 30px;\n  color: #999;\n}\n.sub_date {\n  font-size: 26px;\n  color: #999;\n}\n.fz22 {\n  font-size: 22px;\n}\n.fz24 {\n  font-size: 24px;\n}\n.fz26 {\n  font-size: 26px;\n}\n.fz28 {\n  font-size: 28px;\n}\n.fz30 {\n  font-size: 30px;\n}\n.fz32 {\n  font-size: 32px;\n}\n.fz35 {\n  font-size: 35px;\n}\n.fz40 {\n  font-size: 40px;\n}\n.boder-bottom {\n  border-style: solid;\n  border-bottom-width: 1px;\n  border-color: #ccc;\n}\n.boder-top {\n  border-style: solid;\n  border-top-width: 1px;\n  border-color: #ccc;\n}\n.boder-right {\n  border-style: solid;\n  border-right-width: 1px;\n  border-color: #ccc;\n}\n.boder-left {\n  border-style: solid;\n  border-left-width: 1px;\n  border-color: #ccc;\n}\n.pl10 {\n  padding-left: 10px;\n}\n.pl5 {\n  padding-left: 5px;\n}\n.pt0 {\n  padding-top: 0px;\n}\n.pt10 {\n  padding-top: 10px;\n}\n.pt15 {\n  padding-top: 15px;\n}\n.pb0 {\n  padding-bottom: 0px;\n}\n.pb10 {\n  padding-bottom: 10px;\n}\n.pl20 {\n  padding-left: 20px;\n}\n.pt20 {\n  padding-top: 20px;\n}\n.pb15 {\n  padding-bottom: 15px;\n}\n.pb20 {\n  padding-bottom: 20px;\n}\n.pt25 {\n  padding-top: 25px;\n}\n.pt30 {\n  padding-top: 30px;\n}\n.pt40 {\n  padding-top: 40px;\n}\n.pb40 {\n  padding-bottom: 40px;\n}\n.pb30 {\n  padding-bottom: 30px;\n}\n.pb25 {\n  padding-bottom: 25px;\n}\n.pl25 {\n  padding-left: 25px;\n}\n.pl30 {\n  padding-left: 30px;\n}\n.pr5 {\n  padding-right: 5px;\n}\n.pr10 {\n  padding-right: 10px;\n}\n.pr20 {\n  padding-right: 20px;\n}\n.pr25 {\n  padding-right: 25px;\n}\n.pr30 {\n  padding-right: 30px;\n}\n.pl35 {\n  padding-left: 35px;\n}\n.pr35 {\n  padding-right: 35px;\n}\n.bgWhite {\n  background-color: #ffffff;\n}\n.textActive:active {\n  background-color: #ccc;\n}\n/**top 大小**/\n.mt0 {\n  margin-top: 0px;\n}\n.mt10 {\n  margin-top: 10px;\n}\n.mt15 {\n  margin-top: 15px;\n}\n.mt20 {\n  margin-top: 20px;\n}\n.mt30 {\n  margin-top: 30px;\n}\n.mt40 {\n  margin-top: 40px;\n}\n.mt50 {\n  margin-top: 50px;\n}\n/**bottom 大小**/\n.bt0 {\n  margin-bottom: 0px;\n}\n.bt5 {\n  margin-bottom: 5px;\n}\n.bt10 {\n  margin-bottom: 10px;\n}\n.bt15 {\n  margin-bottom: 15px;\n}\n.bt20 {\n  margin-bottom: 20px;\n}\n.bt30 {\n  margin-bottom: 30px;\n}\n.bt45 {\n  margin-bottom: 45px;\n}\n.bt50 {\n  margin-bottom: 50px;\n}\n.mr5 {\n  margin-right: 5px;\n}\n.mr10 {\n  margin-right: 10px;\n}\n.mr15 {\n  margin-right: 15px;\n}\n.mr20 {\n  margin-right: 20px;\n}\n.mr30 {\n  margin-right: 30px;\n}\n/**left 大小**/\n.ml5 {\n  margin-left: 5px;\n}\n.ml10 {\n  margin-left: 10px;\n}\n.ml20 {\n  margin-left: 20px;\n}\n.ml30 {\n  margin-left: 30px;\n}\n.header {\n  height: 136px;\n  padding-top: 44px;\n  flex-direction: row;\n  position: sticky;\n  background-color: #068F3D;\n}\n.baseNavBg {\n  background-color: #068F3D;\n}\n.baseNavColor {\n  color: #068F3D;\n}\n.nav {\n  width: 654px;\n  justify-content: space-between;\n  flex-direction: row;\n  height: 92px;\n  align-items: center;\n  margin-top: 0px;\n}\n.nav_back {\n  margin-top: 0px;\n  flex-direction: row;\n  width: 92px;\n  height: 92px;\n  align-items: center;\n  justify-content: center;\n}\n.corpusActive {\n  color: #068F3D;\n  border-color: #068F3D;\n  border-style: solid;\n  border-bottom-width: 4px;\n}\n.footer {\n  position: fixed;\n  bottom: 0px;\n  left: 0px;\n  right: 0px;\n  height: 100px;\n}\n.fill {\n  height: 500px;\n  width: 750px;\n  background-color: #eee;\n}\n/** 图标图像 **/\n.iconImg {\n  width: 60px;\n  height: 60px;\n  font-size: 60px;\n}\n/**cell 分组头**/\n.cell-header {\n  height: 70px;\n  flex-direction: row;\n  background-color: #ddd;\n  padding-left: 20px;\n}\n/**cell 行**/\n.cell-row {\n  min-height: 100px;\n  flex-direction: column;\n  background-color: #ffffff;\n  padding-left: 20px;\n  margin-top: 20px;\n}\n.cell-row-row {\n  min-height: 100px;\n  flex-direction: row;\n  justify-content: space-between;\n  background-color: #ffffff;\n  padding-left: 20px;\n  padding-right: 20px;\n  align-items: center;\n  margin-top: 20px;\n}\n.cell-line {\n  border-top-width: 1px;\n  border-top-color: #ccc;\n  border-top-style: solid;\n  border-bottom-width: 1px;\n  border-bottom-color: #ccc;\n  border-bottom-style: solid;\n}\n.borderTop {\n  border-top-width: 1px;\n  border-top-color: #ccc;\n  border-top-style: solid;\n}\n.borderBottom {\n  border-bottom-width: 1px;\n  border-bottom-color: #ccc;\n  border-bottom-style: solid;\n}\n/**cell 内面行**/\n.cell-panel {\n  height: 98px;\n  min-height: 98px;\n  flex-direction: row;\n  align-items: center;\n  border-bottom-width: 1px;\n  border-bottom-color: #ccc;\n  border-bottom-style: solid;\n}\n.cell-panel-column {\n  height: 98px;\n  min-height: 98px;\n  flex-direction: column;\n  justify-content: space-around;\n  border-bottom-width: 1px;\n  border-bottom-color: #ccc;\n  border-bottom-style: solid;\n  padding-top: 10px;\n  padding-bottom: 10px;\n}\n.cell-panel-column :last-child {\n  border-bottom-width: 0px;\n}\n.cell-panel :last-child {\n  border-bottom-width: 0px;\n}\n.cell-bottom-clear {\n  border-bottom-width: 0px;\n}\n.cell-clear {\n  margin-top: 0px;\n  margin-bottom: 0px;\n  border-top-width: 0px;\n  border-bottom-width: 0px;\n}\n/**两边对齐**/\n.space-between {\n  justify-content: space-between;\n  flex-direction: row;\n  align-items: center;\n}\n.flex-start {\n  justify-content: flex-start;\n  flex-direction: row;\n  align-items: center;\n}\n.flex-end {\n  justify-content: flex-end;\n  flex-direction: row;\n  align-items: center;\n}\n.flex-center {\n  justify-content: center;\n  flex-direction: row;\n  align-items: center;\n}\n.space-around {\n  justify-content: space-around;\n  flex-direction: row;\n  align-items: center;\n}\n/**横向部局居中对齐**/\n.flex-row {\n  flex-direction: row;\n  align-items: center;\n}\n.flex-column {\n  flex-direction: column;\n  align-items: center;\n}\n/**flex 部局比例**/\n.flex1 {\n  flex: 1;\n}\n.flex2 {\n  flex: 2;\n}\n.flex3 {\n  flex: 3;\n}\n.flex4 {\n  flex: 4;\n}\n.flex5 {\n  flex: 6;\n}\n.flex6 {\n  flex: 6;\n}\n/**常用背景颜色**/\n.bkg-white {\n  background-color: white;\n}\n.bkg-primary {\n  background-color: #068F3D;\n}\n.bkg-gray {\n  background-color: #eee;\n}\n.bd-primary {\n  border-color: #068F3D;\n}\n.bkg-delete {\n  background-color: red;\n}\n/**常用字体颜色**/\n.white {\n  color: white;\n}\n.primary {\n  color: #068F3D;\n}\n.gray {\n  color: #999;\n}\n/**ico 字体大小与颜色**/\n.ico {\n  font-size: 48px;\n  color: #068F3D;\n  margin-top: 2px;\n}\n.ico_big {\n  font-size: 72px;\n  color: #068F3D;\n  margin-top: 4px;\n}\n.ico_small {\n  font-size: 32px;\n  color: #068F3D;\n  margin-top: 1px;\n}\n/**右箭头 字体大小与颜色**/\n.arrow {\n  font-size: 32px;\n  color: #ccc;\n  width: 40px;\n}\n/**打勾 字体大小与颜色**/\n.check {\n  font-size: 32px;\n  color: #068F3D;\n  width: 40px;\n}\n.shopCheck {\n  font-size: 32px;\n  color: #068F3D;\n  width: 40px;\n  margin-left: 150px;\n}\n/**默认按钮类型**/\n.button {\n  font-size: 32px;\n  text-align: center;\n  color: #fff;\n  padding-top: 15px;\n  padding-bottom: 15px;\n  background-color: #068F3D;\n  border-radius: 15px;\n  height: 80px;\n  line-height: 50px;\n  align-items: center;\n  justify-content: center;\n}\n.button:active {\n  background-color: #ccc;\n  color: #068F3D;\n}\n.button:disabled {\n  background-color: #068F3D;\n  color: #999;\n}\n/**上拉刷新，下拉加载样式**/\n.refresh {\n  flex-direction: column;\n  align-items: center;\n  padding-top: 10px;\n}\n.loading {\n  flex-direction: column;\n  align-items: center;\n  padding-top: 10px;\n}\n.noLoading {\n  height: 999px;\n}\n.gif {\n  width: 50px;\n  height: 50px;\n}\n.indicator {\n  font-size: 36px;\n  color: #068F3D;\n  width: 750px;\n  text-align: center;\n  margin-top: 20px;\n  margin-bottom: 20px;\n}\n/**超长用省略号**/\n.lines-ellipsis {\n  lines: 1;\n  text-overflow: ellipsis;\n}\n.V1 {\n  height: 146px;\n  padding-top: 54px;\n}\n.IPhoneX {\n  height: 156px;\n  padding-top: 64px;\n}\n.addTopV1 {\n  top: 54px;\n}\n.addTopIPhoneX {\n  top: 64px;\n}\n.addInfoV1 {\n  height: 430px;\n  padding-top: 50px;\n}\n.addInfoIPhoneX {\n  height: 440px;\n  padding-top: 60px;\n}\n.addBgImgV1 {\n  height: 430px;\n}\n.addBgImgIPhoneX {\n  height: 440px;\n}\n.hideCorpusV1 {\n  top: 146px;\n}\n.hideCorpusIPhoneX {\n  top: 156px;\n}\n.pageTopV1 {\n  top: 226px;\n}\n.pageTopIPhoneX {\n  top: 236px;\n}\n.maskLayer {\n  position: fixed;\n  top: 0px;\n  left: 0px;\n  right: 0px;\n  bottom: 0px;\n  background-color: #000;\n  opacity: 0.4;\n}\n.showBox {\n  position: fixed;\n  top: 150px;\n  right: 15px;\n  padding-top: 20px;\n  padding-bottom: 20px;\n}\n.showBg {\n  position: absolute;\n  top: 0;\n  bottom: 0;\n  left: 0;\n  right: 0;\n  background-color: #fff;\n  border-radius: 20px;\n}\n.arrowUp {\n  position: fixed;\n  top: 148px;\n  right: 30px;\n}\n.refreshImg {\n  width: 60px;\n  height: 60px;\n  border-radius: 30px;\n}\n.refreshBox {\n  height: 120px;\n  width: 750px;\n  align-items: center;\n  justify-content: center;\n}\n.indexMtIPhoneX {\n  margin-top: 124px;\n}\n.indexSliderMtIPhone {\n  margin-top: 44px;\n}\n.indexSliderMtIPhoneX {\n  margin-top: 124px;\n}\n.artOutBoxTopIPhoneX {\n  top: 156px;\n}\n.processTotal {\n  position: absolute;\n  bottom: 40px;\n  right: 50px;\n  font-size: 28px;\n  color: #888;\n}\n.processBg {\n  background-color: #ccc;\n  width: 500px;\n}\n.processStyle {\n  height: 10px;\n  position: absolute;\n  left: 50px;\n  bottom: 100px;\n}\n.processText {\n  position: absolute;\n  top: 40px;\n  left: 50px;\n  font-size: 32px;\n}\n.processBox {\n  height: 250px;\n  border-radius: 5px;\n  width: 600px;\n  background-color: #fff;\n  justify-content: space-between;\n}\n.sendMask {\n  position: absolute;\n  top: 0;\n  bottom: 0;\n  left: 0;\n  right: 0;\n  background-color: rgba(0, 0, 0, 0.8);\n  align-items: center;\n  justify-content: center;\n}\n.coverAbsoTop {\n  position: absolute;\n  top: 0;\n  background-color: rgba(136, 136, 136, 0.1);\n}\n", ""]);

// exports


/***/ }),

/***/ 8:
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(0)();
// imports


// module
exports.push([module.i, "/**每个页面都必须的，墙纸**/\n.wrapper {\n  position: absolute;\n  top: 0;\n  left: 0;\n  right: 0;\n  bottom: 0;\n  width: 750px;\n  background-color: #eee;\n}\n/**默认标题字体**/\n.nav_title {\n  font-size: 38px;\n  color: #fff;\n  line-height: 38px;\n}\n.title {\n  font-size: 32px;\n  color: #000;\n}\n/**默认子标题字体**/\n.sub_title {\n  font-size: 30px;\n  color: #999;\n}\n.sub_date {\n  font-size: 26px;\n  color: #999;\n}\n.fz22 {\n  font-size: 22px;\n}\n.fz24 {\n  font-size: 24px;\n}\n.fz26 {\n  font-size: 26px;\n}\n.fz28 {\n  font-size: 28px;\n}\n.fz30 {\n  font-size: 30px;\n}\n.fz32 {\n  font-size: 32px;\n}\n.fz35 {\n  font-size: 35px;\n}\n.fz40 {\n  font-size: 40px;\n}\n.boder-bottom {\n  border-style: solid;\n  border-bottom-width: 1px;\n  border-color: #ccc;\n}\n.boder-top {\n  border-style: solid;\n  border-top-width: 1px;\n  border-color: #ccc;\n}\n.boder-right {\n  border-style: solid;\n  border-right-width: 1px;\n  border-color: #ccc;\n}\n.boder-left {\n  border-style: solid;\n  border-left-width: 1px;\n  border-color: #ccc;\n}\n.pl10 {\n  padding-left: 10px;\n}\n.pl5 {\n  padding-left: 5px;\n}\n.pt0 {\n  padding-top: 0px;\n}\n.pt10 {\n  padding-top: 10px;\n}\n.pt15 {\n  padding-top: 15px;\n}\n.pb0 {\n  padding-bottom: 0px;\n}\n.pb10 {\n  padding-bottom: 10px;\n}\n.pl20 {\n  padding-left: 20px;\n}\n.pt20 {\n  padding-top: 20px;\n}\n.pb15 {\n  padding-bottom: 15px;\n}\n.pb20 {\n  padding-bottom: 20px;\n}\n.pt25 {\n  padding-top: 25px;\n}\n.pt30 {\n  padding-top: 30px;\n}\n.pt40 {\n  padding-top: 40px;\n}\n.pb40 {\n  padding-bottom: 40px;\n}\n.pb30 {\n  padding-bottom: 30px;\n}\n.pb25 {\n  padding-bottom: 25px;\n}\n.pl25 {\n  padding-left: 25px;\n}\n.pl30 {\n  padding-left: 30px;\n}\n.pr5 {\n  padding-right: 5px;\n}\n.pr10 {\n  padding-right: 10px;\n}\n.pr20 {\n  padding-right: 20px;\n}\n.pr25 {\n  padding-right: 25px;\n}\n.pr30 {\n  padding-right: 30px;\n}\n.pl35 {\n  padding-left: 35px;\n}\n.pr35 {\n  padding-right: 35px;\n}\n.bgWhite {\n  background-color: #ffffff;\n}\n.textActive:active {\n  background-color: #ccc;\n}\n/**top 大小**/\n.mt0 {\n  margin-top: 0px;\n}\n.mt10 {\n  margin-top: 10px;\n}\n.mt15 {\n  margin-top: 15px;\n}\n.mt20 {\n  margin-top: 20px;\n}\n.mt30 {\n  margin-top: 30px;\n}\n.mt40 {\n  margin-top: 40px;\n}\n.mt50 {\n  margin-top: 50px;\n}\n/**bottom 大小**/\n.bt0 {\n  margin-bottom: 0px;\n}\n.bt5 {\n  margin-bottom: 5px;\n}\n.bt10 {\n  margin-bottom: 10px;\n}\n.bt15 {\n  margin-bottom: 15px;\n}\n.bt20 {\n  margin-bottom: 20px;\n}\n.bt30 {\n  margin-bottom: 30px;\n}\n.bt45 {\n  margin-bottom: 45px;\n}\n.bt50 {\n  margin-bottom: 50px;\n}\n.mr5 {\n  margin-right: 5px;\n}\n.mr10 {\n  margin-right: 10px;\n}\n.mr15 {\n  margin-right: 15px;\n}\n.mr20 {\n  margin-right: 20px;\n}\n.mr30 {\n  margin-right: 30px;\n}\n/**left 大小**/\n.ml5 {\n  margin-left: 5px;\n}\n.ml10 {\n  margin-left: 10px;\n}\n.ml20 {\n  margin-left: 20px;\n}\n.ml30 {\n  margin-left: 30px;\n}\n.header {\n  height: 136px;\n  padding-top: 44px;\n  flex-direction: row;\n  position: sticky;\n  background-color: #068F3D;\n}\n.baseNavBg {\n  background-color: #068F3D;\n}\n.baseNavColor {\n  color: #068F3D;\n}\n.nav {\n  width: 654px;\n  justify-content: space-between;\n  flex-direction: row;\n  height: 92px;\n  align-items: center;\n  margin-top: 0px;\n}\n.nav_back {\n  margin-top: 0px;\n  flex-direction: row;\n  width: 92px;\n  height: 92px;\n  align-items: center;\n  justify-content: center;\n}\n.corpusActive {\n  color: #068F3D;\n  border-color: #068F3D;\n  border-style: solid;\n  border-bottom-width: 4px;\n}\n.footer {\n  position: fixed;\n  bottom: 0px;\n  left: 0px;\n  right: 0px;\n  height: 100px;\n}\n.fill {\n  height: 500px;\n  width: 750px;\n  background-color: #eee;\n}\n/** 图标图像 **/\n.iconImg {\n  width: 60px;\n  height: 60px;\n  font-size: 60px;\n}\n/**cell 分组头**/\n.cell-header {\n  height: 70px;\n  flex-direction: row;\n  background-color: #ddd;\n  padding-left: 20px;\n}\n/**cell 行**/\n.cell-row {\n  min-height: 100px;\n  flex-direction: column;\n  background-color: #ffffff;\n  padding-left: 20px;\n  margin-top: 20px;\n}\n.cell-row-row {\n  min-height: 100px;\n  flex-direction: row;\n  justify-content: space-between;\n  background-color: #ffffff;\n  padding-left: 20px;\n  padding-right: 20px;\n  align-items: center;\n  margin-top: 20px;\n}\n.cell-line {\n  border-top-width: 1px;\n  border-top-color: #ccc;\n  border-top-style: solid;\n  border-bottom-width: 1px;\n  border-bottom-color: #ccc;\n  border-bottom-style: solid;\n}\n.borderTop {\n  border-top-width: 1px;\n  border-top-color: #ccc;\n  border-top-style: solid;\n}\n.borderBottom {\n  border-bottom-width: 1px;\n  border-bottom-color: #ccc;\n  border-bottom-style: solid;\n}\n/**cell 内面行**/\n.cell-panel {\n  height: 98px;\n  min-height: 98px;\n  flex-direction: row;\n  align-items: center;\n  border-bottom-width: 1px;\n  border-bottom-color: #ccc;\n  border-bottom-style: solid;\n}\n.cell-panel-column {\n  height: 98px;\n  min-height: 98px;\n  flex-direction: column;\n  justify-content: space-around;\n  border-bottom-width: 1px;\n  border-bottom-color: #ccc;\n  border-bottom-style: solid;\n  padding-top: 10px;\n  padding-bottom: 10px;\n}\n.cell-panel-column :last-child {\n  border-bottom-width: 0px;\n}\n.cell-panel :last-child {\n  border-bottom-width: 0px;\n}\n.cell-bottom-clear {\n  border-bottom-width: 0px;\n}\n.cell-clear {\n  margin-top: 0px;\n  margin-bottom: 0px;\n  border-top-width: 0px;\n  border-bottom-width: 0px;\n}\n/**两边对齐**/\n.space-between {\n  justify-content: space-between;\n  flex-direction: row;\n  align-items: center;\n}\n.flex-start {\n  justify-content: flex-start;\n  flex-direction: row;\n  align-items: center;\n}\n.flex-end {\n  justify-content: flex-end;\n  flex-direction: row;\n  align-items: center;\n}\n.flex-center {\n  justify-content: center;\n  flex-direction: row;\n  align-items: center;\n}\n.space-around {\n  justify-content: space-around;\n  flex-direction: row;\n  align-items: center;\n}\n/**横向部局居中对齐**/\n.flex-row {\n  flex-direction: row;\n  align-items: center;\n}\n.flex-column {\n  flex-direction: column;\n  align-items: center;\n}\n/**flex 部局比例**/\n.flex1 {\n  flex: 1;\n}\n.flex2 {\n  flex: 2;\n}\n.flex3 {\n  flex: 3;\n}\n.flex4 {\n  flex: 4;\n}\n.flex5 {\n  flex: 6;\n}\n.flex6 {\n  flex: 6;\n}\n/**常用背景颜色**/\n.bkg-white {\n  background-color: white;\n}\n.bkg-primary {\n  background-color: #068F3D;\n}\n.bkg-gray {\n  background-color: #eee;\n}\n.bd-primary {\n  border-color: #068F3D;\n}\n.bkg-delete {\n  background-color: red;\n}\n/**常用字体颜色**/\n.white {\n  color: white;\n}\n.primary {\n  color: #068F3D;\n}\n.gray {\n  color: #999;\n}\n/**ico 字体大小与颜色**/\n.ico {\n  font-size: 48px;\n  color: #068F3D;\n  margin-top: 2px;\n}\n.ico_big {\n  font-size: 72px;\n  color: #068F3D;\n  margin-top: 4px;\n}\n.ico_small {\n  font-size: 32px;\n  color: #068F3D;\n  margin-top: 1px;\n}\n/**右箭头 字体大小与颜色**/\n.arrow {\n  font-size: 32px;\n  color: #ccc;\n  width: 40px;\n}\n/**打勾 字体大小与颜色**/\n.check {\n  font-size: 32px;\n  color: #068F3D;\n  width: 40px;\n}\n.shopCheck {\n  font-size: 32px;\n  color: #068F3D;\n  width: 40px;\n  margin-left: 150px;\n}\n/**默认按钮类型**/\n.button {\n  font-size: 32px;\n  text-align: center;\n  color: #fff;\n  padding-top: 15px;\n  padding-bottom: 15px;\n  background-color: #068F3D;\n  border-radius: 15px;\n  height: 80px;\n  line-height: 50px;\n  align-items: center;\n  justify-content: center;\n}\n.button:active {\n  background-color: #ccc;\n  color: #068F3D;\n}\n.button:disabled {\n  background-color: #068F3D;\n  color: #999;\n}\n/**上拉刷新，下拉加载样式**/\n.refresh {\n  flex-direction: column;\n  align-items: center;\n  padding-top: 10px;\n}\n.loading {\n  flex-direction: column;\n  align-items: center;\n  padding-top: 10px;\n}\n.noLoading {\n  height: 999px;\n}\n.gif {\n  width: 50px;\n  height: 50px;\n}\n.indicator {\n  font-size: 36px;\n  color: #068F3D;\n  width: 750px;\n  text-align: center;\n  margin-top: 20px;\n  margin-bottom: 20px;\n}\n/**超长用省略号**/\n.lines-ellipsis {\n  lines: 1;\n  text-overflow: ellipsis;\n}\n.V1 {\n  height: 146px;\n  padding-top: 54px;\n}\n.IPhoneX {\n  height: 156px;\n  padding-top: 64px;\n}\n.addTopV1 {\n  top: 54px;\n}\n.addTopIPhoneX {\n  top: 64px;\n}\n.addInfoV1 {\n  height: 430px;\n  padding-top: 50px;\n}\n.addInfoIPhoneX {\n  height: 440px;\n  padding-top: 60px;\n}\n.addBgImgV1 {\n  height: 430px;\n}\n.addBgImgIPhoneX {\n  height: 440px;\n}\n.hideCorpusV1 {\n  top: 146px;\n}\n.hideCorpusIPhoneX {\n  top: 156px;\n}\n.pageTopV1 {\n  top: 226px;\n}\n.pageTopIPhoneX {\n  top: 236px;\n}\n.maskLayer {\n  position: fixed;\n  top: 0px;\n  left: 0px;\n  right: 0px;\n  bottom: 0px;\n  background-color: #000;\n  opacity: 0.4;\n}\n.showBox {\n  position: fixed;\n  top: 150px;\n  right: 15px;\n  padding-top: 20px;\n  padding-bottom: 20px;\n}\n.showBg {\n  position: absolute;\n  top: 0;\n  bottom: 0;\n  left: 0;\n  right: 0;\n  background-color: #fff;\n  border-radius: 20px;\n}\n.arrowUp {\n  position: fixed;\n  top: 148px;\n  right: 30px;\n}\n.refreshImg {\n  width: 60px;\n  height: 60px;\n  border-radius: 30px;\n}\n.refreshBox {\n  height: 120px;\n  width: 750px;\n  align-items: center;\n  justify-content: center;\n}\n.indexMtIPhoneX {\n  margin-top: 124px;\n}\n.indexSliderMtIPhone {\n  margin-top: 44px;\n}\n.indexSliderMtIPhoneX {\n  margin-top: 124px;\n}\n.artOutBoxTopIPhoneX {\n  top: 156px;\n}\n.processTotal {\n  position: absolute;\n  bottom: 40px;\n  right: 50px;\n  font-size: 28px;\n  color: #888;\n}\n.processBg {\n  background-color: #ccc;\n  width: 500px;\n}\n.processStyle {\n  height: 10px;\n  position: absolute;\n  left: 50px;\n  bottom: 100px;\n}\n.processText {\n  position: absolute;\n  top: 40px;\n  left: 50px;\n  font-size: 32px;\n}\n.processBox {\n  height: 250px;\n  border-radius: 5px;\n  width: 600px;\n  background-color: #fff;\n  justify-content: space-between;\n}\n.sendMask {\n  position: absolute;\n  top: 0;\n  bottom: 0;\n  left: 0;\n  right: 0;\n  background-color: rgba(0, 0, 0, 0.8);\n  align-items: center;\n  justify-content: center;\n}\n.coverAbsoTop {\n  position: absolute;\n  top: 0;\n  background-color: rgba(136, 136, 136, 0.1);\n}\n", ""]);

// exports


/***/ }),

/***/ 894:
/***/ (function(module, exports) {

exports.read = function (buffer, offset, isLE, mLen, nBytes) {
  var e, m
  var eLen = nBytes * 8 - mLen - 1
  var eMax = (1 << eLen) - 1
  var eBias = eMax >> 1
  var nBits = -7
  var i = isLE ? (nBytes - 1) : 0
  var d = isLE ? -1 : 1
  var s = buffer[offset + i]

  i += d

  e = s & ((1 << (-nBits)) - 1)
  s >>= (-nBits)
  nBits += eLen
  for (; nBits > 0; e = e * 256 + buffer[offset + i], i += d, nBits -= 8) {}

  m = e & ((1 << (-nBits)) - 1)
  e >>= (-nBits)
  nBits += mLen
  for (; nBits > 0; m = m * 256 + buffer[offset + i], i += d, nBits -= 8) {}

  if (e === 0) {
    e = 1 - eBias
  } else if (e === eMax) {
    return m ? NaN : ((s ? -1 : 1) * Infinity)
  } else {
    m = m + Math.pow(2, mLen)
    e = e - eBias
  }
  return (s ? -1 : 1) * m * Math.pow(2, e - mLen)
}

exports.write = function (buffer, value, offset, isLE, mLen, nBytes) {
  var e, m, c
  var eLen = nBytes * 8 - mLen - 1
  var eMax = (1 << eLen) - 1
  var eBias = eMax >> 1
  var rt = (mLen === 23 ? Math.pow(2, -24) - Math.pow(2, -77) : 0)
  var i = isLE ? 0 : (nBytes - 1)
  var d = isLE ? 1 : -1
  var s = value < 0 || (value === 0 && 1 / value < 0) ? 1 : 0

  value = Math.abs(value)

  if (isNaN(value) || value === Infinity) {
    m = isNaN(value) ? 1 : 0
    e = eMax
  } else {
    e = Math.floor(Math.log(value) / Math.LN2)
    if (value * (c = Math.pow(2, -e)) < 1) {
      e--
      c *= 2
    }
    if (e + eBias >= 1) {
      value += rt / c
    } else {
      value += rt * Math.pow(2, 1 - eBias)
    }
    if (value * c >= 2) {
      e++
      c /= 2
    }

    if (e + eBias >= eMax) {
      m = 0
      e = eMax
    } else if (e + eBias >= 1) {
      m = (value * c - 1) * Math.pow(2, mLen)
      e = e + eBias
    } else {
      m = value * Math.pow(2, eBias - 1) * Math.pow(2, mLen)
      e = 0
    }
  }

  for (; mLen >= 8; buffer[offset + i] = m & 0xff, i += d, m /= 256, mLen -= 8) {}

  e = (e << mLen) | m
  eLen += mLen
  for (; eLen > 0; buffer[offset + i] = e & 0xff, i += d, e /= 256, eLen -= 8) {}

  buffer[offset + i - d] |= s * 128
}


/***/ }),

/***/ 895:
/***/ (function(module, exports) {

var toString = {}.toString;

module.exports = Array.isArray || function (arr) {
  return toString.call(arr) == '[object Array]';
};


/***/ }),

/***/ 896:
/***/ (function(module, exports, __webpack_require__) {

/* WEBPACK VAR INJECTION */(function(global) {var __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;/*
 *  base64.js
 *
 *  Licensed under the BSD 3-Clause License.
 *    http://opensource.org/licenses/BSD-3-Clause
 *
 *  References:
 *    http://en.wikipedia.org/wiki/Base64
 */
;(function (global, factory) {
     true
        ? module.exports = factory(global)
        : typeof define === 'function' && define.amd
        ? define(factory) : factory(global)
}((
    typeof self !== 'undefined' ? self
        : typeof window !== 'undefined' ? window
        : typeof global !== 'undefined' ? global
: this
), function(global) {
    'use strict';
    // existing version for noConflict()
    var _Base64 = global.Base64;
    var version = "2.4.5";
    // if node.js, we use Buffer
    var buffer;
    if (typeof module !== 'undefined' && module.exports) {
        try {
            buffer = __webpack_require__(619).Buffer;
        } catch (err) {}
    }
    // constants
    var b64chars
        = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
    var b64tab = function(bin) {
        var t = {};
        for (var i = 0, l = bin.length; i < l; i++) t[bin.charAt(i)] = i;
        return t;
    }(b64chars);
    var fromCharCode = String.fromCharCode;
    // encoder stuff
    var cb_utob = function(c) {
        if (c.length < 2) {
            var cc = c.charCodeAt(0);
            return cc < 0x80 ? c
                : cc < 0x800 ? (fromCharCode(0xc0 | (cc >>> 6))
                                + fromCharCode(0x80 | (cc & 0x3f)))
                : (fromCharCode(0xe0 | ((cc >>> 12) & 0x0f))
                   + fromCharCode(0x80 | ((cc >>>  6) & 0x3f))
                   + fromCharCode(0x80 | ( cc         & 0x3f)));
        } else {
            var cc = 0x10000
                + (c.charCodeAt(0) - 0xD800) * 0x400
                + (c.charCodeAt(1) - 0xDC00);
            return (fromCharCode(0xf0 | ((cc >>> 18) & 0x07))
                    + fromCharCode(0x80 | ((cc >>> 12) & 0x3f))
                    + fromCharCode(0x80 | ((cc >>>  6) & 0x3f))
                    + fromCharCode(0x80 | ( cc         & 0x3f)));
        }
    };
    var re_utob = /[\uD800-\uDBFF][\uDC00-\uDFFFF]|[^\x00-\x7F]/g;
    var utob = function(u) {
        return u.replace(re_utob, cb_utob);
    };
    var cb_encode = function(ccc) {
        var padlen = [0, 2, 1][ccc.length % 3],
        ord = ccc.charCodeAt(0) << 16
            | ((ccc.length > 1 ? ccc.charCodeAt(1) : 0) << 8)
            | ((ccc.length > 2 ? ccc.charCodeAt(2) : 0)),
        chars = [
            b64chars.charAt( ord >>> 18),
            b64chars.charAt((ord >>> 12) & 63),
            padlen >= 2 ? '=' : b64chars.charAt((ord >>> 6) & 63),
            padlen >= 1 ? '=' : b64chars.charAt(ord & 63)
        ];
        return chars.join('');
    };
    var btoa = global.btoa ? function(b) {
        return global.btoa(b);
    } : function(b) {
        return b.replace(/[\s\S]{1,3}/g, cb_encode);
    };
    var _encode = buffer ?
        buffer.from && Uint8Array && buffer.from !== Uint8Array.from
        ? function (u) {
            return (u.constructor === buffer.constructor ? u : buffer.from(u))
                .toString('base64')
        }
        :  function (u) {
            return (u.constructor === buffer.constructor ? u : new  buffer(u))
                .toString('base64')
        }
        : function (u) { return btoa(utob(u)) }
    ;
    var encode = function(u, urisafe) {
        return !urisafe
            ? _encode(String(u))
            : _encode(String(u)).replace(/[+\/]/g, function(m0) {
                return m0 == '+' ? '-' : '_';
            }).replace(/=/g, '');
    };
    var encodeURI = function(u) { return encode(u, true) };
    // decoder stuff
    var re_btou = new RegExp([
        '[\xC0-\xDF][\x80-\xBF]',
        '[\xE0-\xEF][\x80-\xBF]{2}',
        '[\xF0-\xF7][\x80-\xBF]{3}'
    ].join('|'), 'g');
    var cb_btou = function(cccc) {
        switch(cccc.length) {
        case 4:
            var cp = ((0x07 & cccc.charCodeAt(0)) << 18)
                |    ((0x3f & cccc.charCodeAt(1)) << 12)
                |    ((0x3f & cccc.charCodeAt(2)) <<  6)
                |     (0x3f & cccc.charCodeAt(3)),
            offset = cp - 0x10000;
            return (fromCharCode((offset  >>> 10) + 0xD800)
                    + fromCharCode((offset & 0x3FF) + 0xDC00));
        case 3:
            return fromCharCode(
                ((0x0f & cccc.charCodeAt(0)) << 12)
                    | ((0x3f & cccc.charCodeAt(1)) << 6)
                    |  (0x3f & cccc.charCodeAt(2))
            );
        default:
            return  fromCharCode(
                ((0x1f & cccc.charCodeAt(0)) << 6)
                    |  (0x3f & cccc.charCodeAt(1))
            );
        }
    };
    var btou = function(b) {
        return b.replace(re_btou, cb_btou);
    };
    var cb_decode = function(cccc) {
        var len = cccc.length,
        padlen = len % 4,
        n = (len > 0 ? b64tab[cccc.charAt(0)] << 18 : 0)
            | (len > 1 ? b64tab[cccc.charAt(1)] << 12 : 0)
            | (len > 2 ? b64tab[cccc.charAt(2)] <<  6 : 0)
            | (len > 3 ? b64tab[cccc.charAt(3)]       : 0),
        chars = [
            fromCharCode( n >>> 16),
            fromCharCode((n >>>  8) & 0xff),
            fromCharCode( n         & 0xff)
        ];
        chars.length -= [0, 0, 2, 1][padlen];
        return chars.join('');
    };
    var atob = global.atob ? function(a) {
        return global.atob(a);
    } : function(a){
        return a.replace(/[\s\S]{1,4}/g, cb_decode);
    };
    var _decode = buffer ?
        buffer.from && Uint8Array && buffer.from !== Uint8Array.from
        ? function(a) {
            return (a.constructor === buffer.constructor
                    ? a : buffer.from(a, 'base64')).toString();
        }
        : function(a) {
            return (a.constructor === buffer.constructor
                    ? a : new buffer(a, 'base64')).toString();
        }
        : function(a) { return btou(atob(a)) };
    var decode = function(a){
        return _decode(
            String(a).replace(/[-_]/g, function(m0) { return m0 == '-' ? '+' : '/' })
                .replace(/[^A-Za-z0-9\+\/]/g, '')
        );
    };
    var noConflict = function() {
        var Base64 = global.Base64;
        global.Base64 = _Base64;
        return Base64;
    };
    // export Base64
    global.Base64 = {
        VERSION: version,
        atob: atob,
        btoa: btoa,
        fromBase64: decode,
        toBase64: encode,
        utob: utob,
        encode: encode,
        encodeURI: encodeURI,
        btou: btou,
        decode: decode,
        noConflict: noConflict
    };
    // if ES5 is available, make Base64.extendString() available
    if (typeof Object.defineProperty === 'function') {
        var noEnum = function(v){
            return {value:v,enumerable:false,writable:true,configurable:true};
        };
        global.Base64.extendString = function () {
            Object.defineProperty(
                String.prototype, 'fromBase64', noEnum(function () {
                    return decode(this)
                }));
            Object.defineProperty(
                String.prototype, 'toBase64', noEnum(function (urisafe) {
                    return encode(this, urisafe)
                }));
            Object.defineProperty(
                String.prototype, 'toBase64URI', noEnum(function () {
                    return encode(this, true)
                }));
        };
    }
    //
    // export Base64 to the namespace
    //
    if (global['Meteor']) { // Meteor.js
        Base64 = global.Base64;
    }
    // module.exports and AMD are mutually exclusive.
    // module.exports has precedence.
    if (typeof module !== 'undefined' && module.exports) {
        module.exports.Base64 = global.Base64;
    }
    else if (true) {
        // AMD. Register as an anonymous module.
        !(__WEBPACK_AMD_DEFINE_ARRAY__ = [], __WEBPACK_AMD_DEFINE_RESULT__ = function(){ return global.Base64 }.apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__),
				__WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
    }
    // that's it!
    return {Base64: global.Base64}
}));

/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__(22)))

/***/ }),

/***/ 9:
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(0)();
// imports


// module
exports.push([module.i, "\n.cb[data-v-019a21a0] {\n    border-bottom-width: 0px;\n}\n.navRightBox[data-v-019a21a0]{\n    min-width: 92px;\n    height: 92px;\n    align-items: center;\n    justify-content: center;\n}\n.nav_bg[data-v-019a21a0] {\n    width:750px;\n    height: 156px;\n    background-size: cover;\n    position: absolute;\n    top:0;\n}\n.nav_ico[data-v-019a21a0] {\n    font-size: 38px;\n    color: #fff;\n    margin-top: 2px;\n}\n.nav_CompleteIcon[data-v-019a21a0]{\n    /*如果nav_ico的字体大小改变这个值也需要变。 （左边box宽度-back图标宽度)/2 */\n    padding-left: 27px;\n    padding-right: 27px;\n    /*ios识别不出该字体，warn警告。  推测可能隐藏到字体图标的渲染*/\n    /*font-family: Verdana, Geneva, sans-serif;*/\n    font-size: 44px;\n    line-height: 44px;\n    color: #FFFFFF;\n}\n.nav_Complete[data-v-019a21a0] {\n    padding-left: 27px;\n    padding-right: 27px;\n    /*ios识别不出该字体，warn警告。  推测可能隐藏到字体图标的渲染*/\n    /*font-family: Verdana, Geneva, sans-serif;*/\n}\n\n", ""]);

// exports


/***/ }),

/***/ 952:
/***/ (function(module, exports, __webpack_require__) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "wrapper"
  }, [_c('navbar', {
    attrs: {
      "title": _vm.title
    },
    on: {
      "goback": _vm.goback
    }
  }), _vm._v(" "), _c('list', {
    class: [_vm.bgWhite ? 'whiteColor' : 'bkg-gray'],
    attrs: {
      "loadmoreoffset": "50"
    },
    on: {
      "loadmore": _vm.onloading
    }
  }, [_c('refresh', {
    staticClass: "refreshBox",
    attrs: {
      "display": _vm.refreshing ? 'show' : 'hide'
    },
    on: {
      "refresh": _vm.onrefresh
    }
  }, [_c('image', {
    ref: "refreshImg",
    staticClass: "refreshImg",
    attrs: {
      "resize": "cover",
      "src": _vm.refreshImg
    }
  })]), _vm._v(" "), _c('cell', [(_vm.dataList.length == 0) ? _c('noData', {
    attrs: {
      "noDataHint": _vm.noDataHint,
      "ndBgColor": "#fff"
    }
  }) : _vm._e()], 1), _vm._v(" "), _vm._l((_vm.dataList), function(item) {
    return (_vm.messageType == 'gm_10200') ? _c('cell', {
      on: {
        "click": function($event) {
          _vm.goLink(item.id)
        }
      }
    }, [_c('div', {
      staticClass: "dateBox"
    }, [_c('text', {
      staticClass: "dateText"
    }, [_vm._v(_vm._s(_vm._f("timefmtMore")(item.createDate)))])]), _vm._v(" "), _c('div', {
      staticClass: "contentBox"
    }, [_c('text', {
      staticClass: "fz45 black"
    }, [_vm._v(_vm._s(item.content))]), _vm._v(" "), _c('text', {
      staticClass: "sub_title mt10"
    }, [_vm._v(_vm._s(_vm._f("ymdtimefmt")(item.createDate)))]), _vm._v(" "), _c('div', {
      staticClass: "moneyBox"
    }, [_c('text', {
      staticClass: "fz65"
    }, [_vm._v(_vm._s(_vm._f("currencyfmt")(item.ext.amount)))]), _vm._v(" "), _c('text', {
      staticClass: "fz30"
    }, [_vm._v("元")])]), _vm._v(" "), _c('div', {
      staticClass: "contentLine"
    }, [_c('text', {
      staticClass: "fz30 black"
    }, [_vm._v("订单号:")]), _vm._v(" "), _c('text', {
      staticClass: "fz30 gray ml10"
    }, [_vm._v(_vm._s(item.ext.sn))])]), _vm._v(" "), _c('div', {
      staticClass: "contentLine"
    }, [_c('text', {
      staticClass: "fz30 black"
    }, [_vm._v("订单状态:")]), _vm._v(" "), _c('text', {
      staticClass: "fz30 gray ml10"
    }, [_vm._v(_vm._s(item.ext.statusDescr))])]), _vm._v(" "), _c('div', {
      staticClass: "contentLine"
    }, [_c('text', {
      staticClass: "fz30 black"
    }, [_vm._v("商品说明:")]), _vm._v(" "), _c('text', {
      staticClass: " fz30 gray ml10 contentLimit"
    }, [_vm._v(_vm._s(item.ext.orderItems[0].name) + _vm._s(item.ext.orderItems[0].spec))])]), _vm._v(" "), _c('div', {
      staticClass: "bottomBtn"
    }, [_c('text', {
      staticClass: "title"
    }, [_vm._v("查看详情")])])])]) : _vm._e()
  }), _vm._v(" "), _vm._l((_vm.dataList), function(item) {
    return (_vm.messageType == 'gm_10213') ? _c('cell', {
      on: {
        "click": function($event) {
          _vm.goLink(item.id)
        }
      }
    }, [_c('div', {
      staticClass: "dateBox"
    }, [_c('text', {
      staticClass: "dateText"
    }, [_vm._v(_vm._s(_vm._f("timefmtMore")(item.createDate)))])]), _vm._v(" "), _c('div', {
      staticClass: "contentBox"
    }, [_c('text', {
      staticClass: "fz45 black"
    }, [_vm._v(_vm._s(item.content))]), _vm._v(" "), _c('text', {
      staticClass: "sub_title mt10"
    }, [_vm._v(_vm._s(_vm._f("ymdtimefmt")(item.createDate)))]), _vm._v(" "), _c('div', {
      staticClass: "moneyBox"
    }, [_c('text', {
      staticClass: "fz65"
    }, [_vm._v(_vm._s(item.ext.quantity))]), _vm._v(" "), _c('text', {
      staticClass: "fz30"
    })]), _vm._v(" "), _c('div', {
      staticClass: "contentLine"
    }, [_c('text', {
      staticClass: "fz30 black"
    }, [_vm._v("订单号:")]), _vm._v(" "), _c('text', {
      staticClass: "fz30 gray ml10"
    }, [_vm._v(_vm._s(item.ext.orderSn))])]), _vm._v(" "), _c('div', {
      staticClass: "contentLine"
    }, [_c('text', {
      staticClass: "fz30 black"
    }, [_vm._v("订单状态:")]), _vm._v(" "), _c('text', {
      staticClass: "fz30 gray ml10"
    }, [_vm._v(_vm._s(item.ext.statusDescr))])]), _vm._v(" "), _c('div', {
      staticClass: "contentLine"
    }, [_c('text', {
      staticClass: "fz30 black"
    }, [_vm._v("商品说明:")]), _vm._v(" "), _c('text', {
      staticClass: " fz30 gray ml10 contentLimit"
    }, [_vm._v(_vm._s(item.ext.shippingItems[0].name) + _vm._s(item.ext.shippingItems[0].spec))])]), _vm._v(" "), _c('div', {
      staticClass: "bottomBtn"
    }, [_c('text', {
      staticClass: "title"
    }, [_vm._v("查看详情")])])])]) : _vm._e()
  }), _vm._v(" "), _vm._l((_vm.dataList), function(item) {
    return (_vm.messageType == 'gm_10201') ? _c('cell', {
      on: {
        "click": function($event) {
          _vm.goLink(item.id)
        }
      }
    }, [_c('div', {
      staticClass: "dateBox"
    }, [_c('text', {
      staticClass: "dateText"
    }, [_vm._v(_vm._s(_vm._f("timefmtMore")(item.createDate)))])]), _vm._v(" "), _c('div', {
      staticClass: "contentBox"
    }, [_c('text', {
      staticClass: "fz45 black"
    }, [_vm._v(_vm._s(item.title))]), _vm._v(" "), _c('text', {
      staticClass: "sub_title mt10"
    }, [_vm._v(_vm._s(_vm._f("ymdtimefmt")(item.createDate)))]), _vm._v(" "), _c('div', {
      staticClass: "moneyBox"
    }, [_c('text', {
      staticClass: "fz65"
    }, [_vm._v(_vm._s(_vm._f("currencyfmt")(item.ext.amount)))]), _vm._v(" "), _c('text', {
      staticClass: "fz30"
    }, [_vm._v("元")])]), _vm._v(" "), _c('div', {
      staticClass: "contentLine"
    }, [_c('text', {
      staticClass: "fz30 black"
    }, [_vm._v("付款方式:")]), _vm._v(" "), _c('text', {
      staticClass: "fz30 gray ml10"
    }, [_vm._v(_vm._s(item.ext.method))])]), _vm._v(" "), _c('div', {
      staticClass: "contentLine"
    }, [_c('text', {
      staticClass: "fz30 black"
    }, [_vm._v("交易对象:")]), _vm._v(" "), _c('text', {
      staticClass: "fz30 gray ml10"
    }, [_vm._v(_vm._s(item.ext.nickName))])]), _vm._v(" "), _c('div', {
      staticClass: "contentLine"
    }, [_c('text', {
      staticClass: "fz30 black"
    }, [_vm._v("商品说明:")]), _vm._v(" "), _c('text', {
      staticClass: " fz30 gray ml10 contentLimit"
    }, [_vm._v(_vm._s(item.ext.memo))])]), _vm._v(" "), _c('div', {
      staticClass: "bottomBtn"
    }, [_c('text', {
      staticClass: "title"
    }, [_vm._v("查看详情")])])])]) : _vm._e()
  }), _vm._v(" "), _vm._l((_vm.dataList), function(item) {
    return (_vm.messageType == 'gm_10212') ? _c('cell', {
      on: {
        "click": function($event) {
          _vm.goLink(item.id)
        }
      }
    }, [_c('div', {
      staticClass: "dateBox"
    }, [_c('text', {
      staticClass: "dateText"
    }, [_vm._v(_vm._s(_vm._f("timefmtMore")(item.createDate)))])]), _vm._v(" "), _c('div', {
      staticClass: "contentBox"
    }, [_c('text', {
      staticClass: "fz45 black"
    }, [_vm._v(_vm._s(item.title))]), _vm._v(" "), _c('text', {
      staticClass: "sub_title mt10"
    }, [_vm._v(_vm._s(_vm._f("ymdtimefmt")(item.createDate)))]), _vm._v(" "), _c('div', {
      staticClass: "moneyBox"
    }, [_c('text', {
      staticClass: "fz65"
    }, [_vm._v(_vm._s(_vm._f("currencyfmt")(item.ext.amount)))]), _vm._v(" "), _c('text', {
      staticClass: "fz30"
    }, [_vm._v("元")])]), _vm._v(" "), _c('div', {
      staticClass: "contentLine"
    }, [_c('text', {
      staticClass: "fz30 black"
    }, [_vm._v("付款方式:")]), _vm._v(" "), _c('text', {
      staticClass: "fz30 gray ml10"
    }, [_vm._v(_vm._s(item.ext.method))])]), _vm._v(" "), _c('div', {
      staticClass: "contentLine"
    }, [_c('text', {
      staticClass: "fz30 black"
    }, [_vm._v("交易对象:")]), _vm._v(" "), _c('text', {
      staticClass: "fz30 gray ml10"
    }, [_vm._v(_vm._s(item.ext.name))])]), _vm._v(" "), _c('div', {
      staticClass: "contentLine"
    }, [_c('text', {
      staticClass: "fz30 black"
    }, [_vm._v("交易说明:")]), _vm._v(" "), _c('text', {
      staticClass: " fz30 gray ml10 contentLimit"
    }, [_vm._v(_vm._s(item.ext.memo))])]), _vm._v(" "), _c('div', {
      staticClass: "bottomBtn"
    }, [_c('text', {
      staticClass: "title"
    }, [_vm._v("查看详情")])])])]) : _vm._e()
  }), _vm._v(" "), _vm._l((_vm.dataList), function(item) {
    return (_vm.messageType == 'gm_10202' || _vm.messageType == 'gm_10209' || _vm.messageType == 'gm_10210') ? _c('cell', {
      on: {
        "click": function($event) {
          _vm.goLink(item.id)
        }
      }
    }, [_c('div', {
      staticClass: "lineBox pt20 pb20"
    }, [_c('div', {
      staticStyle: {
        "flex-direction": "row"
      }
    }, [_c('image', {
      staticClass: "headImg",
      attrs: {
        "src": _vm._f("watchLogo")(item.logo)
      },
      on: {
        "click": function($event) {
          _vm.goAuthor(item.userId)
        }
      }
    }), _vm._v(" "), _c('div', {
      staticClass: "commentsInfo"
    }, [_c('text', {
      staticClass: "fz30 nameColor"
    }, [_vm._v(_vm._s(item.nickName))]), _vm._v(" "), _c('text', {
      staticClass: "commentsText"
    }, [_vm._v(_vm._s(item.content))]), _vm._v(" "), _c('text', {
      staticClass: "sub_title"
    }, [_vm._v(_vm._s(_vm._f("timefmtOther")(item.createDate)))])])])]), _vm._v(" "), _c('div', {
      staticClass: "lineBoxBorder"
    })]) : _vm._e()
  }), _vm._v(" "), _vm._l((_vm.dataList), function(item) {
    return (_vm.messageType == 'gm_10203') ? _c('cell', {
      on: {
        "click": function($event) {
          _vm.goLink(item.id)
        }
      }
    }, [_c('div', {
      staticClass: "lineBox pt20 pb20"
    }, [_c('div', {
      staticStyle: {
        "flex-direction": "row"
      }
    }, [_c('image', {
      staticClass: "headImg",
      attrs: {
        "src": _vm._f("watchLogo")(item.logo)
      },
      on: {
        "click": function($event) {
          _vm.goAuthor(item.userId)
        }
      }
    }), _vm._v(" "), _c('div', {
      staticClass: "commentsInfo"
    }, [_c('text', {
      staticClass: "fz30 nameColor"
    }, [_vm._v(_vm._s(item.nickName))]), _vm._v(" "), _c('text', {
      staticClass: "commentsText"
    }, [_vm._v(_vm._s(item.content))]), _vm._v(" "), _c('text', {
      staticClass: "sub_title"
    }, [_vm._v(_vm._s(_vm._f("timefmtOther")(item.createDate)))])])]), _vm._v(" "), _c('image', {
      staticClass: "coverImg",
      attrs: {
        "resize": "cover",
        "src": _vm._f("watchThumbnail")(item.ext.thumbnail)
      }
    })]), _vm._v(" "), _c('div', {
      staticClass: "lineBoxBorder"
    })]) : _vm._e()
  }), _vm._v(" "), _vm._l((_vm.dataList), function(item) {
    return (_vm.messageType == 'gm_10204') ? _c('cell', {
      on: {
        "click": function($event) {
          _vm.goLink(item.id)
        }
      }
    }, [_c('div', {
      staticClass: "lineBox lineBoxHeight"
    }, [_c('div', {
      staticClass: "flex-row"
    }, [_c('image', {
      staticClass: "headImg",
      attrs: {
        "src": _vm._f("watchLogo")(item.logo)
      },
      on: {
        "click": function($event) {
          _vm.goAuthor(item.userId)
        }
      }
    }), _vm._v(" "), _c('div', {
      staticClass: "userInfo"
    }, [_c('text', {
      staticClass: "fz30 nameColor"
    }, [_vm._v(_vm._s(item.nickName))]), _vm._v(" "), _c('text', {
      staticClass: "infoText",
      style: ({
        fontFamily: 'iconfont'
      })
    }, [_vm._v("")]), _vm._v(" "), _c('text', {
      staticClass: "sub_title"
    }, [_vm._v(_vm._s(_vm._f("timefmtOther")(item.createDate)))])])]), _vm._v(" "), _c('image', {
      staticClass: "coverImg",
      attrs: {
        "resize": "cover",
        "src": _vm._f("watchThumbnail")(item.ext.thumbnail)
      }
    })]), _vm._v(" "), _c('div', {
      staticClass: "lineBoxBorder"
    })]) : _vm._e()
  }), _vm._v(" "), _vm._l((_vm.dataList), function(item) {
    return (_vm.messageType == 'gm_10205') ? _c('cell', {
      on: {
        "click": function($event) {
          _vm.goLink(item.id)
        }
      }
    }, [_c('div', {
      staticClass: "lineBox lineBoxHeight"
    }, [_c('div', {
      staticClass: "flex-row"
    }, [_c('image', {
      staticClass: "headImg",
      attrs: {
        "src": _vm._f("watchLogo")(item.logo)
      },
      on: {
        "click": function($event) {
          _vm.goAuthor(item.userId)
        }
      }
    }), _vm._v(" "), _c('div', {
      staticClass: "userInfo"
    }, [_c('text', {
      staticClass: "fz30 nameColor"
    }, [_vm._v(_vm._s(item.nickName))]), _vm._v(" "), _c('text', {
      staticClass: "infoText"
    }, [_vm._v("关注了你")]), _vm._v(" "), _c('text', {
      staticClass: "sub_title"
    }, [_vm._v(_vm._s(_vm._f("timefmtOther")(item.createDate)))])])])]), _vm._v(" "), _c('div', {
      staticClass: "lineBoxBorder"
    })]) : _vm._e()
  }), _vm._v(" "), _vm._l((_vm.dataList), function(item) {
    return (_vm.messageType == 'gm_10206' || _vm.messageType == 'gm_10207' || _vm.messageType == 'gm_10208') ? _c('cell', {
      on: {
        "click": function($event) {
          _vm.goLink(item.id)
        }
      }
    }, [_c('div', {
      staticClass: "lineBox pt20 pb20"
    }, [_c('div', {
      staticStyle: {
        "flex-direction": "row"
      }
    }, [_c('image', {
      staticClass: "headImg",
      attrs: {
        "src": _vm._f("watchLogo")(item.logo)
      },
      on: {
        "click": function($event) {
          _vm.goAuthor(item.userId)
        }
      }
    }), _vm._v(" "), _c('div', {
      staticClass: "commentsInfo"
    }, [_c('text', {
      staticClass: "fz30 nameColor"
    }, [_vm._v(_vm._s(item.nickName))]), _vm._v(" "), _c('text', {
      staticClass: "commentsText"
    }, [_vm._v(_vm._s(item.content))]), _vm._v(" "), _c('text', {
      staticClass: "sub_title"
    }, [_vm._v(_vm._s(_vm._f("timefmtOther")(item.createDate)))])])]), _vm._v(" "), _c('image', {
      staticClass: "coverImg",
      attrs: {
        "resize": "cover",
        "src": _vm._f("watchThumbnail")(item.ext.thumbnail)
      }
    })]), _vm._v(" "), _c('div', {
      staticClass: "lineBoxBorder"
    })]) : _vm._e()
  })], 2)], 1)
},staticRenderFns: []}
module.exports.render._withStripped = true
if (false) {
  module.hot.accept()
  if (module.hot.data) {
     require("vue-loader/node_modules/vue-hot-reload-api").rerender("data-v-45e47c12", module.exports)
  }
}

/***/ })

/******/ });