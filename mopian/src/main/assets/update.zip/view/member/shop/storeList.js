// { "framework": "Vue" }
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};

/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {

/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId])
/******/ 			return installedModules[moduleId].exports;

/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			exports: {},
/******/ 			id: moduleId,
/******/ 			loaded: false
/******/ 		};

/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);

/******/ 		// Flag the module as loaded
/******/ 		module.loaded = true;

/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}


/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;

/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;

/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";

/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(0);
/******/ })
/************************************************************************/
/******/ ({

/***/ 0:
/***/ (function(module, exports, __webpack_require__) {

	var __vue_exports__, __vue_options__
	var __vue_styles__ = []

	/* styles */
	__vue_styles__.push(__webpack_require__(335)
	)

	/* template */
	var __vue_template__ = __webpack_require__(336)
	__vue_options__ = __vue_exports__ = __vue_exports__ || {}
	if (
	  typeof __vue_exports__.default === "object" ||
	  typeof __vue_exports__.default === "function"
	) {
	if (Object.keys(__vue_exports__).some(function (key) { return key !== "default" && key !== "__esModule" })) {console.error("named exports are not supported in *.vue files.")}
	__vue_options__ = __vue_exports__ = __vue_exports__.default
	}
	if (typeof __vue_options__ === "function") {
	  __vue_options__ = __vue_options__.options
	}
	__vue_options__.__file = "/Users/ke/mopian/GitHubMoPian/mp/src/view/member/shop/storeList.vue"
	__vue_options__.render = __vue_template__.render
	__vue_options__.staticRenderFns = __vue_template__.staticRenderFns
	__vue_options__._scopeId = "data-v-70712c4e"
	__vue_options__.style = __vue_options__.style || {}
	__vue_styles__.forEach(function (module) {
	  for (var name in module) {
	    __vue_options__.style[name] = module[name]
	  }
	})
	if (typeof __register_static_styles__ === "function") {
	  __register_static_styles__(__vue_options__._scopeId, __vue_styles__)
	}

	module.exports = __vue_exports__
	module.exports.el = 'true'
	new Vue(module.exports)


/***/ }),

/***/ 335:
/***/ (function(module, exports) {

	module.exports = {
	  "head": {
	    "backgroundColor": "#FFFFFF",
	    "borderWidth": 0,
	    "marginBottom": 20,
	    "height": 80,
	    "alignItems": "center",
	    "justifyContent": "center"
	  },
	  "clickAdd": {
	    "fontSize": 40
	  },
	  "shops": {
	    "backgroundColor": "#FFFFFF",
	    "flexDirection": "row",
	    "alignItems": "center",
	    "marginBottom": 10,
	    "height": 230
	  },
	  "shopLogo": {
	    "marginLeft": 20
	  },
	  "shopInformation": {
	    "height": 230,
	    "marginLeft": 20
	  },
	  "shopName": {
	    "fontWeight": "bold",
	    "fontSize": 28
	  },
	  "shopAddress": {
	    "fontWeight": "bold",
	    "fontSize": 28
	  },
	  "shopNameDiv": {
	    "flexDirection": "row",
	    "marginTop": 20
	  },
	  "shopAddressDiv": {
	    "flexDirection": "row",
	    "marginTop": 30
	  },
	  "concretely": {
	    "width": 350
	  }
	}

/***/ }),

/***/ 336:
/***/ (function(module, exports) {

	module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
	  return _vm._m(0)
	},staticRenderFns: [function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
	  return _c('div', {
	    staticStyle: {
	      backgroundColor: "#eeeeee"
	    }
	  }, [_c('div', {
	    staticClass: ["head"]
	  }, [_c('text', {
	    staticClass: ["clickAdd"]
	  }, [_vm._v("+点击添加商铺")])]), _c('div', {
	    staticClass: ["shops"]
	  }, [_c('div', {
	    staticClass: ["shopLogo"]
	  }, [_c('image', {
	    staticClass: ["img"],
	    staticStyle: {
	      width: "250px",
	      height: "200px"
	    },
	    attrs: {
	      "src": "https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg"
	    }
	  })]), _c('div', {
	    staticClass: ["shopInformation"]
	  }, [_c('div', {
	    staticClass: ["shopNameDiv"]
	  }, [_c('text', {
	    staticClass: ["shopName"]
	  }, [_vm._v("店铺名：")]), _c('text', {
	    staticClass: ["fullName"]
	  }, [_vm._v("111")])]), _c('div', {
	    staticClass: ["shopAddressDiv"]
	  }, [_c('text', {
	    staticClass: ["shopAddress"]
	  }, [_vm._v("地址：")]), _c('text', {
	    staticClass: ["concretely"]
	  }, [_vm._v("11111111111111111111111111")])])])])])
	}]}
	module.exports.render._withStripped = true

/***/ })

/******/ });