// { "framework": "Vue"} 

/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// identity function for calling harmony imports with the correct context
/******/ 	__webpack_require__.i = function(value) { return value; };
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 385);
/******/ })
/************************************************************************/
/******/ ({

/***/ 0:
/***/ (function(module, exports) {

/*
	MIT License http://www.opensource.org/licenses/mit-license.php
	Author Tobias Koppers @sokra
*/
// css base code, injected by the css-loader
module.exports = function() {
	var list = [];

	// return the list of modules as css string
	list.toString = function toString() {
		var result = [];
		for(var i = 0; i < this.length; i++) {
			var item = this[i];
			if(item[2]) {
				result.push("@media " + item[2] + "{" + item[1] + "}");
			} else {
				result.push(item[1]);
			}
		}
		return result.join("");
	};

	// import a list of modules into the list
	list.i = function(modules, mediaQuery) {
		if(typeof modules === "string")
			modules = [[null, modules, ""]];
		var alreadyImportedModules = {};
		for(var i = 0; i < this.length; i++) {
			var id = this[i][0];
			if(typeof id === "number")
				alreadyImportedModules[id] = true;
		}
		for(i = 0; i < modules.length; i++) {
			var item = modules[i];
			// skip already imported module
			// this implementation is not 100% perfect for weird media query combinations
			//  when a module is imported multiple times with different media queries.
			//  I hope this will never occur (Hey this way we have smaller bundles)
			if(typeof item[0] !== "number" || !alreadyImportedModules[item[0]]) {
				if(mediaQuery && !item[2]) {
					item[2] = mediaQuery;
				} else if(mediaQuery) {
					item[2] = "(" + item[2] + ") and (" + mediaQuery + ")";
				}
				list.push(item);
			}
		}
	};
	return list;
};


/***/ }),

/***/ 1:
/***/ (function(module, exports, __webpack_require__) {

/*
  MIT License http://www.opensource.org/licenses/mit-license.php
  Author Tobias Koppers @sokra
  Modified by Evan You @yyx990803
*/

var hasDocument = typeof document !== 'undefined'

if (typeof DEBUG !== 'undefined' && DEBUG) {
  if (!hasDocument) {
    throw new Error(
    'vue-style-loader cannot be used in a non-browser environment. ' +
    "Use { target: 'node' } in your Webpack config to indicate a server-rendering environment."
  ) }
}

var listToStyles = __webpack_require__(4)

/*
type StyleObject = {
  id: number;
  parts: Array<StyleObjectPart>
}

type StyleObjectPart = {
  css: string;
  media: string;
  sourceMap: ?string
}
*/

var stylesInDom = {/*
  [id: number]: {
    id: number,
    refs: number,
    parts: Array<(obj?: StyleObjectPart) => void>
  }
*/}

var head = hasDocument && (document.head || document.getElementsByTagName('head')[0])
var singletonElement = null
var singletonCounter = 0
var isProduction = false
var noop = function () {}

// Force single-tag solution on IE6-9, which has a hard limit on the # of <style>
// tags it will allow on a page
var isOldIE = typeof navigator !== 'undefined' && /msie [6-9]\b/.test(navigator.userAgent.toLowerCase())

module.exports = function (parentId, list, _isProduction) {
  isProduction = _isProduction

  var styles = listToStyles(parentId, list)
  addStylesToDom(styles)

  return function update (newList) {
    var mayRemove = []
    for (var i = 0; i < styles.length; i++) {
      var item = styles[i]
      var domStyle = stylesInDom[item.id]
      domStyle.refs--
      mayRemove.push(domStyle)
    }
    if (newList) {
      styles = listToStyles(parentId, newList)
      addStylesToDom(styles)
    } else {
      styles = []
    }
    for (var i = 0; i < mayRemove.length; i++) {
      var domStyle = mayRemove[i]
      if (domStyle.refs === 0) {
        for (var j = 0; j < domStyle.parts.length; j++) {
          domStyle.parts[j]()
        }
        delete stylesInDom[domStyle.id]
      }
    }
  }
}

function addStylesToDom (styles /* Array<StyleObject> */) {
  for (var i = 0; i < styles.length; i++) {
    var item = styles[i]
    var domStyle = stylesInDom[item.id]
    if (domStyle) {
      domStyle.refs++
      for (var j = 0; j < domStyle.parts.length; j++) {
        domStyle.parts[j](item.parts[j])
      }
      for (; j < item.parts.length; j++) {
        domStyle.parts.push(addStyle(item.parts[j]))
      }
      if (domStyle.parts.length > item.parts.length) {
        domStyle.parts.length = item.parts.length
      }
    } else {
      var parts = []
      for (var j = 0; j < item.parts.length; j++) {
        parts.push(addStyle(item.parts[j]))
      }
      stylesInDom[item.id] = { id: item.id, refs: 1, parts: parts }
    }
  }
}

function createStyleElement () {
  var styleElement = document.createElement('style')
  styleElement.type = 'text/css'
  head.appendChild(styleElement)
  return styleElement
}

function addStyle (obj /* StyleObjectPart */) {
  var update, remove
  var styleElement = document.querySelector('style[data-vue-ssr-id~="' + obj.id + '"]')

  if (styleElement) {
    if (isProduction) {
      // has SSR styles and in production mode.
      // simply do nothing.
      return noop
    } else {
      // has SSR styles but in dev mode.
      // for some reason Chrome can't handle source map in server-rendered
      // style tags - source maps in <style> only works if the style tag is
      // created and inserted dynamically. So we remove the server rendered
      // styles and inject new ones.
      styleElement.parentNode.removeChild(styleElement)
    }
  }

  if (isOldIE) {
    // use singleton mode for IE9.
    var styleIndex = singletonCounter++
    styleElement = singletonElement || (singletonElement = createStyleElement())
    update = applyToSingletonTag.bind(null, styleElement, styleIndex, false)
    remove = applyToSingletonTag.bind(null, styleElement, styleIndex, true)
  } else {
    // use multi-style-tag mode in all other cases
    styleElement = createStyleElement()
    update = applyToTag.bind(null, styleElement)
    remove = function () {
      styleElement.parentNode.removeChild(styleElement)
    }
  }

  update(obj)

  return function updateStyle (newObj /* StyleObjectPart */) {
    if (newObj) {
      if (newObj.css === obj.css &&
          newObj.media === obj.media &&
          newObj.sourceMap === obj.sourceMap) {
        return
      }
      update(obj = newObj)
    } else {
      remove()
    }
  }
}

var replaceText = (function () {
  var textStore = []

  return function (index, replacement) {
    textStore[index] = replacement
    return textStore.filter(Boolean).join('\n')
  }
})()

function applyToSingletonTag (styleElement, index, remove, obj) {
  var css = remove ? '' : obj.css

  if (styleElement.styleSheet) {
    styleElement.styleSheet.cssText = replaceText(index, css)
  } else {
    var cssNode = document.createTextNode(css)
    var childNodes = styleElement.childNodes
    if (childNodes[index]) styleElement.removeChild(childNodes[index])
    if (childNodes.length) {
      styleElement.insertBefore(cssNode, childNodes[index])
    } else {
      styleElement.appendChild(cssNode)
    }
  }
}

function applyToTag (styleElement, obj) {
  var css = obj.css
  var media = obj.media
  var sourceMap = obj.sourceMap

  if (media) {
    styleElement.setAttribute('media', media)
  }

  if (sourceMap) {
    // https://developer.chrome.com/devtools/docs/javascript-debugging
    // this makes source maps inside style tags work properly in Chrome
    css += '\n/*# sourceURL=' + sourceMap.sources[0] + ' */'
    // http://stackoverflow.com/a/26603875
    css += '\n/*# sourceMappingURL=data:application/json;base64,' + btoa(unescape(encodeURIComponent(JSON.stringify(sourceMap)))) + ' */'
  }

  if (styleElement.styleSheet) {
    styleElement.styleSheet.cssText = css
  } else {
    while (styleElement.firstChild) {
      styleElement.removeChild(styleElement.firstChild)
    }
    styleElement.appendChild(document.createTextNode(css))
  }
}


/***/ }),

/***/ 10:
/***/ (function(module, exports, __webpack_require__) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "header",
    class: [_vm.classHeader(), _vm.border == true ? '' : 'cb']
  }, [_c('div', {
    staticClass: "nav_back",
    on: {
      "click": function($event) {
        _vm.goback('/')
      }
    }
  }, [_c('text', {
    staticClass: "nav_ico",
    style: ({
      fontFamily: 'iconfont'
    })
  }, [_vm._v("")])]), _vm._v(" "), _c('div', {
    staticClass: "nav"
  }, [_c('text', {
    staticClass: "nav_title"
  }, [_vm._v(_vm._s(_vm.title))]), _vm._v(" "), (_vm.showComplete) ? _c('div', {
    staticClass: "navRightBox",
    on: {
      "click": function($event) {
        _vm.goComplete('/')
      }
    }
  }, [(_vm.complete != 'textIcon') ? _c('text', {
    staticClass: "nav_Complete nav_title"
  }, [_vm._v(_vm._s(_vm.complete))]) : _c('text', {
    staticClass: "nav_CompleteIcon",
    style: ({
      fontFamily: 'iconfont'
    })
  }, [_vm._v("")])]) : _vm._e()])])
},staticRenderFns: []}
module.exports.render._withStripped = true
if (false) {
  module.hot.accept()
  if (module.hot.data) {
     require("vue-loader/node_modules/vue-hot-reload-api").rerender("data-v-019a21a0", module.exports)
  }
}

/***/ }),

/***/ 11:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(7);
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var update = __webpack_require__(1)("ebebfb4a", content, false);
// Hot Module Replacement
if(false) {
 // When the styles change, update the <style> tags
 if(!content.locals) {
   module.hot.accept("!!../../node_modules/_css-loader@0.26.4@css-loader/index.js!../../node_modules/_vue-loader@10.3.0@vue-loader/lib/style-rewriter.js?id=data-v-019a21a0!../../node_modules/less-loader/dist/cjs.js!./wx.less", function() {
     var newContent = require("!!../../node_modules/_css-loader@0.26.4@css-loader/index.js!../../node_modules/_vue-loader@10.3.0@vue-loader/lib/style-rewriter.js?id=data-v-019a21a0!../../node_modules/less-loader/dist/cjs.js!./wx.less");
     if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
     update(newContent);
   });
 }
 // When the module is disposed, remove the <style> tags
 module.hot.dispose(function() { update(); });
}

/***/ }),

/***/ 12:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(8);
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var update = __webpack_require__(1)("5944172c", content, false);
// Hot Module Replacement
if(false) {
 // When the styles change, update the <style> tags
 if(!content.locals) {
   module.hot.accept("!!../../node_modules/_css-loader@0.26.4@css-loader/index.js!../../node_modules/_vue-loader@10.3.0@vue-loader/lib/style-rewriter.js?id=data-v-019a21a0&scoped=true!../../node_modules/_vue-loader@10.3.0@vue-loader/lib/selector.js?type=styles&index=1!./navbar.vue", function() {
     var newContent = require("!!../../node_modules/_css-loader@0.26.4@css-loader/index.js!../../node_modules/_vue-loader@10.3.0@vue-loader/lib/style-rewriter.js?id=data-v-019a21a0&scoped=true!../../node_modules/_vue-loader@10.3.0@vue-loader/lib/selector.js?type=styles&index=1!./navbar.vue");
     if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
     update(newContent);
   });
 }
 // When the module is disposed, remove the <style> tags
 module.hot.dispose(function() { update(); });
}

/***/ }),

/***/ 13:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
const dom = weex.requireModule('dom');
const event = weex.requireModule('event');
const stream = weex.requireModule('stream');
const storage = weex.requireModule('storage');
const animation = weex.requireModule('animation');
/* unused harmony default export */ var _unused_webpack_default_export = ({ dom, event, stream, storage, animation });

/***/ }),

/***/ 172:
/***/ (function(module, exports, __webpack_require__) {


/* styles */
__webpack_require__(936)
__webpack_require__(937)

var Component = __webpack_require__(3)(
  /* script */
  __webpack_require__(274),
  /* template */
  __webpack_require__(756),
  /* scopeId */
  "data-v-9278264c",
  /* cssModules */
  null
)
Component.options.__file = "/Users/zhangsr/Documents/GitHub/weex/mp/src/view/live/host.vue"
if (Component.esModule && Object.keys(Component.esModule).some(function (key) {return key !== "default" && key !== "__esModule"})) {console.error("named exports are not supported in *.vue files.")}
if (Component.options.functional) {console.error("[vue-loader] host.vue: functional components are not supported with templates, they should use render functions.")}

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-loader/node_modules/vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-9278264c", Component.options)
  } else {
    hotAPI.reload("data-v-9278264c", Component.options)
  }
})()}

module.exports = Component.exports


/***/ }),

/***/ 2:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/**
 * Created by zwwill on 2017/8/27.
 */
const resLocateURL = 'file://';
const resRemoteURL = 'http://cdn.rzico.com/weex/';
// const websiteURL = 'http://mopian.1xx.me';
const websiteURL = 'http://weixin.rzico.com';
const event = weex.requireModule('event');
const debug = false; //删掉该属性时请查找该页所有debug变量并删除变量
let utilsFunc = {
    initIconFont() {
        let domModule = weex.requireModule('dom');
        domModule.addRule('fontFace', {
            'fontFamily': "iconfont",
            'src': "url('" + resLocateURL + "resources/fonts/iconfont.ttf')"
        });
    },
    //获取本地资源
    locate(url) {
        const newUrl = resLocateURL + url;
        return newUrl;
    },
    //获取远程资源
    remote(url) {
        const newUrl = resRemoteURL + url;
        return newUrl;
    },
    //获取网站资源
    website(url) {
        const newUrl = websiteURL + url;
        return newUrl;
    },
    //获取URL参数
    getUrlParameter(name, dataUrl) {
        let url;
        if (dataUrl == null || dataUrl == undefined || dataUrl == '') {
            url = weex.config.bundleUrl;
        } else {
            url = dataUrl;
        }
        let reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
        let r = url.slice(url.indexOf('?') + 1).match(reg);
        if (r != null) {
            try {
                return decodeURIComponent(r[2]);
            } catch (_e) {
                return null;
            }
        }
        return null;
    },
    message(_type, _content, _data) {
        return {
            type: _type,
            content: _content,
            data: _data
        };
    },
    //判空
    isNull(value) {
        if (value == null || value == undefined || value == '' || value == 'undefined') {
            return true;
        } else {
            return false;
        }
    },
    //把缩略图过滤为原图
    filterThumbnail(url) {

        if (this.isNull(url)) {
            return url;
        }
        if (url.indexOf('?x-oss-') != -1) {
            url = url.substring(0, url.indexOf('?x-oss-'));
        } else if (url.indexOf('@') != -1) {
            url = url.substring(0, url.indexOf('@'));
        }
        return url;
    },
    //获取缩略图
    thumbnail(url, w, h) {
        if (this.isNull(url)) {
            return url;
        }
        //获取屏幕宽度计算得出比例
        let proportion = weex.config.env.deviceWidth / 750;
        //                获取缩略图的宽高
        w = parseInt(w * proportion);
        h = parseInt(h * proportion);
        if (url.substring(0, 11) == "http://cdnx") {
            return url + "?x-oss-process=image/resize,m_fill,w_" + w + ",h_" + h + "";
        } else if (url.substring(0, 10) == "http://cdn") {
            return url + "@" + w + "w_" + h + "h_1e_1c_100Q";
        } else {
            return url;
        }
    },
    //获取全屏的高度尺寸,可传入父组件的导航栏高度进行适配
    fullScreen(topHeight) {
        //减1是为了能触发loading，不能够高度刚刚好
        topHeight = topHeight == '' ? 0 : topHeight - 1;
        return 750 / weex.config.env.deviceWidth * weex.config.env.deviceHeight - topHeight;
    },
    //模糊图片，r, s  为 1-50，超大超模糊
    blur(url, r, s) {
        if (this.isNull(url)) {
            return url;
        }
        if (url.substring(0, 10) == "http://cdn") {
            return url + "@" + r + "-" + s + "bl";
        } else {
            return url;
        }
    },
    //获取文章URL地址
    articleUrl(template, id) {
        template = template == '' ? 't1001' : template;
        return websiteURL + "/#/" + template + "?id=" + id;
    },
    debug(msg) {
        if (debug) {
            event.toast(msg);
        }
    },
    isRoles(roles, all) {
        for (var i = 0; i < roles.length; i++) {
            let role = roles.substring(i, i + 1);
            if (all.indexOf(role) >= 0) {
                return true;
            }
        }
        return false;
    },
    //  获取字符串的字符总长度
    getLength(e) {
        var name = e;
        var len = 0;
        for (let i = 0; i < name.length; i++) {
            var a = name.charAt(i);
            if (a.match(/[^\x00-\xff]/ig) != null) {
                len += 2;
            } else {
                len += 1;
            }
        }
        return len;
    },
    //    将过长的字符串换成 XXX...格式 默认取前7个字符
    changeStrLast(value, length, maxLength) {
        length = this.isNull(length) ? 7 : length;
        maxLength = this.isNull(maxLength) ? 16 : maxLength;
        //              如果用户名称过长，便截取拼成名字
        if (this.getLength(value) > maxLength) {
            value = value.substr(0, length) + '...';
        }
        return value;
    },

    //    将过长的字符串换成 XXX...XXX格式
    changeStr(e) {
        return e.substr(0, 4) + '...' + e.substr(-4);
    },
    //js中用正则表达式 过滤特殊字符, 校验所有输入域是否含有特殊符号 (无法过滤 \ )
    //  searchFilter(s) {
    //         event.toast(s);
    //         var pattern = new RegExp("[`~!@#$^&*()=|{}':;',\\[\\].<>/?~！@#￥……&*（）&mdash;—|{}【】‘；：”“'。，、？]");
    //         var rs = "";
    //         for (var i = 0; i < s.length; i++) {
    //             rs = rs + s.substr(i, 1).replace(pattern,'');
    //         }
    //         return rs;
    //     }

    //老的二维码转换成新格式
    qr2scan(e) {
        let type = this.getUrlParameter("type", e);
        let code = this.getUrlParameter("no", e);
        if (type == "paybill") {
            return websiteURL + "/q/818804" + code + ".jhtml";
        } else if (type == "card_active") {
            return websiteURL + "/q/818801" + code + ".jhtml";
        } else {
            return e;
        }
    },
    //    二维码读取内容
    readScan(e, callback) {
        e = this.qr2scan(e);
        let backData = {};
        //二维码字段截取. indexOf 没找到时返回-1， 此时如果2个indexof都没找到 那么 e.substring（-1 + 3 ，-1）,e的长度会变为2
        // let subData = e.substring(e.indexOf("/q/8") + 3,e.indexOf(".jhtml"));

        let start = e.indexOf("/q/8");
        let end = e.indexOf(".jhtml");
        var subData = null;
        if (start != -1 && end != -1) {
            subData = e.substring(start + 3, end);
        }
        //判断是不是web  code'000000'为无效二维码 '999999'为webView；
        if (subData == null) {
            //如果没有找到q/ 和 .jhtml中的字端，就执行该段代码
            if (e.substring(0, 4) == 'http' && debug) {
                let data = {
                    type: 'webView',
                    code: '999999'
                };
                backData = this.message('success', 'webView', data);
            } else {
                let data = {
                    type: 'error',
                    code: '000000'
                };
                backData = this.message('error', '无效二维码', data);
            }
            callback(backData);
        } else {
            //截取11位的判断码
            let type = subData.substring(0, 6);
            let code = subData.slice(6);
            let data = {
                type: type,
                code: code
            };
            if (code == '000000') {
                backData = this.message('error', '无效二维码', data);
            } else {
                backData = this.message('success', '扫描成功', data);
            }
            callback(backData);
        }
    },
    //判断用户是否只输入了空格
    isAllEmpty(str) {
        if (str.replace(/ /g, "").length == 0) {
            return true;
        } else {
            return false;
        }
    },
    //判断设备型号
    device: function () {
        let s = weex.config.env.deviceModel;
        if (this.isNull(s)) {
            return "";
        } else {
            if (s.indexOf("V1") > 0) {
                return "V1";
            } else if (s.indexOf("10,3") > 0 || s.indexOf("10,6") > 0) {
                return 'IPhoneX';
            } else {
                return s;
            }
        }
    },

    //    登录主页的轮播图控制
    indexMt() {
        let s = this.device();
        if (this.isNull(s)) {
            return "";
        } else {
            if (s == 'V1') {
                return 'indexMtV1';
            } else if (s == 'IPhoneX') {
                return 'indexMtIPhoneX';
            } else {
                return s;
            }
        }
    },

    //    登录主页的轮播图slider控制
    indexMtSlider() {
        let s = this.device();
        if (this.isNull(s)) {
            return "";
        } else {
            if (s == 'IPhoneX') {
                return 'indexSliderMtIPhoneX';
            } else if (this.isIosSystem()) {
                return 'indexSliderMtIPhone';
            } else {
                return s;
            }
        }
    },

    //    判断设备型号为fix定位的元素添加高度 (会员首页 作者专栏 顶部设置跟返回按钮)
    addTop: function () {
        let s = this.device();
        if (this.isNull(s)) {
            return "";
        } else {
            if (s == 'V1') {
                return 'addTopV1';
            } else if (s == 'IPhoneX') {
                return 'addTopIPhoneX';
            } else {
                return s;
            }
        }
    },
    //   会员首页 作者专栏 顶部信息栏
    addInfo: function () {
        let s = this.device();
        if (this.isNull(s)) {
            return "";
        } else {
            if (s == 'V1') {
                return 'addInfoV1';
            } else if (s == 'IPhoneX') {
                return 'addInfoIPhoneX';
            } else {
                return s;
            }
        }
    },
    //    判断设备型号为fix定位的元素添加高度 (会员首页 作者专栏 顶部设置跟返回按钮)
    addBgImg: function () {
        let s = this.device();
        if (this.isNull(s)) {
            return "";
        } else {
            if (s == 'V1') {
                return 'addBgImgV1';
            } else if (s == 'IPhoneX') {
                return 'addBgImgIPhoneX';
            } else {
                return s;
            }
        }
    },
    //    控制滑动时文集box的显示
    hideCorpus: function () {
        let s = this.device();
        if (this.isNull(s)) {
            return "";
        } else {
            if (s == 'V1') {
                return 'hideCorpusV1';
            } else if (s == 'IPhoneX') {
                return 'hideCorpusIPhoneX';
            } else {
                return s;
            }
        }
    },
    //    控制滑动时文集box的显示
    pageTop: function () {
        let s = this.device();
        if (this.isNull(s)) {
            return "";
        } else {
            if (s == 'V1') {
                return 'pageTopV1';
            } else if (s == 'IPhoneX') {
                return 'pageTopIPhoneX';
            } else {
                return s;
            }
        }
    },
    //    控制preview文章box的top
    artOutTop: function () {
        let s = this.device();
        if (this.isNull(s)) {
            return "";
        } else {
            if (s == 'V1') {
                return 'artOutBoxTopV1';
            } else if (s == 'IPhoneX') {
                return 'artOutBoxTopIPhoneX';
            } else {
                return s;
            }
        }
    },
    //    控制预览文章页底部栏的bottom高度
    previewBottom: function () {
        let s = this.device();
        if (this.isNull(s)) {
            return '';
        } else {
            if (s == 'IPhoneX') {
                return s;
            } else {
                return '';
            }
        }
    },

    //判断设备系统是不是ios
    isIosSystem: function () {
        let s = weex.config.env.osName;
        if (s == 'iOS') {
            return true;
        } else {
            return false;
        }
    },

    resolvetimefmt: function (value) {
        if (this.isNull(value)) {
            return value;
        }
        //value 传进来是个整数型，要判断是10位还是13位需要转成字符串。这边的方法是检测13位的时间戳 所以要*1000；并且转回整型。安卓下，时间早了8个小时
        if (value.toString().length == 10) {
            value = parseInt(value) * 1000;
        } else {
            value = parseInt(value);
        }
        // 返回处理后的值
        var date = new Date(value);

        var d2 = Date.UTC(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate(), date.getUTCHours(), date.getUTCMinutes(), date.getUTCSeconds());

        date = new Date(d2 + 28800000);

        var y = date.getUTCFullYear();
        var m = date.getUTCMonth() + 1;
        var d = date.getUTCDate();
        var h = date.getUTCHours();
        var i = date.getUTCMinutes();
        var s = date.getUTCSeconds();
        if (m < 10) {
            m = '0' + m;
        }
        if (d < 10) {
            d = '0' + d;
        }
        if (h < 10) {
            h = '0' + h;
        }
        if (i < 10) {
            i = '0' + i;
        }
        if (s < 10) {
            s = '0' + s;
        }
        let timeObj = {
            y: y,
            m: m,
            d: d,
            h: h,
            i: i,
            s: s
        };
        return timeObj;
    },
    //返回格式 2017-09-01
    ymdtimefmt: function (value) {
        if (value == '' || value == null || value == undefined) {
            return value;
        }
        let timeObj = this.resolvetimefmt(value);
        return timeObj.y + '-' + timeObj.m + '-' + timeObj.d;
    },
    //返回格式 2017-09-01 06:35:59
    ymdhistimefmt: function (value) {
        if (value == '' || value == null || value == undefined) {
            return value;
        }
        let timeObj = this.resolvetimefmt(value);

        return timeObj.y + '-' + timeObj.m + '-' + timeObj.d + ' ' + timeObj.h + ':' + timeObj.i + ':' + timeObj.s;
    },
    //返回格式 2017年09月01日 06:35:59
    ymdhisdayfmt: function (value) {
        if (value == '' || value == null || value == undefined) {
            return value;
        }
        let timeObj = this.resolvetimefmt(value);

        return timeObj.y + '年' + timeObj.m + '月' + timeObj.d + '日' + ' ' + timeObj.h + ':' + timeObj.i + ':' + timeObj.s;
    },
    //返回格式 06:35:59
    histimefmt: function (value) {
        if (value == '' || value == null || value == undefined) {
            return value;
        }
        let timeObj = this.resolvetimefmt(value);
        return timeObj.h + ':' + timeObj.i + ':' + timeObj.s;
    },
    //过滤表情
    filteremoji(text, type) {
        var ranges = ['\ud83c[\udf00-\udfff]', '\ud83d[\udc00-\ude4f]', '\ud83d[\ude80-\udeff]'];
        text = text.replace(new RegExp(ranges.join('|'), 'g'), '');
        if (this.isNull(text) && type == 'article') {
            return '点击设置标题';
        }
        return text;
    },
    //金额保留两位小数点
    currencyfmt(value) {
        if (value == '' || value == null || value == undefined) {
            return value;
        }
        // 返回处理后的值
        if (value != null) {
            if (value == 0) {
                return value;
            } else {
                var price = (Math.round(value * Math.pow(10, 2)) / Math.pow(10, 2)).toFixed(2);
                return price;
            }
        }
    }
};

/* harmony default export */ __webpack_exports__["a"] = (utilsFunc);

/***/ }),

/***/ 274:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__weex_js__ = __webpack_require__(13);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__assets_letter__ = __webpack_require__(51);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__include_navbar_vue__ = __webpack_require__(9);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__include_navbar_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2__include_navbar_vue__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__assets_fetch__ = __webpack_require__(5);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__assets_utils__ = __webpack_require__(2);
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//






const animation = weex.requireModule('animation');
const livePlayer = weex.requireModule('livePlayer');
const modal = weex.requireModule('modal');
/* harmony default export */ __webpack_exports__["default"] = ({
    data: function () {
        return {
            infoData: [
                //                    {
                //                    autograph:'输入的日期格式错误输入的日期格式错误输入的日期格式错误输入的日期格式错误输入的日期格式错误',
                //                    birth:'1500048000000',
                //                    logo:utils.locate('resources/images/background.png'),
                //                    nickName:'程序',
                //                    gender:'male',
                //                    vip:2,
                //                    follow:5,
                //                    fans:2,
                //                    userId:'u10100'
                //                }
            ],
            //                headImage:utils.locate('resources/images/background.png'),
            //                headImage:'https://ss0.bdstatic.com/94oJfD_bAAcT8t7mm9GUKT-xh_/timg?image&quality=100&size=b4000_4000&sec=1522811100&di=5570cc3ef01b85c21e54b7fb29a97756&src=http://img4q.duitang.com/uploads/item/201305/03/20130503034918_envh2.jpeg',
            //                nickName:'珍珠火凤凰',
            //                userSign:'TA好像忘记签名了',
            //                印票
            //                ticketImgList:[utils.locate('resources/images/background.png'),
            //                    utils.locate('resources/images/background.png'),
            //                    utils.locate('resources/images/background.png'),],
            bottomNum: 0,
            screenHeight: 0,
            pageName: '个人信息',
            id: '',
            //                是否关注
            isFocus: false,
            groupId: '',
            clicked: false,
            //                是否用户
            isUser: true,
            //                是否禁言
            isGag: false,
            //                是否管理员
            isManager: false,
            userId: '',
            hasManager: false
        };
    },
    created() {
        let _this = this;
        __WEBPACK_IMPORTED_MODULE_4__assets_utils__["a" /* default */].initIconFont();
        //            判断是iponex就动态获取底部上弹高度
        if (__WEBPACK_IMPORTED_MODULE_4__assets_utils__["a" /* default */].previewBottom() != '' && __WEBPACK_IMPORTED_MODULE_4__assets_utils__["a" /* default */].previewBottom() == 'IPhoneX') {
            this.bottomNum = parseInt(__WEBPACK_IMPORTED_MODULE_0__weex_js__["event"].deviceInfo().bottomHeight) * 2;
        }
        this.isUser = __WEBPACK_IMPORTED_MODULE_4__assets_utils__["a" /* default */].getUrlParameter('isUser');
        if (this.isUser == 'false') {
            this.isUser = false;
        }
        if (this.isUser == 'true') {
            this.isUser = true;
        }
        this.id = __WEBPACK_IMPORTED_MODULE_4__assets_utils__["a" /* default */].getUrlParameter('id');
        this.userId = 'u' + (10200 + parseInt(this.id));
        this.groupId = __WEBPACK_IMPORTED_MODULE_4__assets_utils__["a" /* default */].getUrlParameter('groupId');

        //            获取相关管理员权限
        this.managerInfo();

        livePlayer.getGag(this.userId, this.groupId, function (data) {
            _this.isGag = data.data;
            if (_this.isGag == 'false') {
                _this.isGag = false;
            }
            if (_this.isGag == 'true') {
                _this.isGag = true;
            }
        });
        //            this.screenHeight = utils.fullScreen(305 );
        this.screenHeight = __WEBPACK_IMPORTED_MODULE_4__assets_utils__["a" /* default */].fullScreen(237 + this.bottomNum);
        this.getInfo();
    },
    filters: {
        watchHeadImage: function (value) {
            if (value != __WEBPACK_IMPORTED_MODULE_4__assets_utils__["a" /* default */].locate('resources/images/background.png')) {
                return __WEBPACK_IMPORTED_MODULE_4__assets_utils__["a" /* default */].thumbnail(value, 200, 200);
            } else {
                return value;
            }
        },
        watchOccupation: function (value) {
            return "你猜";
        },
        watchNickName: function (value) {
            if (__WEBPACK_IMPORTED_MODULE_4__assets_utils__["a" /* default */].isNull(value)) {
                return 'host';
            } else {
                return value;
            }
        },
        watchLogo: function (value) {
            if (__WEBPACK_IMPORTED_MODULE_4__assets_utils__["a" /* default */].isNull(value)) {
                return __WEBPACK_IMPORTED_MODULE_4__assets_utils__["a" /* default */].locate('resources/images/background.png');
            } else {
                return value;
            }
        },
        watchBirth: function (value) {
            if (__WEBPACK_IMPORTED_MODULE_4__assets_utils__["a" /* default */].isNull(value)) {
                return "你猜";
            }
            //            日期计算年龄
            var str = __WEBPACK_IMPORTED_MODULE_4__assets_utils__["a" /* default */].ymdtimefmt(value);
            var r = str.match(/^(\d{1,4})(-|\/)(\d{1,2})\2(\d{1,2})$/);
            if (r == null) return "你猜";
            var d = new Date(r[1], r[3] - 1, r[4]);
            if (d.getFullYear() == r[1] && d.getMonth() + 1 == r[3] && d.getDate() == r[4]) {
                var Y = new Date().getFullYear();
                return Y - r[1] + " 岁";
            }
            return "你猜";
        },
        watchAutograph: function (value) {
            if (__WEBPACK_IMPORTED_MODULE_4__assets_utils__["a" /* default */].isNull(value)) {
                return 'TA好像忘记签名了';
            } else {
                return value;
            }
        }
    },
    methods: {
        //            获取相关管理员权限
        managerInfo() {
            let _this = this;
            if (!this.isUser) {
                __webpack_require__.i(__WEBPACK_IMPORTED_MODULE_3__assets_fetch__["a" /* GET */])('weex/live/admin/view.jhtml?liveId=' + _this.groupId + '&memberId=' + this.id, function (mes) {
                    if (mes.type == 'success' && (mes.data == true || mes.data == 'true')) {
                        _this.hasManager = mes.data;
                    }
                }, function (err) {
                    __WEBPACK_IMPORTED_MODULE_0__weex_js__["event"].toast(err.content);
                });
            } else {
                __webpack_require__.i(__WEBPACK_IMPORTED_MODULE_3__assets_fetch__["a" /* GET */])('weex/live/admin/view.jhtml?liveId=' + _this.groupId, function (mes) {
                    if (mes.type == 'success' && (mes.data == true || mes.data == 'true')) {
                        _this.isManager = mes.data;
                    }
                }, function (err) {
                    __WEBPACK_IMPORTED_MODULE_0__weex_js__["event"].toast(err.content);
                });
            }
        },
        hasVip: function (vip) {
            if (__WEBPACK_IMPORTED_MODULE_4__assets_utils__["a" /* default */].isNull(vip)) {
                return false;
            } else {
                return true;
            }
        },
        classHeader: function () {
            let dc = __WEBPACK_IMPORTED_MODULE_4__assets_utils__["a" /* default */].device();
            return dc;
        },
        //            点击返回
        goback() {
            __WEBPACK_IMPORTED_MODULE_0__weex_js__["event"].closeURL();
        },
        getInfo() {
            let _this = this;
            __webpack_require__.i(__WEBPACK_IMPORTED_MODULE_3__assets_fetch__["a" /* GET */])('weex/user/view.jhtml?id=' + this.id, function (data) {
                if (data.type == 'success') {
                    //                        if(!utils.isNull(data.data.logo)){
                    //                            _this.headImage = data.data.logo;
                    //                        }
                    //                        if(!utils.isNull(data.data.nickName)){
                    //                            _this.nickName = data.data.nickName;
                    //                        }
                    _this.isFocus = data.data.isfollow;
                    _this.infoData.push(data.data);
                } else {
                    __WEBPACK_IMPORTED_MODULE_0__weex_js__["event"].toast(data.content);
                }
            }, function (err) {
                __WEBPACK_IMPORTED_MODULE_0__weex_js__["event"].toast(err.content);
            });
        },
        //            前往聊天
        goChat() {
            //                let userId = 'u' + (10200 + parseInt(this.id));
            __WEBPACK_IMPORTED_MODULE_0__weex_js__["event"].navToChat(this.userId);
        },
        toGag() {
            //防止重复点击按钮
            if (this.clicked) {
                return;
            }
            this.clicked = true;
            var _this = this;
            setTimeout(function () {
                _this.clicked = false;
            }, 1500);
            //                let userId = 'u' + (10200 + parseInt(this.id));
            var gagTime = '1';
            if (!_this.isGag) {
                gagTime = '86400';
            }
            livePlayer.toGag(this.userId, this.infoData[0].nickName, this.groupId, gagTime, function (data) {
                if (data.type == 'success') {
                    //                        livePlayer.getGag(userId,_this.groupId,function(mes){
                    //                            if(mes.data){
                    if (!_this.isGag) {
                        __WEBPACK_IMPORTED_MODULE_0__weex_js__["event"].toast('禁言成功');
                    } else {
                        __WEBPACK_IMPORTED_MODULE_0__weex_js__["event"].toast('解除禁言成功');
                    }
                    _this.isGag = !_this.isGag;
                    //                            }else{
                    //                                event.toast('系统繁忙,请稍后重试');
                    //                            }
                    //                        })
                } else {
                    __WEBPACK_IMPORTED_MODULE_0__weex_js__["event"].toast(data.content);
                }
            });
        },
        //            关注
        focus: function () {
            //防止重复点击按钮
            if (this.clicked) {
                return;
            }
            this.clicked = true;
            var _this = this;
            setTimeout(function () {
                _this.clicked = false;
            }, 1500);
            if (this.isFocus) {
                __webpack_require__.i(__WEBPACK_IMPORTED_MODULE_3__assets_fetch__["b" /* POST */])('weex/member/follow/delete.jhtml?authorId=' + this.id).then(function (data) {
                    if (data.type == 'success') {
                        _this.isFocus = !_this.isFocus;
                        //                                event.sendGlobalEvent('onUserInfoChange',data);
                    } else {
                        __WEBPACK_IMPORTED_MODULE_0__weex_js__["event"].toast(data.content);
                    }
                }, function (err) {
                    __WEBPACK_IMPORTED_MODULE_0__weex_js__["event"].toast(err.content);
                });
            } else {
                __webpack_require__.i(__WEBPACK_IMPORTED_MODULE_3__assets_fetch__["b" /* POST */])('weex/member/follow/add.jhtml?authorId=' + this.id).then(function (data) {
                    if (data.type == 'success') {
                        _this.isFocus = !_this.isFocus;
                        //                                event.sendGlobalEvent('onUserInfoChange',data);
                    } else {
                        __WEBPACK_IMPORTED_MODULE_0__weex_js__["event"].toast(data.content);
                    }
                }, function (err) {
                    __WEBPACK_IMPORTED_MODULE_0__weex_js__["event"].toast(err.content);
                });
            }
        },

        //            监听设备型号,控制导航栏设置 返回按钮
        classTop: function () {
            let dc = __WEBPACK_IMPORTED_MODULE_4__assets_utils__["a" /* default */].addTop();
            return dc;
        },
        //            设置管理员
        setManager() {
            this.hasManager = !this.hasManager;
            return;
            //防止重复点击按钮
            if (this.clicked) {
                return;
            }
            this.clicked = true;
            var _this = this;
            setTimeout(function () {
                _this.clicked = false;
            }, 1500);
            if (this.hasManager) {
                modal.confirm({
                    message: '是否收回该用户的管理员资格?',
                    duration: 0.3,
                    okTitle: '确定',
                    cancelTitle: '取消'
                }, function (value) {
                    if (value == '确定') {
                        __webpack_require__.i(__WEBPACK_IMPORTED_MODULE_3__assets_fetch__["b" /* POST */])('weex/live/admin/delete.jhtml?id=' + _this.id + '&liveId=' + _this.groupId).then(function (data) {
                            if (data.type == 'success') {
                                __WEBPACK_IMPORTED_MODULE_0__weex_js__["event"].toast('收回资格成功');
                                _this.hasManager = !_this.hasManager;
                            } else {
                                __WEBPACK_IMPORTED_MODULE_0__weex_js__["event"].toast(data.content);
                            }
                        }, function (err) {
                            __WEBPACK_IMPORTED_MODULE_0__weex_js__["event"].toast(err.content);
                        });
                    }
                });
            } else {
                modal.confirm({
                    message: '是否将该用户升为管理员?',
                    duration: 0.3,
                    okTitle: '确定',
                    cancelTitle: '取消'
                }, function (value) {
                    if (value == '确定') {
                        __webpack_require__.i(__WEBPACK_IMPORTED_MODULE_3__assets_fetch__["b" /* POST */])('weex/live/admin/add.jhtml?id=' + _this.id + '&liveId=' + _this.groupId).then(function (data) {
                            if (data.type == 'success') {
                                __WEBPACK_IMPORTED_MODULE_0__weex_js__["event"].toast('升为管理员成功');
                                _this.hasManager = !_this.hasManager;
                            } else {
                                __WEBPACK_IMPORTED_MODULE_0__weex_js__["event"].toast(data.content);
                            }
                        }, function (err) {
                            __WEBPACK_IMPORTED_MODULE_0__weex_js__["event"].toast(err.content);
                        });
                    }
                });
            }
        },
        //            踢人
        tickOut() {
            //防止重复点击按钮
            if (this.clicked) {
                return;
            }
            this.clicked = true;
            var _this = this;
            setTimeout(function () {
                _this.clicked = false;
            }, 1500);
            modal.confirm({
                message: '是否将该用户踢出直播间?',
                duration: 0.3,
                okTitle: '确定',
                cancelTitle: '取消'
            }, function (value) {
                if (value == '确定') {
                    //                        let userId = 'u' + (10200 + parseInt(_this.id));
                    livePlayer.toKick(_this.userId, _this.infoData[0].nickName, function (data) {
                        if (data.type == 'success') {
                            __WEBPACK_IMPORTED_MODULE_0__weex_js__["event"].toast('踢出成功');
                            __WEBPACK_IMPORTED_MODULE_0__weex_js__["event"].closeURL();
                        } else {
                            __WEBPACK_IMPORTED_MODULE_0__weex_js__["event"].toast(data.content);
                        }
                    });
                }
            });
        }
    }
});

/***/ }),

/***/ 3:
/***/ (function(module, exports) {

module.exports = function normalizeComponent (
  rawScriptExports,
  compiledTemplate,
  scopeId,
  cssModules
) {
  var esModule
  var scriptExports = rawScriptExports = rawScriptExports || {}

  // ES6 modules interop
  var type = typeof rawScriptExports.default
  if (type === 'object' || type === 'function') {
    esModule = rawScriptExports
    scriptExports = rawScriptExports.default
  }

  // Vue.extend constructor export interop
  var options = typeof scriptExports === 'function'
    ? scriptExports.options
    : scriptExports

  // render functions
  if (compiledTemplate) {
    options.render = compiledTemplate.render
    options.staticRenderFns = compiledTemplate.staticRenderFns
  }

  // scopedId
  if (scopeId) {
    options._scopeId = scopeId
  }

  // inject cssModules
  if (cssModules) {
    var computed = options.computed || (options.computed = {})
    Object.keys(cssModules).forEach(function (key) {
      var module = cssModules[key]
      computed[key] = function () { return module }
    })
  }

  return {
    esModule: esModule,
    exports: scriptExports,
    options: options
  }
}


/***/ }),

/***/ 385:
/***/ (function(module, exports, __webpack_require__) {

var App = __webpack_require__(172);
App.el = '#root';
new Vue(App);

/***/ }),

/***/ 4:
/***/ (function(module, exports) {

/**
 * Translates the list format produced by css-loader into something
 * easier to manipulate.
 */
module.exports = function listToStyles (parentId, list) {
  var styles = []
  var newStyles = {}
  for (var i = 0; i < list.length; i++) {
    var item = list[i]
    var id = item[0]
    var css = item[1]
    var media = item[2]
    var sourceMap = item[3]
    var part = {
      id: parentId + ':' + i,
      css: css,
      media: media,
      sourceMap: sourceMap
    }
    if (!newStyles[id]) {
      styles.push(newStyles[id] = { id: id, parts: [part] })
    } else {
      newStyles[id].parts.push(part)
    }
  }
  return styles
}


/***/ }),

/***/ 5:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (immutable) */ __webpack_exports__["b"] = POST;
/* harmony export (immutable) */ __webpack_exports__["a"] = GET;
/* harmony export (immutable) */ __webpack_exports__["c"] = SCAN;
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__utils_js__ = __webpack_require__(2);
const stream = weex.requireModule('stream');
const modal = weex.requireModule('modal');
const baseURL = '';

const event = weex.requireModule('event');
function POST(path, body) {
    return new Promise((resolve, reject) => {
        stream.fetch({
            method: 'POST',
            url: `${baseURL}${path}`,
            type: 'json',
            body: `${body}`
        }, response => {
            if (response.status == 200) {
                resolve(response.data);
            } else {
                reject({
                    type: "error",
                    content: "网络不稳定"
                });
            }
        }, () => {});
    });
}

function GET(path, resolve, reject) {
    // let cacheParams = {
    //     type:'httpCache',//类型
    //     key:`${baseURL}${path}`,//关键址
    // }
    // event.find(cacheParams,function (cache) {
    //    if (cache.type=='success') {
    //        if (cache.data != '') {
    //            resolve(JSON.parse(cache.data.value));
    //        }
    //    }
    // })
    stream.fetch({
        method: 'GET',
        url: `${baseURL}${path}`,
        type: 'json'
    }, response => {
        //请求 type=success 或 warn 或 error（没缓存） 时返回，都能正常获取数据
        if (response.status == 200) {
            resolve(response.data);
        } else
            //请求 type= error 网络正常，但服务器返回错误，有缓存，也需要给数据，并提示出错了  statusText=服务器返回的 content
            //网络异常，有缓存，需要给出缓存数据，并且   statusText 固定为 "网络不稳定"
            if (response.status == 304) {
                resolve(response.data);
                reject({
                    type: "error",
                    content: response.statusText
                });
            } else
                //网络异常，没有缓存
                {
                    reject({
                        type: "error",
                        content: '网络不稳定'
                    });
                }
    }, () => {});
}
//二维码扫描
function SCAN(message, resolve, reject) {
    if (message.type == 'success') {
        __WEBPACK_IMPORTED_MODULE_0__utils_js__["a" /* default */].readScan(message.data, function (data) {
            if (data.type == 'success') {
                if (data.data.type == '865380') {
                    let userId = parseInt(data.data.code) - 10200;
                    POST('weex/member/friends/add.jhtml?friendId=' + userId).then(function (mes) {
                        if (mes.type == "success") {
                            event.toast('添加好友请求已发送,请等待对方验证');
                        } else {
                            event.toast(mes.content);
                        }
                        resolve(mes);
                    }, function (err) {
                        reject(err);
                        event.toast(err.content);
                    });
                } else if (data.data.type == '818803') {
                    GET('weex/member/couponCode/use.jhtml?code=' + data.data.code, function (mes) {
                        modal.alert({
                            message: mes.content,
                            duration: 0.3
                        }, function (value) {});
                    }, function (err) {
                        event.toast(err.content);
                    });
                } else if (data.data.type == 'webView') {
                    event.openURL(message.data, function () {});
                } else {
                    event.toast('无效验证码');
                }
            } else {
                event.toast(data.content);
            }
        });
    } else {}
}

/***/ }),

/***/ 51:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
//定义汉字字典
const dictFirstLetter = {};
dictFirstLetter.all = "YDYQSXMWZSSXJBYMGCCZQPSSQBYCDSCDQLDYLYBSSJGYZZJJFKCCLZDHWDWZJLJPFYYNWJJTMYHZWZHFLZPPQHGSCYYYNJQYXXGJHHSDSJNKKTMOMLCRXYPSNQSECCQZGGLLYJLMYZZSECYKYYHQWJSSGGYXYZYJWWKDJHYCHMYXJTLXJYQBYXZLDWRDJRWYSRLDZJPCBZJJBRCFTLECZSTZFXXZHTRQHYBDLYCZSSYMMRFMYQZPWWJJYFCRWFDFZQPYDDWYXKYJAWJFFXYPSFTZYHHYZYSWCJYXSCLCXXWZZXNBGNNXBXLZSZSBSGPYSYZDHMDZBQBZCWDZZYYTZHBTSYYBZGNTNXQYWQSKBPHHLXGYBFMJEBJHHGQTJCYSXSTKZHLYCKGLYSMZXYALMELDCCXGZYRJXSDLTYZCQKCNNJWHJTZZCQLJSTSTBNXBTYXCEQXGKWJYFLZQLYHYXSPSFXLMPBYSXXXYDJCZYLLLSJXFHJXPJBTFFYABYXBHZZBJYZLWLCZGGBTSSMDTJZXPTHYQTGLJSCQFZKJZJQNLZWLSLHDZBWJNCJZYZSQQYCQYRZCJJWYBRTWPYFTWEXCSKDZCTBZHYZZYYJXZCFFZZMJYXXSDZZOTTBZLQWFCKSZSXFYRLNYJMBDTHJXSQQCCSBXYYTSYFBXDZTGBCNSLCYZZPSAZYZZSCJCSHZQYDXLBPJLLMQXTYDZXSQJTZPXLCGLQTZWJBHCTSYJSFXYEJJTLBGXSXJMYJQQPFZASYJNTYDJXKJCDJSZCBARTDCLYJQMWNQNCLLLKBYBZZSYHQQLTWLCCXTXLLZNTYLNEWYZYXCZXXGRKRMTCNDNJTSYYSSDQDGHSDBJGHRWRQLYBGLXHLGTGXBQJDZPYJSJYJCTMRNYMGRZJCZGJMZMGXMPRYXKJNYMSGMZJYMKMFXMLDTGFBHCJHKYLPFMDXLQJJSMTQGZSJLQDLDGJYCALCMZCSDJLLNXDJFFFFJCZFMZFFPFKHKGDPSXKTACJDHHZDDCRRCFQYJKQCCWJDXHWJLYLLZGCFCQDSMLZPBJJPLSBCJGGDCKKDEZSQCCKJGCGKDJTJDLZYCXKLQSCGJCLTFPCQCZGWPJDQYZJJBYJHSJDZWGFSJGZKQCCZLLPSPKJGQJHZZLJPLGJGJJTHJJYJZCZMLZLYQBGJWMLJKXZDZNJQSYZMLJLLJKYWXMKJLHSKJGBMCLYYMKXJQLBMLLKMDXXKWYXYSLMLPSJQQJQXYXFJTJDXMXXLLCXQBSYJBGWYMBGGBCYXPJYGPEPFGDJGBHBNSQJYZJKJKHXQFGQZKFHYGKHDKLLSDJQXPQYKYBNQSXQNSZSWHBSXWHXWBZZXDMNSJBSBKBBZKLYLXGWXDRWYQZMYWSJQLCJXXJXKJEQXSCYETLZHLYYYSDZPAQYZCMTLSHTZCFYZYXYLJSDCJQAGYSLCQLYYYSHMRQQKLDXZSCSSSYDYCJYSFSJBFRSSZQSBXXPXJYSDRCKGJLGDKZJZBDKTCSYQPYHSTCLDJDHMXMCGXYZHJDDTMHLTXZXYLYMOHYJCLTYFBQQXPFBDFHHTKSQHZYYWCNXXCRWHOWGYJLEGWDQCWGFJYCSNTMYTOLBYGWQWESJPWNMLRYDZSZTXYQPZGCWXHNGPYXSHMYQJXZTDPPBFYHZHTJYFDZWKGKZBLDNTSXHQEEGZZYLZMMZYJZGXZXKHKSTXNXXWYLYAPSTHXDWHZYMPXAGKYDXBHNHXKDPJNMYHYLPMGOCSLNZHKXXLPZZLBMLSFBHHGYGYYGGBHSCYAQTYWLXTZQCEZYDQDQMMHTKLLSZHLSJZWFYHQSWSCWLQAZYNYTLSXTHAZNKZZSZZLAXXZWWCTGQQTDDYZTCCHYQZFLXPSLZYGPZSZNGLNDQTBDLXGTCTAJDKYWNSYZLJHHZZCWNYYZYWMHYCHHYXHJKZWSXHZYXLYSKQYSPSLYZWMYPPKBYGLKZHTYXAXQSYSHXASMCHKDSCRSWJPWXSGZJLWWSCHSJHSQNHCSEGNDAQTBAALZZMSSTDQJCJKTSCJAXPLGGXHHGXXZCXPDMMHLDGTYBYSJMXHMRCPXXJZCKZXSHMLQXXTTHXWZFKHCCZDYTCJYXQHLXDHYPJQXYLSYYDZOZJNYXQEZYSQYAYXWYPDGXDDXSPPYZNDLTWRHXYDXZZJHTCXMCZLHPYYYYMHZLLHNXMYLLLMDCPPXHMXDKYCYRDLTXJCHHZZXZLCCLYLNZSHZJZZLNNRLWHYQSNJHXYNTTTKYJPYCHHYEGKCTTWLGQRLGGTGTYGYHPYHYLQYQGCWYQKPYYYTTTTLHYHLLTYTTSPLKYZXGZWGPYDSSZZDQXSKCQNMJJZZBXYQMJRTFFBTKHZKBXLJJKDXJTLBWFZPPTKQTZTGPDGNTPJYFALQMKGXBDCLZFHZCLLLLADPMXDJHLCCLGYHDZFGYDDGCYYFGYDXKSSEBDHYKDKDKHNAXXYBPBYYHXZQGAFFQYJXDMLJCSQZLLPCHBSXGJYNDYBYQSPZWJLZKSDDTACTBXZDYZYPJZQSJNKKTKNJDJGYYPGTLFYQKASDNTCYHBLWDZHBBYDWJRYGKZYHEYYFJMSDTYFZJJHGCXPLXHLDWXXJKYTCYKSSSMTWCTTQZLPBSZDZWZXGZAGYKTYWXLHLSPBCLLOQMMZSSLCMBJCSZZKYDCZJGQQDSMCYTZQQLWZQZXSSFPTTFQMDDZDSHDTDWFHTDYZJYQJQKYPBDJYYXTLJHDRQXXXHAYDHRJLKLYTWHLLRLLRCXYLBWSRSZZSYMKZZHHKYHXKSMDSYDYCJPBZBSQLFCXXXNXKXWYWSDZYQOGGQMMYHCDZTTFJYYBGSTTTYBYKJDHKYXBELHTYPJQNFXFDYKZHQKZBYJTZBXHFDXKDASWTAWAJLDYJSFHBLDNNTNQJTJNCHXFJSRFWHZFMDRYJYJWZPDJKZYJYMPCYZNYNXFBYTFYFWYGDBNZZZDNYTXZEMMQBSQEHXFZMBMFLZZSRXYMJGSXWZJSPRYDJSJGXHJJGLJJYNZZJXHGXKYMLPYYYCXYTWQZSWHWLYRJLPXSLSXMFSWWKLCTNXNYNPSJSZHDZEPTXMYYWXYYSYWLXJQZQXZDCLEEELMCPJPCLWBXSQHFWWTFFJTNQJHJQDXHWLBYZNFJLALKYYJLDXHHYCSTYYWNRJYXYWTRMDRQHWQCMFJDYZMHMYYXJWMYZQZXTLMRSPWWCHAQBXYGZYPXYYRRCLMPYMGKSJSZYSRMYJSNXTPLNBAPPYPYLXYYZKYNLDZYJZCZNNLMZHHARQMPGWQTZMXXMLLHGDZXYHXKYXYCJMFFYYHJFSBSSQLXXNDYCANNMTCJCYPRRNYTYQNYYMBMSXNDLYLYSLJRLXYSXQMLLYZLZJJJKYZZCSFBZXXMSTBJGNXYZHLXNMCWSCYZYFZLXBRNNNYLBNRTGZQYSATSWRYHYJZMZDHZGZDWYBSSCSKXSYHYTXXGCQGXZZSHYXJSCRHMKKBXCZJYJYMKQHZJFNBHMQHYSNJNZYBKNQMCLGQHWLZNZSWXKHLJHYYBQLBFCDSXDLDSPFZPSKJYZWZXZDDXJSMMEGJSCSSMGCLXXKYYYLNYPWWWGYDKZJGGGZGGSYCKNJWNJPCXBJJTQTJWDSSPJXZXNZXUMELPXFSXTLLXCLJXJJLJZXCTPSWXLYDHLYQRWHSYCSQYYBYAYWJJJQFWQCQQCJQGXALDBZZYJGKGXPLTZYFXJLTPADKYQHPMATLCPDCKBMTXYBHKLENXDLEEGQDYMSAWHZMLJTWYGXLYQZLJEEYYBQQFFNLYXRDSCTGJGXYYNKLLYQKCCTLHJLQMKKZGCYYGLLLJDZGYDHZWXPYSJBZKDZGYZZHYWYFQYTYZSZYEZZLYMHJJHTSMQWYZLKYYWZCSRKQYTLTDXWCTYJKLWSQZWBDCQYNCJSRSZJLKCDCDTLZZZACQQZZDDXYPLXZBQJYLZLLLQDDZQJYJYJZYXNYYYNYJXKXDAZWYRDLJYYYRJLXLLDYXJCYWYWNQCCLDDNYYYNYCKCZHXXCCLGZQJGKWPPCQQJYSBZZXYJSQPXJPZBSBDSFNSFPZXHDWZTDWPPTFLZZBZDMYYPQJRSDZSQZSQXBDGCPZSWDWCSQZGMDHZXMWWFYBPDGPHTMJTHZSMMBGZMBZJCFZWFZBBZMQCFMBDMCJXLGPNJBBXGYHYYJGPTZGZMQBQTCGYXJXLWZKYDPDYMGCFTPFXYZTZXDZXTGKMTYBBCLBJASKYTSSQYYMSZXFJEWLXLLSZBQJJJAKLYLXLYCCTSXMCWFKKKBSXLLLLJYXTYLTJYYTDPJHNHNNKBYQNFQYYZBYYESSESSGDYHFHWTCJBSDZZTFDMXHCNJZYMQWSRYJDZJQPDQBBSTJGGFBKJBXTGQHNGWJXJGDLLTHZHHYYYYYYSXWTYYYCCBDBPYPZYCCZYJPZYWCBDLFWZCWJDXXHYHLHWZZXJTCZLCDPXUJCZZZLYXJJTXPHFXWPYWXZPTDZZBDZCYHJHMLXBQXSBYLRDTGJRRCTTTHYTCZWMXFYTWWZCWJWXJYWCSKYBZSCCTZQNHXNWXXKHKFHTSWOCCJYBCMPZZYKBNNZPBZHHZDLSYDDYTYFJPXYNGFXBYQXCBHXCPSXTYZDMKYSNXSXLHKMZXLYHDHKWHXXSSKQYHHCJYXGLHZXCSNHEKDTGZXQYPKDHEXTYKCNYMYYYPKQYYYKXZLTHJQTBYQHXBMYHSQCKWWYLLHCYYLNNEQXQWMCFBDCCMLJGGXDQKTLXKGNQCDGZJWYJJLYHHQTTTNWCHMXCXWHWSZJYDJCCDBQCDGDNYXZTHCQRXCBHZTQCBXWGQWYYBXHMBYMYQTYEXMQKYAQYRGYZSLFYKKQHYSSQYSHJGJCNXKZYCXSBXYXHYYLSTYCXQTHYSMGSCPMMGCCCCCMTZTASMGQZJHKLOSQYLSWTMXSYQKDZLJQQYPLSYCZTCQQPBBQJZCLPKHQZYYXXDTDDTSJCXFFLLCHQXMJLWCJCXTSPYCXNDTJSHJWXDQQJSKXYAMYLSJHMLALYKXCYYDMNMDQMXMCZNNCYBZKKYFLMCHCMLHXRCJJHSYLNMTJZGZGYWJXSRXCWJGJQHQZDQJDCJJZKJKGDZQGJJYJYLXZXXCDQHHHEYTMHLFSBDJSYYSHFYSTCZQLPBDRFRZTZYKYWHSZYQKWDQZRKMSYNBCRXQBJYFAZPZZEDZCJYWBCJWHYJBQSZYWRYSZPTDKZPFPBNZTKLQYHBBZPNPPTYZZYBQNYDCPJMMCYCQMCYFZZDCMNLFPBPLNGQJTBTTNJZPZBBZNJKLJQYLNBZQHKSJZNGGQSZZKYXSHPZSNBCGZKDDZQANZHJKDRTLZLSWJLJZLYWTJNDJZJHXYAYNCBGTZCSSQMNJPJYTYSWXZFKWJQTKHTZPLBHSNJZSYZBWZZZZLSYLSBJHDWWQPSLMMFBJDWAQYZTCJTBNNWZXQXCDSLQGDSDPDZHJTQQPSWLYYJZLGYXYZLCTCBJTKTYCZJTQKBSJLGMGZDMCSGPYNJZYQYYKNXRPWSZXMTNCSZZYXYBYHYZAXYWQCJTLLCKJJTJHGDXDXYQYZZBYWDLWQCGLZGJGQRQZCZSSBCRPCSKYDZNXJSQGXSSJMYDNSTZTPBDLTKZWXQWQTZEXNQCZGWEZKSSBYBRTSSSLCCGBPSZQSZLCCGLLLZXHZQTHCZMQGYZQZNMCOCSZJMMZSQPJYGQLJYJPPLDXRGZYXCCSXHSHGTZNLZWZKJCXTCFCJXLBMQBCZZWPQDNHXLJCTHYZLGYLNLSZZPCXDSCQQHJQKSXZPBAJYEMSMJTZDXLCJYRYYNWJBNGZZTMJXLTBSLYRZPYLSSCNXPHLLHYLLQQZQLXYMRSYCXZLMMCZLTZSDWTJJLLNZGGQXPFSKYGYGHBFZPDKMWGHCXMSGDXJMCJZDYCABXJDLNBCDQYGSKYDQTXDJJYXMSZQAZDZFSLQXYJSJZYLBTXXWXQQZBJZUFBBLYLWDSLJHXJYZJWTDJCZFQZQZZDZSXZZQLZCDZFJHYSPYMPQZMLPPLFFXJJNZZYLSJEYQZFPFZKSYWJJJHRDJZZXTXXGLGHYDXCSKYSWMMZCWYBAZBJKSHFHJCXMHFQHYXXYZFTSJYZFXYXPZLCHMZMBXHZZSXYFYMNCWDABAZLXKTCSHHXKXJJZJSTHYGXSXYYHHHJWXKZXSSBZZWHHHCWTZZZPJXSNXQQJGZYZYWLLCWXZFXXYXYHXMKYYSWSQMNLNAYCYSPMJKHWCQHYLAJJMZXHMMCNZHBHXCLXTJPLTXYJHDYYLTTXFSZHYXXSJBJYAYRSMXYPLCKDUYHLXRLNLLSTYZYYQYGYHHSCCSMZCTZQXKYQFPYYRPFFLKQUNTSZLLZMWWTCQQYZWTLLMLMPWMBZSSTZRBPDDTLQJJBXZCSRZQQYGWCSXFWZLXCCRSZDZMCYGGDZQSGTJSWLJMYMMZYHFBJDGYXCCPSHXNZCSBSJYJGJMPPWAFFYFNXHYZXZYLREMZGZCYZSSZDLLJCSQFNXZKPTXZGXJJGFMYYYSNBTYLBNLHPFZDCYFBMGQRRSSSZXYSGTZRNYDZZCDGPJAFJFZKNZBLCZSZPSGCYCJSZLMLRSZBZZLDLSLLYSXSQZQLYXZLSKKBRXBRBZCYCXZZZEEYFGKLZLYYHGZSGZLFJHGTGWKRAAJYZKZQTSSHJJXDCYZUYJLZYRZDQQHGJZXSSZBYKJPBFRTJXLLFQWJHYLQTYMBLPZDXTZYGBDHZZRBGXHWNJTJXLKSCFSMWLSDQYSJTXKZSCFWJLBXFTZLLJZLLQBLSQMQQCGCZFPBPHZCZJLPYYGGDTGWDCFCZQYYYQYSSCLXZSKLZZZGFFCQNWGLHQYZJJCZLQZZYJPJZZBPDCCMHJGXDQDGDLZQMFGPSYTSDYFWWDJZJYSXYYCZCYHZWPBYKXRYLYBHKJKSFXTZJMMCKHLLTNYYMSYXYZPYJQYCSYCWMTJJKQYRHLLQXPSGTLYYCLJSCPXJYZFNMLRGJJTYZBXYZMSJYJHHFZQMSYXRSZCWTLRTQZSSTKXGQKGSPTGCZNJSJCQCXHMXGGZTQYDJKZDLBZSXJLHYQGGGTHQSZPYHJHHGYYGKGGCWJZZYLCZLXQSFTGZSLLLMLJSKCTBLLZZSZMMNYTPZSXQHJCJYQXYZXZQZCPSHKZZYSXCDFGMWQRLLQXRFZTLYSTCTMJCXJJXHJNXTNRZTZFQYHQGLLGCXSZSJDJLJCYDSJTLNYXHSZXCGJZYQPYLFHDJSBPCCZHJJJQZJQDYBSSLLCMYTTMQTBHJQNNYGKYRQYQMZGCJKPDCGMYZHQLLSLLCLMHOLZGDYYFZSLJCQZLYLZQJESHNYLLJXGJXLYSYYYXNBZLJSSZCQQCJYLLZLTJYLLZLLBNYLGQCHXYYXOXCXQKYJXXXYKLXSXXYQXCYKQXQCSGYXXYQXYGYTQOHXHXPYXXXULCYEYCHZZCBWQBBWJQZSCSZSSLZYLKDESJZWMYMCYTSDSXXSCJPQQSQYLYYZYCMDJDZYWCBTJSYDJKCYDDJLBDJJSODZYSYXQQYXDHHGQQYQHDYXWGMMMAJDYBBBPPBCMUUPLJZSMTXERXJMHQNUTPJDCBSSMSSSTKJTSSMMTRCPLZSZMLQDSDMJMQPNQDXCFYNBFSDQXYXHYAYKQYDDLQYYYSSZBYDSLNTFQTZQPZMCHDHCZCWFDXTMYQSPHQYYXSRGJCWTJTZZQMGWJJTJHTQJBBHWZPXXHYQFXXQYWYYHYSCDYDHHQMNMTMWCPBSZPPZZGLMZFOLLCFWHMMSJZTTDHZZYFFYTZZGZYSKYJXQYJZQBHMBZZLYGHGFMSHPZFZSNCLPBQSNJXZSLXXFPMTYJYGBXLLDLXPZJYZJYHHZCYWHJYLSJEXFSZZYWXKZJLUYDTMLYMQJPWXYHXSKTQJEZRPXXZHHMHWQPWQLYJJQJJZSZCPHJLCHHNXJLQWZJHBMZYXBDHHYPZLHLHLGFWLCHYYTLHJXCJMSCPXSTKPNHQXSRTYXXTESYJCTLSSLSTDLLLWWYHDHRJZSFGXTSYCZYNYHTDHWJSLHTZDQDJZXXQHGYLTZPHCSQFCLNJTCLZPFSTPDYNYLGMJLLYCQHYSSHCHYLHQYQTMZYPBYWRFQYKQSYSLZDQJMPXYYSSRHZJNYWTQDFZBWWTWWRXCWHGYHXMKMYYYQMSMZHNGCEPMLQQMTCWCTMMPXJPJJHFXYYZSXZHTYBMSTSYJTTQQQYYLHYNPYQZLCYZHZWSMYLKFJXLWGXYPJYTYSYXYMZCKTTWLKSMZSYLMPWLZWXWQZSSAQSYXYRHSSNTSRAPXCPWCMGDXHXZDZYFJHGZTTSBJHGYZSZYSMYCLLLXBTYXHBBZJKSSDMALXHYCFYGMQYPJYCQXJLLLJGSLZGQLYCJCCZOTYXMTMTTLLWTGPXYMZMKLPSZZZXHKQYSXCTYJZYHXSHYXZKXLZWPSQPYHJWPJPWXQQYLXSDHMRSLZZYZWTTCYXYSZZSHBSCCSTPLWSSCJCHNLCGCHSSPHYLHFHHXJSXYLLNYLSZDHZXYLSXLWZYKCLDYAXZCMDDYSPJTQJZLNWQPSSSWCTSTSZLBLNXSMNYYMJQBQHRZWTYYDCHQLXKPZWBGQYBKFCMZWPZLLYYLSZYDWHXPSBCMLJBSCGBHXLQHYRLJXYSWXWXZSLDFHLSLYNJLZYFLYJYCDRJLFSYZFSLLCQYQFGJYHYXZLYLMSTDJCYHBZLLNWLXXYGYYHSMGDHXXHHLZZJZXCZZZCYQZFNGWPYLCPKPYYPMCLQKDGXZGGWQBDXZZKZFBXXLZXJTPJPTTBYTSZZDWSLCHZHSLTYXHQLHYXXXYYZYSWTXZKHLXZXZPYHGCHKCFSYHUTJRLXFJXPTZTWHPLYXFCRHXSHXKYXXYHZQDXQWULHYHMJTBFLKHTXCWHJFWJCFPQRYQXCYYYQYGRPYWSGSUNGWCHKZDXYFLXXHJJBYZWTSXXNCYJJYMSWZJQRMHXZWFQSYLZJZGBHYNSLBGTTCSYBYXXWXYHXYYXNSQYXMQYWRGYQLXBBZLJSYLPSYTJZYHYZAWLRORJMKSCZJXXXYXCHDYXRYXXJDTSQFXLYLTSFFYXLMTYJMJUYYYXLTZCSXQZQHZXLYYXZHDNBRXXXJCTYHLBRLMBRLLAXKYLLLJLYXXLYCRYLCJTGJCMTLZLLCYZZPZPCYAWHJJFYBDYYZSMPCKZDQYQPBPCJPDCYZMDPBCYYDYCNNPLMTMLRMFMMGWYZBSJGYGSMZQQQZTXMKQWGXLLPJGZBQCDJJJFPKJKCXBLJMSWMDTQJXLDLPPBXCWRCQFBFQJCZAHZGMYKPHYYHZYKNDKZMBPJYXPXYHLFPNYYGXJDBKXNXHJMZJXSTRSTLDXSKZYSYBZXJLXYSLBZYSLHXJPFXPQNBYLLJQKYGZMCYZZYMCCSLCLHZFWFWYXZMWSXTYNXJHPYYMCYSPMHYSMYDYSHQYZCHMJJMZCAAGCFJBBHPLYZYLXXSDJGXDHKXXTXXNBHRMLYJSLTXMRHNLXQJXYZLLYSWQGDLBJHDCGJYQYCMHWFMJYBMBYJYJWYMDPWHXQLDYGPDFXXBCGJSPCKRSSYZJMSLBZZJFLJJJLGXZGYXYXLSZQYXBEXYXHGCXBPLDYHWETTWWCJMBTXCHXYQXLLXFLYXLLJLSSFWDPZSMYJCLMWYTCZPCHQEKCQBWLCQYDPLQPPQZQFJQDJHYMMCXTXDRMJWRHXCJZYLQXDYYNHYYHRSLSRSYWWZJYMTLTLLGTQCJZYABTCKZCJYCCQLJZQXALMZYHYWLWDXZXQDLLQSHGPJFJLJHJABCQZDJGTKHSSTCYJLPSWZLXZXRWGLDLZRLZXTGSLLLLZLYXXWGDZYGBDPHZPBRLWSXQBPFDWOFMWHLYPCBJCCLDMBZPBZZLCYQXLDOMZBLZWPDWYYGDSTTHCSQSCCRSSSYSLFYBFNTYJSZDFNDPDHDZZMBBLSLCMYFFGTJJQWFTMTPJWFNLBZCMMJTGBDZLQLPYFHYYMJYLSDCHDZJWJCCTLJCLDTLJJCPDDSQDSSZYBNDBJLGGJZXSXNLYCYBJXQYCBYLZCFZPPGKCXZDZFZTJJFJSJXZBNZYJQTTYJYHTYCZHYMDJXTTMPXSPLZCDWSLSHXYPZGTFMLCJTYCBPMGDKWYCYZCDSZZYHFLYCTYGWHKJYYLSJCXGYWJCBLLCSNDDBTZBSCLYZCZZSSQDLLMQYYHFSLQLLXFTYHABXGWNYWYYPLLSDLDLLBJCYXJZMLHLJDXYYQYTDLLLBUGBFDFBBQJZZMDPJHGCLGMJJPGAEHHBWCQXAXHHHZCHXYPHJAXHLPHJPGPZJQCQZGJJZZUZDMQYYBZZPHYHYBWHAZYJHYKFGDPFQSDLZMLJXKXGALXZDAGLMDGXMWZQYXXDXXPFDMMSSYMPFMDMMKXKSYZYSHDZKXSYSMMZZZMSYDNZZCZXFPLSTMZDNMXCKJMZTYYMZMZZMSXHHDCZJEMXXKLJSTLWLSQLYJZLLZJSSDPPMHNLZJCZYHMXXHGZCJMDHXTKGRMXFWMCGMWKDTKSXQMMMFZZYDKMSCLCMPCGMHSPXQPZDSSLCXKYXTWLWJYAHZJGZQMCSNXYYMMPMLKJXMHLMLQMXCTKZMJQYSZJSYSZHSYJZJCDAJZYBSDQJZGWZQQXFKDMSDJLFWEHKZQKJPEYPZYSZCDWYJFFMZZYLTTDZZEFMZLBNPPLPLPEPSZALLTYLKCKQZKGENQLWAGYXYDPXLHSXQQWQCQXQCLHYXXMLYCCWLYMQYSKGCHLCJNSZKPYZKCQZQLJPDMDZHLASXLBYDWQLWDNBQCRYDDZTJYBKBWSZDXDTNPJDTCTQDFXQQMGNXECLTTBKPWSLCTYQLPWYZZKLPYGZCQQPLLKCCYLPQMZCZQCLJSLQZDJXLDDHPZQDLJJXZQDXYZQKZLJCYQDYJPPYPQYKJYRMPCBYMCXKLLZLLFQPYLLLMBSGLCYSSLRSYSQTMXYXZQZFDZUYSYZTFFMZZSMZQHZSSCCMLYXWTPZGXZJGZGSJSGKDDHTQGGZLLBJDZLCBCHYXYZHZFYWXYZYMSDBZZYJGTSMTFXQYXQSTDGSLNXDLRYZZLRYYLXQHTXSRTZNGZXBNQQZFMYKMZJBZYMKBPNLYZPBLMCNQYZZZSJZHJCTZKHYZZJRDYZHNPXGLFZTLKGJTCTSSYLLGZRZBBQZZKLPKLCZYSSUYXBJFPNJZZXCDWXZYJXZZDJJKGGRSRJKMSMZJLSJYWQSKYHQJSXPJZZZLSNSHRNYPZTWCHKLPSRZLZXYJQXQKYSJYCZTLQZYBBYBWZPQDWWYZCYTJCJXCKCWDKKZXSGKDZXWWYYJQYYTCYTDLLXWKCZKKLCCLZCQQDZLQLCSFQCHQHSFSMQZZLNBJJZBSJHTSZDYSJQJPDLZCDCWJKJZZLPYCGMZWDJJBSJQZSYZYHHXJPBJYDSSXDZNCGLQMBTSFSBPDZDLZNFGFJGFSMPXJQLMBLGQCYYXBQKDJJQYRFKZTJDHCZKLBSDZCFJTPLLJGXHYXZCSSZZXSTJYGKGCKGYOQXJPLZPBPGTGYJZGHZQZZLBJLSQFZGKQQJZGYCZBZQTLDXRJXBSXXPZXHYZYCLWDXJJHXMFDZPFZHQHQMQGKSLYHTYCGFRZGNQXCLPDLBZCSCZQLLJBLHBZCYPZZPPDYMZZSGYHCKCPZJGSLJLNSCDSLDLXBMSTLDDFJMKDJDHZLZXLSZQPQPGJLLYBDSZGQLBZLSLKYYHZTTNTJYQTZZPSZQZTLLJTYYLLQLLQYZQLBDZLSLYYZYMDFSZSNHLXZNCZQZPBWSKRFBSYZMTHBLGJPMCZZLSTLXSHTCSYZLZBLFEQHLXFLCJLYLJQCBZLZJHHSSTBRMHXZHJZCLXFNBGXGTQJCZTMSFZKJMSSNXLJKBHSJXNTNLZDNTLMSJXGZJYJCZXYJYJWRWWQNZTNFJSZPZSHZJFYRDJSFSZJZBJFZQZZHZLXFYSBZQLZSGYFTZDCSZXZJBQMSZKJRHYJZCKMJKHCHGTXKXQGLXPXFXTRTYLXJXHDTSJXHJZJXZWZLCQSBTXWXGXTXXHXFTSDKFJHZYJFJXRZSDLLLTQSQQZQWZXSYQTWGWBZCGZLLYZBCLMQQTZHZXZXLJFRMYZFLXYSQXXJKXRMQDZDMMYYBSQBHGZMWFWXGMXLZPYYTGZYCCDXYZXYWGSYJYZNBHPZJSQSYXSXRTFYZGRHZTXSZZTHCBFCLSYXZLZQMZLMPLMXZJXSFLBYZMYQHXJSXRXSQZZZSSLYFRCZJRCRXHHZXQYDYHXSJJHZCXZBTYNSYSXJBQLPXZQPYMLXZKYXLXCJLCYSXXZZLXDLLLJJYHZXGYJWKJRWYHCPSGNRZLFZWFZZNSXGXFLZSXZZZBFCSYJDBRJKRDHHGXJLJJTGXJXXSTJTJXLYXQFCSGSWMSBCTLQZZWLZZKXJMLTMJYHSDDBXGZHDLBMYJFRZFSGCLYJBPMLYSMSXLSZJQQHJZFXGFQFQBPXZGYYQXGZTCQWYLTLGWSGWHRLFSFGZJMGMGBGTJFSYZZGZYZAFLSSPMLPFLCWBJZCLJJMZLPJJLYMQDMYYYFBGYGYZMLYZDXQYXRQQQHSYYYQXYLJTYXFSFSLLGNQCYHYCWFHCCCFXPYLYPLLZYXXXXXKQHHXSHJZCFZSCZJXCPZWHHHHHAPYLQALPQAFYHXDYLUKMZQGGGDDESRNNZLTZGCHYPPYSQJJHCLLJTOLNJPZLJLHYMHEYDYDSQYCDDHGZUNDZCLZYZLLZNTNYZGSLHSLPJJBDGWXPCDUTJCKLKCLWKLLCASSTKZZDNQNTTLYYZSSYSSZZRYLJQKCQDHHCRXRZYDGRGCWCGZQFFFPPJFZYNAKRGYWYQPQXXFKJTSZZXSWZDDFBBXTBGTZKZNPZZPZXZPJSZBMQHKCYXYLDKLJNYPKYGHGDZJXXEAHPNZKZTZCMXCXMMJXNKSZQNMNLWBWWXJKYHCPSTMCSQTZJYXTPCTPDTNNPGLLLZSJLSPBLPLQHDTNJNLYYRSZFFJFQWDPHZDWMRZCCLODAXNSSNYZRESTYJWJYJDBCFXNMWTTBYLWSTSZGYBLJPXGLBOCLHPCBJLTMXZLJYLZXCLTPNCLCKXTPZJSWCYXSFYSZDKNTLBYJCYJLLSTGQCBXRYZXBXKLYLHZLQZLNZCXWJZLJZJNCJHXMNZZGJZZXTZJXYCYYCXXJYYXJJXSSSJSTSSTTPPGQTCSXWZDCSYFPTFBFHFBBLZJCLZZDBXGCXLQPXKFZFLSYLTUWBMQJHSZBMDDBCYSCCLDXYCDDQLYJJWMQLLCSGLJJSYFPYYCCYLTJANTJJPWYCMMGQYYSXDXQMZHSZXPFTWWZQSWQRFKJLZJQQYFBRXJHHFWJJZYQAZMYFRHCYYBYQWLPEXCCZSTYRLTTDMQLYKMBBGMYYJPRKZNPBSXYXBHYZDJDNGHPMFSGMWFZMFQMMBCMZZCJJLCNUXYQLMLRYGQZCYXZLWJGCJCGGMCJNFYZZJHYCPRRCMTZQZXHFQGTJXCCJEAQCRJYHPLQLSZDJRBCQHQDYRHYLYXJSYMHZYDWLDFRYHBPYDTSSCNWBXGLPZMLZZTQSSCPJMXXYCSJYTYCGHYCJWYRXXLFEMWJNMKLLSWTXHYYYNCMMCWJDQDJZGLLJWJRKHPZGGFLCCSCZMCBLTBHBQJXQDSPDJZZGKGLFQYWBZYZJLTSTDHQHCTCBCHFLQMPWDSHYYTQWCNZZJTLBYMBPDYYYXSQKXWYYFLXXNCWCXYPMAELYKKJMZZZBRXYYQJFLJPFHHHYTZZXSGQQMHSPGDZQWBWPJHZJDYSCQWZKTXXSQLZYYMYSDZGRXCKKUJLWPYSYSCSYZLRMLQSYLJXBCXTLWDQZPCYCYKPPPNSXFYZJJRCEMHSZMSXLXGLRWGCSTLRSXBZGBZGZTCPLUJLSLYLYMTXMTZPALZXPXJTJWTCYYZLBLXBZLQMYLXPGHDSLSSDMXMBDZZSXWHAMLCZCPJMCNHJYSNSYGCHSKQMZZQDLLKABLWJXSFMOCDXJRRLYQZKJMYBYQLYHETFJZFRFKSRYXFJTWDSXXSYSQJYSLYXWJHSNLXYYXHBHAWHHJZXWMYLJCSSLKYDZTXBZSYFDXGXZJKHSXXYBSSXDPYNZWRPTQZCZENYGCXQFJYKJBZMLJCMQQXUOXSLYXXLYLLJDZBTYMHPFSTTQQWLHOKYBLZZALZXQLHZWRRQHLSTMYPYXJJXMQSJFNBXYXYJXXYQYLTHYLQYFMLKLJTMLLHSZWKZHLJMLHLJKLJSTLQXYLMBHHLNLZXQJHXCFXXLHYHJJGBYZZKBXSCQDJQDSUJZYYHZHHMGSXCSYMXFEBCQWWRBPYYJQTYZCYQYQQZYHMWFFHGZFRJFCDPXNTQYZPDYKHJLFRZXPPXZDBBGZQSTLGDGYLCQMLCHHMFYWLZYXKJLYPQHSYWMQQGQZMLZJNSQXJQSYJYCBEHSXFSZPXZWFLLBCYYJDYTDTHWZSFJMQQYJLMQXXLLDTTKHHYBFPWTYYSQQWNQWLGWDEBZWCMYGCULKJXTMXMYJSXHYBRWFYMWFRXYQMXYSZTZZTFYKMLDHQDXWYYNLCRYJBLPSXCXYWLSPRRJWXHQYPHTYDNXHHMMYWYTZCSQMTSSCCDALWZTCPQPYJLLQZYJSWXMZZMMYLMXCLMXCZMXMZSQTZPPQQBLPGXQZHFLJJHYTJSRXWZXSCCDLXTYJDCQJXSLQYCLZXLZZXMXQRJMHRHZJBHMFLJLMLCLQNLDXZLLLPYPSYJYSXCQQDCMQJZZXHNPNXZMEKMXHYKYQLXSXTXJYYHWDCWDZHQYYBGYBCYSCFGPSJNZDYZZJZXRZRQJJYMCANYRJTLDPPYZBSTJKXXZYPFDWFGZZRPYMTNGXZQBYXNBUFNQKRJQZMJEGRZGYCLKXZDSKKNSXKCLJSPJYYZLQQJYBZSSQLLLKJXTBKTYLCCDDBLSPPFYLGYDTZJYQGGKQTTFZXBDKTYYHYBBFYTYYBCLPDYTGDHRYRNJSPTCSNYJQHKLLLZSLYDXXWBCJQSPXBPJZJCJDZFFXXBRMLAZHCSNDLBJDSZBLPRZTSWSBXBCLLXXLZDJZSJPYLYXXYFTFFFBHJJXGBYXJPMMMPSSJZJMTLYZJXSWXTYLEDQPJMYGQZJGDJLQJWJQLLSJGJGYGMSCLJJXDTYGJQJQJCJZCJGDZZSXQGSJGGCXHQXSNQLZZBXHSGZXCXYLJXYXYYDFQQJHJFXDHCTXJYRXYSQTJXYEFYYSSYYJXNCYZXFXMSYSZXYYSCHSHXZZZGZZZGFJDLTYLNPZGYJYZYYQZPBXQBDZTZCZYXXYHHSQXSHDHGQHJHGYWSZTMZMLHYXGEBTYLZKQWYTJZRCLEKYSTDBCYKQQSAYXCJXWWGSBHJYZYDHCSJKQCXSWXFLTYNYZPZCCZJQTZWJQDZZZQZLJJXLSBHPYXXPSXSHHEZTXFPTLQYZZXHYTXNCFZYYHXGNXMYWXTZSJPTHHGYMXMXQZXTSBCZYJYXXTYYZYPCQLMMSZMJZZLLZXGXZAAJZYXJMZXWDXZSXZDZXLEYJJZQBHZWZZZQTZPSXZTDSXJJJZNYAZPHXYYSRNQDTHZHYYKYJHDZXZLSWCLYBZYECWCYCRYLCXNHZYDZYDYJDFRJJHTRSQTXYXJRJHOJYNXELXSFSFJZGHPZSXZSZDZCQZBYYKLSGSJHCZSHDGQGXYZGXCHXZJWYQWGYHKSSEQZZNDZFKWYSSTCLZSTSYMCDHJXXYWEYXCZAYDMPXMDSXYBSQMJMZJMTZQLPJYQZCGQHXJHHLXXHLHDLDJQCLDWBSXFZZYYSCHTYTYYBHECXHYKGJPXHHYZJFXHWHBDZFYZBCAPNPGNYDMSXHMMMMAMYNBYJTMPXYYMCTHJBZYFCGTYHWPHFTWZZEZSBZEGPFMTSKFTYCMHFLLHGPZJXZJGZJYXZSBBQSCZZLZCCSTPGXMJSFTCCZJZDJXCYBZLFCJSYZFGSZLYBCWZZBYZDZYPSWYJZXZBDSYUXLZZBZFYGCZXBZHZFTPBGZGEJBSTGKDMFHYZZJHZLLZZGJQZLSFDJSSCBZGPDLFZFZSZYZYZSYGCXSNXXCHCZXTZZLJFZGQSQYXZJQDCCZTQCDXZJYQJQCHXZTDLGSCXZSYQJQTZWLQDQZTQCHQQJZYEZZZPBWKDJFCJPZTYPQYQTTYNLMBDKTJZPQZQZZFPZSBNJLGYJDXJDZZKZGQKXDLPZJTCJDQBXDJQJSTCKNXBXZMSLYJCQMTJQWWCJQNJNLLLHJCWQTBZQYDZCZPZZDZYDDCYZZZCCJTTJFZDPRRTZTJDCQTQZDTJNPLZBCLLCTZSXKJZQZPZLBZRBTJDCXFCZDBCCJJLTQQPLDCGZDBBZJCQDCJWYNLLZYZCCDWLLXWZLXRXNTQQCZXKQLSGDFQTDDGLRLAJJTKUYMKQLLTZYTDYYCZGJWYXDXFRSKSTQTENQMRKQZHHQKDLDAZFKYPBGGPZREBZZYKZZSPEGJXGYKQZZZSLYSYYYZWFQZYLZZLZHWCHKYPQGNPGBLPLRRJYXCCSYYHSFZFYBZYYTGZXYLXCZWXXZJZBLFFLGSKHYJZEYJHLPLLLLCZGXDRZELRHGKLZZYHZLYQSZZJZQLJZFLNBHGWLCZCFJYSPYXZLZLXGCCPZBLLCYBBBBUBBCBPCRNNZCZYRBFSRLDCGQYYQXYGMQZWTZYTYJXYFWTEHZZJYWLCCNTZYJJZDEDPZDZTSYQJHDYMBJNYJZLXTSSTPHNDJXXBYXQTZQDDTJTDYYTGWSCSZQFLSHLGLBCZPHDLYZJYCKWTYTYLBNYTSDSYCCTYSZYYEBHEXHQDTWNYGYCLXTSZYSTQMYGZAZCCSZZDSLZCLZRQXYYELJSBYMXSXZTEMBBLLYYLLYTDQYSHYMRQWKFKBFXNXSBYCHXBWJYHTQBPBSBWDZYLKGZSKYHXQZJXHXJXGNLJKZLYYCDXLFYFGHLJGJYBXQLYBXQPQGZTZPLNCYPXDJYQYDYMRBESJYYHKXXSTMXRCZZYWXYQYBMCLLYZHQYZWQXDBXBZWZMSLPDMYSKFMZKLZCYQYCZLQXFZZYDQZPZYGYJYZMZXDZFYFYTTQTZHGSPCZMLCCYTZXJCYTJMKSLPZHYSNZLLYTPZCTZZCKTXDHXXTQCYFKSMQCCYYAZHTJPCYLZLYJBJXTPNYLJYYNRXSYLMMNXJSMYBCSYSYLZYLXJJQYLDZLPQBFZZBLFNDXQKCZFYWHGQMRDSXYCYTXNQQJZYYPFZXDYZFPRXEJDGYQBXRCNFYYQPGHYJDYZXGRHTKYLNWDZNTSMPKLBTHBPYSZBZTJZSZZJTYYXZPHSSZZBZCZPTQFZMYFLYPYBBJQXZMXXDJMTSYSKKBJZXHJCKLPSMKYJZCXTMLJYXRZZQSLXXQPYZXMKYXXXJCLJPRMYYGADYSKQLSNDHYZKQXZYZTCGHZTLMLWZYBWSYCTBHJHJFCWZTXWYTKZLXQSHLYJZJXTMPLPYCGLTBZZTLZJCYJGDTCLKLPLLQPJMZPAPXYZLKKTKDZCZZBNZDYDYQZJYJGMCTXLTGXSZLMLHBGLKFWNWZHDXUHLFMKYSLGXDTWWFRJEJZTZHYDXYKSHWFZCQSHKTMQQHTZHYMJDJSKHXZJZBZZXYMPAGQMSTPXLSKLZYNWRTSQLSZBPSPSGZWYHTLKSSSWHZZLYYTNXJGMJSZSUFWNLSOZTXGXLSAMMLBWLDSZYLAKQCQCTMYCFJBSLXCLZZCLXXKSBZQCLHJPSQPLSXXCKSLNHPSFQQYTXYJZLQLDXZQJZDYYDJNZPTUZDSKJFSLJHYLZSQZLBTXYDGTQFDBYAZXDZHZJNHHQBYKNXJJQCZMLLJZKSPLDYCLBBLXKLELXJLBQYCXJXGCNLCQPLZLZYJTZLJGYZDZPLTQCSXFDMNYCXGBTJDCZNBGBQYQJWGKFHTNPYQZQGBKPBBYZMTJDYTBLSQMPSXTBNPDXKLEMYYCJYNZCTLDYKZZXDDXHQSHDGMZSJYCCTAYRZLPYLTLKXSLZCGGEXCLFXLKJRTLQJAQZNCMBYDKKCXGLCZJZXJHPTDJJMZQYKQSECQZDSHHADMLZFMMZBGNTJNNLGBYJBRBTMLBYJDZXLCJLPLDLPCQDHLXZLYCBLCXZZJADJLNZMMSSSMYBHBSQKBHRSXXJMXSDZNZPXLGBRHWGGFCXGMSKLLTSJYYCQLTSKYWYYHYWXBXQYWPYWYKQLSQPTNTKHQCWDQKTWPXXHCPTHTWUMSSYHBWCRWXHJMKMZNGWTMLKFGHKJYLSYYCXWHYECLQHKQHTTQKHFZLDXQWYZYYDESBPKYRZPJFYYZJCEQDZZDLATZBBFJLLCXDLMJSSXEGYGSJQXCWBXSSZPDYZCXDNYXPPZYDLYJCZPLTXLSXYZYRXCYYYDYLWWNZSAHJSYQYHGYWWAXTJZDAXYSRLTDPSSYYFNEJDXYZHLXLLLZQZSJNYQYQQXYJGHZGZCYJCHZLYCDSHWSHJZYJXCLLNXZJJYYXNFXMWFPYLCYLLABWDDHWDXJMCXZTZPMLQZHSFHZYNZTLLDYWLSLXHYMMYLMBWWKYXYADTXYLLDJPYBPWUXJMWMLLSAFDLLYFLBHHHBQQLTZJCQJLDJTFFKMMMBYTHYGDCQRDDWRQJXNBYSNWZDBYYTBJHPYBYTTJXAAHGQDQTMYSTQXKBTZPKJLZRBEQQSSMJJBDJOTGTBXPGBKTLHQXJJJCTHXQDWJLWRFWQGWSHCKRYSWGFTGYGBXSDWDWRFHWYTJJXXXJYZYSLPYYYPAYXHYDQKXSHXYXGSKQHYWFDDDPPLCJLQQEEWXKSYYKDYPLTJTHKJLTCYYHHJTTPLTZZCDLTHQKZXQYSTEEYWYYZYXXYYSTTJKLLPZMCYHQGXYHSRMBXPLLNQYDQHXSXXWGDQBSHYLLPJJJTHYJKYPPTHYYKTYEZYENMDSHLCRPQFDGFXZPSFTLJXXJBSWYYSKSFLXLPPLBBBLBSFXFYZBSJSSYLPBBFFFFSSCJDSTZSXZRYYSYFFSYZYZBJTBCTSBSDHRTJJBYTCXYJEYLXCBNEBJDSYXYKGSJZBXBYTFZWGENYHHTHZHHXFWGCSTBGXKLSXYWMTMBYXJSTZSCDYQRCYTWXZFHMYMCXLZNSDJTTTXRYCFYJSBSDYERXJLJXBBDEYNJGHXGCKGSCYMBLXJMSZNSKGXFBNBPTHFJAAFXYXFPXMYPQDTZCXZZPXRSYWZDLYBBKTYQPQJPZYPZJZNJPZJLZZFYSBTTSLMPTZRTDXQSJEHBZYLZDHLJSQMLHTXTJECXSLZZSPKTLZKQQYFSYGYWPCPQFHQHYTQXZKRSGTTSQCZLPTXCDYYZXSQZSLXLZMYCPCQBZYXHBSXLZDLTCDXTYLZJYYZPZYZLTXJSJXHLPMYTXCQRBLZSSFJZZTNJYTXMYJHLHPPLCYXQJQQKZZSCPZKSWALQSBLCCZJSXGWWWYGYKTJBBZTDKHXHKGTGPBKQYSLPXPJCKBMLLXDZSTBKLGGQKQLSBKKTFXRMDKBFTPZFRTBBRFERQGXYJPZSSTLBZTPSZQZSJDHLJQLZBPMSMMSXLQQNHKNBLRDDNXXDHDDJCYYGYLXGZLXSYGMQQGKHBPMXYXLYTQWLWGCPBMQXCYZYDRJBHTDJYHQSHTMJSBYPLWHLZFFNYPMHXXHPLTBQPFBJWQDBYGPNZTPFZJGSDDTQSHZEAWZZYLLTYYBWJKXXGHLFKXDJTMSZSQYNZGGSWQSPHTLSSKMCLZXYSZQZXNCJDQGZDLFNYKLJCJLLZLMZZNHYDSSHTHZZLZZBBHQZWWYCRZHLYQQJBEYFXXXWHSRXWQHWPSLMSSKZTTYGYQQWRSLALHMJTQJSMXQBJJZJXZYZKXBYQXBJXSHZTSFJLXMXZXFGHKZSZGGYLCLSARJYHSLLLMZXELGLXYDJYTLFBHBPNLYZFBBHPTGJKWETZHKJJXZXXGLLJLSTGSHJJYQLQZFKCGNNDJSSZFDBCTWWSEQFHQJBSAQTGYPQLBXBMMYWXGSLZHGLZGQYFLZBYFZJFRYSFMBYZHQGFWZSYFYJJPHZBYYZFFWODGRLMFTWLBZGYCQXCDJYGZYYYYTYTYDWEGAZYHXJLZYYHLRMGRXXZCLHNELJJTJTPWJYBJJBXJJTJTEEKHWSLJPLPSFYZPQQBDLQJJTYYQLYZKDKSQJYYQZLDQTGJQYZJSUCMRYQTHTEJMFCTYHYPKMHYZWJDQFHYYXWSHCTXRLJHQXHCCYYYJLTKTTYTMXGTCJTZAYYOCZLYLBSZYWJYTSJYHBYSHFJLYGJXXTMZYYLTXXYPZLXYJZYZYYPNHMYMDYYLBLHLSYYQQLLNJJYMSOYQBZGDLYXYLCQYXTSZEGXHZGLHWBLJHEYXTWQMAKBPQCGYSHHEGQCMWYYWLJYJHYYZLLJJYLHZYHMGSLJLJXCJJYCLYCJPCPZJZJMMYLCQLNQLJQJSXYJMLSZLJQLYCMMHCFMMFPQQMFYLQMCFFQMMMMHMZNFHHJGTTHHKHSLNCHHYQDXTMMQDCYZYXYQMYQYLTDCYYYZAZZCYMZYDLZFFFMMYCQZWZZMABTBYZTDMNZZGGDFTYPCGQYTTSSFFWFDTZQSSYSTWXJHXYTSXXYLBYQHWWKXHZXWZNNZZJZJJQJCCCHYYXBZXZCYZTLLCQXYNJYCYYCYNZZQYYYEWYCZDCJYCCHYJLBTZYYCQWMPWPYMLGKDLDLGKQQBGYCHJXY";
dictFirstLetter.polyphone = { "19969": "DZ", "19975": "WM", "19988": "QJ", "20048": "YL", "20056": "SC", "20060": "NM", "20094": "QG", "20127": "QJ", "20167": "QC", "20193": "YG", "20250": "KH", "20256": "ZC", "20282": "SC", "20285": "QJG", "20291": "TD", "20314": "YD", "20340": "NE", "20375": "TD", "20389": "YJ", "20391": "CZ", "20415": "PB", "20446": "YS", "20447": "SQ", "20504": "TC", "20608": "KG", "20854": "QJ", "20857": "ZC", "20911": "PF", "20504": "TC", "20608": "KG", "20854": "QJ", "20857": "ZC", "20911": "PF", "20985": "AW", "21032": "PB", "21048": "XQ", "21049": "SC", "21089": "YS", "21119": "JC", "21242": "SB", "21273": "SC", "21305": "YP", "21306": "QO", "21330": "ZC", "21333": "SDC", "21345": "QK", "21378": "CA", "21397": "SC", "21414": "XS", "21442": "SC", "21477": "JG", "21480": "TD", "21484": "ZS", "21494": "YX", "21505": "YX", "21512": "HG", "21523": "XH", "21537": "PB", "21542": "PF", "21549": "KH", "21571": "E", "21574": "DA", "21588": "TD", "21589": "O", "21618": "ZC", "21621": "KHA", "21632": "ZJ", "21654": "KG", "21679": "LKG", "21683": "KH", "21710": "A", "21719": "YH", "21734": "WOE", "21769": "A", "21780": "WN", "21804": "XH", "21834": "A", "21899": "ZD", "21903": "RN", "21908": "WO", "21939": "ZC", "21956": "SA", "21964": "YA", "21970": "TD", "22003": "A", "22031": "JG", "22040": "XS", "22060": "ZC", "22066": "ZC", "22079": "MH", "22129": "XJ", "22179": "XA", "22237": "NJ", "22244": "TD", "22280": "JQ", "22300": "YH", "22313": "XW", "22331": "YQ", "22343": "YJ", "22351": "PH", "22395": "DC", "22412": "TD", "22484": "PB", "22500": "PB", "22534": "ZD", "22549": "DH", "22561": "PB", "22612": "TD", "22771": "KQ", "22831": "HB", "22841": "JG", "22855": "QJ", "22865": "XQ", "23013": "ML", "23081": "WM", "23487": "SX", "23558": "QJ", "23561": "YW", "23586": "YW", "23614": "YW", "23615": "SN", "23631": "PB", "23646": "ZS", "23663": "ZT", "23673": "YG", "23762": "TD", "23769": "ZS", "23780": "QJ", "23884": "QK", "24055": "XH", "24113": "DC", "24162": "ZC", "24191": "GA", "24273": "QJ", "24324": "NL", "24377": "TD", "24378": "QJ", "24439": "PF", "24554": "ZS", "24683": "TD", "24694": "WE", "24733": "LK", "24925": "TN", "25094": "ZG", "25100": "XQ", "25103": "XH", "25153": "PB", "25170": "PB", "25179": "KG", "25203": "PB", "25240": "ZS", "25282": "FB", "25303": "NA", "25324": "KG", "25341": "ZY", "25373": "WZ", "25375": "XJ", "25384": "A", "25457": "A", "25528": "SD", "25530": "SC", "25552": "TD", "25774": "ZC", "25874": "ZC", "26044": "YW", "26080": "WM", "26292": "PB", "26333": "PB", "26355": "ZY", "26366": "CZ", "26397": "ZC", "26399": "QJ", "26415": "ZS", "26451": "SB", "26526": "ZC", "26552": "JG", "26561": "TD", "26588": "JG", "26597": "CZ", "26629": "ZS", "26638": "YL", "26646": "XQ", "26653": "KG", "26657": "XJ", "26727": "HG", "26894": "ZC", "26937": "ZS", "26946": "ZC", "26999": "KJ", "27099": "KJ", "27449": "YQ", "27481": "XS", "27542": "ZS", "27663": "ZS", "27748": "TS", "27784": "SC", "27788": "ZD", "27795": "TD", "27812": "O", "27850": "PB", "27852": "MB", "27895": "SL", "27898": "PL", "27973": "QJ", "27981": "KH", "27986": "HX", "27994": "XJ", "28044": "YC", "28065": "WG", "28177": "SM", "28267": "QJ", "28291": "KH", "28337": "ZQ", "28463": "TL", "28548": "DC", "28601": "TD", "28689": "PB", "28805": "JG", "28820": "QG", "28846": "PB", "28952": "TD", "28975": "ZC", "29100": "A", "29325": "QJ", "29575": "SL", "29602": "FB", "30010": "TD", "30044": "CX", "30058": "PF", "30091": "YSP", "30111": "YN", "30229": "XJ", "30427": "SC", "30465": "SX", "30631": "YQ", "30655": "QJ", "30684": "QJG", "30707": "SD", "30729": "XH", "30796": "LG", "30917": "PB", "31074": "NM", "31085": "JZ", "31109": "SC", "31181": "ZC", "31192": "MLB", "31293": "JQ", "31400": "YX", "31584": "YJ", "31896": "ZN", "31909": "ZY", "31995": "XJ", "32321": "PF", "32327": "ZY", "32418": "HG", "32420": "XQ", "32421": "HG", "32438": "LG", "32473": "GJ", "32488": "TD", "32521": "QJ", "32527": "PB", "32562": "ZSQ", "32564": "JZ", "32735": "ZD", "32793": "PB", "33071": "PF", "33098": "XL", "33100": "YA", "33152": "PB", "33261": "CX", "33324": "BP", "33333": "TD", "33406": "YA", "33426": "WM", "33432": "PB", "33445": "JG", "33486": "ZN", "33493": "TS", "33507": "QJ", "33540": "QJ", "33544": "ZC", "33564": "XQ", "33617": "YT", "33632": "QJ", "33636": "XH", "33637": "YX", "33694": "WG", "33705": "PF", "33728": "YW", "33882": "SR", "34067": "WM", "34074": "YW", "34121": "QJ", "34255": "ZC", "34259": "XL", "34425": "JH", "34430": "XH", "34485": "KH", "34503": "YS", "34532": "HG", "34552": "XS", "34558": "YE", "34593": "ZL", "34660": "YQ", "34892": "XH", "34928": "SC", "34999": "QJ", "35048": "PB", "35059": "SC", "35098": "ZC", "35203": "TQ", "35265": "JX", "35299": "JX", "35782": "SZ", "35828": "YS", "35830": "E", "35843": "TD", "35895": "YG", "35977": "MH", "36158": "JG", "36228": "QJ", "36426": "XQ", "36466": "DC", "36710": "JC", "36711": "ZYG", "36767": "PB", "36866": "SK", "36951": "YW", "37034": "YX", "37063": "XH", "37218": "ZC", "37325": "ZC", "38063": "PB", "38079": "TD", "38085": "QY", "38107": "DC", "38116": "TD", "38123": "YD", "38224": "HG", "38241": "XTC", "38271": "ZC", "38415": "YE", "38426": "KH", "38461": "YD", "38463": "AE", "38466": "PB", "38477": "XJ", "38518": "YT", "38551": "WK", "38585": "ZC", "38704": "XS", "38739": "LJ", "38761": "GJ", "38808": "SQ", "39048": "JG", "39049": "XJ", "39052": "HG", "39076": "CZ", "39271": "XT", "39534": "TD", "39552": "TD", "39584": "PB", "39647": "SB", "39730": "LG", "39748": "TPB", "40109": "ZQ", "40479": "ND", "40516": "HG", "40536": "HG", "40583": "QJ", "40765": "YQ", "40784": "QJ", "40840": "YK", "40863": "QJG" };
let getLetter = {
    /**
     * 获取汉字的拼音首字母
     * @param str 汉字字符串
     * @param polyphone 是否支持多音字，默认false，如果为true，会返回所有可能的组合数组
     */
    getFirstLetter: function (str, polyphone) {
        polyphone = polyphone == undefined ? false : polyphone;
        if (!str || /^ +$/g.test(str)) return '';
        if (dictFirstLetter) // 使用首字母字典文件
            {
                var result = [];
                for (var i = 0; i < str.length; i++) {
                    var unicode = str.charCodeAt(i);
                    var ch = str.charAt(i);
                    if (unicode >= 19968 && unicode <= 40869) {
                        ch = dictFirstLetter.all.charAt(unicode - 19968);
                        if (polyphone) ch = dictFirstLetter.polyphone[unicode] || ch;
                    } else {
                        //如果遇到非汉字则返回 '#'号
                        ch = '#';
                    }
                    result.push(ch); //返回数据
                }
                if (!polyphone) return result.join(''); // 如果不用管多音字，直接将数组拼接成字符串
                else return handlePolyphone(result, '', ''); // 处理多音字，此时的result类似于：['D', 'ZC', 'F']
            } else {
            var py = this.getPinyin(str, ' ', false, polyphone);
            py = py instanceof Array ? py : [py];
            var result = [];
            for (var i = 0; i < py.length; i++) {
                result.push(py[i].replace(/(^| )(\w)\w*/g, function (m, $1, $2) {
                    return $2.toUpperCase();
                }));
            }
            if (!polyphone) return result[0];else return simpleUnique(result);
        }
    }

};

/* unused harmony default export */ var _unused_webpack_default_export = ({ getLetter, dictFirstLetter });

/***/ }),

/***/ 6:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__assets_utils__ = __webpack_require__(2);
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//


/* harmony default export */ __webpack_exports__["default"] = ({
    props: {
        title: { default: "navbar" },
        complete: { default: '' },
        showComplete: { default: true },
        border: { default: true }
    },
    methods: {
        classHeader: function () {
            let dc = __WEBPACK_IMPORTED_MODULE_0__assets_utils__["a" /* default */].device();

            return dc;
        },
        goback: function (e) {
            this.$emit('goback');
        },
        goComplete: function (e) {
            this.$emit('goComplete');
        }
    }
});

/***/ }),

/***/ 633:
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(0)();
// imports


// module
exports.push([module.i, "/**每个页面都必须的，墙纸**/\n.wrapper {\n  position: absolute;\n  top: 0;\n  left: 0;\n  right: 0;\n  bottom: 0;\n  width: 750px;\n  background-color: #eee;\n}\n/**默认标题字体**/\n.nav_title {\n  font-size: 38px;\n  color: #fff;\n  line-height: 38px;\n}\n.title {\n  font-size: 32px;\n  color: #000;\n}\n/**默认子标题字体**/\n.sub_title {\n  font-size: 30px;\n  color: #999;\n}\n.sub_date {\n  font-size: 26px;\n  color: #999;\n}\n.fz28 {\n  font-size: 28px;\n}\n.fz30 {\n  font-size: 30px;\n}\n.fz32 {\n  font-size: 32px;\n}\n.fz35 {\n  font-size: 35px;\n}\n.fz40 {\n  font-size: 40px;\n}\n.boder-bottom {\n  border-style: solid;\n  border-bottom-width: 1px;\n  border-color: #ccc;\n}\n.boder-top {\n  border-style: solid;\n  border-top-width: 1px;\n  border-color: #ccc;\n}\n.boder-right {\n  border-style: solid;\n  border-right-width: 1px;\n  border-color: #ccc;\n}\n.boder-left {\n  border-style: solid;\n  border-left-width: 1px;\n  border-color: #ccc;\n}\n.pl10 {\n  padding-left: 10px;\n}\n.pl5 {\n  padding-left: 5px;\n}\n.pt0 {\n  padding-top: 0px;\n}\n.pt10 {\n  padding-top: 10px;\n}\n.pt15 {\n  padding-top: 15px;\n}\n.pb10 {\n  padding-bottom: 10px;\n}\n.pl20 {\n  padding-left: 20px;\n}\n.pt20 {\n  padding-top: 20px;\n}\n.pb15 {\n  padding-bottom: 15px;\n}\n.pb20 {\n  padding-bottom: 20px;\n}\n.pt25 {\n  padding-top: 25px;\n}\n.pt30 {\n  padding-top: 30px;\n}\n.pt40 {\n  padding-top: 40px;\n}\n.pb40 {\n  padding-bottom: 40px;\n}\n.pb30 {\n  padding-bottom: 30px;\n}\n.pb25 {\n  padding-bottom: 25px;\n}\n.pl25 {\n  padding-left: 25px;\n}\n.pl30 {\n  padding-left: 30px;\n}\n.pr5 {\n  padding-right: 5px;\n}\n.pr10 {\n  padding-right: 10px;\n}\n.pr20 {\n  padding-right: 20px;\n}\n.pr25 {\n  padding-right: 25px;\n}\n.pr30 {\n  padding-right: 30px;\n}\n.pl35 {\n  padding-left: 35px;\n}\n.pr35 {\n  padding-right: 35px;\n}\n.bgWhite {\n  background-color: #ffffff;\n}\n.textActive:active {\n  background-color: #ccc;\n}\n/**top 大小**/\n.mt0 {\n  margin-top: 0px;\n}\n.mt10 {\n  margin-top: 10px;\n}\n.mt20 {\n  margin-top: 20px;\n}\n.mt30 {\n  margin-top: 30px;\n}\n.mt40 {\n  margin-top: 40px;\n}\n.mt50 {\n  margin-top: 50px;\n}\n/**bottom 大小**/\n.bt0 {\n  margin-bottom: 0px;\n}\n.bt5 {\n  margin-bottom: 5px;\n}\n.bt10 {\n  margin-bottom: 10px;\n}\n.bt15 {\n  margin-bottom: 15px;\n}\n.bt20 {\n  margin-bottom: 20px;\n}\n.bt30 {\n  margin-bottom: 30px;\n}\n.bt45 {\n  margin-bottom: 45px;\n}\n.bt50 {\n  margin-bottom: 50px;\n}\n.mr5 {\n  margin-right: 5px;\n}\n.mr10 {\n  margin-right: 10px;\n}\n.mr30 {\n  margin-right: 30px;\n}\n/**left 大小**/\n.ml5 {\n  margin-left: 5px;\n}\n.ml10 {\n  margin-left: 10px;\n}\n.ml20 {\n  margin-left: 20px;\n}\n.ml30 {\n  margin-left: 30px;\n}\n.header {\n  height: 136px;\n  padding-top: 44px;\n  flex-direction: row;\n  position: sticky;\n  background-color: #EB4E40;\n}\n.nav {\n  width: 654px;\n  justify-content: space-between;\n  flex-direction: row;\n  height: 92px;\n  align-items: center;\n  margin-top: 0px;\n}\n.nav_back {\n  margin-top: 0px;\n  flex-direction: row;\n  width: 92px;\n  height: 92px;\n  align-items: center;\n  justify-content: center;\n}\n.corpusActive {\n  color: #EB4E40;\n  border-color: #EB4E40;\n  border-style: solid;\n  border-bottom-width: 4px;\n}\n.footer {\n  position: fixed;\n  bottom: 0px;\n  left: 0px;\n  right: 0px;\n  height: 100px;\n}\n.fill {\n  height: 500px;\n  width: 750px;\n  background-color: #eee;\n}\n/** 图标图像 **/\n.iconImg {\n  width: 60px;\n  height: 60px;\n  font-size: 60px;\n}\n/**cell 分组头**/\n.cell-header {\n  height: 70px;\n  flex-direction: row;\n  background-color: #ddd;\n  padding-left: 20px;\n}\n/**cell 行**/\n.cell-row {\n  min-height: 100px;\n  flex-direction: column;\n  background-color: #ffffff;\n  padding-left: 20px;\n  margin-top: 20px;\n}\n.cell-row-row {\n  min-height: 100px;\n  flex-direction: row;\n  justify-content: space-between;\n  background-color: #ffffff;\n  padding-left: 20px;\n  padding-right: 20px;\n  align-items: center;\n  margin-top: 20px;\n}\n.cell-line {\n  border-top-width: 1px;\n  border-top-color: #ccc;\n  border-top-style: solid;\n  border-bottom-width: 1px;\n  border-bottom-color: #ccc;\n  border-bottom-style: solid;\n}\n.borderTop {\n  border-top-width: 1px;\n  border-top-color: #ccc;\n  border-top-style: solid;\n}\n.borderBottom {\n  border-bottom-width: 1px;\n  border-bottom-color: #ccc;\n  border-bottom-style: solid;\n}\n/**cell 内面行**/\n.cell-panel {\n  height: 98px;\n  min-height: 98px;\n  flex-direction: row;\n  align-items: center;\n  border-bottom-width: 1px;\n  border-bottom-color: #ccc;\n  border-bottom-style: solid;\n}\n.cell-panel-column {\n  height: 98px;\n  min-height: 98px;\n  flex-direction: column;\n  justify-content: space-around;\n  border-bottom-width: 1px;\n  border-bottom-color: #ccc;\n  border-bottom-style: solid;\n  padding-top: 10px;\n  padding-bottom: 10px;\n}\n.cell-panel-column :last-child {\n  border-bottom-width: 0px;\n}\n.cell-panel :last-child {\n  border-bottom-width: 0px;\n}\n.cell-bottom-clear {\n  border-bottom-width: 0px;\n}\n.cell-clear {\n  margin-top: 0px;\n  margin-bottom: 0px;\n  border-top-width: 0px;\n  border-bottom-width: 0px;\n}\n/**两边对齐**/\n.space-between {\n  justify-content: space-between;\n  flex-direction: row;\n  align-items: center;\n}\n.flex-start {\n  justify-content: flex-start;\n  flex-direction: row;\n  align-items: center;\n}\n.flex-end {\n  justify-content: flex-end;\n  flex-direction: row;\n  align-items: center;\n}\n.flex-center {\n  justify-content: center;\n  flex-direction: row;\n  align-items: center;\n}\n.space-around {\n  justify-content: space-around;\n  flex-direction: row;\n  align-items: center;\n}\n/**横向部局居中对齐**/\n.flex-row {\n  flex-direction: row;\n  align-items: center;\n}\n.flex-column {\n  flex-direction: column;\n  align-items: center;\n}\n/**flex 部局比例**/\n.flex1 {\n  flex: 1;\n}\n.flex2 {\n  flex: 2;\n}\n.flex3 {\n  flex: 3;\n}\n.flex4 {\n  flex: 4;\n}\n.flex5 {\n  flex: 6;\n}\n.flex6 {\n  flex: 6;\n}\n/**常用背景颜色**/\n.bkg-white {\n  background-color: white;\n}\n.bkg-primary {\n  background-color: #EB4E40;\n}\n.bkg-gray {\n  background-color: #eee;\n}\n.bd-primary {\n  border-color: #EB4E40;\n}\n.bkg-delete {\n  background-color: red;\n}\n/**常用字体颜色**/\n.white {\n  color: white;\n}\n.primary {\n  color: #EB4E40;\n}\n.gray {\n  color: #999;\n}\n/**ico 字体大小与颜色**/\n.ico {\n  font-size: 48px;\n  color: #EB4E40;\n  margin-top: 2px;\n}\n.ico_big {\n  font-size: 72px;\n  color: #EB4E40;\n  margin-top: 4px;\n}\n.ico_small {\n  font-size: 32px;\n  color: #EB4E40;\n  margin-top: 1px;\n}\n/**右箭头 字体大小与颜色**/\n.arrow {\n  font-size: 32px;\n  color: #ccc;\n  width: 40px;\n}\n/**打勾 字体大小与颜色**/\n.check {\n  font-size: 32px;\n  color: #EB4E40;\n  width: 40px;\n}\n.shopCheck {\n  font-size: 32px;\n  color: #EB4E40;\n  width: 40px;\n  margin-left: 150px;\n}\n/**默认按钮类型**/\n.button {\n  font-size: 32px;\n  text-align: center;\n  color: #fff;\n  padding-top: 15px;\n  padding-bottom: 15px;\n  background-color: #EB4E40;\n  border-radius: 15px;\n  height: 80px;\n  line-height: 50px;\n  align-items: center;\n  justify-content: center;\n}\n.button:active {\n  background-color: #ccc;\n  color: #EB4E40;\n}\n.button:disabled {\n  background-color: #EB4E40;\n  color: #999;\n}\n/**上拉刷新，下拉加载样式**/\n.refresh {\n  flex-direction: column;\n  align-items: center;\n  padding-top: 10px;\n}\n.loading {\n  flex-direction: column;\n  align-items: center;\n  padding-top: 10px;\n}\n.noLoading {\n  height: 999px;\n}\n.gif {\n  width: 50px;\n  height: 50px;\n}\n.indicator {\n  font-size: 36px;\n  color: #EB4E40;\n  width: 750px;\n  text-align: center;\n  margin-top: 20px;\n  margin-bottom: 20px;\n}\n/**超长用省略号**/\n.lines-ellipsis {\n  lines: 1;\n  text-overflow: ellipsis;\n}\n.V1 {\n  height: 146px;\n  padding-top: 54px;\n}\n.IPhoneX {\n  height: 156px;\n  padding-top: 64px;\n}\n.addTopV1 {\n  top: 54px;\n}\n.addTopIPhoneX {\n  top: 64px;\n}\n.addInfoV1 {\n  height: 430px;\n  padding-top: 50px;\n}\n.addInfoIPhoneX {\n  height: 440px;\n  padding-top: 60px;\n}\n.addBgImgV1 {\n  height: 430px;\n}\n.addBgImgIPhoneX {\n  height: 440px;\n}\n.hideCorpusV1 {\n  top: 146px;\n}\n.hideCorpusIPhoneX {\n  top: 156px;\n}\n.pageTopV1 {\n  top: 226px;\n}\n.pageTopIPhoneX {\n  top: 236px;\n}\n.maskLayer {\n  position: fixed;\n  top: 0px;\n  left: 0px;\n  right: 0px;\n  bottom: 0px;\n  background-color: #000;\n  opacity: 0.4;\n}\n.showBox {\n  position: fixed;\n  top: 150px;\n  right: 15px;\n  padding-top: 20px;\n  padding-bottom: 20px;\n}\n.showBg {\n  position: absolute;\n  top: 0;\n  bottom: 0;\n  left: 0;\n  right: 0;\n  background-color: #fff;\n  border-radius: 20px;\n}\n.arrowUp {\n  position: fixed;\n  top: 148px;\n  right: 30px;\n}\n.refreshImg {\n  width: 60px;\n  height: 60px;\n  border-radius: 30px;\n}\n.refreshBox {\n  height: 120px;\n  width: 750px;\n  align-items: center;\n  justify-content: center;\n}\n.indexMtIPhoneX {\n  margin-top: 124px;\n}\n.indexSliderMtIPhone {\n  margin-top: 44px;\n}\n.indexSliderMtIPhoneX {\n  margin-top: 124px;\n}\n.artOutBoxTopIPhoneX {\n  top: 156px;\n}\n.processTotal {\n  position: absolute;\n  bottom: 40px;\n  right: 50px;\n  font-size: 28px;\n  color: #888;\n}\n.processBg {\n  background-color: #ccc;\n  width: 500px;\n}\n.processStyle {\n  height: 10px;\n  position: absolute;\n  left: 50px;\n  bottom: 100px;\n}\n.processText {\n  position: absolute;\n  top: 40px;\n  left: 50px;\n  font-size: 32px;\n}\n.processBox {\n  height: 250px;\n  border-radius: 5px;\n  width: 600px;\n  background-color: #fff;\n  justify-content: space-between;\n}\n.sendMask {\n  position: absolute;\n  top: 0;\n  bottom: 0;\n  left: 0;\n  right: 0;\n  background-color: rgba(0, 0, 0, 0.8);\n  align-items: center;\n  justify-content: center;\n}\n", ""]);

// exports


/***/ }),

/***/ 634:
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(0)();
// imports


// module
exports.push([module.i, "\n.greenColor[data-v-9278264c]{\n    color:#1AA218;\n}\n.topIcon[data-v-9278264c]{\n    font-size:50px;color: #fff;\n}\n.fzz65[data-v-9278264c]{\n    font-size:65px;\n}\n.rightTopBox[data-v-9278264c]{\n    position: fixed;\n    top: 44px;\n    right: 20px;\n    /*width: 110px;*/\n    /*width: 92px;*/\n    height: 92px;\n    align-items: center;\n    justify-content: center;\n}\n.scrollerStyle[data-v-9278264c]{\n    position: relative;\n    top:0;\n    bottom: 100px;\n}\n/*底部按钮*/\n.bottomBR[data-v-9278264c]{\n    border-right-color:#fff;width: 1px;height: 50px;\n}\n.fz45[data-v-9278264c]{\n    font-size: 45px;\n    line-height: 45px;\n}\n.bottomBtnBox[data-v-9278264c]{\n    flex: 1;\n    flex-direction: row;\n    align-items: center;justify-content: center;\n}\n.fz26fff[data-v-9278264c]{\n    font-size: 32px;\n    line-height: 32px;\n    color: #fff;\n}\n.footBox[data-v-9278264c]{\n    align-items: center;\n    justify-content: center;\n    flex-direction: row;\n    width:750px;\n    /*height:100px;*/\n    background-color: #8947FA;\n    /*position: fixed;*/\n    border-style:solid;\n    border-top-width: 1px;\n    border-color: #ccc;\n    /*bottom:0;*/\n}\n.cb-top[data-v-9278264c]{\n    border-top-width: 0px;\n}\n/*底部按钮*/\n\n/*主页 直播*/\n.ticketImg[data-v-9278264c]{\n    width: 60px;\n    height: 60px;\n    border-radius: 30px;\n}\n.cell-height[data-v-9278264c]{\n    height: 100px;\n}\n.cell-height-title[data-v-9278264c]{\n    height: 110px;\n}\n.activeColor[data-v-9278264c]{\n    color:#8947FA;\n    font-weight: 600;\n}\n.ptb35[data-v-9278264c]{\n    padding-top: 35px;\n    padding-bottom: 35px;\n}\n.ptb5[data-v-9278264c]{\n    padding-top: 5px;\n    padding-bottom: 5px;\n}\n/*主页 直播*/\n\n/*顶部导航栏*/\n.rightTop[data-v-9278264c]{\n    height: 96px;width: 98px;align-items: center;justify-content: center;margin-top: 5px;\n}\n.nav_ico[data-v-9278264c] {\n    font-size: 38px;\n    color: #fff;\n    margin-top: 2px;\n}\n.userBox[data-v-9278264c]{\n    flex-direction: row;\n    align-items: center;\n}\n.nw[data-v-9278264c]{\n    width: 750px;\n}\n/*顶部导航栏*/\n\n/*个人信息栏*/\n.starNum[data-v-9278264c]{\n    font-size: 30px;color: #fff;\n}\n.starIcon[data-v-9278264c]{\n    font-size:36px;color:#fff;\n}\n.starBox[data-v-9278264c]{\n    background-color: #8EC103;border-radius: 5px;\n}\n.womenIcon[data-v-9278264c]{\n    color:pink;\n}\n.manIcon[data-v-9278264c]{\n    color:#1296db;\n}\n.sexIcon[data-v-9278264c]{\n    font-size:45px;color: pink;\n}\n.ptb3[data-v-9278264c]{\n    padding-top: 3px;\n    padding-bottom: 3px;\n}\n.alignCenter[data-v-9278264c]{\n    align-items: center;\n}\n.topBox[data-v-9278264c]{\n    position: relative;\n    background-color: #fff;\n}\n.topHead[data-v-9278264c]{\n    flex-direction: column;\n    align-items: center;\n    padding-top: 20px;\n    padding-bottom: 20px;\n    color: white;\n}\n.headImage[data-v-9278264c]{\n    width: 200px;\n    height:200px;\n    border-width: 5px;\n    border-style: solid;\n    border-color: #ccc;\n    border-radius: 100px;\n}\n.userSign[data-v-9278264c]{\n    lines:2;\n    text-overflow:ellipsis;\n    width:500px;\n    font-size: 28px;\n    color: #999;\n    text-align: center;\n}\n.focusFans[data-v-9278264c]{\n    font-size: 30px;\n    color: #777;\n}\n.userName[data-v-9278264c]{\n    font-weight: 600;\n    font-size: 32px;\n    color: #666;\n}\n/*个人信息栏*/\n", ""]);

// exports


/***/ }),

/***/ 7:
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(0)();
// imports


// module
exports.push([module.i, "/**每个页面都必须的，墙纸**/\n.wrapper {\n  position: absolute;\n  top: 0;\n  left: 0;\n  right: 0;\n  bottom: 0;\n  width: 750px;\n  background-color: #eee;\n}\n/**默认标题字体**/\n.nav_title {\n  font-size: 38px;\n  color: #fff;\n  line-height: 38px;\n}\n.title {\n  font-size: 32px;\n  color: #000;\n}\n/**默认子标题字体**/\n.sub_title {\n  font-size: 30px;\n  color: #999;\n}\n.sub_date {\n  font-size: 26px;\n  color: #999;\n}\n.fz28 {\n  font-size: 28px;\n}\n.fz30 {\n  font-size: 30px;\n}\n.fz32 {\n  font-size: 32px;\n}\n.fz35 {\n  font-size: 35px;\n}\n.fz40 {\n  font-size: 40px;\n}\n.boder-bottom {\n  border-style: solid;\n  border-bottom-width: 1px;\n  border-color: #ccc;\n}\n.boder-top {\n  border-style: solid;\n  border-top-width: 1px;\n  border-color: #ccc;\n}\n.boder-right {\n  border-style: solid;\n  border-right-width: 1px;\n  border-color: #ccc;\n}\n.boder-left {\n  border-style: solid;\n  border-left-width: 1px;\n  border-color: #ccc;\n}\n.pl10 {\n  padding-left: 10px;\n}\n.pl5 {\n  padding-left: 5px;\n}\n.pt0 {\n  padding-top: 0px;\n}\n.pt10 {\n  padding-top: 10px;\n}\n.pt15 {\n  padding-top: 15px;\n}\n.pb10 {\n  padding-bottom: 10px;\n}\n.pl20 {\n  padding-left: 20px;\n}\n.pt20 {\n  padding-top: 20px;\n}\n.pb15 {\n  padding-bottom: 15px;\n}\n.pb20 {\n  padding-bottom: 20px;\n}\n.pt25 {\n  padding-top: 25px;\n}\n.pt30 {\n  padding-top: 30px;\n}\n.pt40 {\n  padding-top: 40px;\n}\n.pb40 {\n  padding-bottom: 40px;\n}\n.pb30 {\n  padding-bottom: 30px;\n}\n.pb25 {\n  padding-bottom: 25px;\n}\n.pl25 {\n  padding-left: 25px;\n}\n.pl30 {\n  padding-left: 30px;\n}\n.pr5 {\n  padding-right: 5px;\n}\n.pr10 {\n  padding-right: 10px;\n}\n.pr20 {\n  padding-right: 20px;\n}\n.pr25 {\n  padding-right: 25px;\n}\n.pr30 {\n  padding-right: 30px;\n}\n.pl35 {\n  padding-left: 35px;\n}\n.pr35 {\n  padding-right: 35px;\n}\n.bgWhite {\n  background-color: #ffffff;\n}\n.textActive:active {\n  background-color: #ccc;\n}\n/**top 大小**/\n.mt0 {\n  margin-top: 0px;\n}\n.mt10 {\n  margin-top: 10px;\n}\n.mt20 {\n  margin-top: 20px;\n}\n.mt30 {\n  margin-top: 30px;\n}\n.mt40 {\n  margin-top: 40px;\n}\n.mt50 {\n  margin-top: 50px;\n}\n/**bottom 大小**/\n.bt0 {\n  margin-bottom: 0px;\n}\n.bt5 {\n  margin-bottom: 5px;\n}\n.bt10 {\n  margin-bottom: 10px;\n}\n.bt15 {\n  margin-bottom: 15px;\n}\n.bt20 {\n  margin-bottom: 20px;\n}\n.bt30 {\n  margin-bottom: 30px;\n}\n.bt45 {\n  margin-bottom: 45px;\n}\n.bt50 {\n  margin-bottom: 50px;\n}\n.mr5 {\n  margin-right: 5px;\n}\n.mr10 {\n  margin-right: 10px;\n}\n.mr30 {\n  margin-right: 30px;\n}\n/**left 大小**/\n.ml5 {\n  margin-left: 5px;\n}\n.ml10 {\n  margin-left: 10px;\n}\n.ml20 {\n  margin-left: 20px;\n}\n.ml30 {\n  margin-left: 30px;\n}\n.header {\n  height: 136px;\n  padding-top: 44px;\n  flex-direction: row;\n  position: sticky;\n  background-color: #EB4E40;\n}\n.nav {\n  width: 654px;\n  justify-content: space-between;\n  flex-direction: row;\n  height: 92px;\n  align-items: center;\n  margin-top: 0px;\n}\n.nav_back {\n  margin-top: 0px;\n  flex-direction: row;\n  width: 92px;\n  height: 92px;\n  align-items: center;\n  justify-content: center;\n}\n.corpusActive {\n  color: #EB4E40;\n  border-color: #EB4E40;\n  border-style: solid;\n  border-bottom-width: 4px;\n}\n.footer {\n  position: fixed;\n  bottom: 0px;\n  left: 0px;\n  right: 0px;\n  height: 100px;\n}\n.fill {\n  height: 500px;\n  width: 750px;\n  background-color: #eee;\n}\n/** 图标图像 **/\n.iconImg {\n  width: 60px;\n  height: 60px;\n  font-size: 60px;\n}\n/**cell 分组头**/\n.cell-header {\n  height: 70px;\n  flex-direction: row;\n  background-color: #ddd;\n  padding-left: 20px;\n}\n/**cell 行**/\n.cell-row {\n  min-height: 100px;\n  flex-direction: column;\n  background-color: #ffffff;\n  padding-left: 20px;\n  margin-top: 20px;\n}\n.cell-row-row {\n  min-height: 100px;\n  flex-direction: row;\n  justify-content: space-between;\n  background-color: #ffffff;\n  padding-left: 20px;\n  padding-right: 20px;\n  align-items: center;\n  margin-top: 20px;\n}\n.cell-line {\n  border-top-width: 1px;\n  border-top-color: #ccc;\n  border-top-style: solid;\n  border-bottom-width: 1px;\n  border-bottom-color: #ccc;\n  border-bottom-style: solid;\n}\n.borderTop {\n  border-top-width: 1px;\n  border-top-color: #ccc;\n  border-top-style: solid;\n}\n.borderBottom {\n  border-bottom-width: 1px;\n  border-bottom-color: #ccc;\n  border-bottom-style: solid;\n}\n/**cell 内面行**/\n.cell-panel {\n  height: 98px;\n  min-height: 98px;\n  flex-direction: row;\n  align-items: center;\n  border-bottom-width: 1px;\n  border-bottom-color: #ccc;\n  border-bottom-style: solid;\n}\n.cell-panel-column {\n  height: 98px;\n  min-height: 98px;\n  flex-direction: column;\n  justify-content: space-around;\n  border-bottom-width: 1px;\n  border-bottom-color: #ccc;\n  border-bottom-style: solid;\n  padding-top: 10px;\n  padding-bottom: 10px;\n}\n.cell-panel-column :last-child {\n  border-bottom-width: 0px;\n}\n.cell-panel :last-child {\n  border-bottom-width: 0px;\n}\n.cell-bottom-clear {\n  border-bottom-width: 0px;\n}\n.cell-clear {\n  margin-top: 0px;\n  margin-bottom: 0px;\n  border-top-width: 0px;\n  border-bottom-width: 0px;\n}\n/**两边对齐**/\n.space-between {\n  justify-content: space-between;\n  flex-direction: row;\n  align-items: center;\n}\n.flex-start {\n  justify-content: flex-start;\n  flex-direction: row;\n  align-items: center;\n}\n.flex-end {\n  justify-content: flex-end;\n  flex-direction: row;\n  align-items: center;\n}\n.flex-center {\n  justify-content: center;\n  flex-direction: row;\n  align-items: center;\n}\n.space-around {\n  justify-content: space-around;\n  flex-direction: row;\n  align-items: center;\n}\n/**横向部局居中对齐**/\n.flex-row {\n  flex-direction: row;\n  align-items: center;\n}\n.flex-column {\n  flex-direction: column;\n  align-items: center;\n}\n/**flex 部局比例**/\n.flex1 {\n  flex: 1;\n}\n.flex2 {\n  flex: 2;\n}\n.flex3 {\n  flex: 3;\n}\n.flex4 {\n  flex: 4;\n}\n.flex5 {\n  flex: 6;\n}\n.flex6 {\n  flex: 6;\n}\n/**常用背景颜色**/\n.bkg-white {\n  background-color: white;\n}\n.bkg-primary {\n  background-color: #EB4E40;\n}\n.bkg-gray {\n  background-color: #eee;\n}\n.bd-primary {\n  border-color: #EB4E40;\n}\n.bkg-delete {\n  background-color: red;\n}\n/**常用字体颜色**/\n.white {\n  color: white;\n}\n.primary {\n  color: #EB4E40;\n}\n.gray {\n  color: #999;\n}\n/**ico 字体大小与颜色**/\n.ico {\n  font-size: 48px;\n  color: #EB4E40;\n  margin-top: 2px;\n}\n.ico_big {\n  font-size: 72px;\n  color: #EB4E40;\n  margin-top: 4px;\n}\n.ico_small {\n  font-size: 32px;\n  color: #EB4E40;\n  margin-top: 1px;\n}\n/**右箭头 字体大小与颜色**/\n.arrow {\n  font-size: 32px;\n  color: #ccc;\n  width: 40px;\n}\n/**打勾 字体大小与颜色**/\n.check {\n  font-size: 32px;\n  color: #EB4E40;\n  width: 40px;\n}\n.shopCheck {\n  font-size: 32px;\n  color: #EB4E40;\n  width: 40px;\n  margin-left: 150px;\n}\n/**默认按钮类型**/\n.button {\n  font-size: 32px;\n  text-align: center;\n  color: #fff;\n  padding-top: 15px;\n  padding-bottom: 15px;\n  background-color: #EB4E40;\n  border-radius: 15px;\n  height: 80px;\n  line-height: 50px;\n  align-items: center;\n  justify-content: center;\n}\n.button:active {\n  background-color: #ccc;\n  color: #EB4E40;\n}\n.button:disabled {\n  background-color: #EB4E40;\n  color: #999;\n}\n/**上拉刷新，下拉加载样式**/\n.refresh {\n  flex-direction: column;\n  align-items: center;\n  padding-top: 10px;\n}\n.loading {\n  flex-direction: column;\n  align-items: center;\n  padding-top: 10px;\n}\n.noLoading {\n  height: 999px;\n}\n.gif {\n  width: 50px;\n  height: 50px;\n}\n.indicator {\n  font-size: 36px;\n  color: #EB4E40;\n  width: 750px;\n  text-align: center;\n  margin-top: 20px;\n  margin-bottom: 20px;\n}\n/**超长用省略号**/\n.lines-ellipsis {\n  lines: 1;\n  text-overflow: ellipsis;\n}\n.V1 {\n  height: 146px;\n  padding-top: 54px;\n}\n.IPhoneX {\n  height: 156px;\n  padding-top: 64px;\n}\n.addTopV1 {\n  top: 54px;\n}\n.addTopIPhoneX {\n  top: 64px;\n}\n.addInfoV1 {\n  height: 430px;\n  padding-top: 50px;\n}\n.addInfoIPhoneX {\n  height: 440px;\n  padding-top: 60px;\n}\n.addBgImgV1 {\n  height: 430px;\n}\n.addBgImgIPhoneX {\n  height: 440px;\n}\n.hideCorpusV1 {\n  top: 146px;\n}\n.hideCorpusIPhoneX {\n  top: 156px;\n}\n.pageTopV1 {\n  top: 226px;\n}\n.pageTopIPhoneX {\n  top: 236px;\n}\n.maskLayer {\n  position: fixed;\n  top: 0px;\n  left: 0px;\n  right: 0px;\n  bottom: 0px;\n  background-color: #000;\n  opacity: 0.4;\n}\n.showBox {\n  position: fixed;\n  top: 150px;\n  right: 15px;\n  padding-top: 20px;\n  padding-bottom: 20px;\n}\n.showBg {\n  position: absolute;\n  top: 0;\n  bottom: 0;\n  left: 0;\n  right: 0;\n  background-color: #fff;\n  border-radius: 20px;\n}\n.arrowUp {\n  position: fixed;\n  top: 148px;\n  right: 30px;\n}\n.refreshImg {\n  width: 60px;\n  height: 60px;\n  border-radius: 30px;\n}\n.refreshBox {\n  height: 120px;\n  width: 750px;\n  align-items: center;\n  justify-content: center;\n}\n.indexMtIPhoneX {\n  margin-top: 124px;\n}\n.indexSliderMtIPhone {\n  margin-top: 44px;\n}\n.indexSliderMtIPhoneX {\n  margin-top: 124px;\n}\n.artOutBoxTopIPhoneX {\n  top: 156px;\n}\n.processTotal {\n  position: absolute;\n  bottom: 40px;\n  right: 50px;\n  font-size: 28px;\n  color: #888;\n}\n.processBg {\n  background-color: #ccc;\n  width: 500px;\n}\n.processStyle {\n  height: 10px;\n  position: absolute;\n  left: 50px;\n  bottom: 100px;\n}\n.processText {\n  position: absolute;\n  top: 40px;\n  left: 50px;\n  font-size: 32px;\n}\n.processBox {\n  height: 250px;\n  border-radius: 5px;\n  width: 600px;\n  background-color: #fff;\n  justify-content: space-between;\n}\n.sendMask {\n  position: absolute;\n  top: 0;\n  bottom: 0;\n  left: 0;\n  right: 0;\n  background-color: rgba(0, 0, 0, 0.8);\n  align-items: center;\n  justify-content: center;\n}\n", ""]);

// exports


/***/ }),

/***/ 756:
/***/ (function(module, exports, __webpack_require__) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "wrapper"
  }, [_c('div', {
    staticClass: "header  ",
    class: [_vm.classHeader()]
  }, [_c('div', {
    staticClass: "nav nw"
  }, [_c('div', {
    staticClass: "nav_back",
    on: {
      "click": function($event) {
        _vm.goback('/')
      }
    }
  }, [_c('text', {
    staticClass: "nav_ico",
    style: ({
      fontFamily: 'iconfont'
    })
  }, [_vm._v("")])]), _vm._v(" "), _c('div', {
    staticClass: "userBox"
  }, [_c('text', {
    staticClass: "nav_title"
  }, [_vm._v(_vm._s(_vm.pageName))])]), _vm._v(" "), _c('div', {
    staticClass: "rightTop"
  })])]), _vm._v(" "), _c('div', {
    staticClass: "rightTopBox flex-row",
    class: [_vm.classTop()]
  }, [(!_vm.isFocus) ? _c('text', {
    staticClass: "ml20 topIcon",
    style: ({
      fontFamily: 'iconfont'
    }),
    on: {
      "click": function($event) {
        _vm.focus()
      }
    }
  }, [_vm._v("")]) : _c('text', {
    staticClass: "ml20 topIcon",
    style: ({
      fontFamily: 'iconfont'
    }),
    on: {
      "click": function($event) {
        _vm.focus()
      }
    }
  }, [_vm._v("")])]), _vm._v(" "), _c('scroller', {
    staticClass: "scrollerStyle"
  }, _vm._l((_vm.infoData), function(item) {
    return _c('div', [_c('div', {
      staticClass: "topBox bt30"
    }, [_c('div', {
      staticClass: "topHead"
    }, [_c('image', {
      staticClass: "headImage",
      attrs: {
        "resize": "cover",
        "src": _vm._f("watchHeadImage")(item.logo)
      }
    }), _vm._v(" "), _c('div', {
      staticClass: "alignCenter"
    }, [_c('div', {
      staticClass: "flex-row pt20"
    }, [_c('text', {
      staticClass: "userName  "
    }, [_vm._v(_vm._s(item.nickName))]), _vm._v(" "), (item.gender == 'male') ? _c('text', {
      staticClass: "pl10 pr10 fz45 manIcon",
      style: ({
        fontFamily: 'iconfont'
      })
    }, [_vm._v("")]) : _vm._e(), _vm._v(" "), (item.gender == 'female') ? _c('text', {
      staticClass: "pl5 pr5 fz45 womenIcon",
      style: ({
        fontFamily: 'iconfont'
      })
    }, [_vm._v("")]) : _vm._e(), _vm._v(" "), (_vm.hasVip(item.vip)) ? _c('div', {
      staticClass: "pl10 pr10 ptb3  flex-row starBox"
    }, [_c('text', {
      staticClass: "starIcon",
      style: ({
        fontFamily: 'iconfont'
      })
    }, [_vm._v("")]), _vm._v(" "), _c('text', {
      staticClass: "starNum"
    }, [_vm._v(" " + _vm._s(item.vip))])]) : _vm._e()]), _vm._v(" "), _c('div', {
      staticClass: "flex-row pt20 pb20"
    }, [_c('div', {
      staticClass: "boder-right"
    }, [_c('text', {
      staticClass: "focusFans pr20"
    }, [_vm._v("关注 " + _vm._s(item.follow))])]), _vm._v(" "), _c('text', {
      staticClass: "focusFans pl20"
    }, [_vm._v("粉丝 " + _vm._s(item.fans))])]), _vm._v(" "), _c('text', {
      staticClass: "userSign"
    }, [_vm._v(_vm._s(_vm._f("watchAutograph")(item.autograph)))])])])]), _vm._v(" "), _c('div', [_c('div', {
      staticClass: " flex-row cell-height boder-bottom  bgWhite pl20 pr20"
    }, [_c('div', {
      staticClass: " flex2"
    }, [_c('text', {
      staticClass: "sub_title fz30"
    }, [_vm._v("职业")])]), _vm._v(" "), _c('div', {
      staticClass: " flex4 "
    }, [_c('text', {
      staticClass: "title"
    }, [_vm._v(_vm._s(_vm._f("watchOccupation")(item.occupation)))])])]), _vm._v(" "), _c('div', {
      staticClass: " flex-row cell-height boder-bottom  bgWhite pl20 pr20"
    }, [_c('div', {
      staticClass: " flex2"
    }, [_c('text', {
      staticClass: "sub_title fz30"
    }, [_vm._v("登录名")])]), _vm._v(" "), _c('div', {
      staticClass: " flex4 "
    }, [_c('text', {
      staticClass: "title"
    }, [_vm._v(_vm._s(item.userId))])])]), _vm._v(" "), _c('div', {
      staticClass: " flex-row cell-height boder-bottom  bgWhite pl20 pr20"
    }, [_c('div', {
      staticClass: " flex2"
    }, [_c('text', {
      staticClass: "sub_title fz30"
    }, [_vm._v("年龄")])]), _vm._v(" "), _c('div', {
      staticClass: " flex4 "
    }, [_c('text', {
      staticClass: "title"
    }, [_vm._v(_vm._s(_vm._f("watchBirth")(item.birth)))])])]), _vm._v(" "), _c('div', {
      staticClass: " flex-row cell-height boder-bottom  bgWhite pl20 pr20"
    }, [_c('div', {
      staticClass: " flex2"
    }, [_c('text', {
      staticClass: "sub_title fz30"
    }, [_vm._v("个性签名")])]), _vm._v(" "), _c('div', {
      staticClass: " flex4 "
    }, [_c('text', {
      staticClass: "title",
      staticStyle: {
        "lines": "1",
        "text-overflow": "ellipsis"
      }
    }, [_vm._v(_vm._s(_vm._f("watchAutograph")(item.autograph)))])])]), _vm._v(" "), (!_vm.isUser) ? _c('div', {
      staticClass: " flex-row cell-height   bgWhite pl20 pr20"
    }, [_c('div', {
      staticClass: " flex2"
    }, [_c('text', {
      staticClass: "sub_title fz30"
    }, [_vm._v("管理员")])]), _vm._v(" "), (_vm.hasManager) ? _c('div', {
      staticClass: " flex4 ",
      on: {
        "click": function($event) {
          _vm.setManager()
        }
      }
    }, [_c('text', {
      staticClass: " fzz65 greenColor",
      style: ({
        fontFamily: 'iconfont'
      })
    }, [_vm._v("")])]) : _c('div', {
      staticClass: " flex4 ",
      on: {
        "click": function($event) {
          _vm.setManager()
        }
      }
    }, [_c('text', {
      staticClass: " fzz65 gray",
      style: ({
        fontFamily: 'iconfont'
      })
    }, [_vm._v("")])])]) : _vm._e()])])
  })), _vm._v(" "), _c('div', {
    staticClass: " footBox",
    style: ({
      height: _vm.bottomNum + 100,
      paddingBottom: _vm.bottomNum
    })
  }, [(!_vm.isUser || _vm.isManager) ? _c('div', {
    staticClass: "bottomBtnBox",
    style: ({
      height: _vm.bottomNum + 100
    }),
    on: {
      "click": function($event) {
        _vm.tickOut()
      }
    }
  }, [_c('text', {
    staticClass: "fz26fff fz45",
    style: ({
      fontFamily: 'iconfont'
    })
  }, [_vm._v("")]), _vm._v(" "), _c('text', {
    staticClass: "fz26fff ml10"
  }, [_vm._v("踢出房间")])]) : _vm._e(), _vm._v(" "), (!_vm.isUser || _vm.isManager) ? _c('div', {
    staticClass: "boder-right bottomBR"
  }) : _vm._e(), _vm._v(" "), _c('div', {
    staticClass: "bottomBtnBox",
    style: ({
      height: _vm.bottomNum + 100
    }),
    on: {
      "click": function($event) {
        _vm.goChat()
      }
    }
  }, [_c('text', {
    staticClass: "fz26fff fz45",
    style: ({
      fontFamily: 'iconfont'
    })
  }, [_vm._v("")]), _vm._v(" "), _c('text', {
    staticClass: "fz26fff ml10"
  }, [_vm._v("私信")])]), _vm._v(" "), (!_vm.isUser || _vm.isManager) ? _c('div', {
    staticClass: "bottomBtnBox"
  }, [_c('div', {
    staticClass: "boder-right bottomBR"
  }), _vm._v(" "), (_vm.isGag) ? _c('div', {
    staticClass: "bottomBtnBox",
    style: ({
      height: _vm.bottomNum + 100
    }),
    on: {
      "click": function($event) {
        _vm.toGag()
      }
    }
  }, [_c('text', {
    staticClass: "fz26fff fz45",
    style: ({
      fontFamily: 'iconfont'
    })
  }, [_vm._v("")]), _vm._v(" "), _c('text', {
    staticClass: "fz26fff ml10"
  }, [_vm._v("禁言")])]) : _c('div', {
    staticClass: "bottomBtnBox",
    style: ({
      height: _vm.bottomNum + 100
    }),
    on: {
      "click": function($event) {
        _vm.toGag()
      }
    }
  }, [_c('text', {
    staticClass: "fz26fff fz45 ",
    style: ({
      fontFamily: 'iconfont'
    })
  }, [_vm._v("")]), _vm._v(" "), _c('text', {
    staticClass: "fz26fff ml10 "
  }, [_vm._v("已禁言")])])]) : _vm._e()])], 1)
},staticRenderFns: []}
module.exports.render._withStripped = true
if (false) {
  module.hot.accept()
  if (module.hot.data) {
     require("vue-loader/node_modules/vue-hot-reload-api").rerender("data-v-9278264c", module.exports)
  }
}

/***/ }),

/***/ 8:
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(0)();
// imports


// module
exports.push([module.i, "\n.cb[data-v-019a21a0] {\n    border-bottom-width: 0px;\n}\n.navRightBox[data-v-019a21a0]{\n    min-width: 92px;\n    height: 92px;\n    align-items: center;\n    justify-content: center;\n}\n.nav_bg[data-v-019a21a0] {\n    width:750px;\n    height: 156px;\n    background-size: cover;\n    position: absolute;\n    top:0;\n}\n.nav_ico[data-v-019a21a0] {\n    font-size: 38px;\n    color: #fff;\n    margin-top: 2px;\n}\n.nav_CompleteIcon[data-v-019a21a0]{\n    /*如果nav_ico的字体大小改变这个值也需要变。 （左边box宽度-back图标宽度)/2 */\n    padding-left: 27px;\n    padding-right: 27px;\n    /*ios识别不出该字体，warn警告。  推测可能隐藏到字体图标的渲染*/\n    /*font-family: Verdana, Geneva, sans-serif;*/\n    font-size: 44px;\n    line-height: 44px;\n    color: #FFFFFF;\n}\n.nav_Complete[data-v-019a21a0] {\n    padding-left: 27px;\n    padding-right: 27px;\n    /*ios识别不出该字体，warn警告。  推测可能隐藏到字体图标的渲染*/\n    /*font-family: Verdana, Geneva, sans-serif;*/\n}\n\n", ""]);

// exports


/***/ }),

/***/ 9:
/***/ (function(module, exports, __webpack_require__) {


/* styles */
__webpack_require__(11)
__webpack_require__(12)

var Component = __webpack_require__(3)(
  /* script */
  __webpack_require__(6),
  /* template */
  __webpack_require__(10),
  /* scopeId */
  "data-v-019a21a0",
  /* cssModules */
  null
)
Component.options.__file = "/Users/zhangsr/Documents/GitHub/weex/mp/src/include/navbar.vue"
if (Component.esModule && Object.keys(Component.esModule).some(function (key) {return key !== "default" && key !== "__esModule"})) {console.error("named exports are not supported in *.vue files.")}
if (Component.options.functional) {console.error("[vue-loader] navbar.vue: functional components are not supported with templates, they should use render functions.")}

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-loader/node_modules/vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-019a21a0", Component.options)
  } else {
    hotAPI.reload("data-v-019a21a0", Component.options)
  }
})()}

module.exports = Component.exports


/***/ }),

/***/ 936:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(633);
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var update = __webpack_require__(1)("fa9e74de", content, false);
// Hot Module Replacement
if(false) {
 // When the styles change, update the <style> tags
 if(!content.locals) {
   module.hot.accept("!!../../node_modules/_css-loader@0.26.4@css-loader/index.js!../../node_modules/_vue-loader@10.3.0@vue-loader/lib/style-rewriter.js?id=data-v-9278264c!../../node_modules/less-loader/dist/cjs.js!./wx.less", function() {
     var newContent = require("!!../../node_modules/_css-loader@0.26.4@css-loader/index.js!../../node_modules/_vue-loader@10.3.0@vue-loader/lib/style-rewriter.js?id=data-v-9278264c!../../node_modules/less-loader/dist/cjs.js!./wx.less");
     if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
     update(newContent);
   });
 }
 // When the module is disposed, remove the <style> tags
 module.hot.dispose(function() { update(); });
}

/***/ }),

/***/ 937:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(634);
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var update = __webpack_require__(1)("bd822806", content, false);
// Hot Module Replacement
if(false) {
 // When the styles change, update the <style> tags
 if(!content.locals) {
   module.hot.accept("!!../../../node_modules/_css-loader@0.26.4@css-loader/index.js!../../../node_modules/_vue-loader@10.3.0@vue-loader/lib/style-rewriter.js?id=data-v-9278264c&scoped=true!../../../node_modules/_vue-loader@10.3.0@vue-loader/lib/selector.js?type=styles&index=1!./host.vue", function() {
     var newContent = require("!!../../../node_modules/_css-loader@0.26.4@css-loader/index.js!../../../node_modules/_vue-loader@10.3.0@vue-loader/lib/style-rewriter.js?id=data-v-9278264c&scoped=true!../../../node_modules/_vue-loader@10.3.0@vue-loader/lib/selector.js?type=styles&index=1!./host.vue");
     if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
     update(newContent);
   });
 }
 // When the module is disposed, remove the <style> tags
 module.hot.dispose(function() { update(); });
}

/***/ })

/******/ });